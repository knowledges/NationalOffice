<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false">
    <el-form :model="dialogObj.data.form"  label-width="80px" ref="query">
      <el-row>
        <el-col :gutter="16">
          <el-col :span='8'>
            <el-form-item prop="customerGrade"  label="客户档级" >
              <el-select v-model="dialogObj.data.form.customerGrade" multiple :clearable="true" placeholder="请选择">
                <el-option
                  v-for="item in options_customerGrade"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <div class="block">
              <el-form-item prop="geoType" label="市场类型">
                <el-select v-model="dialogObj.data.form.geoType" multiple :clearable="true" placeholder="请选择">
                  <el-option
                    v-for="item in options_geoType"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </div>
          </el-col>
          <el-col :span='8'>
            <div class="block">
              <el-form-item prop="businessType" label="零售业态">
                <el-select v-model="dialogObj.data.form.businessType" multiple :clearable="true" placeholder="请选择">
                  <el-option
                    v-for="item in options_businessType"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </div>
          </el-col>
        </el-col>
      </el-row>
      <el-row>
        <el-col :gutter="18">
          <el-col :span='8'>
            <el-form-item prop="operationScale" label="经营规模" >
              <el-select v-model="dialogObj.data.form.operationScale" multiple :clearable="true" placeholder="请选择">
                <el-option
                  v-for="item in options_operationScale"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <div class="block">
              <el-form-item label="客户集">
                <el-select v-model="dialogObj.data.form.rtlcatId" multiple  :clearable="true"  placeholder="请选择客户集">
                  <template v-for="item in rtlcatIdGroup">
                    <el-option
                      :key="item.rowId"
                      :label="item.name"
                      :value="item.rowId">
                    </el-option>
                  </template>
                </el-select>
              </el-form-item>
            </div>
          </el-col>
          <el-col :span='8'>
            <el-form-item label="客户经理">
              <el-select v-model="dialogObj.data.form.custmgrId" class="input_width" multiple :clearable="true" placeholder="请选择" :disabled="custmgrDisable">
                <el-option
                  v-for="item in options_custmgrId"
                  :key="item.rowId"
                  :label="item.employeeName"
                  :value="item.rowId">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
      <el-row>
        <el-col :gutter="24">
          <el-col :span='24'>
            <el-form-item style="float: right">
              <el-button @click="resetForm('addForm')">取 消</el-button>
              <el-button type="success" @click="submitForm('query')">确 定</el-button>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
    </el-form>
  </el-dialog>
</template>
      <script>
        import {getUser, getCodeList} from '@/config/info'
//        import {dateFormat} from '@/utils/dateFormat.js'
        import BasePath from '@/config/BasePath'
        import api from '@/api'
        import axios from 'axios'
        export default {
          props: ['dialogObj'],
          mounted () {
            getCodeList('YC_GEO_TYPE', (data) => {
              this.options_geoType = data
            }) // 市场类型
            getCodeList('YC_BUSINESS_TYPE', (data) => {
              this.options_businessType = data
            }) // 零售业态
            getCodeList('YC_OPERATION_SCALE', (data) => {
              this.options_operationScale = data
            }) // 经营规模
            getCodeList('CUSTOMER_GRADE', (data) => {
              this.options_customerGrade = data
            }) // 客户级别
            getCodeList('YC_CUST_STATUS', (data) => {
              this.options_stauts = data
            }) // 客户状态
            let rtlcatIdparams = {}
            rtlcatIdparams.parentId = getUser().personId
            axios.all([
              api.requestJava('POST', BasePath.SELECT_RTLCATIDGROUP, rtlcatIdparams)
            ])
              .then(axios.spread((_rtlcatId) => {
                this.rtlcatIdGroup = JSON.parse(JSON.stringify(_rtlcatId.data.data))
              })) // 客户集
            let _this = this
            let custMgrParam = {}
            custMgrParam.place = 135
            custMgrParam.county_dept = getUser().companyId
            custMgrParam.fields = {include: 'employeeName,rowId'}
            custMgrParam.status = 1
            axios.all([
              api.requestJava('POST', BasePath.EMPLOYEE_SELECT, custMgrParam) // 市场经理
            ])
              .then(axios.spread(function (_custmgrId) {
                _this.options_custmgrId = JSON.parse(JSON.stringify(_custmgrId.data.data))
              })) // 客户经理
          },
          data () {
            return {
              custmgrDisable: false,
              rtlcatIdGroup: [], // 客户集id
              options_customerGrade: [],
              options_operationScale: [],
              options_businessType: [],
              options_geoType: [],
              options_stauts: [],
              options_custmgrId: []
            }
          },
          methods: {
            clearMethod () {
              this.dialogObj.data.form.customerGrade = ''
              this.dialogObj.data.form.geoType = ''
              this.dialogObj.data.form.businessType = ''
              this.dialogObj.data.form.operationScale = ''
              this.dialogObj.data.form.rtlcatId = ''
              this.dialogObj.data.form.custmgrId = ''
            },
            resetForm (formName) {
              this.dialogObj.dialogVisible = false
              this.clearMethod()
            },
            submitForm (formName) {
              this.$refs[formName].validate((valid) => {
                if (valid) {
                  this.dialogObj.dialogVisible = false
                  this.$emit('confirmBack', this.dialogObj)
                } else {
                  return false
                }
              })
            }
          }
        }
      </script>

      <style scoped>
        .item__label_popup {
          text-align: right;
          vertical-align: middle;
          float: right;
          font-size: 14px;
          color: #48576a;
          line-height: 1;
          padding: 11px 8px 11px 0;
          box-sizing: border-box;
          /* display: inline-block; */
        }
        .el-input, .el-input__inner {
          /*width: '';*/
          display: inline-block;
        }
      </style>
