import log from '@/log'

export default {
  TOGGLE_LOADING (state) {
    state.callingAPI = !state.callingAPI
  },
  TOGGLE_SEARCHING (state) {
    state.searching = (state.searching === '') ? 'loading' : ''
  },
  SET_USER (state, user) {
    state.user = user
  },
  SET_TOKEN (state, token) {
    state.token = token
  },
  LOGIN_DO_SUCCESS (state, response) {
    localStorage.setItem('information', JSON.stringify(response.data))
    // console.log('LOGIN_DO_SUCCESS', response.data)
    state.userInfo = response.data
  },
  COMPANY_SUCCESS (state, reponse) {
    state.company = reponse.data
  },
  DEPARMENT_SUCCESS (state, reponse) {
    state.deparment = reponse.data
  },
  POWER_TREE_SUCCESS (state, reponse) {
    state.powerMenu = reponse.data
  },
  LOCAL_POWER_TREE_SUCCESS (state, reponse) {
    state.localPowerMenu = reponse.data
  },
  CALL_BACK_ERROR (state, err) {
    state.errorMessage = err.message
    log.work(err, err.culprit)
  },
  SET_LOADING (state, obj) {
    let data = JSON.parse(obj)
    state.isLoading.status = data.status
    if (data.msg !== undefined) {
      state.isLoading.msg = data.msg
    }
  },
  SET_SESSIONMENUS (state, str) {
    state.sessionMenus = str
  },
  SET_ROUTERIDX (state, idx) {
    sessionStorage.setItem('routingIndex', idx)
    state.routeIdx = idx
  }
}
