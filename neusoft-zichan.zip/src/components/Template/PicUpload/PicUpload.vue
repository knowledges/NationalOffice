<template>
  <div>
    <div class="vue-uploader">
        <div class="file-list">
            <section v-for="(file, index) of uploadFiles" class="file-item draggable-item">
                <div v-if="file.isImg">
                  <img :src="file.src" alt="" ondragstart="return false;" @click="open(file, 'img')">
                </div>
                <div v-else align="center">
                  <div v-if="file.fileExtension == 'mp4'" class="file-type mp4"  @click="open(file, file.fileExtension)"></div>
                  <div v-if="file.fileExtension == 'apk'" class="file-type apk"  @click="open(file, file.fileExtension)">
                    <a :href="file.src" style="display: inline-block;width: 100%;height: 100%;opacity: 0;
    filter:alpha(Opacity=0)">下载</a>
                  </div>
                  <div v-if="file.fileExtension == 'doc' || file.fileExtension == 'docx'" class="file-type word"  @click="open(file, file.fileExtension)">
                    <a :href="file.src" style="display: inline-block;width: 100%;height: 100%;opacity: 0;
    filter:alpha(Opacity=0)">下载</a>
                  </div>
                  <div v-if="file.fileExtension == 'ppt' || file.fileExtension == 'pptx'" class="file-type ppt"  @click="open(file, file.fileExtension)">
                    <a :href="file.src" style="display: inline-block;width: 100%;height: 100%;opacity: 0;
    filter:alpha(Opacity=0)">下载</a>
                  </div>
                  <div v-if="file.fileExtension == 'xls' || file.fileExtension == 'xlsx'" class="file-type xls"  @click="open(file, file.fileExtension)">
                    <a :href="file.src" style="display: inline-block;width: 100%;height: 100%;opacity: 0;
    filter:alpha(Opacity=0)">下载</a>
                  </div>
                  <div v-else-if="file.fileExtension == 'zip' || file.fileExtension == 'rar'" class="file-type zip">
                    <a :href="file.src" style="display: inline-block;width: 100%;height: 100%;opacity: 0;
    filter:alpha(Opacity=0)">下载</a>
                  </div>
                  <div v-else-if="file.fileExtension == 'pdf'" class="file-type pdf">
                    <a :href="file.src" style="display: inline-block;width: 100%;height: 100%;opacity: 0;
    filter:alpha(Opacity=0)">下载</a>
                  </div>
                  <div v-else-if="file.fileExtension == 'txt'" class="file-type txt">
                    <a :href="file.src" style="display: inline-block;width: 100%;height: 100%;opacity: 0;
    filter:alpha(Opacity=0)">下载</a>
                  </div>
                </div>
                <!--<div v-else align="center" class="file-type">{{file.fileExtension}}文件</div>-->
                <!--<p class="file-name">{{file.fileName}}</p>-->
                <span class="file-remove" @click="remove(index)">+</span>
            </section>
            <section v-if="status == 'ready' && operation" class="file-item">
                <div v-if="operation" @click="add" class="add">
                    <span>+</span>
                </div>
            </section>
        </div>
        <input type="file" accept="*" @change="fileChanged" ref="file" multiple="multiple">
    </div>
  <el-dialog title="预览" :visible.sync="dialogTableVisible" size="large" :modal=false>
    <img v-if="itype == 'img'" :src="iurl" width="100%" alt="" />
    <video v-if="itype == 'mp4'" :src="iurl"  width="100%" height="400px" controls="controls">
  </video>
  </el-dialog>
  </div>
</template>

<script>
    import config from '@/config'
//    const uploadArr = ['apk', 'zip', 'ppt', 'pptx', 'doc', 'docx', 'xls', 'xlsx', 'txt', 'dat', 'log', 'tmp', 'html']
    export default {
      props: {
        src: {
          type: String,
          required: false
        },
        files: {
          type: Array,
          required: false,
          default: []
        },
        operation: {
          type: Boolean,
          default: true
        }
      },
      watch: {
        files (oldValue, newValue) {
          this.uploadFiles = []
          for (var i = 0; i < oldValue.length; i++) {
            const fileItem = oldValue[i]
            var fileExtension = fileItem.fileName.lastIndexOf('.') > -1 ? fileItem.fileName.substring(fileItem.fileName.lastIndexOf('.') + 1) : '未知类型'
            var isImg = this.imgExtension.indexOf(fileExtension.toUpperCase()) > -1
            this.$set(fileItem, 'fileExtension', fileExtension)
            this.$set(fileItem, 'isImg', isImg)
            this.$set(fileItem, 'src', config.FILE_ADDR + fileItem.fileData)
          }
          this.uploadFiles = this.uploadFiles.concat(oldValue)
//          console.log(this.uploadFiles)
        }
      },
      data () {
        return {
          imgExtension: 'PNG|JPEG|JPG|BMP|GIF',
          uploadArr: ['apk', 'zip', 'ppt', 'pptx', 'doc', 'docx', 'xls', 'xlsx', 'txt', 'dat', 'log', 'tmp', 'html'],
          status: 'ready',
          point: {},
          uploadFiles: [],
          uploading: false,
          iurl: '',
          itype: '',
          dialogTableVisible: false,
          percent: 0
        }
      },
      mounted () {
        this.$nextTick(() => {
          this.uploadFiles = []
          for (var i = 0; i < this.files.length; i++) {
            const fileItem = this.files[i]
            var fileExtension = fileItem.fileName.lastIndexOf('.') > -1 ? fileItem.fileName.substring(fileItem.fileName.lastIndexOf('.') + 1) : '未知类型'
            var isImg = this.imgExtension.indexOf(fileExtension.toUpperCase()) > -1
            this.$set(fileItem, 'fileExtension', fileExtension)
            this.$set(fileItem, 'isImg', isImg)
            this.$set(fileItem, 'src', config.FILE_ADDR + fileItem.fileData)
            console.log('src:', config.FILE_ADDR + fileItem.fileData)
          }
          this.uploadFiles = this.uploadFiles.concat(this.files)
//          console.log(this.uploadFiles)
        })
      },
      methods: {
        mediaInit () {

        },
        open (file, type) {
          console.log(file, type)
          this.iurl = file.src
          this.itype = type
          this.dialogTableVisible = true
        },
        add () {
          this.$refs.file.click()
        },
        getFiles () {
          return this.uploadFiles
        },
        submit () {
          if (this.files.length === 0) {
            console.warn('no file!')
            return
          }
          const formData = new FormData()
          this.files.forEach((item) => {
            formData.append(item.name, item.file)
          })
          const xhr = new XMLHttpRequest()
          xhr.upload.addEventListener('progress', this.uploadProgress, false)
          xhr.open('POST', this.src, true)
          this.uploading = true
          xhr.send(formData)
          xhr.onload = () => {
            this.uploading = false
            if (xhr.status === 200 || xhr.status === 304) {
              this.status = 'finished'
//              console.log('upload success!')
            } else {
//              console.log(`error：error code ${xhr.status}`)
            }
          }
        },
        finished () {
          this.uploadFiles = []
          this.status = 'ready'
        },
        remove (index) {
          this.uploadFiles.splice(index, 1)
        },
        fileChanged () {
          const list = this.$refs.file.files
          for (let i = 0; i < list.length; i++) {
            if (!this.isContain(list[i])) {
              var fileExtension = list[i].name.lastIndexOf('.') > -1 ? list[i].name.substring(list[i].name.lastIndexOf('.') + 1) : '未知类型'
              var isImg = this.imgExtension.indexOf(fileExtension.toUpperCase()) > -1
              const item = {
                fileName: list[i].name,
                fileSize: list[i].size,
                fileExtension: fileExtension,
                isImg: isImg,
                file: list[i]
              }
              this.html5Reader(list[i], item)
              this.uploadFiles.push(item)
            }
          }
          this.$refs.file.value = ''
        },
            // 将图片文件转成BASE64格式
        html5Reader (file, item) {
          const reader = new FileReader()
          reader.onload = (e) => {
            var base64Arr = e.target.result.split(',')
            this.$set(item, 'src', e.target.result)
            this.$set(item, 'fileData', base64Arr[1])
          }
          reader.readAsDataURL(file)
        },
        isContain (file) {
          this.uploadFiles.forEach((item) => {
            if (item.name === file.name && item.size === file.size) {
              return true
            }
          })
          return false
        },
        uploadProgress (evt) {
          const component = this
          if (evt.lengthComputable) {
            const percentComplete = Math.round((evt.loaded * 100) / evt.total)
            component.percent = percentComplete / 100
          } else {
            console.warn('upload progress unable to compute')
          }
        }
      }
    }
</script>
<style>
.vue-uploader {
    border: 1px solid #e5e5e5;
}
.vue-uploader .file-list {
    padding: 10px 0px;
}
.vue-uploader .file-list:after {
    content: '';
    display: block;
    clear: both;
    visibility: hidden;
    line-height: 0;
    height: 0;
    font-size: 0;
}
.vue-uploader .file-list .file-item {
    float: left;
    position: relative;
    width: 100px;
    text-align: center;
}
.vue-uploader .file-list .file-item img{
    width: 80px;
    height: 80px;
    border: 1px solid #ececec;
}
.vue-uploader .file-list .file-item .file-remove {
    position: absolute;
    right: 12px;
    display: none;
    top: 4px;
    width: 14px;
    height: 14px;
    color: white;
    cursor: pointer;
    line-height: 12px;
    border-radius: 100%;
    transform: rotate(45deg);
    background: rgba(0, 0, 0, 0.5);
}
.vue-uploader .file-list .file-item:hover .file-remove {
    display: inline;
}
.vue-uploader .file-list .file-item .file-type {
  width: 90px;
  height: 80px;
  line-height: 80px;
  font-size: 14px;
  cursor: pointer;
}
.vue-uploader .file-list .file-item .file-name {
    margin: 0;
    align: center;
    height: 50px;
    width: 80px;
    word-break: break-all;
    font-size: 14px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}
.vue-uploader .add {
    width: 80px;
    height: 80px;
    margin-left: 10px;
    float: left;
    text-align: center;
    line-height: 80px;
    border: 1px dashed #ececec;
    font-size: 30px;
    cursor: pointer;
}
.vue-uploader .upload-func {
    display: flex;
    padding: 10px;
    margin: 0px;
    background: #f8f8f8;
    border-top: 1px solid #ececec;
}
.vue-uploader .upload-func .progress-bar {
    flex-grow: 1;
}
.vue-uploader .upload-func .progress-bar section {
    margin-top: 5px;
    background: #00b4aa;
    border-radius: 3px;
    text-align: center;
    color: #fff;
    font-size: 12px;
    transition: all .5s ease;
}
.vue-uploader .upload-func .operation-box {
    flex-grow: 0;
    padding-left: 10px;
}
.vue-uploader .upload-func .operation-box button {
    padding: 4px 12px;
    color: #fff;
    background: #007ACC;
    border: none;
    border-radius: 2px;
    cursor: pointer;
}
.vue-uploader > input[type="file"] {
    display: none;
}
.mp4 {
  background-image: url('./img/media.png');
  background-size: 100% 100%;
  background-repeat: no-repeat;
}
.apk {
  background-image: url('./img/apk.png');
  background-size: cover;
  background-repeat: no-repeat;
}
.word {
  background-image: url('./img/word.png');
  background-size: 100% 100%;
  background-repeat: no-repeat;
}
.ppt {
  background-image: url('./img/ppt.png');
  background-size: 100% 100%;
  background-repeat: no-repeat;
}
.zip {
  background-image: url('./img/zip.png');
  background-size: 100% 100%;
  background-repeat: no-repeat;
}
.xls {
  background-image: url('./img/xls.png');
  background-size: 100% 100%;
  background-repeat: no-repeat;
}
.pdf {
  background-image: url(require('./img/pdf.png'));
  background-size: 100% 100%;
  background-repeat: no-repeat;
}
.txt {
  background-image: url(require('./img/txt.png'));
  background-size: 100% 100%;
  background-repeat: no-repeat;
}
.preview {
  position: absolute;
  top:0;
  left: 0;
  opacity: 0;
  filter: alpha(Opacity=0);
  display: inline-block;
  width: 100%;
  height: 100%;
  background: rebeccapurple;
}
</style>
