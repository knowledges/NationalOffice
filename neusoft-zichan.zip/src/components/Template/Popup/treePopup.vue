<template>
  <el-dialog :title="dialogObj.title" :visible.sync="$parent.treedialogVisible" :close-on-click-modal="false"  @close="resetForm('form')">
      <_TREE :search=searchable :data='treeData'  :nodeKey="nodeKey"
                     :showCheckBox=showCheckBox :expandAll=expandAll ref='tree' :highlight='true'
                     :defaultCheckedKeys=defaultCheckedKeys  :check-change="handleCheckChange"></_TREE>

    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="resetForm('form')">取 消</el-button>
      <el-button type="primary" @click="submitForm('form')">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
import _TREE from '@/components/Template/Tree/Tree.vue'
import api from '@/api'
import log from '@/log'
import { mapState } from 'vuex'
export default {
  props: ['dialogObj', 'treedialogVisible'],
  data () {
    return {
      msg: '某某市烟草公司',
      nodeKey: 'id',
      defaultCheckedKeys: [],
      searchable: true, // 是否带搜索框
      showCheckBox: true, // 是否带复选框
      expandAll: true, // 是否展开所有节点
      treeData: [],
      dialogVisible: false,
      changeArr: [],
      tempChangeArr: []
    }
  },
  methods: {
    //  组织机构树初始化
    treeInit () {
      console.log('url:' + this.dialogObj.getDataObj.url)
      console.log('params:' + JSON.stringify(this.dialogObj.getDataObj.params))
      api.requestJava('POST', this.dialogObj.getDataObj.url, this.dialogObj.getDataObj.params)
        .then((request) => {
          if (Number(request.data.code) === 200) {
            this.treeData = this.mapfuc(request.data.data.children)
            console.log('defaultCheckedKeys' + JSON.stringify(this.defaultCheckedKeys))
          } else if (Number(request.data.code) === 401) {
            this.$message('登录失效')
          } else {
            this.$notify.error({title: '提示', message: request.data.message})
            throw new Error(JSON.stringify(request))
          }
        })
        .catch((err) => {
          let culprit = this.$route.name
            // this.toggleLoading()
          log.work(err, culprit)
        })
    },
    handleCheckChange (data, checked, indeterminate) {
      let _this = this
      if (checked) {
        let obj = {}
        obj.roleId = _this.dialogObj.getDataObj.params.originApp
        obj.resId = data.id
        this.tempChangeArr.push(obj)
      } else {
        this.defaultCheckedKeys.forEach(function (item, index) {
          if (Number(item) === Number(data.id)) {
            _this.defaultCheckedKeys.splice(index, 1)
          }
        })
      }
    },
    mapfuc (arr) {
      arr.forEach((val, key) => {
        if (val.children.length > 0) {
          this.mapfuc(val.children)
        }
        if (val.originFlag === 'Y' && val.children.length <= 0) {
          this.defaultCheckedKeys.push(val.id)
        }
        if (this.dialogObj.getDataObj.params.hasOwnProperty('roleId')) {
          val.roleId = this.dialogObj.getDataObj.params.roleId
        }
        if (this.dialogObj.type === 'role') {
          val.createdBy = ''
        }
        val.changeflag = false
      })
      return arr
    },
    resetForm (formName) {
      this.treeData = []
      this.$parent.treedialogVisible = false
    },
    submitForm (formName) {
      let _this = this
      if (this.defaultCheckedKeys.length > 0) { // 将默认的选项合并到新的选项数组中去
        this.defaultCheckedKeys.forEach(function (item, index) {
          console.log('item' + item)
          let defaultObj = {}
          defaultObj.roleId = _this.dialogObj.getDataObj.params.originApp
          defaultObj.resId = item
          _this.tempChangeArr.push(defaultObj)
        })
      }
      if (this.tempChangeArr.length === 0) { // 如果为空 则传roleId 后台全部
        let emptyObj = {}
        emptyObj.roleId = this.dialogObj.getDataObj.params.originApp
        this.tempChangeArr.push(emptyObj)
      }
      console.log('合并以后：' + JSON.stringify(this.tempChangeArr))
      api.requestJava('POST', this.dialogObj.conmitObj.url, this.tempChangeArr)
        .then((request) => {
          if (Number(request.data.code) === 200) {
            this.$message({ type: 'success', message: '保存成功!' })
          } else if (Number(request.data.code) === 401) {
            this.$message('登录失效')
          } else {
            this.$notify.error({title: '提示', message: request.result.message})
            throw new Error(JSON.stringify(request))
          }
        })
        .catch((err) => {
          let culprit = this.$route.name
          log.work(err, culprit)
        })
      this.tempChangeArr = []
      this.$parent.treedialogVisible = false
    },
    clearObj () {
      this.tempChangeArr = []
    }
  },
  mounted () {
    this.clearObj()
    // this.treeInit()
    // this.roletreeInit()
    // this.treeData = this.mapfuc(this.treeData)
    // this.dialogVisible = this.dialogObj.dialogVisible
  },
  watch: {
    treedialogVisible (newv, old) {
      if (newv) {
        this.defaultCheckedKeys = []
        this.treeInit()
      }
      // this.treedialogVisible = newv
    }
  },
  computed: {
    ...mapState([
      'tree'
    ])
  },
  components: {
    _TREE
  }
}
</script>
<style scoped>
.item__label_popup {
    text-align: right;
    vertical-align: middle;
    float: right;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 8px 11px 0;
    box-sizing: border-box;
    /* display: inline-block; */
}
.el-input, .el-input__inner {
    /*width: '';*/
    display: inline-block;
}
</style>
