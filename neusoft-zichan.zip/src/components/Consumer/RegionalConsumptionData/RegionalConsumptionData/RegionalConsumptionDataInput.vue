<style scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-24 {
    height: 36px;
  }
</style>
<template>
  <div  class="container-fluid">
      <el-row class="filter_style">
        <el-col :gutter="24">
          <el-col :span='12'>
            <div v-if="isSelect">
              <el-form ref="searchForm" :model="searchForm" label-width="120px">
                <el-col :gutter="24">
                  <el-col :span='24'>
                    <el-form-item label="收集日期">
                      <el-date-picker
                        v-model="searchForm.clDateL"
                        type="date"
                        format="yyyy-MM-dd"
                        placeholder="选择日期">
                      </el-date-picker> --
                      <el-date-picker
                        v-model="searchForm.clDateR"
                        type="date"
                        format="yyyy-MM-dd"
                        placeholder="选择日期">
                      </el-date-picker>
                    </el-form-item>
                  </el-col>
                </el-col>
              </el-form>
            </div>
          </el-col>
          <el-col :span="12">
            <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" :tableData="tableData" @on-click="exportEve" :isMore="isMore"></_BTN_FILTER>
          </el-col>
        </el-col>
      </el-row>
      <div>
        <tableVue
        ref="tableGrid"
        stripe
        maxHeight="500"
        @update:data="tabChange" :reqParams="reqParams"
        :data="dataSource"
        :columns="columns"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData></tableVue>
        <_POPUP :dialogObj='dialogObj' @confirmBack="confirmBack" v-popupdra-directive="{'show': dialogObj.dialogVisible}"/>
      </div>
  </div>
</template>
<script>
  import tableVue from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import _POPUP from './Popup.vue'
  import {getUser} from '@/config/info'
  import {dateFormat} from '@/utils/dateFormat.js'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import log from '@/log'
  export default {
    mounted () {
      this.init()
    },
    data () {
      return {
        queryParams: {},
//        custmgrDisable: false,
        isSelect: true,
        isMore: true, // 查询更多条件
        searchForm: {
          clDateL: new Date(),
          clDateR: new Date(),
          custmgrId: ''
        },
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['areaAddr', 'events', 'flowrateChg', 'populationChg'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '新增', // 按钮名称
            className: 'btn-info', // 按钮样式名称
            iconName: 'fa-plus', // 按钮图标名称
            event: this.addClk // 按钮事件方法名称；可以自定义
          },
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        /** 弹出层 **/
        dialogObj: {
          title: '筛选条件',
          type: 'query',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              rowId: '',
              sno: '',
              areaAddr: '',
              customerNbr: 0,
              events: '',
              infoSrc: '',
              clDate: new Date(),
              flowrateChg: '',
              populationChg: '',
              priceSegment: '',
              brands: '',
              priceSegmentl: [],
              brandsl: [],
              advise: ''
            }
          }
        },
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        selectSells: [],
        totalCount: 0, // 表格总记录数
        hasPagination: true, // 是否有分页
        columns: [ // 表格列
          { label: '序号', prop: 'sno', columnsProps: {width: 100} },
          { label: '区域地址', prop: 'areaAddr', columnsProps: {width: 200} },
          { label: '收集日期', prop: 'clDate', columnsProps: {width: 200} },
          { label: '区域客户总数', prop: 'customerNbr', columnsProps: {width: 200} },
          { label: '区域变化事件', prop: 'events', columnsProps: {width: 200} },
          { label: '整体人流量变化', prop: 'flowrateChg', columnsProps: {width: 200} },
          { label: '卷烟消费人口变化', prop: 'populationChg', columnsProps: {width: 200} },
          { label: '操作', prop: 'operation', columnsProps: {width: 300, type: 'button', textAlign: 'center'}, cptProperties: [{ label: '修改', icon: 'edit', value: 'modify', type: 'success', size: 'small', eventClick: this.modify }, { label: '删除', icon: 'delete', value: 'del', type: 'danger', size: 'small', eventClick: this.del }, { label: '预览', icon: 'search', value: 'look', type: 'success', size: 'small', eventClick: this.search }] }
        ],
        tableData: [],
        tableType: '4',
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        sessionFailedDialogObj: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        }
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      isMoreClk () {
//        this.isSelect = !this.isSelect
        this.dialogObj.dialogVisible = true
      },
      init () {
        let param = {}
        param.companyId = getUser().companyId
        param.clDateL = this.getTime(Date.parse(this.searchForm.clDateL))
        param.clDateR = this.getTime(Date.parse(this.searchForm.clDateR))
        param.sorter = 'sno asc'
        console.log('param:' + JSON.stringify(param))
        this.reqParams.url = BasePath.AREARTINFO_SELECT
        this.reqParams.params = param
        api.requestJava('POST', BasePath.AREARTINFO_SELECT, param, {})
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.dataSource = request.data.data
              this.tableData = request.data.data
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      headerClick () {},
      sortChange (msg) {},
      rowClick (msg) {},
      modify (index, row) {
        this.dialogObj.data.form.disabled = false
        Object.assign(this.dialogObj.data.form, row)
        this.dialogObj.data.form.brandsl = row.brands.split(',')
        this.dialogObj.data.form.priceSegmentl = row.priceSegment.split(',')
        this.dialogObj.dialogVisible = true
      }, // 修改
      search (index, row) {
        this.dialogObj.data.form.disabled = true
        Object.assign(this.dialogObj.data.form, row)
        this.dialogObj.data.form.brandsl = row.brands.split(',')
        this.dialogObj.data.form.priceSegmentl = row.priceSegment.split(',')
        this.dialogObj.dialogVisible = true
      }, // 查看
      sessionFailedBack (msg) {
        let headers = msg.data.form
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.sessionFailedDialogObj.dialogVisible = false
            }
          })
          .catch((err) => { console.log(err) })
      }, // 会话失效
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      confirmBack (msg) {
        if (msg) {
          if (msg.data.form.rowId === '') {
            this.queryExit()
          } else {
            this._upload_submit()
          }
        } else {
          this.clearObject()
        }
      },
      queryExit () {
        let params = {}
//        params.sno = this.dialogObj.data.form.sno
        api.requestJava('POST', BasePath.AREARTINFO_SELECT, params)
          .then(request => {
            console.log(request.data.data.length)
            if (Number(request.data.code) === 200) {
              this.dialogObj.data.form.sno = request.data.data.length + 1
              this._upload_submit()
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      _upload_submit () {
        let params = this.dialogObj.data.form
        console.log('params', params)
        params.createdBy = getUser().userID
        params.companyId = getUser().companyId
        params.deptId = getUser().deptId
        params.collectorId = getUser().personId
        params.collectorNm = getUser().userName
        params.priceSegment = this.listToString(params.priceSegmentl, 'int')
        params.brands = this.listToString(params.brandsl, 'int')
        console.log('params', params)
        if (params.rowId === '') { // 新建
          api.requestJava('POST', BasePath.AREARTINFO_INSERT, params)
            .then(request => {
              if (Number(request.data.code) === 200) {
                this.$message({ type: 'success', message: '新增成功!' })
                this.init()
              } else {
                this.$notify.error({ title: '提示', message: '新增错误' })
                throw new Error(JSON.stringify(request))
              }
            })
        } else {
          console.log(JSON.stringify(params))
          api.requestJava('POST', BasePath.AREARTINFO_UPDATE, params)
            .then(request => {
              console.log(request.data.code)
              if (Number(request.data.code) === 200) {
                this.$message({ type: 'success', message: '更新成功!' })
                this.init()
              } else {
                this.$notify.error({ title: '提示', message: '更新错误' })
                throw new Error(JSON.stringify(request))
              }
            })
            .catch(err => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        }
      },
      addClk () {
        this.clearObject()
        this.dialogObj.dialogVisible = true
//        this.getBillNo()
      },
      getBillNo () {
        api.requestJava('POST', BasePath.GET_BILLNO, {})
          .then(request => {
            if (Number(request.data.code) === 200) {
              console.log(request.data.data)
              this.dialogObj.data.form.sno = request.data.data
              this.dialogObj.dialogVisible = true
            } else {
              this.$notify.error({ title: '提示', message: '获取单据号接口调用失败！' })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      clearObject () {
        let temp = {
          title: '区域消费数据收集维护',
          type: 'addConfigure',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              sno: '',
              customerNbr: 0,
              events: '',
              infoSrc: '',
              clDate: new Date(),
              flowrateChg: '',
              populationChg: '',
              priceSegment: '',
              brands: '',
              priceSegmentl: [],
              brandsl: [],
              advise: ''
            }
          }
        }
        Object.assign(this.dialogObj, temp)
      },
      del (index, row) {
        let params = {}
        params.rowId = row.rowId
        api.requestJava('POST', BasePath.AREARTINFO_DELETE, params)
          .then(request => {
            console.log(request.data.code)
            if (Number(request.data.code) === 200) {
              this.$message({ type: 'success', message: '删除成功!' })
              this.init()
            } else {
              this.$notify.error({ title: '提示', message: '删除错误' })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      query () {
        this.init()
      },
      listToString (values, type) {
        let result = ''
        for (let i = 0; i < values.length; i++) {
          result = result + values[i] + ','
        }
        if (result.length > 0) {
          result = result.substr(0, result.length - 1)
        }
        return result
      }
    },
    components: {
      tableVue,
      _BTN_FILTER,
      _POPUP
    }
  }
</script>
