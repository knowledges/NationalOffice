<!--徐晓菁  4.8.2	接口二（客户当日订单汇总） 接口未开发  后天调试-->
<template>
  <div>
    <div class="container-fluid_new" style="font-family: 'Helvetica Neue'">
      <el-row :span="24" style="/*max-width: 1325px;*/width: 100%;margin: auto;">
        <el-col :span="4">
          <div class="grid-content bg-purple" @click="custFind()">
            <el-row :span="24">
              <el-col :span="8"><img src="./img/visitingQlan.png" class="img1"></el-col>
              <el-col :span="16"><span class="notice1">{{ visitingQlan }}</span>&nbsp;&nbsp;<span class="notice">户</span></br>
                <span class="notice">合计客户数</span></el-col>
            </el-row>
          </div>
        </el-col>
        <el-col :span="4">
          <div class="grid-content bg-purple"    @click="query()">
            <el-row :span="24">
              <el-col :span="8"><img src="./img/visited.png" class="img1"></el-col>
              <el-col :span="16"><span class="notice1">{{ visited }}</span>&nbsp;&nbsp;<span class="notice">户</span></br>
                <span class="notice">已拜访客户</span></el-col>
            </el-row>
          </div>
        </el-col>
        <el-col :span="4">
          <div class="grid-content bg-purple" @click="noOrderFind()">
            <el-row :span="24">
              <el-col :span="8"><img src="./img/notOrdered.png" class="img1"></el-col>
              <el-col :span="16"><span class="notice1">{{ notOrdered }}</span>&nbsp;&nbsp;<span class="notice">户</span></br>
                <span class="notice">当日未订货</span></el-col>
            </el-row>
          </div>
        </el-col>
        <el-col :span="4">
          <div class="grid-content bg-purple" @click="noDebitFind()">
            <el-row :span="24">
              <el-col :span="8"><img src="./img/nonDebit.png" class="img1"></el-col>
              <el-col :span="16"><span class="notice1">{{ nonDebit }}</span>&nbsp;&nbsp;<span class="notice">户</span></br>
                <span class="notice">当日未扣款</span></el-col>
            </el-row>
          </div>
        </el-col>
        <el-col :span="4">
          <div class="grid-content bg-purple" @click="orderFind()">
            <el-row :span="24">
              <el-col :span="8"><img src="./img/dayOrder.png" class="img1"></el-col>
              <el-col :span="16"><span class="notice1">{{ dayOrder }}</span>&nbsp;&nbsp;<span class="notice">户</span></br>
                <span class="notice">当日订单</span></el-col>
            </el-row>
          </div>
        </el-col>
      </el-row>
      <el-row :span="24">
        <simple-fullcalendar :events="events" @timeRangeSelected="addEvent2Events" @confirmBack="editEve"></simple-fullcalendar>
      </el-row>
    </div>
    <MY_POPUP_NODEBIT :dialogObj='noDebit' @confirmBack="noDebitEve"/>
    <MY_POPUP_NOORDER :dialogObj='noOrder' @confirmBack="noOrderEve"/>
    <MY_POPUP_ORDER :dialogObj='order' @confirmBack="orderEve"/>
  </div>
</template>
<style>
</style>
<script>
  import MY_POPUP_NODEBIT from './noDebitListPopup.vue'
  import MY_POPUP_NOORDER from './noOrderListPopup.vue'
  import MY_POPUP_ORDER from './orderListPopup.vue'
  import {getUser} from '@/config/info'
  import 'echarts/lib/component/toolbox'
  import 'echarts/lib/chart/bar'
  import 'echarts/lib/chart/line'
  import moment from 'moment'
  import api from '@/api'
  import log from '@/log'
  import { dateFormat } from '@/utils/dateFormat.js'
  import simpleFullcalendar from '@/components/Home/ClientManager/simple-fullcalendar'
  import BasePath from '@/config/BasePath'
  const FORMATTER = 'YYYY-MM-DD'
  let TODAY = moment()
  export default {
    name: 'app',
    mounted () {
      this.queryDdTotalUpper()
    },
    components: {
      simpleFullcalendar,
      MY_POPUP_NODEBIT,
      MY_POPUP_ORDER,
      MY_POPUP_NOORDER
    },
    data () {
      return {
        visitingQlan: '0', // 合计户数
        visited: '0', // 已拜访
        notOrdered: '0', // 未订货
        dayOrder: '0', // 当日订货
        nonDebit: '0', // 未付款
        datetime: [new Date().setDate(1), new Date()],
        cache: {},
        event: [],
        events: [],
        noDebit: {
          title: '当日未扣款',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              products: []
            }
          }
        },
        noOrder: {
          title: '当日未订货',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              products: []
            }
          }
        },
        order: {
          title: '当日订单',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              products: []
            }
          }
        },
        today: TODAY.format(FORMATTER)
      }
    },
    methods: {
      query () {
        this.$router.push('Query')
      }, // 新增
      noDebitEve (msg) {
        this.noDebit.dialogVisible = false
        let tmp = {
          title: '当日未扣款',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              products: []
            }
          }
        }
        Object.assign(this.noDebit, tmp)
      }, // 未扣款事件
      noOrderEve (msg) {
        this.noOrder.dialogVisible = false
        let tmp = {
          title: '当日未订货',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              products: []
            }
          }
        }
        Object.assign(this.noOrder, tmp)
      }, // 未订货事件
      orderEve (msg) {
        this.order.dialogVisible = false
        let tmp = {
          title: '当日未订货',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              products: []
            }
          }
        }
        Object.assign(this.order, tmp)
      }, // 当日订单量事件
      noDebitFind () { // 消费者调查  新品测试调查（消费者）
        let param = {}
        var myDate = new Date()
        param.employeecode = getUser().userCode
        param.bornDate = this.getTime(myDate.getTime())
        console.log('noDebitFind', param)
        api.requestJava('POST', BasePath.CLIENTMANAGER_QUERYPAYFAIL, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.noDebit.data.form.products = request.data.data
              this.noDebit.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 未扣款请求
      noOrderFind () { // 消费者调查  新品测试调查（消费者）
        let param = {}
        var myDate = new Date()
        param.employeecode = getUser().userCode
        param.bornDate = this.getTime(myDate.getTime())
        console.log('noOrderFind', param)
        api.requestJava('POST', BasePath.CLIENTMANAGER_NOORDERCUSTS, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.noOrder.data.form.products = request.data.data
              this.noOrder.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 未订货请求
      orderFind () { // 消费者调查  新品测试调查（消费者）
        this.order.dialogVisible = true
//        let param = {}
//        var myDate = new Date()
//        param.employeecode = getUser().userCode
//        param.bornDate = this.getTime(myDate.getTime())
//        console.log('orderFind', param)
//        api.requestJava('POST', BasePath.CLIENTMANAGER_ORDERCUSTS, param)
//          .then((request) => {
//            if (Number(request.data.code) === 200) {
//              this.order.data.form.products = request.data.data
//              this.order.dialogVisible = true
//            } else if (Number(request.data.code) === 401) {
//              this.$message('登录失效')
//              this.logInvalid.dialogVisible = true
//            } else {
//              this.$notify.error({title: '提示', message: request.data.message})
//              throw new Error(JSON.stringify(request))
//            }
//          })
//          .catch((err) => {
//            let culprit = this.$route.name
//            log.work(err, culprit)
//          })
      }, // 当日订单量请求
      editEve (msg) {
        let begin = msg + '-01'
        let date = new Date(Date.parse(begin))
        let next = date.setMonth(date.getMonth() + 1)
        let d = new Date(next)
        let end = d.setDate(d.getDate() - 1)
        this.queryTotalUpper(begin, this.getTime(end))
      }, // 修改事件
      queryTotalUpper (begin, end) {
        let params = {}
        params.custmgrId = getUser().personId
        params.planMonthBegin = begin
        params.planMonthEnd = end
        api.requestJava('POST', BasePath.VISITPLAN_TOTAL, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.visitingQlan = request.data.data.allCusts
              this.visited = request.data.data.visitCusts
              this.queryEventsTotalUpper(request.data.data.allCusts, begin, end)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 拜访查询接口
      queryDdTotalUpper () {
        var myDate = new Date()
        let params = {}
        params.employeecode = getUser().userCode
        params.bornDate = this.getTime(myDate.getTime())
        console.log('params', params)
        api.requestJava('POST', BasePath.CLIENTMANAGER_ORDER_TOTAL, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if ('noOrderCusts' in request.data.data) {
                this.notOrdered = request.data.data.noOrderCusts
              }
              if ('noPayCusts' in request.data.data) {
                this.nonDebit = request.data.data.noPayCusts
              }
              if ('orders' in request.data.data) {
                this.dayOrder = request.data.data.orders
              }
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 订单查询接口
      queryEventsTotalUpper (allCusts, begin, end) {
        let params = {}
        params.custmgrId = getUser().personId
        params.visitBegin = begin
        params.visitEnd = end
        api.requestJava('POST', BasePath.CLIENTMANAGER_CALENDAR, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.event = request.data.data
              let even = []
              for (let i = 0; i < this.event.length; i++) {
                let rowS = {}
                if (Number(allCusts) > 0) {
                  rowS.planRage = (Number(this.event[i].planCusts) * 100 / Number(allCusts)).toFixed(2) + '%'
                } else {
                  rowS.planRage = '0.00%'
                }
                rowS.expectedTime = this.getTime(Date.parse(this.event[i].expectedTime))
                rowS.planCusts = this.event[i].planCusts
                rowS.visitCusts = this.event[i].visitCusts
                even.push(rowS)
              }
              this.events = even
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 订单查询接口
      clearCache () {},
      addEvent2Events (event) {
        this.$router.push({name: 'MapMonitor', params: {uId: getUser().personId, visitDate: event.start, companyId: null, countyDept: null}})
      },
      custFind () { // 打开客户信息
        this.$router.push('Customer')
      },
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      }  // 时间格式化
    }
  }
</script>
<style scoped>
  .img1 {
    border-style: none;
    padding-top: 8px;
    padding-left: 4px;
  }
  .el-col-4 {
    width: 20%;
    height: 75px;
  }
  .el-col-24 {
    height: 46px;
  }
.el-collapse {
    border: none;
    border-radius: 0;
    padding: 10px;
}
.notice{
  color: #0e0808 !important;
  font-size: 15px;
}
  .notice1{
    color: #7e9aeb !important;
    font-size: 20px;
    cursor:pointer;
  }
.bg-purple {
  background-color: #ffffff !important;
  width: 95.5%;
  margin: auto;
}
  .el-row {
    box-sizing: border-box;
    padding-left: 10px;
  }
  .el-col-16 {
    width: 66.66667%;
    padding-left: 20px;
    padding-top: 10px;
  }
  .container-fluid_new {
    background: #fafafa;
    margin: 0 5px 5px 5px;
    padding-top: 50px;
  }
</style>

