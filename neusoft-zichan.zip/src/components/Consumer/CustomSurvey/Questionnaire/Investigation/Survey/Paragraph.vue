<template>
  <li class="li_surveyQuItemBody surveyQu_1">
    <div class="surveyQuItemBody">
      <div class="surveyQuItem">
        <div class="surveyQuItemContent" style="min-height: 35px;">
          <div class="quCoTitle" style="background: rgb(243, 247, 247);">
            <div class="editAble quCoTitleEdit" style="padding-left: 15px;">
              <div v-html="Paragraph.title"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </li>
</template>
<script>
  export default {
    props: ['Paragraph']
  }
</script>
