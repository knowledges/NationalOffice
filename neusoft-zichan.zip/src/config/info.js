import api from '@/api'
import BasePath from '@/config/BasePath'

export function getUser () {
  return JSON.parse(localStorage.getItem('information'))
}

export function getCodeList (typeCode, callback) {
  let dict = JSON.parse(localStorage.getItem('localdict'))
  if (dict !== null && dict !== '{}' && dict !== 'undefined') {
    if (dict[typeCode] == null) {
      api.requestJava('post', BasePath.SELECT_CODELIST_MAPLIST, {'mapKey': 'typeCode', 'fields': {'include': 'codeName,codeValue'}})
        .then(response => {
          if (Number(response.data.code) === 200 || Number(response.data.status) === 200) {
            localStorage.setItem('localdict', JSON.stringify(response.data.data))
            let result = []
            for (let codeList in response.data.data[typeCode]) {
              let temp = {'value': response.data.data[typeCode][codeList].codeValue, 'label': response.data.data[typeCode][codeList].codeName}
              result.push(temp)
            }
            if (typeof callback === 'function') {
              callback(result)
            }
          } else {
            throw new Error(JSON.stringify(response))
          }
        })
    } else {
      let result = []
      for (let codeList in dict[typeCode]) {
        let temp = {'value': dict[typeCode][codeList].codeValue, 'label': dict[typeCode][codeList].codeName}
        result.push(temp)
      }
      if (typeof callback === 'function') {
        callback(result)
      }
    }
  } else {
    api.requestJava('post', BasePath.SELECT_CODELIST_MAPLIST, {'mapKey': 'typeCode', 'fields': {'include': 'codeValue,codeName,typeCode'}}).then(response => {
      if (Number(response.data.code) === 200 || Number(response.data.status) === 200) {
        localStorage.setItem('localdict', JSON.stringify(response.data.data))
        let result = []
        for (let codeList in response.data.data[typeCode]) {
          let temp = {'value': response.data.data[typeCode][codeList].codeValue, 'label': response.data.data[typeCode][codeList].codeName}
          result.push(temp)
        }
        if (typeof callback === 'function') {
          callback(result)
        }
      } else {
        throw new Error(JSON.stringify(response))
      }
    })
  }
}

export function isIE () {
  if (!!window.ActiveXObject || 'ActiveXObject' in window) {
    return true
  } else {
    return false
  }
}
