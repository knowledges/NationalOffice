<!--qiu.bl-->
<!--采集价格趋势分析-->
<style rel="stylesheet/scss" lang="scss" scoped>
  .el-col-24 {
    height: 36px;
  }
</style>
<template>
  <div class="container-fluid"  style="height: 99%">
    <el-row class="filter_style">
      <!--<el-col :gutter="24">-->
      <el-form ref="searchForm" label-width="100px">
        <el-col :gutter="24">
          <el-col :span='6'>
            <el-form-item prop="countyId" label="数据范围">
              <el-cascader
                :clearable="true"
                :disabled="disable"
                :options="options"
                @change="getChangeValue"
                v-model="selected"
                change-on-select
              ></el-cascader>
              <!--<_cascader @on-change="getChangeValue"/>-->
            </el-form-item>
          </el-col>
          <el-col :span='6'>
            <el-form-item prop="products" label="商品选择">
              <el-select v-model="product_id" filterable placeholder="请选择">
                <el-option
                  :clearable="true"
                  v-for="item in products"
                  :key="item.productId || item.rowId"
                  :label="item.productName || item.shortName"
                  :value="item.productId || item.rowId">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='9'>
            <el-form-item label="查询周期">
              <DatePickerTemp @on-change="rangeTime" :types="daterange" :quick="quick"/>
              <el-button type="primary" @click="findClk">查询</el-button>
            </el-form-item>
          </el-col>
        </el-col>
      </el-form>
      <!--</el-col>-->
    </el-row>
    <div style="height: calc(100% - 94px)">
      <iframe id="myIframe" :src="htl" frameborder="0" allowtransparency="true" width="100%" height="100%" scrolling="yes"></iframe>
    </div>
  </div>
</template>
<script>
  import config from '@/config'
  import {getUser} from '@/config/info'
  import DatePickerTemp from '@/components/Template/DatePicker/DatePickerTemp.vue'
//  import _cascader from '@/components/Template/Cascader/Cascader.vue'
  import api from '@/api'
  import log from '@/log'
  import BasePath from '@/config/BasePath'
  export default {
    name: 'ReportVisitStatistics',
    props: {},
    mounted () {
      this.init()
    },
    data () {
      return {
        start_date: '',
        end_date: '',
        daterange: 'daterange',
        quick: true,
        company_id: '', // 公司ID
        county_dept: '', // 分公司
        products: '', // 商品
        product_id: '', // 商品ID
        where_clause: '',
        selected: [], // 数据范围
        disable: false,
        options: [],
        htl: ''
      }
    },
    methods: {
      init () {
        let orgTreeparam = {}
        orgTreeparam.orgrelTypeId = 2
        orgTreeparam.treeRoot = getUser().companyId
        api.requestJava('POST', BasePath.ORGUNIT_TREE, orgTreeparam)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (Number(getUser().unitLevel) === 1) { // 省公司
                let provinceTreeObj = request.data.data
                let treeObj = {}
                treeObj.value = provinceTreeObj.id
                treeObj.label = provinceTreeObj.label
                treeObj.type = 'PROVINCE'
                let companyTreeChildrens = []
                let companyTreeChildrensObj = provinceTreeObj.children
                if (companyTreeChildrensObj.length > 0) {
                  let i = 0
                  companyTreeChildrensObj.forEach((e) => {
                    let companyChildren = {}
                    companyChildren.value = companyTreeChildrensObj[i].id
                    companyChildren.label = companyTreeChildrensObj[i].label
                    companyChildren.type = 'COMPANY'
                    let countyTreeChildrens = []
                    let countyTreeChildrensObj = companyTreeChildrensObj[i].children
                    if (countyTreeChildrensObj.length > 0) {
                      let j = 0
                      countyTreeChildrensObj.forEach((e) => {
                        let countyChildren = {}
                        countyChildren.value = countyTreeChildrensObj[j].id
                        countyChildren.label = countyTreeChildrensObj[j].label
                        countyChildren.type = 'COUNTY'
                        countyChildren.orgRoleTypId = countyTreeChildrensObj[j].orgRoleTypId
                        countyTreeChildrens.push(countyChildren)
                        j++
                      })
                    }
                    companyChildren.children = countyTreeChildrens
                    companyTreeChildrens.push(companyChildren)
                    i++
                  })
                }
                treeObj.children = companyTreeChildrens
                console.log(treeObj)
                this.options.push(treeObj)
                console.log(this.options)
              } else {
                let companyTreeObj = request.data.data
                let treeObj = {}
                treeObj.value = companyTreeObj.id
                treeObj.label = companyTreeObj.label
                treeObj.type = 'COMPANY'
                let countyTreeChildrens = []
                let countyTreeChildrensObj = request.data.data.children
                if (countyTreeChildrensObj.length > 0) {
                  let i = 0
                  countyTreeChildrensObj.forEach((e) => {
                    let countyChildren = {}
                    countyChildren.value = countyTreeChildrensObj[i].id
                    countyChildren.label = countyTreeChildrensObj[i].label
                    countyChildren.type = 'COUNTY'
                    countyTreeChildrens.push(countyChildren)
                    i++
                  })
                }
                treeObj.children = countyTreeChildrens
                this.options.push(treeObj)
                if (Number(getUser().unitLevel) === 2) {
                  if (getUser().countyId !== 'null') {
                    this.selected = [getUser().companyId, getUser().countyId]
                    this.where_clause = 'where_clause=b.sales_unit_id=' + getUser().countyId
                    this.getChangeValue(this.selected)
                    this.disable = true
                  }
                }
              }
            } else if (Number(request.data.code) === 401) {
              this.$notify.error({ title: '查询失败', message: request.data.message })
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      rangeTime (val) {
        var tmp = JSON.parse(val).split(' - ')
        this.start_date = tmp[0]
        this.end_date = tmp[1]
      },
      getChangeValue (arr) {
        this.company_id = getUser().companyId
        if (Number(getUser().unitLevel) === 1) { // 展示所有
          arr.forEach((val, key) => {
            switch (key) {
              case 0:
                this.company_id = val
                console.log(val)
                this.where_clause = 'where_clause=1=1'
                break
              case 1:
                this.where_clause = 'where_clause=b.company_id=' + val
                this.company_id = val
                break
              case 2:
                this.where_clause = 'where_clause=b.sales_unit_id=' + val
                break
            }
          })
        } else if (Number(getUser().unitLevel) === 2) {
          if (getUser().countyId === 'null') {
            arr.forEach((val, key) => {
              switch (key) {
                case 0:
                  this.where_clause = 'where_clause=b.company_id=' + val
                  this.company_id = val
                  break
                case 1:
                  this.where_clause = 'where_clause=b.sales_unit_id=' + val
                  break
              }
            })
          } else if (getUser().countyId !== 'null' && Number(getUser().place) === 9999) {
            if (arr.length > 0) {
              arr.forEach((val, key) => {
                switch (key) {
                  case 1:
                    this.where_clause = 'where_clause=b.sales_unit_id=' + val
                    break
                }
              })
            }
          }
        }
        console.log('this.company_id:', this.company_id + '&where_clause:', this.where_clause)
        var params = {}
        var url = ''
        if (Number(this.company_id) === 1) {
          url = BasePath.COMMODITY_SELECT
          params.isConfiscated = 'N'
          params.status = 'Y'
          params.fields = {'include': 'rowId,shortName'}
          params.sorter = 'goods_code'
        } else {
          url = BasePath.GATHER_SELECT
          params.companyId = this.company_id
          params.fields = {'include': 'productId,productName'}
          params.sorter = 'product_code'
        }
        api.requestJava('POST', url, params)
          .then((response) => {
            if (Number(response.data.code) === 200 && response.data.data.length > 0) {
              this.products = response.data.data
            }
          })
      },
      findClk () {
        var reportId = 'b800a00b-c5ba-47c3-baf8-843626394260'
        if (this.selected.length <= 0) {
          this.$notify({
            title: '警告',
            message: '数据范围不能为空',
            type: 'warning'
          })
        } else if (this.product_id === '') {
          this.$notify({
            title: '警告',
            message: '商品为空，不能查询',
            type: 'warning'
          })
        } else if (this.start_date === '' && this.end_date === '') {
          this.$notify({
            title: '警告',
            message: '时间范围不能为空',
            type: 'warning'
          })
        } else {
//          console.log('this.company_id:', this.company_id + '&where_clause:', this.where_clause)
          // 省公司
          if (Number(getUser().unitLevel) === 1) {
//            reportId = 'c8e0b672-d6cc-4524-b586-669025103d59'
            this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&start_date=' + this.start_date + '&end_date=' + this.end_date + '&' + this.where_clause + '&product_id=' + this.product_id
          } else if (Number(getUser().unitLevel) === 2) {
            // 市公司
            if (getUser().countyId === null || getUser().countyId === 'null') {
//              reportId = 'c8e0b672-d6cc-4524-b586-669025103d60'
              this.company_id = getUser().companyId
              this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&start_date=' + this.start_date + '&end_date=' + this.end_date + '&' + this.where_clause + '&product_id=' + this.product_id
              // 分公司
            } else if (getUser().countyId !== null) {
//              reportId = '0bf74df3-0732-454b-a156-a6e519e6e266'
              this.county_dept = getUser().countyId
              this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&start_date=' + this.start_date + '&end_date=' + this.end_date + '&' + this.where_clause + '&product_id=' + this.product_id
            }
            console.log(this.htl)
          }
        }
      }
    },
    components: {
      DatePickerTemp
//      , _cascader
    },
    watch: {}
  }
</script>

