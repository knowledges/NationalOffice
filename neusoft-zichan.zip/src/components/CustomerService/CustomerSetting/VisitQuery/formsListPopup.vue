<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false"  :size='dialogObj.size' :before-close="cancleClk" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-table :data="this.dialogObj.data.form.products"  >
        <el-table-column prop="title" label="标题" ></el-table-column>
        <el-table-column prop="endTime" label="时间" ></el-table-column>
        <el-table-column label="操作" width="100">
          <template scope="scope">
            <el-button @click="handleClick(scope.row)" type="text" size="small">查看</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
    </div>
  </el-dialog>
  <el-dialog title="调查问卷浏览" :visible.sync="dialogTableVisible">
    <iframe :src="iurl"  style="width: 100%;height: 521px;"></iframe>
  </el-dialog>

  </div>
</template>

<script>
  import {getUser} from '@/config/info'
  import config from '@/config'
  //  import MY_POPUP_SALES from './salesPopup.vue'
//  import log from '@/log'
//  import api from '@/api'
//  import BasePath from '@/config/BasePath'
  export default {
    props: ['dialogObj'],
    mounted () {
    },
    data () {
      return {
        addrules: {},
        iurl: '',
        dialogTableVisible: false
      }
    },
    methods: {
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      },
      handleClick (row) {
        this.findByIdUpper1(row)
      },
      findByIdUpper1 (row) { //  客户意见征集及反馈
        console.log('row数据' + JSON.stringify(row))
        let temp = {}
        temp.formId = row.formId
        temp.stepId = row.stepId
        temp.userId = getUser().id
        temp.customerId = row.customerId
        temp.brandId = 0
        temp.companyId = row.companyId
        temp.personId = getUser().personId
        temp.disabled = 0
        temp.visitingRecId = row.rowId
        temp.planId = row.planId
        temp.visitor = row.visitor
        temp.visitorName = row.visitorName
        temp.customerName = row.cusotmerName
        let str = JSON.stringify(temp)
        console.log('str' + str)
        let enCode = encodeURI(str)
        this.iurl = config.root + '/survey/' + enCode
        console.log('this.iurl' + this.iurl)
        this.dialogTableVisible = true
      }, // 问题需求采集

      salesEve (msg) {
        this.sales.dialogVisible = false
        let tmp = {
          title: '驻店销售记录',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              visitingRecId: '',
              visitor: '',
              visitorName: '',
              customerId: '',
              cusotmerName: '',
              visitDate: '',
              productId: '',
              productCode: '',
              productName: '',
              saleTime: '',
              unit: '',
              quantity: '',
              amount: '',
              notes: '',
              status: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: ''
            }
          }
        }
        Object.assign(this.sales, tmp)
      } // 修改事件
    },
    components: {
//      MY_POPUP_SALES
    }
  }
</script>
