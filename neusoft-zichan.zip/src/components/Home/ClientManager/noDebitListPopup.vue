<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog title="当日未扣款" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false"  :size='dialogObj.size' :before-close="cancleClk" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-table :data="this.dialogObj.data.form.products"  >
        <el-table-column prop="customerdesc" label="客户名称" ></el-table-column>
        <el-table-column prop="legalperson" label="法人"  width="180"></el-table-column>
        <el-table-column prop="tel" label="订货电话"  width="180"></el-table-column>
        <el-table-column prop="qtysum" label="订货金额"  width="180"></el-table-column>
        <!--<el-table-column prop="retMsg" label="原因" ></el-table-column>-->
      </el-table>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
    </div>
  </el-dialog>
  </div>
</template>

<script>
  export default {
    props: ['dialogObj'],
    mounted () {
    },
    data () {
      return {
        addrules: {}
      }
    },
    methods: {
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      }
    },
    components: {
    }
  }
</script>
