<!--  Auther:luoshuo -->
<!--  评分题分析 -->
<template>
  <div>
    <div class="rateTitle">
      <div>{{question.questionNo}}、{{question.questionTitle}}[填空题]</div>
    </div>
    <div>
      <table id="rate" class="rateTableStyle">
        <tbody>
          <tr v-for="item in question.options" :key="item.id" class="rateTrOptions">
            <td width="2%" height="30px">&nbsp;</td>
            <td width="48%">{{item.val}}</td>
            <td width="25%" align="right"><el-rate disabled v-model="item.percent"></el-rate></td>
            <td width="25%">{{item.selected}}分&nbsp;&nbsp;平均</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div>
      <el-tabs v-model="rateModel" type="card" @tab-click="handleClick">
        <el-tab-pane label="柱状图" name="histogram">
           <ve-histogram :data="rateChartData" :settings="rateChartSettings" width="100%"></ve-histogram>
        </el-tab-pane>
        <el-tab-pane label="饼图" name="pie">
          <ve-pie :data="rateChartData" :settings="rateChartSettings" width="700px" class="rateMargin"></ve-pie>
        </el-tab-pane>
        <el-tab-pane label="条形图" name="bar">
          <ve-bar :data="rateChartData" :settings="rateChartSettings" width="700px" class="rateMargin"></ve-bar>
        </el-tab-pane>
        <el-tab-pane label="折线图" name="line">
          <ve-line :data="rateChartData" :settings="rateChartSettings" width="700px" class="rateMargin"></ve-line>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      rateModel: 'histogram',
      rateChartData: {
        columns: ['val', 'selected'],
        rows: [
        ]
      },
      rateChartSettings: {
        metrics: ['selected'],
        dimension: ['val'],
        labelMap: {
          'selected': '总分数'
        }
      }
    }
  },
  methods: {
    handleClick (tab, event) {

    }
  },
  props: {
    question: {
      type: Object,
      required: true
    },
    idx: Number
  },
  mounted () {
    this.$nextTick(() => {
      this.rateChartData.rows = this.question.detailList
    })
  }
}
</script>
<style>
.rateTitle {
  color: #625F5F;
  font-size: x-large;
  display: inline-block;
}
.rateTableStyle {
  border: 1px solid #c5b6b6;
  width: 100%;
  margin: 5px;
}
.rateTrOptions {
  color: rgb(155, 150, 150);
  font: '14px/20px "Microsoft Yahei","微软雅黑","SimSun","宋体","Arial Narrow",HELVETICA';
  font-size: '20px';
}
.rateMargin {
  margin: 0 auto;
}
</style>
