<!-- 徐晓菁 -->
<template>
  <div class="container-fluid">
     <div>
       <el-col :span="6"  v-for="item in tableData">
         <div class="divclass2"  @click="modify(item)">
           <!--originApp-->
           <div class="img"><img :src="gatherer+item.originApp" class="img1"></div><br>
           <div class="img12">
             <div><span class="warningtitle">{{item.name}}</span></div>
             <div><span class="numtitle">{{item.count}}</span><span class="numtitle1">个</span></div>
           </div>
         </div>
       </el-col>
    </div>
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve" />
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import MY_POPUP_CONFIG from './Popup.vue'
  import log from '@/log'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  import config from '@/config'
  export default {
    mounted () {
      this.query()
    },
    data () {
      return {
        gatherer: config.root + '/static/img/',
        hasPagination: true,
        tableData: [],
        edit: {
          title: '预警明细查看',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              rowId: '',
              cat: '',
              name: '',
              descText: '',
              priority: '',
              checkFlag: '',
              receiverType: '',
              exeMode: '',
              interface: '',
              templateId: '',
              status: ''
            }
          }
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        }
      }
    },
    methods: {
      query () {
        this.queryUpper({pageNum: 1})
      }, // 查询方法
      queryUpper (params) {
        params.companyId = getUser().companyId
        params.empId = getUser().personId
        params.status = 1
        params.pageSize = 1
        api.requestJava('POST', BasePath.WARNINGINFO_RULECOUNT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              var tmp = this.tableData
              this.tableData = tmp.concat(request.data.data)
              var num = params.pageNum
              if (num < Number(request.data.count)) {
                ++num
                this.queryUpper({pageNum: num})
              }
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      modify (row) {
        this.edit.title = row.name + '预警明细'
        Object.assign(this.edit.data.form, row)
        this.edit.dialogVisible = true
      }, // 修改// 修改
      editEve (msg) {
        this.edit.dialogVisible = false
        let tmp = {
          title: '预警明细查看',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              rowId: '',
              cat: '',
              name: '',
              descText: '',
              priority: '',
              checkFlag: '',
              receiverType: '',
              exeMode: '',
              interface: '',
              templateId: '',
              status: ''
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      dateFormatter (row, column) {
        var unixDate = row[column.property]
        return dateFormat(unixDate, 'YYYY-MM-DD')
      },  // 时间格式化
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      } // 时间格式化
    },
    components: {
      _TABLE,
      _POPUP,
      MY_POPUP_CONFIG
    }
  }
</script>

<style scoped>
  .title {
    color: #222222 100%;
    opacity: 100%;
    font-size: 24px;
    font-family: PingFangSC-Medium;
    character: 1.7px;
    line: 33px (1.4);
  }
  .img {
    background-color: #f3f9ec;
    height: 140px;
    text-align: center;
  }
  .img12 {
    background-color: #fefefe;
    width: 100%;
  }
  .warningtitle {
    color: #666666;
    opacity: 100%;
    font-size: 16px;
    font-family: PingFangSC-Regular;
    character: 1.1px;
    padding-top: 20px;
    padding-left: 28px;
    line: 22px (1.4);
  }
  .numtitle {
    color: #59B072;
    opacity: 100%;
    font-size: 30px;
    padding-top: 10px;
    padding-left: 28px;
    font-family: PingFangSC-Medium;
    character: 2.3px;
    line: 45px (1.4);
    text-decoration: underline;
  }
  .numtitle1 {
    color: #59B072;
    opacity: 100%;
    font-size: 30px;
    font-family: PingFangSC-Medium;
  }
  .divclass2 {
    border-style: solid;
    border-color: #dddddd;
    border-width: 2px;
    border-radius: 6px;
    width: 230px;
    height: 240px;
    margin: auto;
    cursor: pointer;
  }
  .img1 {
    padding-top: 13px;
  }
  .el-col-6 {
    height: 260px;
    padding-top: 13px;
  }
</style>
