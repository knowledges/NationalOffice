import axios from 'axios'
import config from '@/config'
import { getUser } from '@/config/info'
export default {
  requestJava (method, uri, data, headerConfig) {
    if (!method) {
      console.error('API function call requires method argument')
      return
    }

    if (!uri) {
      console.error('API function call requires uri argument')
      return
    }

    let url = config.serverURL + uri

    if (JSON.stringify(headerConfig) === '{}' || headerConfig === undefined || headerConfig === null) {
      let headers = {}
      headers.userCode = getUser().userCode
      headers.authToken = getUser().authToken
      return axios({method, url, data, headers})
    } else {
      return axios({method, url, data, ...headerConfig})
    }
  },
  requestLocal (uri) {
    let url = uri
    return axios.get(url)
  }
}
