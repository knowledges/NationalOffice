<template>
  <li class="li_surveyQuItemBody">
    <div class="surveyQuItemBody">
      <div class="initLine"></div>
      <div class="quInputCase">
        <input type="hidden" name="quType" value="radio">
        <input type="hidden" name="rowId" :value="SubRadios.rowId"/>
        <input type="hidden" name="itemCode" :value="SubRadios.itemCode">
        <!--<input type="hidden" name="orderById" :value="SubRadios.rowId + 1">-->
        <input type="hidden" name="sortNbr" :value="SubRadios.sortNbr">
        <input type="hidden" name="saveTag" value="0">
        <input type="hidden" name="hv" value="2"> <!-- 类型 2：基础类型 3：表格类型 -->
        <!--<input type="hidden" name="hoverTag" value="0">-->
        <input type="hidden" name="isRequired" :value="SubRadios.mustFlag">
        <!--<input type="hidden" name="randOrder" value="0">-->
        <!--<input type="hidden" name="cellCount" value="0">-->
        <!--<input type="hidden" name="contactsAttr" value="0">-->
        <!--<input type="hidden" name="contactsField" value="0">-->
        <!--<div class="quLogicInputCase">-->
        <!--<input type="hidden" name="quLogicItemNum" value="0">-->
        <!--</div>-->
      </div>
      <div class="surveyQuItem">
        <div class="surveyQuItemLeftTools"  v-if="SubRadios.itemCode == SubRadios.rowId" >
          <ul class="surveyQuItemLeftToolsUl">
            <li title="移动排序" class="dwQuMove ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
            <li title="设置" class="dwQuSet ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
            <!--<li title="逻辑" class="dwQuLogic ui-draggable ui-draggable-handle">-->
              <!--<div class="dwQuIcon">-->
                <!--<div class="quLogicInfo"></div>-->
              <!--</div>-->
            <!--</li>-->
            <li title="删除" class="dwQuDelete ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
          </ul>
        </div>
        <div class="surveyQuItemRightTools">
          <ul class="surveyQuItemRightToolsUl">
            <li class="questionUp ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
            <li class="questionDown ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
          </ul>
        </div>
        <div class="surveyQuItemContent">
          <div class="quCoTitle">
            <div class="quCoNum">{{SubRadios.sortNbr}}、</div>
            <div class="editAble quCoTitleEdit">{{SubRadios.title}}</div>
            <input type="hidden" name="quTitleSaveTag" value="1">
          </div>
          <div class="quCoItem">
            <ul>
              <template v-for="item in SubRadios.enumList">
                <li class="quCoItemUlLi ui-draggable ui-draggable-handle quOption_0">
                  <template>
                    <el-radio :name="SubRadios.itemCode" :label="SubRadios.itemCode">
                      <label class="editAble quCoOptionEdit">{{item.listTitle}}</label>
                    </el-radio>
                  </template>
                  <div class="quItemInputCase">
                    <input type="hidden" name="rowId" :value="SubRadios.rowId">
                    <input type="hidden" name="rcFlag" :value="0">
                  </div>
                </li>
              </template>
            </ul>
          </div>
          <div class="quCoBottomTools">
            <ul class="quCoBottomToolsUl"  v-if="SubRadios.itemCode == SubRadios.rowId">
              <li title="添加" class="addOption ui-draggable ui-draggable-handle">
                <div class="dwQuIcon"></div>
              </li> <!---->
            </ul>
          </div>
        </div>
      </div>
    </div>
  </li>
</template>
<script>
  export default {
    props: ['SubRadios']
  }
</script>
