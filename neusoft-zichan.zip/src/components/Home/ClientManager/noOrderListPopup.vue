<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog title="当日未订货" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false"  :size='dialogObj.size' :before-close="cancleClk" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-row class="filter_style">
        <el-col :gutter="24">
          <el-col :span='12'>
            <label class="el-form-item__label" style="width: 120px;">日期</label>
            <el-date-picker
              v-model="orderDate1"
              type="date"
              format="yyyy-MM-dd"
              :editable=false
              :clearable=false
              @change="noOrderFind1"
              placeholder="选择查询日期">
            </el-date-picker>
          </el-col>
        </el-col>
      </el-row>
      <el-table :data="this.dialogObj.data.form.products"  >
        <el-table-column prop="customerdesc" label="客户名称" ></el-table-column>
        <el-table-column prop="legalperson" label="法人"  ></el-table-column>
        <el-table-column prop="tel" label="订货电话"  ></el-table-column>
        <!--<el-table-column prop="passreason" label="不订货原因" ></el-table-column>-->
      </el-table>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
    </div>
  </el-dialog>
  </div>
</template>

<script>
  import api from '@/api'
  import log from '@/log'
  import BasePath from '@/config/BasePath'
  import { dateFormat } from '@/utils/dateFormat.js'
  import {getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      this.orderDate1 = new Date()
      this.noOrderFind1()
    },
    data () {
      return {
        orderDate1: '',
        addrules: {}
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      },
      noOrderFind1 () { // 消费者调查  新品测试调查（消费者）
        let param = {}
        param.employeecode = getUser().userCode
        param.bornDate = this.getTime(Date.parse(this.orderDate1))
        console.log('noOrderFind', param)
        api.requestJava('POST', BasePath.CLIENTMANAGER_NOORDERCUSTS, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.dialogObj.data.form.products = request.data.data
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      } // 未订货请求
    },
    components: {
    }
  }
</script>
