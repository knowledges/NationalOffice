<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk"  :size='dialogObj.size' v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <div class="container-fluid_new">
      <el-row class="filter_style">
        <el-col :span="24" style="padding: 0 0">
          <_BTN_FILTER  @on-change="inputChange" :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData"/>
         </el-col>
      </el-row>
      <div>
        <_TABLE
          ref="table"
          stripe
          maxHeight="500"
          :data="dataSource"
          :columns="columnHeader"
          :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
          :totalCount="totalCount" :hasPagination="hasPagination"
          @selection-change="selectionChange" :setPage=this.getPage ></_TABLE>
      </div>
    </div>
  </el-dialog>
    <MY_POPUP_CONFIG :dialogObj='addDialogObj' @confirmBack="addBack"/>
  </div>
</template>

<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import MY_POPUP_CONFIG from './ComplaintAddProp.vue'
  import api from '@/api'
  import log from '@/log'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {},
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        this.query(1, this.pageSize)
      }
    },
    data () {
      return {
        /** table **/
        columnType: 'selection',
        hasPagination: true,
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [10, 20, 40, 50, 100], // 分页数选择项
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'cat', // 列的值
            label: '事项类型', // 列的显示字段
            columnsProps: {width: 200, align: 'left'}
          },
          {
            prop: 'contents', // 列的值
            label: '事项描述', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'receiveTime',
            label: '受理日期',
            columnsProps: {width: 180, align: 'center'}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 200, type: 'button'},
            cptProperties: [
              {
                label: '查看',
                value: 'query',
                icon: 'search',
                size: 'small',
                type: 'primary',
                eventClick: this.modify
              }
            ]
          }
        ],
        addDialogObj: {
          title: '咨询投诉信息',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              matterId: '',
              stepIds: '',
              stepId: [],
              unitId: '',
              deptId: '',
              maker: '',
              makerNm: '',
              parentId: '',
              beginDate: '',
              endDate: '',
              fpConds: '',
              title: '',
              notes: '',
              status: '',
              createdBy: '',
              haveAttach: '',
              files: []
            }
          }
        },
        tableData: [],
        dataSource: [], // 当前页的数据
        /** filter **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['customerCode', 'customerDesc'],
        isMore: true,
        isSelect: true,
        keyupend: false,   // 输入筛选；true：之前展示；false：之后展示
        templTableData: [], // 临时记录tableDate的值
        btnGroups: [],
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        treeData: [],
        nodeKey: 'id',
        defaultCheckedKeys: [],
        isLoading: true
        /** 弹出层 **/
      }
    },
    methods: {
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      modify (index, row) {
        Object.assign(this.addDialogObj.data.form, row)
        this.addDialogObj.dialogVisible = true
      }, // 修改
      addBack (msg) {
        this.addDialogObj.dialogVisible = false
        let temp = {
          title: '咨询投诉信息',
          type: '1',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              personId: '',
              userName: '',
              userCode: '',
              password: '',
              confirmPass: '',
              company: '',
              department: '',
              email: '',
              status: false,
              loginFlag: false,
              contactPhone: '',
              mobile: '',
              remark: '',
              fields: [],
              certYn: 'N',
              attrFlag: '0',
              menuFlag: '0',
              appUserFlag: 'Y',
              usingFlag: '0',
              auditUserId: '-1',
              loginFirst: 'Y',
              companyId: '32070000',
              divisionId: '32070001'
            }
          }
        }
        Object.assign(this.addDialogObj, temp)
      },
      getPage (page, size) {
        this.currentPage = page
        this.pageSize = size
        this.query(this.currentPage, this.pageSize)
      },
      query_New () {
        this.currentPage = '1'
        this.query(this.currentPage, this.pageSize)
      },
      query (pageNum, pageSize) {
        let param = {}
        param.status = '1'
        param.receiver = getUser().personId
        param.pageSize = pageSize
        param.pageNum = pageNum
        console.log('param', JSON.stringify(param))
        api.requestJava('POST', BasePath.COMPLAINTREC_SELECT, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.dataSource = request.data.data
              this.totalCount = Number(request.data.count)
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询方法
      toMoreChange (values, type) {
        let result = ''
        for (let i = 0; i < values.length; i++) {
          if (type === 'int') {
            result = result + values[i] + ','
          } else if (type === 'string') {
            result = result + "'" + values[i] + "'" + ','
          }
        }
        if (result.length > 0) {
          result = result.substr(0, result.length - 1)
        }
        return result
      },
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = this.currentPage
        let size = this.pageSize
        this.dataSource = JSON.parse(val).filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      onendChange (val) {}, // 过滤器修改事件
      select (selection, index) {}, // 选中某1条
      selectAll (data) {}, // 全选
      headerClick (column, event) {},
      sortChange (msg) {},
      rowClick (msg) {},
      selectionChange (rows) {},
      addClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'update')
      },
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      },
      isMoreClk () {
        this.isSelect = !this.isSelect
      }
    },
    components: {
      _TABLE,
      _BTN_FILTER,
      MY_POPUP_CONFIG
    }
  }
</script>
<style scoped>
  .container-fluid_new {
    background: #FFF;
    margin: 0 5px 5px 5px;
  }
</style>

