<!--qiu.bl-->
<style rel="stylesheet/scss" lang="scss" scoped>
  ul {
    padding: 0;
  }
  li {
    padding: 5px 8px;
    border-bottom: 1px solid #f4f4f4;
  }
  li:last-child{
    border-bottom: none;
  }
</style>
<template>
    <div>
      <ul>
        <li v-for="(item, key) in data">{{item}}</li>
      </ul>
    </div>
</template>
<script>
  export default {
    name: 'latList',
    props: ['data']
  }
</script>
