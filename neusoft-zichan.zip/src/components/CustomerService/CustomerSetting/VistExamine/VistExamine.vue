<!-- 徐晓菁 -->
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='12'>
          <div v-if="isSelect">
            <el-form ref="searchForm" :model="searchForm" label-width="120px">
              <el-col :gutter="24">
                <el-col :span='24'>
                  <div class="block">
                    <el-form-item label="查询周期">
                      <el-date-picker
                        v-model="datetime"
                        type="daterange"
                        :editable=false
                        :clearable=false
                        @change="datePickerChange"
                        placeholder="选择日期范围"
                        :picker-options="pickerOptions">
                      </el-date-picker>
                    </el-form-item>
                  </div>
                </el-col>
              </el-col>
            </el-form>
          </div>
        </el-col>
        <el-col :span="12">
            <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData" /></_BTN_FILTER>
        </el-col>
      </el-col>
    </el-row>
     <div>
       <_TABLE
         ref="table"
         stripe
         @update:data="tabChange"
         :reqParams="reqParams"
         maxHeight="500"
         @select="select"
         @select-all="selectAll"
         :column-type="columnType"
         :data="dataSource"
         :columns="columnHeader"
         :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
         :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData>
       </_TABLE>
    </div>
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve"/>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import { changeListValueByCode, dateFormat } from '@/utils/common'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import MY_POPUP_CONFIG from './VistExamine_old.vue'
  import log from '@/log'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import {getCodeList, getUser} from '@/config/info'
  export default {
    mounted () {
      getCodeList('VISIT_MODE', (data) => {
        this.visitTypeGroup = data.splice(1, 2)
        this.changeValueDate.visitMode.group = this.visitTypeGroup
      }) // 拜访方式
      getCodeList('CUSTOMER_GRADE', (data) => {
        this.changeValueDate.customerGrade.group = data
      }) // 客户档级
      this.initDate(this.getNowTime())
    },
    data () {
      return {
        columnType: 'selection',    // ["expand", "selection"]
        isSelect: true,
        isMore: true, // 查询更多条件
        datetime: [],
        pickerOptions: {
          shortcuts: [{
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '当前月',
            onClick (picker) {
              const end = new Date()
              const start = new Date(new Date().setDate(1))
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }]
        },
        rtlcatIdGroup: [], // 客户集id
        visitStatusGroup: [], // 拜访情况
        customerGradeGroup: [], // 客户档级
        routeIdGroup: [], // 送货线路id
        visitTypeGroup: [], // 拜访方式..
        operationScaleGroup: [], // 经营规模..
        geoTypeGroup: [], // 市场类型id..
        busnessTypeGroup: [], // 经营业态id..
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        objectCdGroup: [],
        fileName: ['employeeName'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '批量通过',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.passDelClk
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'custmgrName', // 列的值
            label: '客户经理', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'allCusts',
            label: '总客户数',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          },
          {
            prop: 'planCusts',
            label: '计划数',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          },
          {
            prop: 'passCusts',
            label: '未审核数',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: '300', type: 'button'},
            cptProperties: [
              {
                label: '计划明细',
                value: 'query',
                icon: 'search',
                size: 'small',
                type: 'primary',
                eventClick: this.modify
              },
              {
                label: '审核通过',
                value: 'modify',
                icon: 'edit',
                size: 'small',
                type: 'warning',
                eventClick: this.pass
              }
            ]
          }
        ],
        changeValueDate: {
          customerGrade: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          visitMode: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          createdTime: {
            type: 'date1'
          }
        },
        tableData: [],
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        /** searchForm **/
        searchForm: {
          custmgrId: '',
          visitMode: '',
          visitBegin: '',
          visitEnd: '',
          manager: ''
        },
        edit: {
          title: '计划明细',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              visitEnd: '',
              visitBegin: '',
              custmgrId: ''
            }
          }
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** 实际操作 **/
        hasPagination: true,
        sel_all: [],
        sel_all_row: []
      }
    },
    methods: {
      modify (index, row) {
        this.edit.title = row.custmgrName + '（' + this.searchForm.visitBegin + '到' + this.searchForm.visitEnd + ')的计划明细'
        this.edit.data.form.visitEnd = this.searchForm.visitEnd
        this.edit.data.form.visitBegin = this.searchForm.visitBegin
        this.edit.data.form.custmgrId = row.custmgrId
        this.edit.dialogVisible = true
      }, // 修改// 修改
      getNowTime () {
        return dateFormat(new Date().getTime(), 'YYYY-MM-DD')
      },  // 时间格式化
      initDate (time) {
        let params = {}
        params.currentDate = time
        api.requestJava('POST', BasePath.VISITPLAN_PLANDATE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.datetime = [new Date(request.data.data.startDate), new Date(request.data.data.endDate)]
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      queryEmpUpper () {
        let params = {}
        params.manager = getUser().personId
        params.mktMgrId = getUser().personId
        params.planMonthBegin = this.searchForm.visitBegin
        params.planMonthEnd = this.searchForm.visitEnd
        /* 将已有的参数赋值给分页参数 */
        this.$set(this.reqParams, 'url', BasePath.VISITPLAN_EMP_SELECT)
        this.$set(this.reqParams, 'params', params)
        api.requestJava('POST', BasePath.VISITPLAN_EMP_SELECT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      pass (index, row) {
        this.$confirm('确定审核通过此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let ryid = [{'visitor': row.custmgrId}]
          this.passUpper(ryid)
        }).catch(() => {
          this.$message({type: 'info', message: '已取消操作!'})
        })
      },  // 删除
      passDelClk () {
        let sel = []
        if (this.sel_all.length > 0) { // 过滤未审核数为0的记录
          for (var i in this.sel_all) {
            var temp = this.sel_all[i].passCusts
            if (Number(temp) !== 0) {
              let rowId = {}
              rowId.visitor = this.sel_all[i].visitor
              sel.push(rowId)
            }
          }
          if (sel.length > 0) {
            this.$confirm('确定审核通过此条信息吗？', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              this.passUpper(sel)
            })
              .catch(() => {
                this.$message({type: 'info', message: '已取消操作!'})
              })
          } else {
            this.$message({type: 'info', message: '未审核数都为0，不可以批量操作!'})
          }
        } else {
          this.$message({type: 'info', message: '没有选择记录，不可以批量操作!'})
        }
      },  // 批量删除
      passUpper (val) {
        let params = {}
        params.planMonthBegin = this.searchForm.visitBegin
        params.planMonthEnd = this.searchForm.visitEnd
        params.status = '0'
        params.checkerId = getUser().personId
        params.checkerNm = getUser().userName
        params.opinions = ''
        params.custmgrId = val
        console.log('params', JSON.stringify(params))
        api.requestJava('POST', BasePath.VISITPLAN_EMP_PASS, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              this.queryEmpUpper()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 删除接口
      select (selection, index) {
        if (selection[0] !== undefined) {
          this.sel_all = []
          this.sel_all_row = []
          for (var i in selection) {
            let rowIds = {}
            rowIds.visitor = selection[i].custmgrId
            rowIds.passCusts = selection[i].passCusts
            this.sel_all.push(rowIds)
            this.sel_all_row.push(selection[i])
          }
        }
      }, // 选中某1条
      selectAll (data) {
        this.sel_all = []
        for (var i in data) {
          var rowIds = {}
          rowIds.visitor = data[i].custmgrId
          rowIds.passCusts = data[i].passCusts
          this.sel_all.push(rowIds)
        }
      }, // 全选
      celldbClick (row, column, cell, event) {
        this.$set(row, '_edit', !row._edit)
      },
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      changeValue1 (row, column) {
        return changeListValueByCode(this.changeValueDate_c, row, column)
      },  // 转换list中的code
      isMoreClk () {
        this.isSelect = !this.isSelect
      },
      datePickerChange (item) {
        this.searchForm.visitBegin = this.getTime(Date.parse(this.datetime[0]))
        this.searchForm.visitEnd = this.getTime(Date.parse(this.datetime[1]))
        this.queryEmpUpper()
      },
      toMoreChange (values, type) {
        let result = ''
        for (let i = 0; i < values.length; i++) {
          if (type === 'int') {
            result = result + values[i] + ','
          } else if (type === 'string') {
            result = result + "'" + values[i] + "'" + ','
          }
        }
        if (result.length > 0) {
          result = result.substr(0, result.length - 1)
        }
        return result
      },
      sortChange (msg) {},
      rowClick (msg) {},
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      dateFormatter (row, column) {
        var unixDate = row[column.property]
        return dateFormat(unixDate, 'YYYY-MM-DD HH:mm:ss')
      },  // 时间格式化
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      editEve (msg) {
        this.edit.dialogVisible = false
        let tmp = {
          title: '计划明细',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              visitEnd: '',
              visitBegin: '',
              custmgrId: ''
            }
          }
        }
        Object.assign(this.edit, tmp)
        this.queryEmpUpper()
      }, // 修改事件
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      exportEve () {
        this.$refs.table.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      onendChange (val) {} // 过滤器修改事件
    },
    components: {
      _TABLE,
      _POPUP,
      MY_POPUP_CONFIG,
      _BTN_FILTER
    }
  }
</script>

<style scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-24 {
    height: 36px;
  }

</style>
