<!-- 徐晓菁 -->
<style scoped rel="stylesheet/scss" lang="scss">
  .editDiv{
  }
  .buttonDiv{
    width: 50%;
  }
  .form-group {
    width: 100%;
    align-content: left;
  }
  .sfc-div {
    float: left;
  }
  .notice {
    font-size: medium;
    color: red;
    padding-left: 14px;
    padding-top: 11px;
  }
  .input-group .input-group-addon {
    border-radius: 0;
    border-color: rgba(210, 214, 222, 0.03);
    background-color: #fff;
  }
  .input-group .form-control {
    text-align: center;
    position: relative;
    z-index: 2;
    font-size: 19px;
    width: 100%;
    margin-bottom: 0;
    border-color: rgba(210, 214, 222, 0.03);
  }
</style>
<template>
  <div>
    <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk" :size='dialogObj.size'  v-popupdra-directive="{'show': dialogObj.dialogVisible}">
      <el-row>
        <el-col :span="7">
          <el-button-group>
            <!--<el-button  type="primary"  @click="chuckCus()"  ><i  class="fa fa-search"></i>&nbsp;选择分析商品</el-button>-->
            <el-button  type="success"  @click="updateClk('addForm')" ><i  class="fa fa-save"></i>&nbsp;保存</el-button>
            <el-button  type="success"  @click="upClk('addForm')" ><i  class="fa fa-cloud-upload"></i>&nbsp;提交</el-button>
            <el-button  type="success"  @click="changSearch1()" ><i  class="fa fa-cloud-upload"></i>&nbsp;查询</el-button>
            <el-button    @click="cancleClk('addForm')" ><i  class="fa fa-remove"></i>&nbsp;取 消</el-button>
          </el-button-group>
        </el-col>
        <el-col :span="7">
          <div class="form-group">
            <div class="input-group">
              <div class="input-group-addon" @click="changeData(-1)"><i class="el-icon-caret-left"></i></div>
              <input type="text" class="form-control" v-model="planTime">
              <div class="input-group-addon" @click="changeData(1)"><i class="el-icon-caret-right"></i></div>
            </div>
          </div>
        </el-col>
        <el-col :span='4'>
          <div class="form-group">
            <div class="input-group">
              <p class="notice">{{ totalNum }}</p>
            </div>
          </div>
        </el-col>
        <el-col :span='6'>
          <div class="form-group">
            <div class="input-group">
              <!--<el-form-item label="商品集" >-->
                <el-select v-model="searchForm.brandSet"  :clearable="true" placeholder="请选择商品集" @change="changSearch()">
                  <template v-for="item in brandSetGroup">
                    <el-option  :key="item.rowId"  :label="item.name" :value="item.rowId"></el-option>
                  </template>
                </el-select>
              <!--</el-form-item>-->
            </div>
          </div>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <div class="editDiv">
        <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
        <el-tabs type="border-card">
          <el-tab-pane label="消费">
            <div>
              <el-form-item label="消费者反馈">
                <el-input type="textarea" resize="none" v-model="dialogObj.data.form.contents.consumer"></el-input>
              </el-form-item>
              <el-form-item label="改进措施">
                <el-input type="textarea" resize="none" v-model="dialogObj.data.form.contents.consumermeasure"></el-input>
              </el-form-item>
              <el-table :data="consumption"  >
                <el-table-column prop="cigProductCd" label="重点卷烟代码" sortable></el-table-column>
                <el-table-column prop="cigProductNm" label="卷烟名称" sortable></el-table-column>
                <el-table-column prop="price1" label="零售指导价（元/条）" sortable></el-table-column>
                <el-table-column prop="Price2" label="市场零售价（元/包）" sortable></el-table-column>
                <el-table-column prop="price3" label="市场零售价（元/条）" sortable></el-table-column>
                <el-table-column prop="price4" label="市场批发价（元/条）" sortable></el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
          <el-tab-pane label="品牌">
            <div>
              <el-form-item label="改进措施">
                <el-input type="textarea" resize="none" v-model="dialogObj.data.form.contents.prdmeasure"></el-input>
              </el-form-item>
              <el-table :data="brands"  >
                <el-table-column prop="cigProductNm" label="重点卷烟代码"   sortable  width="140" ></el-table-column>
                <el-table-column prop="cigProductCd" label="卷烟名称" sortable  width="140"></el-table-column>
                <el-table-column prop="orderQty" label="销量(条)" sortable width="85"></el-table-column>
                <el-table-column prop="rate1" label="环比(%)" sortable></el-table-column>
                <el-table-column prop="orderCoveredRat" label="订货面(%)" sortable></el-table-column>
                <el-table-column prop="rate2" label="环比(%)" sortable></el-table-column>
                <el-table-column prop="fullordCoveredRat" label="订足面(%)" sortable></el-table-column>
                <el-table-column prop="rate3" label="环比(%)" sortable></el-table-column>
                <el-table-column prop="ordFullfilRat" label="订单满足率(%)" sortable width="100"></el-table-column>
                <el-table-column prop="rate4" label="环比(%)" ></el-table-column>
                <el-table-column prop="supUtilizeRat" label="货源利用率(%)" sortable width="100"></el-table-column>
                <el-table-column prop="rate5" label="环比(%)" ></el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
          <el-tab-pane label="客户">
            <div>
              <el-form-item label="未订货原因">
                <el-input type="textarea" resize="none" v-model="dialogObj.data.form.contents.noordreason"></el-input>
              </el-form-item>
              <el-form-item label="改进措施">
                <el-input type="textarea" resize="none" v-model="dialogObj.data.form.contents.noordmeasure"></el-input>
              </el-form-item>
              <el-table :data="customer"  >
                <el-table-column prop="itemDesc" label="指标项" sortable></el-table-column>
                <el-table-column prop="qty" label="指标值" sortable ></el-table-column>
                <el-table-column prop="qtyRate" label="环比(%)" sortable></el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
        </el-tabs>
      </el-form>
      </div>
        </el-col>
      </el-row>
    </el-dialog>
  </div>
</template>

<script>
  import log from '@/log'
  import api from '@/api'
  import axios from 'axios'
  import BasePath from '@/config/BasePath'
  import { dateFormat } from '@/utils/dateFormat.js'
  import {getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      let param = {} // 客户集
      param.whereClause = 'and def_ou_id= ' + getUser().companyId + ' and scope=1 or def_person_id=' + getUser().personId
      axios.all([
        api.requestJava('POST', BasePath.CIGCATEGORYS_SELECTLIST, param)
      ])
      .then(axios.spread((first) => {
        this.brandSetGroup = first.data.data
      }))
    },
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        if (this.dialogObj.data.form.periodId === '') {
          this.initDate('date', dateFormat(new Date().getTime(), 'YYYYMMDD'))
        } else {
          this.initDate('id', this.dialogObj.data.form.periodId)
        }
      }
    },
    data () {
      return {
        isLoading: true,
        brandSetGroup: [],
        monthText: '111',
        totalNum: '状态：',
        planTime: '',
        addrules: {},
        consumption: [],
        brands: [],
        customer: [],
        timeDate: {},
        searchForm: {
          companyId: '',
          objectCd: '',
          brandSet: ''
        },
        edit: {
          title: '分析品牌选择',
          type: '3',
          dialogVisible: false,
          size: 'small',
          data: {
            form: {
              goods: []
            }
          }
        }
      }
    },
    methods: {
      changSearch () {
        this.dialogObj.data.form.contents.brandSet = this.searchForm.brandSet
        this.consumption = []
        this.brands = []
        this.customer = []
        this.findConsumptionByUpper()
        this.findBrandsByUpper()
        this.getNextData(this.searchForm.dtLastweekId)
      },
      changSearch1 () {
        if (this.searchForm.brandSet !== '') {
          this.changSearch()
        } else {
          this.$message({type: 'info', message: '请先选择商品集。'})
        }
      },
      query () {
        let params = {}
        params.objectType = '1'
        params.objectCd = this.searchForm.objectCd
        params.periodId = this.searchForm.dtWeekId
        console.log('params-query', JSON.stringify(params))
        this.queryUpper(params)
      }, // 查询方法
      queryUpper (params) {
        api.requestJava('POST', BasePath.WEEKORDERREPORT_SELECT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              let rows = request.data.data
              if (rows.length > 0) {
                this.dialogObj.data.form = request.data.data[0]
                this.dialogObj.data.form.contents = JSON.parse(request.data.data[0].contents)
                this.searchForm.brandSet = this.dialogObj.data.form.contents.brandSet
                if (Number(this.dialogObj.data.form.status) === 0) {
                  this.totalNum = '状态：撰写'
                } else if (Number(this.dialogObj.data.form.status) === 1) {
                  this.totalNum = '状态：提交'
                } else {
                  this.totalNum = '状态：作废'
                }
                if (this.searchForm.brandSet !== '') {
                  this.changSearch()
                }
              } else {
                this.dialogObj.data.form.rowId = ''
                this.dialogObj.data.form.periodId = this.timeDate.dtWeekId
                this.dialogObj.data.form.objectType = '1'
                this.dialogObj.data.form.objectId = getUser().personId
                this.dialogObj.data.form.objectCd = getUser().userCode
                this.dialogObj.data.form.objectNm = getUser().userName
                this.dialogObj.data.form.otherPr = ''
                this.dialogObj.data.form.reportorId = getUser().personId
                this.dialogObj.data.form.reportorNm = getUser().userName
                this.dialogObj.data.form.title = this.timeDate.dtWeekNm + getUser().userName + '周分析报告'
                this.dialogObj.data.form.status = '0'
                this.dialogObj.data.form.fbNum = '0'
                this.dialogObj.data.form.cEval = '0.0'
                this.dialogObj.data.form.deptname = getUser().deptName
                this.dialogObj.data.form.periodName = this.timeDate.dtWeekNm
                this.dialogObj.data.form.companyId = getUser().companyId
                this.dialogObj.data.form.countyDept = getUser().countyId
                this.dialogObj.data.form.creatBy = getUser().personId
                this.totalNum = '状态：撰写'
                this.dialogObj.data.form.contents = {}
                this.dialogObj.data.form.contents.consumer = ''
                this.dialogObj.data.form.contents.consumermeasure = ''
                this.dialogObj.data.form.contents.prdmeasure = ''
                this.dialogObj.data.form.contents.noordreason = ''
                this.dialogObj.data.form.contents.noordmeasure = ''
                this.dialogObj.data.form.contents.brandSet = ''
                if (this.searchForm.brandSet !== '') {
                  this.changSearch()
                }
              }
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      chuckCus () {
        this.edit.dialogVisible = true
      },
      handleClick (tab, event) {
        console.log(tab, event)
      },
      changeData (num) {
        if (Number(num) === 1) {
          this.initDate('dtLastweekId', this.searchForm.dtWeekId)
        } else {
          this.initDate('id', this.searchForm.dtLastweekId)
        }
      },
      getNextData (dtWeekId) {
        let params = {}
        params.dtWeekId = dtWeekId
        params.orgCompanyId = getUser().companyId
        api.requestJava('POST', BasePath.WEEKORDERREPORT_QUARTER_SELECTONE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.timeDate = request.data.data
              let param = {}
              param.objectCd = this.searchForm.objectCd
              param.startDate = this.searchForm.startTime
              param.endDate = this.searchForm.endTime
              param.upDate = request.data.data.beginDt
              param.nextDate = request.data.data.endDt
              this.findCustomerByUpper(param)
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      initDate (type, time) {
        let params = {}
        if (type === 'date') {
          params.whereClause = 'and ( ' + time + ' between begin_Dt and end_Dt )'
        } else if (type === 'id') {
          params.dtWeekId = time
        } else {
          params.dtLastweekId = time
        }
        params.orgCompanyId = getUser().companyId
        console.log('params_save', JSON.stringify(params))
        api.requestJava('POST', BasePath.WEEKORDERREPORT_QUARTER_SELECTONE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (request.data.data === '') {
                let end1 = this.timeDate.endDt + ''
                this.$message({type: 'info', message: '货源周期截止至' + end1.substr(0, 4) + '-' + end1.substr(4, 2) + '-' + end1.substr(6, 2) + '。'})
                return
              }
              this.timeDate = request.data.data
              let begin = this.timeDate.beginDt + ''
              let end = this.timeDate.endDt + ''
              this.planTime = begin.substr(0, 4) + '-' + begin.substr(4, 2) + '-' + begin.substr(6, 2) + '至' + end.substr(0, 4) + '-' + end.substr(4, 2) + '-' + end.substr(6, 2)
              this.searchForm.companyId = getUser().companyId
              this.searchForm.objectCd = getUser().userCode
              this.searchForm.objectId = getUser().personId
              this.searchForm.dtLastweekId = this.timeDate.dtLastweekId
              this.searchForm.dtWeekId = this.timeDate.dtWeekId
              this.searchForm.startTime = this.timeDate.beginDt
              this.searchForm.endTime = this.timeDate.endDt
              this.query()
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      findConsumptionByUpper () {
        let param = {}
        param.brandSet = this.searchForm.brandSet
        param.companyId = this.searchForm.companyId
        param.startDate = this.searchForm.startDate
        param.endDate = this.searchForm.endDate
        api.requestJava('POST', BasePath.WEEKORDERREPORT_CONSUMPTION, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.consumption = request.data.data
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      findBrandsByUpper () {
        let param = {}
        param.brandSet = this.searchForm.brandSet
        param.custMgrId = this.searchForm.objectId
        param.dtLastweekId = this.searchForm.dtLastweekId
        param.dtWeekId = this.searchForm.dtWeekId
        api.requestJava('POST', BasePath.WEEKORDERREPORT_BRANDS, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.brands = request.data.data
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      findCustomerByUpper (param) {
        api.requestJava('POST', BasePath.WEEKORDERREPORT_CUSTOMER, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.customer = request.data.data
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      },
      getNowTime () {
        return dateFormat(new Date().getTime(), 'YYYY-MM-DD')
      },  // 时间格式化
      updateClk (formName) {
        if (Number(this.dialogObj.data.form.status) === 1) {
          this.$message({type: 'info', message: '该记录已提交，不可修改!'})
          return
        }
        if (this.searchForm.brandSet === '') {
          this.$message({type: 'info', message: '品牌集不能为空!'})
          return
        }
        this.isLoading = true
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      upClk (formName) {
        if (Number(this.dialogObj.data.form.status) === 1) {
          this.$message({type: 'info', message: '该记录已提交，不可修改!'})
          return
        }
        if (this.searchForm.brandSet === '') {
          this.$message({type: 'info', message: '品牌集不能为空!'})
          return
        }
        this.isLoading = true
        this.dialogObj.data.form.status = '1'
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      }
    },
    components: {
    }
  }
</script>
