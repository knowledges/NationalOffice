<template>
  <li :class="isFolder ? 'treeview' : 'pageLink'">
    <template v-if="model.resUrl != ''">
      <router-link :to="levelRouter(model)" @click.native="toggleMenu(model)">
        <i :class="model.resSicon"></i>
        <span :class="isFolder ?'pull-right-container':'page'">
          {{model.resName}}
          <i :class="isFolder && 'fa fa-angle-left fa-fw pull-right'"></i>
        </span>
      </router-link>
      <ul class="treeview-menu">
        <sidebar-menu :model="slide" v-for="(slide, key) in model.children" :key="key"/>
      </ul>
    </template>
    <template v-else>
      <a href="#" class="clearfix">
        <i :class="model.resSicon"></i>
        <span :class="isFolder ?'pull-right-container':'page'">
          {{model.resName}}
          <i :class="isFolder && 'fa fa-angle-left fa-fw pull-right'"></i>
        </span>
      </a>
      <ul class="treeview-menu">
        <sidebar-menu :model="item" v-for="(item, idx) in model.children" :key="idx"/>
      </ul>
    </template>
  </li>
</template>
<script>
  import { mapState } from 'vuex'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import { getUser } from '@/config/info'
  import { dateFormat } from '@/utils/dateFormat.js'
  export default {
    name: 'sidebarMenu',
    props: ['model'],
    mounted () { },
    data () {
      return {
        setParms: ['MapMonitor', 'MaterielQuery', 'MaterielAdd', 'MaterielReceive', 'MaterielGrant', 'CustomSurvey', 'SurveyCount', 'QuarterCustSalesAnalysisEdit'], // 带参路由 - 包含 【二级、三级】
        setDataViz: ['DatavizCustom', 'VizDataAnalysis'],
        index: null
      }
    },
    methods: {
      toggleMenu (obj) {
        /* 是 DataViz 内容 直接open 新页面 */
        if (this.setDataViz.indexOf(obj.resCode) >= 0) {
          window.open(obj.resUrl)
          return
        }
        let sessionMenus = !sessionStorage.getItem('sessionMenus') ? sessionMenus = [] : JSON.parse(sessionStorage.getItem('sessionMenus'))
        if (Number(sessionMenus.length) === 0) {
          sessionMenus.push(obj)
        } else {
          let isAdd = false
          for (let i in sessionMenus) {
            if (sessionMenus[i].resName.indexOf(obj.resName) >= 0) {
              isAdd = true
            }
          }
          if (!isAdd) {
            if (Number(sessionMenus.length) < 5) {
              sessionMenus.push(obj)
            } else {
              sessionMenus.splice(0, 1)
              sessionMenus.push(obj)
            }
          }
        }
        sessionStorage.setItem('sessionMenus', JSON.stringify(sessionMenus))
        this.$store.dispatch('setSessionMenus', JSON.stringify(sessionMenus))
        /* 记录每一个被点击模块的 */
        var returnCitySN = JSON.parse(localStorage.getItem('returnCitySN'))
        var GetOSInfo = localStorage.getItem('GetOSInfo')
        var params = {}
        params.companyId = getUser().companyId
        params.deptId = getUser().deptId
        params.userId = getUser().id
        params.userName = getUser().userName
        params.opdate = dateFormat(new Date().getTime(), 'YYYY-MM-DD')
        params.optime = dateFormat(new Date().getTime(), 'YYYY-MM-DD HH:mm:ss')
        params.ipAddr = returnCitySN.cip
        params.machineName = GetOSInfo
        params.programId = obj.id
        params.programName = obj.resName
        console.log(params)
        api.requestJava('POST', BasePath.OPLOG_INSERT, params)
          .then((response) => {
            if (Number(response.data.code) === 200) {
              console.log()
            }
          })
      },
      levelRouter (obj) {
        let isTrue = true
        if (~this.setParms.indexOf(obj.resCode)) {
          isTrue = false
        }
        if (isTrue) {
          return {name: obj.resCode}
        } else {
          let uId = -1
          if (obj.resCode === 'CustomSurvey') {
            uId = 0
          } else if (obj.resCode === 'MaterielAdd') {
            uId = 11
          } else if (obj.resCode === 'MaterielReceive') {
            uId = 22
          } else if (obj.resCode === 'MaterielGrant') {
            uId = 21
          }
          this.$set(obj, 'params', { uId: uId })
          return {name: obj.resCode, params: { uId: uId }}
        }
      }
//      secondLevelRouter (obj) {
//        console.log(obj)
//        let isTrue = true
//        if (~this.setParms.indexOf(obj.resCode)) {
//          isTrue = false
//        }
//        if (isTrue) {
//          return {name: obj.resCode, routerLinkActive: 'active'}
//        } else {
//          let uId = -1
//          if (obj.resCode === 'CustomSurvey') {
//            debugger
//            uId = 0
//          }
//          this.$set(obj, 'params', { uId: uId })
//          return {name: obj.resCode, params: { uId: uId }, routerLinkActive: 'active'}
//        }
//      }, // 二级路由动态设置
//      threeLevel (obj) {
//        console.log(obj.children)
//        let isTrue = true
//        if (~this.setParms.indexOf(obj.resCode)) {
//          isTrue = false
//        }
//        if (isTrue) {
//          return {name: obj.resCode}
//        } else {
//          let uId = 0
//          if (obj.resCode === 'MaterielAdd') {
//            uId = 11
//          } else if (obj.resCode === 'MaterielReceive') {
//            uId = 22
//          } else if (obj.resCode === 'MaterielGrant') {
//            uId = 21
//          }
//          this.$set(obj, 'params', { uId: uId })
//          return {name: obj.resCode, params: { uId: uId }}
//        }
//      } // 三级路由动态设置
    },
    computed: {
      ...mapState([
        'powerMenu'
//        'routeIdx'
      ]),
      isFolder: function () {
        return this.model.children && this.model.children.length
      }
    }
  }
</script>
<style>
  /* override default */
  .sidebar-menu > li > a {
    padding: 12px 15px 12px 15px;
  }

  .sidebar-menu li.active > a > .fa-angle-left, .sidebar-menu li.active > a > .pull-right-container > .fa-angle-left {
    animation-name: rotate;
    animation-duration: .2s;
    animation-fill-mode: forwards;
  }

  @keyframes rotate {
    0% {
      transform: rotate(0deg);
    }

    100% {
      transform: rotate(-90deg);
    }
  }
</style>
<style scoped>
  .pull-right {
    position: absolute;
    right: 15px;
    float: none!important;
  }
</style>
