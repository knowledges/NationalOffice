<template>
  <div class="container-fluid" id="app">
    <el-row :gutter="22" class="cust_el_row">
      <el-row :gutter="24" class="cust_row_l">
        <el-col :span="4"  class="cust_el_col">
          <button class="btn cust_btn_l" @click="showTreeClk">
            <i class="fa fa-angle-double-left" v-if="isTree"></i>
            <i class="fa fa-angle-double-right" v-if="!isTree"></i>
          </button>
        </el-col>
        <transition name="moveL">
          <el-col :span="20" class="cust_el_col cust_btn_box moveCust"  v-if="isTree">
            <div class="events-list">
              <p>日程明细：</p>
              <ul>
                <li v-for="(eventItem, index) in events">
                  {{ eventItem.start }}~{{ eventItem.end }}: {{ eventItem.content }}
                  <button type="button" name="button" @click="removeEvent(index)">x</button>
                </li>
              </ul>
            </div>
          </el-col>
        </transition>
      </el-row>
      <el-col :span="22" class="cust_el_col" style="margin-left: 8%">
        <div class="grid-content bg-purple">
          <simple-fullcalendar :events="events" @timeRangeSelected="addEvent2Events"></simple-fullcalendar>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import moment from 'moment'
import simpleFullcalendar from '@/components/CustomerService/PriceCollection/CycleSet/simple-fullcalendar'
const FORMATTER = 'YYYY-MM-DD'
let TODAY = moment()
export default {
  name: 'app',
  components: {
    simpleFullcalendar
  },
  data () {
    return {
      isTree: false,
      cache: {
        start: '',
        end: '',
        content: ''
      },
      events: [{
        start: TODAY.format(FORMATTER),
        end: TODAY.clone().add(1, 'day').format(FORMATTER),
        content: 'wow ~~~'
      }, {
        start: TODAY.format(FORMATTER),
        end: TODAY.clone().add(7, 'day').format(FORMATTER),
        content: 'so nice a simple fullcalendar with vue2 ~~~'
      }],
      today: TODAY.format(FORMATTER)
    }
  },
  methods: {
    showTreeClk () {
      this.isTree = !this.isTree
    },
    clearCache () {
      this.cache.start = ''
      this.cache.end = ''
      this.cache.content = ''
    },
    removeEvent (index) {
      this.events.splice(index, 1)
    },
    addEvent2Events (event) {
      let content = window.prompt(`${event.start} ~ ${event.end}`)
      if (content && content.length) {
        this.events.push(Object.assign(event, {
          content
        }))
      }
    }
  }
}
</script>


<style scoped rel="stylesheet/scss" lang="scss">
  #app{
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #2c3e50;
  }
  .moveCust {
    height: 590px;
    background-color: white;
  }
  .grid-content {
    border-radius: 4px;
    min-height: 36px;
    box-shadow: 1px 1px 4px #ccc;
    height: 590px;
  }
  .header {
    text-align: center
  }
  .events-list {
    width: 100%;
    margin: 0 auto;
  }
  .cust_row_l{
    position: absolute;
    top:0;
    left: 10px;
    z-index:9;
    width: 315px;
    border: none;
  }
  .cust_btn_box {
    box-shadow: 2px 3px 6px #666;
    padding: 0!important;
  }
  .cust_btn_l{
    background: #fff;
    border-radius: 50%;
    box-shadow: 2px 2px 5px #999;
    position: absolute;
    top: 50%;
    left: 0;
    margin-top: -18px;
  }
  .moveL-enter-active {
    animation: moveL-in .5s;
  }
  .moveL-leave-active {
    animation: moveL-in .5s reverse;
  }
  @keyframes moveL-in {
    0% {
      transform: translate(-315px, 0px);
    }
    80% {
      transform: translate(25px, 0px);
    }
    100% {
      transform: translate(-5px, 0px);
    }
  }
</style>
