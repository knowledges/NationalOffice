<!--qiu.bl-->
<style rel="stylesheet/scss" lang="scss" scoped>
  .el-form-item {
    margin: 0 0;
    .el-form-item__label {
      width: 100px;
    }
  }
</style>
<template>
  <el-row class="filter_style">
    <el-form ref="form" :model="form" label-width="80px">
      <el-col :gutter="24" style="padding: 0 0">
        <el-col :span="6">
          <el-form-item label="市场经理">
            <el-select v-model="form.mktMgrId" :clearable="true" placeholder="请选择市场经理"  @change="getCustomerManager(form.mktMgrId)">
              <template v-for="(item, key) in marketArr">
                <el-option :label="item.employeeName" :value="item.rowId" :key="item.rowId"></el-option>
              </template>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="客户经理">
            <el-select v-model="form.custMgrId" :clearable="true" placeholder="请选择客户经理" :disabled="place == 24 ? false : 'true' ">
              <template v-for="(item, key) in customerArr">
                <el-option :label="item.employeeName" :value="item.rowId" :key="item.rowId"></el-option>
              </template>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label="活动选择">
            <el-select v-model="form.planId" :clearable="true" placeholder="请选择活动">
              <template v-for="(item, key) in activedArr">
                <el-option :label="item.title" :value="item.planId" :key="item.planId"></el-option>
              </template>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="4">
          <el-button type="success" @click="onSubmit">查询</el-button>
          <!--<el-button type="success" @click="exportClk">导出Excel</el-button>-->
        </el-col>
      </el-col>
    </el-form>
  </el-row>
</template>
<script>
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import { getUser } from '@/config/info'
  export default {
    name: 'Selection',
    props: {},
    mounted () {
      this.getMarketManager({})
      this.getAvtived(this.$route.params.fromId, this.$route.params.companyId)
      this.getSuperior()
    },
    data () {
      return {
        form: {
          formId: this.$route.params.fromId,
          companyId: this.$route.params.companyId,
          planId: '', // 活动Id
          custMgrId: '', // 客户经理Id
          mktMgrId: ''
        },
        marketArr: [],
        customerArr: [],
        activedArr: [],
        place: getUser().place
      }
    },
    methods: {
      init (params) {
        params.fields = {include: 'employeeName,rowId'}
        params.county_dept = getUser().companyId
        params.status = 1
        return new Promise((resolve, reject) => {
          api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                return resolve(request)
              }
            })
            .catch((err) => {
              this.isTrue = false
              this.$notify.error({title: '人员列表反回失败', message: err})
              console.error(err)
            })
        })
      },
      getMarketManager () {
        this.init({place: 24})
          .then((request) => {
            this.marketArr = request.data.data
          })
      }, // 获取市场经理列表
      getCustomerManager (val) {
//        this.form.custMgrId = ''
        this.customerArr = []
        let params = {}
        params.manager = val
        params.place = 135
        this.init(params)
          .then((request) => {
            this.customerArr = request.data.data
          })
      },
      getAvtived (fromId, companyId) {
        let params = {}
        params.formsId = fromId
        params.companyId = companyId
        api.requestJava('POST', BasePath.FW_COMMON_SELECTPLANSBYFORMID, params)
          .then((request) => {
            this.activedArr = request.data.data
            console.log('activedArr', this.activedArr)
          })
          .catch((err) => {
            this.isTrue = false
            this.$notify.error({title: '人员列表反回失败', message: err})
            console.error(err)
          })
      },
      onSubmit () {
        console.log('数据：', this.form)
        this.$emit('callback', JSON.stringify(this.form))
      },
      exportClk () {
        this.$emit('export')
      },
      getSuperior () {
        if (Number(getUser().place) === 24) {
          this.form.mktMgrId = getUser().personId
        } else if (Number(getUser().place) === 135) {
          this.form.custMgrId = getUser().personId
          api.requestJava('POST', BasePath.EMPLOYEE_SELECTONE, {fields: {'include': 'manager'}, rowId: getUser().personId})
            .then((request) => {
              if (request.data.data.manager !== '') {
                this.form.mktMgrId = request.data.data.manager
              }
            })
        }
      }
    },
    components: {},
    watch: {}
  }
</script>
