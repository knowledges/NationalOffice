<!-- 徐晓菁 -->
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false">
    <el-form :model="dialogObj.data.form" label-width="80px" ref="query" :rules="addrules">
      <el-row>
        <el-col :gutter="24">
          <el-col :span='12'>
            <el-form-item label="卷烟代码">
              <el-input  v-model="dialogObj.data.form.goodsCode"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='12' >
            <el-form-item label="卷烟名称">
              <el-input  v-model="dialogObj.data.form.goodsDesc"></el-input>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
      <el-row>
        <el-col :gutter="24">
          <el-col :span='12' >
            <el-form-item label="简码">
              <el-input  v-model="dialogObj.data.form.shortCode"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='12'>
            <el-form-item  prop="orderMethod" label="等级" >
              <el-select v-model="dialogObj.data.form.goodsGrade" :clearable="true" placeholder="请选择卷烟级别">
                <template v-for="item in dialogObj.data.form.goodsGradeGroupCode">
                  <el-option  :key="item.rowId"  :label="item.gradeDesc" :value="item.rowId"></el-option>
                </template>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
      <!--<el-row>-->
        <!--<el-col :gutter="24">-->
          <!--<el-col :span='12' >-->
            <!--<el-form-item prop="customerGrade" label="显示停用">-->
              <!--<el-switch on-text="" off-text="" v-model="dialogObj.data.form.status"></el-switch>-->
            <!--</el-form-item>-->
          <!--</el-col>-->
          <!--<el-col :span='12' >-->
            <!--<el-form-item prop="batchNo" label="显示罚没烟">-->
              <!--<el-switch on-text="" off-text="" v-model="dialogObj.data.form.isConfiscated"></el-switch>-->
            <!--</el-form-item>-->
          <!--</el-col>-->
        <!--</el-col>-->
      <!--</el-row>-->
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
      <el-button @click="clearClk('clear')">重 置</el-button>
      <el-button type="success" @click="updateClk('query')">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
//  import api from '@/api'
//  import axios from 'axios'
//  import BasePath from '@/config/BasePath'
  export default {
    props: ['dialogObj'],
    mounted () {
//      axios.all([
//        api.requestJava('POST', BasePath.SELECT_GOODSGRADEGROUP, {'gradeType': '1'})
//      ])
//      .then(axios.spread((first) => {
//        this.goodsGradeGroupCode = JSON.parse(JSON.stringify(first.data.data))
//      }))
    },
    data () {
      return {
        goodsGradeGroupCode: [],
        addrules: {
        },
        value: '',
        form: {}
      }
    },
    methods: {
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      },
      updateClk (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$emit('confirmBack', 'query')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      clearClk (formName) {
        let selectTmp = {
          title: '查询条件选择',
          type: 'selectCommodityManagement',
          dialogVisible: false,
          size: 'small',
          data: {
            form: {
              goodsCode: '',
              goodsDesc: '',
              goodsGrade: '',
              status: '',
              isConfiscated: '',
              shortCode: ''
            }
          }
        }
        Object.assign(this.dialogObj, selectTmp)
        this.dialogObj.dialogVisible = true
      }
    }
  }
</script>

