<style scoped>
  .cust_el_col{
    display: inline-block;
    height:calc(100vh - 185px);
  }
  .cust_row_r{
    display: flex;
    flex: 1;
    /*position: absolute;*/
    /*top: 9%;*/
    /*right: 20px;*/
    /*z-index:1;*/
    /*width: 615px;*/
    /*border: none;*/
  }
  .cust_btn_box1 {
    position: absolute;
    top: 40px;
    width: 600px;
    height: calc(100vh - 120px);
    overflow-y: auto;
    background: #fff;
    right: 0px;
    box-shadow: -2px 3px 6px #666;
    padding: 0!important;
  }
  .cust_btn_box {
    position: absolute;
    top: 40px;
    width: 420px;
    height: calc(100vh - 120px);
    overflow-y: auto;
    background: #fff;
    right: 0px;
    box-shadow: -2px 3px 6px #666;
    padding: 0!important;
  }
  .cust_btn_r{
    background: #00b234;
    -webkit-box-shadow: 2px 2px 5px #008627;
    box-shadow: 2px 2px 5px #008627;
    position: absolute;
    top: 50%;
    right: 5%;
    margin-top: -18px;
    z-index: 9;
  }
  .cust_btn_r i {
    font-size: 18px;
    color: #FFF;
  }
  .grid-content {
    background: #FFF;
    box-shadow: none;
  }
  .moveR-enter-active {
    animation: moveR-in .5s;
  }
  .moveR-leave-active {
    animation: moveR-in .5s reverse;
  }
  @keyframes moveR-in {
    0% {
      transform: translate(520px, 0px);
    }
    80% {
      transform: translate(-20px, 0px);
    }
    100% {
      transform: translate(0px, 0px);
    }
  }
</style>
<template>
  <div style="height: 100%;">
    <el-row :gutter="22" class="cust_el_row" style="margin: 0 0; height: 100%;">
      <el-col :span="22" class="cust_el_min" id="el-col-map" style="padding: 0 0; height: 100%;">
          <_Map :coors="coors" :zoom="zoom" :place="place" :coorGroup="coorGroup" ref="childs"></_Map>
      </el-col>
      <el-row :gutter="24" class="cust_row_r">
        <transition name="moveR">
          <el-col :span="20" :class="place != 24 && place != 135 ? 'cust_btn_box1' : 'cust_btn_box'" v-show="isTree">
            <div class="grid-content">
              <_VisitingLog @confirmBack="confirmBack_base"></_VisitingLog>
            </div>
          </el-col>
        </transition>
        <el-col :span="2"  class="cust_el_col">
          <button class="btn cust_btn_r" @click="showTreeClk">
            <i class="fa fa-angle-double-left" v-if="!isTree"></i>
            <i class="fa fa-angle-double-right" v-if="isTree"></i>
          </button>
        </el-col>
      </el-row>
    </el-row>
  </div>
</template>
<script>
  import {getUser} from '@/config/info'
  import _Map from '@/components/Template/Map/Map.vue'
  import _VisitingLog from '../../System/Other/Map/Monitor/MarketVisitingLog.vue'
  export default {
    name: 'Home',
    mounted () {
      document.getElementById('el-col-map').style.height = document.documentElement.clientHeight - 80 + 'px'
      this.coors = []
    },
    data: () => ({
      zoom: 12, // 根据百度地图变焦值（3-18）默认 12
      coors: [],
      coorGroup: [],
      place: Number(getUser().place), // 135 客戶經理 或者 24 市場經理
      isTree: true
    }),
    methods: {
      showTreeClk () {
        this.isTree = !this.isTree
      },
      confirmBack_base (msg) {
        this.coors = msg
      }
    },
    components: {
      _Map, _VisitingLog
    }
  }
</script>
