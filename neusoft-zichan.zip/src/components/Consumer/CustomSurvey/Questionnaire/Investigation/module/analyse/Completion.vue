<!--  Auther:luoshuo -->
<!--  填空题分析 -->
<template>
  <div>
    <div class="completionTitle">
      <div>{{idx + 1}}、{{question.itemTitle}}[填空题]</div>
    </div>
    <div>
      <div class="answerCount">回答数：{{question.total}}条</div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    question: {
      type: Object,
      required: true
    },
    idx: Number
  }
}
</script>
<style>
.completionTitle {
  color: #625F5F;
  font-size: x-large;
  display: inline-block;
}
.answerCount {
  color: rgb(155, 150, 150);
  font-size: large;
  padding: 20px;
}
</style>
