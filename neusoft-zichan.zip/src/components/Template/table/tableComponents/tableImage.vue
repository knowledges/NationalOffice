<!--qiu.bl-->
<style rel="stylesheet/scss" lang="scss" scoped>
  .thumbnail{
    width: 100%;
    cursor: zoom-in;
  }
  .modal{
    position: fixed;
    top: 0;
    width: 100%;
    height: 100%;
    z-index: 9;
    background: rgba(0,0,0,0.3);
    display: inline-block;
  }
  .popoClk{
    position: absolute;
    z-index: 2;
    width: 100%;
    height: 100%;
    opacity: 0;
    background: rgba(0,0,0,0);
  }
</style>
<template>
  <div v-if="col.meta == 'qrcode'"  id="code">
  </div>
  <div v-else>
    <el-popover
      ref="popover4"
      placement="right"
      trigger="hover">
      <img src="" alt="">
    </el-popover>
    <el-button v-popover:popover4 class="popoClk">click 激活</el-button>
    <img v-model="row[col.prop]" :src="prefix+row.image+Suffix" class="thumbnail" alt="">
  </div>
</template>
<script>
  import $ from 'jquery'
  require('static/js/plugins/jQuery/jquery.qrcode.min')
  import config from '@/config'
  export default {
    name: 'tableImage',
    props: {
      row: Object,
      col: Object,
      data: Array
    },
    mounted () {
      this.$nextTick(() => {
        this.qrcode()
      })
    },
    data () {
      return {
        prefix: 'http://js.xinshangmeng.com/xsm6/resource/ec/cgtpic/',
        Suffix: '_middle_face.png?v=2017112500'
      }
    },
    methods: {
      amplifierClk (url) {},
      qrcode () {
        $('#code').qrcode({
          text: config.FILE_ADDR + this.row.appPath,
          width: 200,
          height: 200
        })
      }
    },
    components: {},
    watch: {}
  }
</script>
