<style scoped>
  .cust_row_r{
    position: absolute;
    top:0;
    right: 20px;
    z-index:1;
    width: 315px;
    border: none;
  }
  .cust_btn_box {
    box-shadow: -2px 3px 6px #666;
    padding: 0!important;
  }
  .cust_btn_r{
    background: #fff;
    border-radius: 50%;
    box-shadow: 2px 2px 5px #999;
    position: absolute;
    top: 50%;
    right: 0;
    margin-top: -18px;
  }
  .moveR-enter-active {
    animation: moveR-in .5s;
  }
  .moveR-leave-active {
    animation: moveR-in .5s reverse;
  }
  @keyframes moveR-in {
    0% {
      transform: translate(250px, 0px);
    }
    80% {
      transform: translate(-40px, 0px);
    }
    100% {
      transform: translate(0px, 0px);
    }
  }
</style>
<template>
  <div class="container-fluid" id="customer">
    <el-row class="filter_style">
      <el-col :span="2" style="padding: 0 0; float: right;">
        <button class="btn btn-success" @click="getDialogMarkerClk">客户分布</button>
      </el-col>
      <el-col :span="22" style="padding: 0 0; float: right;">
        <_BTN_FILTER :isMore="isMore" :fileName="filName" :btnGroups="btnGroups" :filterMethod="inputChange"
                     :tableData="tableData" @on-click="exportEve"/>
      </el-col>
    </el-row>
    <el-row :gutter="24" class="cust_el_row">
      <div>
      <el-col :span="6" v-if=isShow>
        <div class="bg-purple">
          <_TREECOMPONENT :search=searchable :data='treeData' :nodeClick='showTree' :nodeKey="nodeKey"
                          :expandAll=expandAll :expandedKey="expandedKey" ref='tree' :highlight='true' :visible='isTree'
                          :defaultCheckedKeys="defaultCheckedKeys"></_TREECOMPONENT>
        </div>
      </el-col>
      <el-col :span="isShow === false ? 24:18" >
        <tableVue
          ref="tableGrid"
          stripe
          maxHeight="500"
          :data="dataSource"
          :columns="columns"
          @update:data="tabChange" :reqParams="reqParams"
          :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
          :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.getPage></tableVue>
      </el-col>
      </div>
    </el-row>
    <_POPUP :dialogObj='dialogObj' @confirmBack="confirmBack" v-popupdra-directive="{'show': dialogObj.dialogVisible}"/>
    <_DetailPopup :dialogObj='dialogObj_base'/>
    <DIALOG_PLAN_MAP ref="marker" :open="open" :isShow="dataFilterShow" :coors="distData"/>
  </div>
</template>
<script>
  import tableVue from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import api from '@/api'
  import log from '@/log'
  import _TREECOMPONENT from '@/components/Template/Tree/Tree.vue'
  import _POPUP from './Popup.vue'
  import _DetailPopup from '@/components/System/Other/Map/Monitor/DetailPopup.vue'
  import DIALOG_PLAN_MAP from '@/components/CustomerService/CustomerSetting/VisitPlan/DialogPlanMap.vue'
  import {getUser, getCodeList} from '@/config/info'
  import BasePath from '@/config/BasePath'
  import { changeListValueByCode } from '@/utils/common'
  import axios from 'axios'
  export default {
    mounted () {
      console.log(this)
      if (Number(getUser().place) === 135 || Number(getUser().place) === 24) {
        this.isShow = false
      } else {
        this.isShow = true
      }
      getCodeList('YC_GEO_TYPE', (data) => {
        this.geoType = data.label
      })
      getCodeList('YC_GEO_TYPE', (data) => {
        this.changeValueDate.geoType.group = data
      }) // 市场类型
      getCodeList('YC_BUSINESS_TYPE', (data) => {
        this.changeValueDate.businessType.group = data
      }) // 零售业态
      getCodeList('YC_OPERATION_SCALE', (data) => {
        this.changeValueDate.operationScale.group = data
      }) // 经营规模
      getCodeList('CUSTOMER_GRADE', (data) => {
        this.changeValueDate.customerGrade.group = data
      }) // 客户级别
      let custMgrParam = {} // 客户经理
      if (getUser().place === '24') {
        custMgrParam.countyDept = getUser().countyId
        custMgrParam.manager = getUser().personId
        custMgrParam.fields = {include: 'rowId'}
      }
      let _this = this
      let custmgrParam = {} // 客户经理
      custmgrParam.place = '135'
      custmgrParam.companyId = getUser().companyId
      custmgrParam.countyDept = getUser().countyId
      custmgrParam.fields = {include: 'employeeName,rowId'}
      custmgrParam.status = 1
      axios.all([
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, custmgrParam), // 客户经理
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, custMgrParam) // 客户经理
      ])
        .then(axios.spread(function (_custmgrId, _custMgrId) {
          _this.changeValueDate.custmgrId.group = _custmgrId.data.data
          _this.customerMgrIds = _custMgrId.data.data
          console.log(JSON.stringify(_this.changeValueDate.custmgrId))
          _this.init()
          _this.treeInit()
        }))
    },
    data () {
      return {
        open: false, // 默认prop 隐藏
        dataFilterShow: false, // 日期过滤 不显示
        distData: [], // 客户分布的数据集
        customerMgrIds: [],
        expandedKey: [], // 默认展开的数组
        queryParams: {},
        isTree: false,
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        selectSells: [],
        totalCount: 0, // 表格总记录数
        hasPagination: true, // 是否有分页
        columns: [ // 表格列
          { label: '许可证号', prop: 'permitNo', columnsProps: {width: 140} },
          { label: '客户代码', prop: 'customerCode', columnsProps: {width: 140} },
          { label: '客户名称', prop: 'customerDesc', columnsProps: {width: 300} },
          { label: '法人', prop: 'legalPerson', columnsProps: {width: 120} },
          { label: '电话', prop: 'tel', columnsProps: {width: 140} },
          { label: '客户经理', prop: 'custmgrId', columnsProps: {width: 140, formatter: this.colFormatter_change, sortable: true} },
          { label: '客户级别', prop: 'customerGrade', columnsProps: {width: 100, formatter: this.colFormatter_change} },
          { label: '市场类型', prop: 'geoType', columnsProps: {width: 100, formatter: this.colFormatter_change} },
          { label: '零售业态', prop: 'businessType', columnsProps: {width: 100, formatter: this.colFormatter_change} },
          { label: '销售规模', prop: 'operationScale', columnsProps: {width: 100, formatter: this.colFormatter_change} },
          { label: '客户星级', prop: 'starGrade', columnsProps: {width: 100} },
          { label: '操作', prop: 'operation', columnsProps: {width: 200, type: 'button', textAlign: 'center'}, cptProperties: [{ label: '详情', icon: 'search', value: 'look', type: 'success', size: 'small', eventClick: this.searchDetail }, { label: '修改', icon: 'edit', value: 'modify', type: 'warning', size: 'small', eventClick: this.handleModify }] }
        ],
        data: [],
        tableData: [],
        dataSource: [], // 当前页的数据
        /** filter **/
        filmode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        filType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        filName: ['customerCode', 'customerDesc', 'contactperson'],
        isMore: true,
        keyupend: false,   // 输入筛选；true：之前展示；false：之后展示
        templTableData: [], // 临时记录tableDate的值
        btnGroups: [
          {
            name: '',
            className: 'btn-primary',
            iconName: 'fa-th',
            event: this.isMoreClk
          }
        ],
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        treeData: [],
        nodeKey: 'id',
        defaultCheckedKeys: [],
        searchable: true, // 是否带搜索框
        showCheckBox: true, // 是否带复选框
        expandAll: true, // 是否展开所有节点
        /** 弹出层 **/
        dialogObj: {
          title: '筛选条件',
          type: 'query',
          dialogVisible: false,
          data: {
            form: {
              geoType: [],
              businessType: '',
              operationScale: '',
              orderMethod: '',
              customerGrade: '',
              batchNo: '',
              status: '',
              treeId: '',
              treeType: '',
              starGrade: ''
            }
          }
        },
        /** 弹出层 **/
        dialogObj_base: {
          title: '客户详情',
          type: 'addConfigure',
          dialogVisible: false,
          size: 'large',
          customerId: '',
          data: {
            form: {
              customerId: ''
            }
          }
        },
        changeValueDate: {
          geoType: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          businessType: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          operationScale: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          customerGrade: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          custmgrId: {
            type: 'text',
            group: [],
            key: 'rowId',
            value: 'employeeName'
          },
          treeParam: {}
        },
        isShow: false
      }
    },
    methods: {
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      showTreeClk () {
        this.isTree = !this.isTree
      },
      treeInit () {
        this.treeData = []
      },
      init () {
        // 组织机构树
        let orgTreeparam = {}
        orgTreeparam.orgrelTypeId = 2
        orgTreeparam.status = 1
        orgTreeparam.place = '135'
        if (getUser().place === '135') { // 市场经理
          this.treeData = []
        } else if (getUser().place === '24') { // 市场经理
          orgTreeparam.treeRoot = getUser().deptId
          api.requestJava('POST', BasePath.EMPLOYEE_TREE, orgTreeparam, {})
            .then(request => {
              if (Number(request.data.code) === 200) {
                this.expandedKey = request.data.data.id
                let cityTreeObj = request.data.data
                let treeObj = {}
                treeObj.id = cityTreeObj.id
                treeObj.label = cityTreeObj.label
                treeObj.type = 'DEPT'
                let proChildrens = []
                let requestProChildren = request.data.data.children
                if (requestProChildren.length > 0) {
                  let i = 0
                  requestProChildren.forEach((e) => {
                    let provinceChildren = {}
                    provinceChildren.id = requestProChildren[i].id
                    provinceChildren.label = requestProChildren[i].label
                    provinceChildren.type = 'MGR'
                    proChildrens.push(provinceChildren)
                    i++
                  })
                }
                treeObj.children = proChildrens
                this.treeData.push(treeObj)
              } else {
                this.$notify.error({ title: '提示', message: request.data.message })
                throw new Error(JSON.stringify(request))
              }
            })
            .catch(err => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        } else if (Number(getUser().place) === 9999 && Number(getUser().unitLevel) === 2) { // 分公司领导
          orgTreeparam.treeRoot = getUser().companyId
          console.log(orgTreeparam)
          api.requestJava('POST', BasePath.EMPLOYEE_TREE, orgTreeparam, {})
            .then(request => {
              if (Number(request.data.code) === 200) {
                this.expandedKey = request.data.data.id
                let cityTreeObj = request.data.data
                let treeObj = {}
                treeObj.id = cityTreeObj.id
                treeObj.label = cityTreeObj.label
                treeObj.type = 'COMPANY'
                let proChildrens = []
                let requestProChildren = request.data.data.children
                if (requestProChildren.length > 0) {
                  let i = 0
                  requestProChildren.forEach((e) => {
                    let provinceChildren = {}
                    provinceChildren.id = requestProChildren[i].id
                    provinceChildren.label = requestProChildren[i].label
                    provinceChildren.type = 'COUNTY'
                    let deptChildrens = []
                    let requestDeptChildren = requestProChildren[i].children
                    var j = 0
                    requestDeptChildren.forEach((e) => {
                      let deptChildren = {}
                      deptChildren.id = requestDeptChildren[j].id
                      deptChildren.label = requestDeptChildren[j].label
                      deptChildren.type = 'DEPT'
                      let personChildren = []
                      let requestpersonChildren = requestDeptChildren[j].children
                      var k = 0
                      requestpersonChildren.forEach((e) => {
                        let mgrChildren = {}
                        mgrChildren.id = requestpersonChildren[k].id
                        mgrChildren.label = requestpersonChildren[k].label
                        mgrChildren.type = 'MGR'
                        personChildren.push(mgrChildren)
                        k++
                      })
                      deptChildren.children = personChildren
                      deptChildrens.push(deptChildren)
                      j++
                    })
                    provinceChildren.children = deptChildrens
                    proChildrens.push(provinceChildren)
                    i++
                  })
                }
                treeObj.children = proChildrens
                this.treeData.push(treeObj)
              } else {
                this.$notify.error({ title: '提示', message: request.data.message })
                throw new Error(JSON.stringify(request))
              }
            })
            .catch(err => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        } else if (Number(getUser().companyId) === 1 && Number(getUser().unitLevel) === 1 && Number(getUser().place) === 9999) {  // 省公司领导
          orgTreeparam.treeRoot = getUser().companyId
          console.log(orgTreeparam)
          api.requestJava('POST', BasePath.EMPLOYEE_TREE, orgTreeparam, {})
            .then(request => {
              if (Number(request.data.code) === 200) {
                this.expandedKey = request.data.data.id
                let cityTreeObj = request.data.data
                let treeObj = {}
                treeObj.id = cityTreeObj.id
                treeObj.label = cityTreeObj.label
                treeObj.type = 'COMPANY'
                let proChildrens = []
                let requestProChildren = request.data.data.children
                if (requestProChildren.length > 0) {
                  let i = 0
                  requestProChildren.forEach((e) => {
                    let provinceChildren = {}
                    provinceChildren.id = requestProChildren[i].id
                    provinceChildren.label = requestProChildren[i].label
                    provinceChildren.type = 'COMPANY'
                    let deptChildrens = []
                    let requestDeptChildren = requestProChildren[i].children
                    var j = 0
                    requestDeptChildren.forEach((e) => {
                      let deptChildren = {}
                      deptChildren.id = requestDeptChildren[j].id
                      deptChildren.label = requestDeptChildren[j].label
                      deptChildren.type = 'COUNTY'
                      let personChildren = []
                      let requestpersonChildren = requestDeptChildren[j].children
                      var k = 0
                      requestpersonChildren.forEach((e) => {
                        let mgrChildren = {}
                        mgrChildren.id = requestpersonChildren[k].id
                        mgrChildren.label = requestpersonChildren[k].label
                        mgrChildren.type = 'DEPT'
                        let lastChildrens = []
                        let reqtuestlastChildren = requestpersonChildren[k].children
                        var l = 0
                        reqtuestlastChildren.forEach((e) => {
                          let lastChildren = {}
                          lastChildren.id = reqtuestlastChildren[l].id
                          lastChildren.label = reqtuestlastChildren[l].label
                          lastChildren.type = 'MGR'
                          lastChildrens.push(lastChildren)
                          l++
                        })
                        mgrChildren.children = lastChildrens
                        personChildren.push(mgrChildren)
                        k++
                      })
                      deptChildren.children = personChildren
                      deptChildrens.push(deptChildren)
                      j++
                    })
                    provinceChildren.children = deptChildrens
                    proChildrens.push(provinceChildren)
                    i++
                  })
                }
                treeObj.children = proChildrens
                this.treeData.push(treeObj)
              } else {
                this.$notify.error({ title: '提示', message: request.data.message })
                throw new Error(JSON.stringify(request))
              }
            })
            .catch(err => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        }
        let param = {}
        param.pageSize = this.pageSize
        param.pageNum = 1
        param.companyId = getUser().companyId
        if (getUser().place === '135') { // 客户经理
          param.custmgrId = getUser().personId
        } else if (getUser().place === '24') { // 市场经理
          param.countyId = getUser().countyId
          let rowids = ''
          for (var i in this.customerMgrIds) {
            rowids += this.customerMgrIds[i].rowId + ','
          }
          rowids = rowids.substring(0, rowids.length - 1)
          param.whereClause = 'and CUSTMGR_ID in (' + rowids + ') '
        }
        param.status = '1'
        param.fields = {'include': 'rowId,customerCode,customerDesc,nationalCode,permitNo,addr,legalPerson,tel,geoType,businessType,operationScale,customerGrade,companyId,countyId,custmgrId,starGrade,x,y'}
        this.queryParams = param
        this.getPage(1, this.pageSize, this.queryParams)
      },
      headerClick () {},
      showTree (data) {
        this.treeId = data.id
        this.treeName = data.label
        this.dialogObj.title = data.label + '筛选条件'
        this.dialogObj.data.form.treeId = data.id
        this.dialogObj.data.form.treeType = data.type
        let param = {}
        param.pageSize = this.pageSize
        param.pageNum = this.currentPage
        if (data.type === 'COMPANY') {
          param.companyId = data.id
        } else if (data.type === 'COUNTY') {
          param.countyId = data.id
        } else if (data.type === 'DEPT') {
          param.marketOrg = data.id
        } else if (data.type === 'MGR') {
          param.custmgrId = data.id
        }
        param.type = data.type // 作为下面地图-客户分布 显示的一个判断条件
        this.queryParams = param
        this.treeParam = param
        this.getPage(1, this.pageSize, this.queryParams)
      },
      getPage (page, size) {
        this.currentPage = page
        this.pageSize = size
        this.queryData(this.currentPage, this.pageSize, this.queryParams)
      },
      queryData (page, size, param) {
        param.pageSize = size
        param.pageNum = page
//        param.status = '1'
        this.reqParams.url = BasePath.CUSTOMER_SELECT
        this.reqParams.params = param
        api.requestJava('POST', BasePath.CUSTOMER_SELECT, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.dataSource = request.data.data
              this.tableData = request.data.data
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      handleModify (index, row) {
        this.$router.push({name: 'CustomerDetail', params: {rowId: row.rowId}})
      }, // 修改
      colFormatter_change (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },
      del (index, row) {
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let params = {}
          params.rowId = row.rowId
          api.requestJava('POST', BasePath.CUSTOMER_DELETE, params, {})
            .then(request => {
              if (Number(request.data.code) === 200) {
                this.$message({ type: 'success', message: '删除成功!' })
                this.init()
              } else {
                this.$notify.error({ title: '提示', message: Number(request.data.code) })
                throw new Error(JSON.stringify(request))
              }
            }).catch(() => {
              this.$message({ type: 'info', message: '删除操作异常!' })
            }
          )
        }).catch(() => {
          this.$message({ type: 'info', message: '已取消删除!' })
        })
      },  // 删除
      onendChange (val) {
        var tmp = JSON.parse(val)
        if (Object.prototype.toString.call(tmp) === '[object Array]') {
          this.dataSource = tmp
        } else {
          this.dataSource = []
          this.dataSource.push(tmp)
        }
      }, // 过滤器修改事件
      confirmBack (msg) {
//        TODO 判断新增还是修改 this.dialogobj.rowid
        let param = {}
        param.pageSize = this.pageSize
        param.pageNum = this.currentPage
        let data = msg.data.form
        param.geoType = data.geoType
        param.businessType = data.businessType
        param.operationScale = data.operationScale
        param.orderMethod = data.orderMethod
        param.customerGrade = data.customerGrade
        param.batchNo = data.batchNo
        param.status = data.status
        param.starGrade = data.starGrade
//        if (data.treeType === 'COMPANY') {
//          param.companyId = data.treeId
//        } else if (data.treeType === 'DEPT') {
//          param.countyId = data.treeId
//        }
        if (getUser().place === '135') { // 客户经理
          param.custmgrId = getUser().personId
        } else if (getUser().place === '24') { // 市场经理
          param.countyId = getUser().countyId
          let rowids = ''
          for (var i in this.customerMgrIds) {
            rowids += this.customerMgrIds[i].rowId + ','
          }
          rowids = rowids.substring(0, rowids.length - 1)
          param.whereClause = 'and CUSTMGR_ID in (' + rowids + ') '
        } else if (getUser().place === '9999' && Number(getUser().companyId) !== 1) {
          param.companyId = getUser().companyId
        }
        if (this.treeParam !== undefined) {
          Object.assign(this.queryParams, this.treeParam)
        }
        Object.assign(this.queryParams, param)
        this.getPage(1, this.pageSize, this.queryParams)
      },
      isMoreClk () {
        this.dialogObj.data.form.geoType = ''
        this.dialogObj.data.form.businessType = ''
        this.dialogObj.data.form.operationScale = ''
        this.dialogObj.data.form.orderMethod = ''
        this.dialogObj.data.form.customerGrade = ''
        this.dialogObj.data.form.batchNo = ''
        this.dialogObj.data.form.status = ''
        this.dialogObj.dialogVisible = true
      },
      searchDetail (index, row) {
        let param = {}
        param.rowId = row.rowId
        param.haveAttach = '1'
        api.requestJava('POST', BasePath.CUSTOMER_SELECTONE, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.dialogObj_base.customerId = JSON.stringify(request.data.data)
              this.dialogObj_base.dialogVisible = true
            } else {
              this.$notify.error({ title: '提示', message: request.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      sortChange (msg) {},
      rowClick (msg) {},
      getDialogMarkerClk () {
        var url = this.reqParams.url
        var params = this.reqParams.params
        params.pageNum = 1
        params.pageSize = 9999
        api.requestJava('POST', url, params)
          .then(request => {
            if (Number(request.data.code) === 200) {
              /* 为了防止数据过多导致内容不能正常显示，将数据过来到订单组以下 */
              if (params.type === 'MGR' || getUser().place === '24' || getUser().place === '135') {
                this.distData = request.data.data
              } else {
                this.distData = []
                this.$notify.error({ title: '提示', message: '只能显示订单组以下的坐标信息！' })
                return
//                this.$message({
//                  message: '只能显示订单组以下的坐标信息！',
//                  type: 'warning'
//                });
              }
              this.open = true
              this.$refs.marker.findAll()
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }
    },
    components: {
      tableVue,
      _BTN_FILTER,
      _TREECOMPONENT,
      _POPUP,
      _DetailPopup,
      DIALOG_PLAN_MAP
    }
  }
</script>

