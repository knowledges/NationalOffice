<!-- 徐晓菁 -->
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='12'>
          <div v-if="isSelect">
            <el-form ref="searchForm" :model="searchForm" label-width="120px">
              <el-col :gutter="24">
                <el-col :span='12'>
                  <div class="block">
                    <el-form-item label="查询月份">
                      <el-date-picker
                        v-model="monthText"
                        type="month"
                        :editable=false
                        :clearable=false
                        style="position: absolute;center: 0;z-index: 9; cursor: pointer;width: 80%"
                        @change="monthChange"
                        placeholder="选择月份"
                        :picker-options="pickerOptions">
                      </el-date-picker>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span='12' v-if="false">
                  <el-form-item label="客户经理" >
                    <el-select v-model="searchForm.objectCd"   placeholder="请选择客户经理">
                      <template v-for="item in objectCdGroup">
                        <el-option  :key="item.employeeCode"  :label="item.employeeName" :value="item.employeeCode"></el-option>
                      </template>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='12' v-else-if="isMin">
                  <el-form-item label="客户服务部" >
                    <el-select v-model="searchForm.countyDept" :clearable="true" placeholder="请选择客户服务部" :disabled="searchForm.disabled">
                      <template v-for="item in factoryIdGroup">
                        <el-option  :key="item.orgUnitId"  :label="item.orgRoleNm" :value="item.orgUnitId"></el-option>
                      </template>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-form>
          </div>
        </el-col>
        <el-col :span="12">
          <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData" :isMore="isMore"/></_BTN_FILTER>
        </el-col>
      </el-col>
    </el-row>
     <div>
       <_TABLE
         ref="tableGrid"
         stripe
         maxHeight="500"
         @update:data="tabChange" :reqParams="reqParams"
         :data="dataSource"
         :columns="columnHeader"
         :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
         :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData></_TABLE>
    </div>
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve" />
    <MY_POPUP_QUERY :dialogObj='queryD' @confirmBack="queEve"  />
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import { changeListValueByCode, dateFormat } from '@/utils/common'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import MY_POPUP_CONFIG from './WeekOrderReportGrunps.vue'
  import MY_POPUP_QUERY from './AnalysisReportQuery.vue'
  import log from '@/log'
  import api from '@/api'
  import axios from 'axios'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  export default {
    mounted () {
      this.init()
      let companyIdParam = {}
      companyIdParam.NextTypeId = '203'
      companyIdParam.unitId = getUser().companyId
      companyIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
      console.log(getUser().countyId !== 'null' && Number(getUser().place) === 9999)
      if (getUser().countyId !== 'null' && Number(getUser().place) === 9999 || Number(getUser().place) === 24 || Number(getUser().place) === 135) {
        this.searchForm.countyDept = getUser().countyId
      }
      axios.all([
        api.requestJava('POST', BasePath.NEXTORGUNIT_SELECT, companyIdParam)
      ])
      .then(axios.spread((first) => {
        this.factoryIdGroup = JSON.parse(JSON.stringify(first.data.data))
      }))
    },
    data () {
      return {
        isSelect: true,
        factoryIdGroup: [],
        objectCdGroup: [],
        isMore: true, // 查询更多条件
        datetime: [new Date().setDate(1), new Date()],
        pickerOptions: {
          shortcuts: [{
            text: '当前月',
            onClick (picker) {
              var myDate = new Date()
              var year = myDate.getFullYear()
              var month = myDate.getMonth() + 1
              picker.$emit('pick', year + '-' + month)
            }
          }]
        },
        monthText: '',
        isCus: false,
        isMin: false,
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['title', 'unitName', 'reportorNm'],
        /** 定义按钮 **/
        btnGroups: [],
        hasPagination: true,
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'title',
            label: '标题',
            columnsProps: {align: 'left'}
          }, {
            prop: 'unitName',
            label: '部门',
            columnsProps: {width: 150, align: 'left'}
          }, {
            prop: 'reportorNm',
            label: '客户经理',
            columnsProps: {width: 150, align: 'left'}
          }, {
            prop: 'createdTime',
            label: '报告日期',
            columnsProps: {width: 120, align: 'center', formatter: this.changeValue}
          }, {
            prop: 'status',
            label: '状态',
            columnsProps: {width: 80, align: 'center', formatter: this.changeValue}
          }
        ],
        changeValueDate: {
          status: {
            type: 'text',
            group: [
              {value: '0', label: '撰写'},
              {value: '1', label: '提交'},
              {value: '9', label: '作废'}
            ],
            key: 'value',
            value: 'label'
          },
          createdTime: {
            type: 'date'
          }
        },
        tableData: [],
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        /** searchForm **/
        searchForm: {
          objectType: '1',
          periodIds: '',
          companyId: getUser().companyId,
          countyDept: '',
          empid: '',
          disabled: false
        },
        edit: {
          title: '撰写报告',
          type: '3',
          size: 'large',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              periodId: '',
              objectType: '',
              objectId: '',
              objectCd: '',
              objectNm: '',
              otherPr: '',
              reportorId: '',
              reportorNm: '',
              title: '',
              documentId: '',
              status: '',
              fbNum: '',
              cEval: '',
              createdTime: '',
              deptname: '',
              periodName: '',
              companyId: '',
              creatBy: '',
              countyDept: '',
              contents: {
                consumer: '',
                consumermeasure: '',
                prdmeasure: '',
                noordreason: '',
                noordmeasure: '',
                brandSet: ''
              }
            }
          }
        },
        queryD: {
          title: '周订单分析报告',
          type: '3',
          size: 'large',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              periodId: '',
              objectType: '',
              objectId: '',
              objectCd: '',
              objectNm: '',
              otherPr: '',
              reportorId: '',
              reportorNm: '',
              title: '',
              documentId: '',
              status: '',
              fbNum: '',
              cEval: '',
              createdTime: '',
              deptname: '',
              periodName: '',
              companyId: '',
              creatBy: '',
              countyDept: '',
              contents: {
                consumer: '',
                consumermeasure: '',
                prdmeasure: '',
                noordreason: '',
                noordmeasure: '',
                brandSet: ''
              }
            }
          }
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** 实际操作 **/
        periodIdGroup: []
      }
    },
    methods: {
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      monthChange () {
        var month = dateFormat(Date.parse(this.monthText), 'YYYYMM')
        let params = {}
        params.dtMonthId = month
        params.orgCompanyId = getUser().companyId
        api.requestJava('POST', BasePath.WEEKORDERREPORT_QUARTER_SELECTLIST, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              let bra = ''
              let children = request.data.data
              for (let i = 0; i < children.length; i++) {
                bra = bra + children[i].dtWeekId + ','
              }
              if (bra.length > 0) {
                bra = bra.substr(0, bra.length - 1)
              }
              this.searchForm.periodIds = bra
              this.query()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      modify (index, row) {
        if (Number(row.status) === 1) {
          this.$message({type: 'info', message: '该记录已提交，不可修改!'})
          return
        }
        Object.assign(this.edit.data.form, row)
        this.edit.data.form.contents = JSON.parse(row.contents)
        this.edit.dialogVisible = true
      }, // 修改
      view (index, row) {
        Object.assign(this.queryD.data.form, row)
        this.queryD.data.form.contents = JSON.parse(row.contents)
        this.queryD.dialogVisible = true
      }, // 预览明细
      addClk () {
        this.edit.dialogVisible = true
      }, // 新增
      isMoreClk () {
        this.isSelect = !this.isSelect
      },
      init () {
        if (getUser().place === '135') {
          this.isCus = false
          this.searchForm.disabled = true
          this.searchForm.objectId = getUser().personId
          this.btnGroups = [
            {
              name: '撰写报告',
              className: 'btn-info',
              iconName: 'fa-plus',
              event: this.addClk
            }
          ]
          let bts = {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 250, type: 'button'},
            cptProperties: [
              {
                label: '修改',
                value: 'modify',
                icon: 'edit',
                size: 'small',
                type: 'warning',
                eventClick: this.modify
              },
              {
                label: '删除',
                value: 'del',
                icon: 'delete',
                size: 'small',
                type: 'danger',
                eventClick: this.del
              },
              {
                label: '预览', // 按钮的名称
                value: 'view', // 按钮的值
                type: 'primary',
                size: 'small',
                icon: 'search',
                eventClick: this.view // 按钮的方法
              }
            ]
          }
          this.columnHeader.push(bts)
        } else if (getUser().place === '24') {
          this.isCus = true
          this.searchForm.disabled = true
          this.searchForm.empid = getUser().personId
          this.btnGroups = [
            {
              name: '查询',
              className: 'btn-primary',
              iconName: 'fa-search',
              event: this.query
            }
          ]
          let bts = {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 200, type: 'button'},
            cptProperties: [
              {
                label: '预览', // 按钮的名称
                value: 'view', // 按钮的值
                type: 'primary',
                size: 'small',
                icon: 'search',
                eventClick: this.view // 按钮的方法
              }
            ]
          }
          this.columnHeader.push(bts)
        } else if (getUser().countyId !== 'null' && Number(getUser().place) === 9999) { // 分公司
          this.isMin = true
          this.searchForm.disabled = true
          this.btnGroups = [
            {
              name: '查询',
              className: 'btn-primary',
              iconName: 'fa-search',
              event: this.query
            }
          ]
          let bts = {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 200, type: 'button'},
            cptProperties: [
              {
                label: '预览', // 按钮的名称
                value: 'view', // 按钮的值
                type: 'primary',
                size: 'small',
                icon: 'search',
                eventClick: this.view // 按钮的方法
              }
            ]
          }
          this.columnHeader.push(bts)
        } else { // 市公司
          this.isMin = true
          this.btnGroups = [
            {
              name: '查询',
              className: 'btn-primary',
              iconName: 'fa-search',
              event: this.query
            }
          ]
          let bts = {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 200, type: 'button'},
            cptProperties: [
              {
                label: '预览', // 按钮的名称
                value: 'view', // 按钮的值
                type: 'primary',
                size: 'small',
                icon: 'search',
                eventClick: this.view // 按钮的方法
              }
            ]
          }
          this.columnHeader.push(bts)
        }
        var myDate = new Date()
        this.monthText = dateFormat(myDate.getTime(), 'YYYY-MM')
      },
      query () {
        let params = this.searchForm
        params.whereClause = 'and  PERIOD_ID in( ' + this.searchForm.periodIds + ')'
        console.log(JSON.stringify(params))
        this.queryUpper(params)
      }, // 查询方法
      queryUpper (params) {
        /* 将已有的参数赋值给分页参数 */
        this.$set(this.reqParams, 'url', BasePath.WEEKORDERREPORT_SELECTLIST)
        this.$set(this.reqParams, 'params', params)
        api.requestJava('POST', BasePath.WEEKORDERREPORT_SELECTLIST, params)
          .then((request) => {
            console.log('request.data', request.data.data)
            if (Number(request.data.code) === 200) {
              if (request.data.data === '') {
                this.dataSource = []
                this.tableData = []
                this.totalCount = 0
              } else {
                this.dataSource = request.data.data
                this.tableData = request.data.data
                this.totalCount = Number(request.data.count)
              }
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      sortChange (msg) {},
      rowClick (msg) {},
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      dateFormatter (row, column) {
        var unixDate = row[column.property]
        return dateFormat(unixDate, 'YYYY-MM-DD HH:mm:ss')
      },  // 时间格式化
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      editEve (msg) {
        if (msg === 'update') {
          this.saveUpper()
        }
        this.edit.dialogVisible = false
        let tmp = {
          title: '撰写报告',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              periodId: '',
              objectType: '',
              objectId: '',
              objectCd: '',
              objectNm: '',
              otherPr: '',
              reportorId: '',
              reportorNm: '',
              title: '',
              documentId: '',
              status: '',
              fbNum: '',
              cEval: '',
              createdTime: '',
              deptname: '',
              periodName: '',
              companyId: '',
              creatBy: '',
              countyDept: '',
              contents: {
                consumer: '',
                consumermeasure: '',
                prdmeasure: '',
                noordreason: '',
                noordmeasure: '',
                brandSet: ''
              }
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      saveUpper () {
        let params = this.edit.data.form
        params.contents = JSON.stringify(this.edit.data.form.contents)
        console.log('params', JSON.stringify(params))
        var url = BasePath.WEEKORDERREPORT_UPDATE
        if (this.edit.data.form.rowId === '') {
          url = BasePath.WEEKORDERREPORT_INSERT
        }
        api.requestJava('POST', url, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              this.query()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 保存
      queEve (msg) {
        this.queryD.dialogVisible = false
        let tmp = {
          title: '撰写报告',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              periodId: '',
              objectType: '',
              objectId: '',
              objectCd: '',
              objectNm: '',
              otherPr: '',
              reportorId: '',
              reportorNm: '',
              title: '',
              documentId: '',
              status: '',
              fbNum: '',
              cEval: '',
              createdTime: '',
              deptname: '',
              periodName: '',
              companyId: '',
              creatBy: '',
              countyDept: '',
              contents: {
                consumer: '',
                consumermeasure: '',
                prdmeasure: '',
                noordreason: '',
                noordmeasure: '',
                brandSet: ''
              }
            }
          }
        }
        Object.assign(this.queryD, tmp)
      }, // 修改事件
      del (index, row) {
        if (Number(row.status) === 1) {
          this.$message({type: 'info', message: '该记录已提交，不可删除!'})
          return
        }
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.deleteUpper(row.rowId)
        }).catch(() => {
          this.$message({type: 'info', message: '已取消删除!'})
        })
      },  // 删除
      batchDelClk () {},  // 批量删除
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      onendChange (val) {}, // 过滤器修改事件
      deleteUpper (val) {
        let params = {}
        params.rowId = val
        api.requestJava('POST', BasePath.WEEKORDERREPORT_DELETE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              this.query()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }
    },
    components: {
      _TABLE,
      _POPUP,
      MY_POPUP_CONFIG,
      MY_POPUP_QUERY,
      _BTN_FILTER
    }
  }
</script>

<style scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-24 {
    height: 36px;
  }
</style>
