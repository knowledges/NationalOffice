<template>
  <el-form :inline="true" :model="formInline" class="demo-form-inline" ref="query" :rules="addrules">
    <template v-if="place != 24 && place != 135 ">
      <el-row>
        <el-col :span="8" style="padding: 0 12px;margin-top: 10px;">
          <div class="bg-purple">
            <_TREECOMPONENT :search=searchable :data='treeData' :expandedKey=expandedKey :nodeClick='showTree' :nodeKey="nodeKey"
                            :expandAll=expandAll ref='tree' :highlight='true' :visible='isTree'
                            :defaultCheckedKeys="defaultCheckedKeys"></_TREECOMPONENT>
          </div>
        </el-col>
        <el-col :span="16">
          <div>
            <el-row>
              <el-col :span="24">
                <el-form-item label="市场经理">
                  <el-select v-model="formInline.marketMgrId" style="width: 190px;" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_marketMgrId"
                      :key="item.rowId"
                      :label="item.employeeName"
                      :value="item.rowId">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="拜访日期">
                  <el-date-picker
                    v-model="formInline.visitDate"
                    type="date"
                    format="yyyy-MM-dd"
                    placeholder="选择日期">
                  </el-date-picker>
                  <el-button icon="search" @click="onSubmit('query')" type="primary" plain>搜索</el-button>
                </el-form-item>
              </el-col>
            </el-row>
            <div>
              <el-table :data="tableData" border>
                <el-table-column prop="visitorName" label="客户经理" width="95">
                </el-table-column>
                <el-table-column prop="planNums" label="拜访情况" width="95">
                </el-table-column>
                <el-table-column prop="visitRate" label="完成率" width="120">
                  <template scope="scope">
                    <el-progress :percentage="scope.row.visitRate"></el-progress>
                  </template>
                </el-table-column>
                <el-table-column
                  fixed="right"
                  label="操作"
                  width="85">
                  <template scope="scope">
                    <el-button
                      @click.native.prevent="detailRow(scope.$index, tableData)"
                      type="text"
                      size="small">
                      详情
                    </el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>
          </div>
        </el-col>
      </el-row>
    </template>
    <template v-else>
      <div>
        <el-row>
          <el-col :span="24">
            <el-form-item label="市场经理">
              <el-select v-model="formInline.marketMgrId" style="width: 190px;" :clearable="true" placeholder="请选择">
                <el-option
                  v-for="item in options_marketMgrId"
                  :key="item.rowId"
                  :label="item.employeeName"
                  :value="item.rowId">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="拜访日期">
              <el-date-picker
                v-model="formInline.visitDate"
                type="date"
                format="yyyy-MM-dd"
                placeholder="选择日期">
              </el-date-picker>
              <el-button icon="search" @click="onSubmit('query')" type="primary" plain>搜索</el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <div>
          <el-table :data="tableData">
            <el-table-column prop="visitorName" label="客户经理">
            </el-table-column>
            <el-table-column prop="planNums" label="拜访情况">
            </el-table-column>
            <el-table-column prop="visitRate" label="完成率">
              <template scope="scope">
                <el-progress :percentage="scope.row.visitRate"></el-progress>
              </template>
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作"
              width="85">
              <template scope="scope">
                <el-button
                  @click.native.prevent="detailRow(scope.$index, tableData)"
                  type="text"
                  size="small">
                  详情
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </template>
  </el-form>
</template>
<script>
  import _TABLE from '@/components/Template/TabPagin/Table.vue'
  import InputTemp from '@/components/Template/filter/InputTemp.vue'
  import uploadTemp from '@/components/Template/Popup/uploadTemp.vue'
  import DatePickerTemp from '@/components/Template/DatePicker/DatePickerTemp.vue'
  import compositeInput from '@/components/Template/Popup/compositeInput.vue'
  import _TREECOMPONENT from '@/components/Template/Tree/Tree.vue'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  import { dateFormat } from '@/utils/dateFormat.js'
  import api from '@/api'
  import log from '@/log'
  export default {
    mounted () {
      this.$nextTick(() => {
        this.init()
        if (Number(getUser().place) === 24) {
          this.formInline.marketMgrId = getUser().personId
          this.onSubmit()
          let params = {}
          params.place = getUser().place
          params.companyId = getUser().companyId
          params.countyDept = getUser().countyId
          this.getEmployees(params)
        }
      })
    },
    data () {
      return {
        isTree: false,
        expandedKey: [], // 展开的数组
        treeData: [],
        nodeKey: 'id',
        defaultCheckedKeys: [],
        searchable: true, // 是否带搜索框
        showCheckBox: true, // 是否带复选框
        expandAll: true, // 是否展开所有节点
        place: Number(getUser().place),
        tableData: [],
        options_marketMgrId: [],
        formInline: {
          companyId: getUser().companyId,
          deptId: getUser().deptId,
          countyDept: '',
          marketMgrId: '',
          visitDate: new Date()
        },
        addrules: {
          marketMgrId: [
            {required: true, message: '请输入角色代码', trigger: 'blur'}
          ],
          visitDate: [
            {required: true, message: '请输入角色名称', trigger: 'blur'}
          ]
        }
      }
    },
    methods: {
      init () {
        let orgTreeparam = {}
        orgTreeparam.orgrelTypeId = 2
        if (Number(getUser().unitLevel) === 1) {
          orgTreeparam.treeRoot = getUser().companyId
        } else {
          if (getUser().countyId === 'null') {
            orgTreeparam.treeRoot = getUser().companyId
          } else {
            orgTreeparam.treeRoot = getUser().countyId
          }
        }
        console.log('数据的参数：', orgTreeparam)
        api.requestJava('POST', BasePath.ORGUNIT_TREE, orgTreeparam)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.expandedKey = [request.data.data.id]
              if (Number(getUser().unitLevel) === 1) { // 省公司
                let provinceTreeObj = request.data.data
                let treeObj = {}
                treeObj.id = provinceTreeObj.id
                treeObj.label = provinceTreeObj.label
                treeObj.type = 'PROVINCE'
                let companyTreeChildrens = []
                let companyTreeChildrensObj = request.data.data.children
                if (companyTreeChildrensObj.length > 0) {
                  let i = 0
                  companyTreeChildrensObj.forEach((e) => {
                    let companyChildren = {}
                    companyChildren.id = companyTreeChildrensObj[i].id
                    companyChildren.label = companyTreeChildrensObj[i].label
                    companyChildren.type = 'COMPANY'
                    let countyTreeChildrens = []
                    let countyTreeChildrensObj = companyTreeChildrensObj[i].children
                    if (countyTreeChildrensObj.length > 0) {
                      let j = 0
                      countyTreeChildrensObj.forEach((e) => {
                        let countyChildren = {}
                        countyChildren.id = countyTreeChildrensObj[j].id
                        countyChildren.label = countyTreeChildrensObj[j].label
                        countyChildren.type = 'COUNTY'
                        countyChildren.orgRoleTypId = countyTreeChildrensObj[j].orgRoleTypId
                        countyTreeChildrens.push(countyChildren)
                        j++
                      })
                    }
                    companyChildren.children = countyTreeChildrens
                    companyTreeChildrens.push(companyChildren)
                    i++
                  })
                }
                treeObj.children = companyTreeChildrens
                this.treeData.push(treeObj)
              } else {
                let companyTreeObj = request.data.data
                let treeObj = {}
                if (getUser().countyId === 'null') {
                  treeObj.id = companyTreeObj.id
                  treeObj.label = companyTreeObj.label
                  treeObj.type = 'COMPANY'
                  let countyTreeChildrens = []
                  let countyTreeChildrensObj = request.data.data.children
                  if (countyTreeChildrensObj.length > 0) {
                    let i = 0
                    countyTreeChildrensObj.forEach((e) => {
                      let countyChildren = {}
                      countyChildren.id = countyTreeChildrensObj[i].id
                      countyChildren.label = countyTreeChildrensObj[i].label
                      countyChildren.type = 'COUNTY'
                      countyTreeChildrens.push(countyChildren)
                      i++
                    })
                  }
                  treeObj.children = countyTreeChildrens
                } else {
//                  delete companyTreeObj.children
//                  companyTreeObj.type =
//                  treeObj = companyTreeObj
//                  treeObj.type = 'COUNTY'
                  treeObj.id = companyTreeObj.id
                  treeObj.label = companyTreeObj.label
                  treeObj.type = 'COUNTY'
                  let countyTreeChildrens = []
                  let countyTreeChildrensObj = request.data.data.children
                  if (countyTreeChildrensObj.length > 0) {
                    let i = 0
                    countyTreeChildrensObj.forEach((e) => {
                      let countyChildren = {}
                      countyChildren.id = countyTreeChildrensObj[i].id
                      countyChildren.label = countyTreeChildrensObj[i].label
                      countyChildren.type = 'DEPT'
                      countyTreeChildrens.push(countyChildren)
                      i++
                    })
                  }
                  treeObj.children = countyTreeChildrens
                }
                this.treeData.push(treeObj)
              }
            } else if (Number(request.data.code) === 401) {
              this.$notify.error({ title: '查询失败', message: request.data.message })
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      showTree (data) {
        this.formInline.companyId = ''
        this.formInline.marketMgrId = ''
        this.formInline.countyDept = ''
        this.formInline.deptId = ''
        if (data.type === 'COMPANY' || data.type === 'PROVINCE') {
          this.formInline.companyId = data.id
        } else if (data.type === 'COUNTY') {
          this.formInline.countyDept = data.id
        } else {
          this.formInline.deptId = data.id
        }
        let params = {}
        params.countyDept = data.id
        this.getEmployees(params)
        this.$nextTick(() => {
          this.onSubmit()
        })
      },
      getEmployees (params) {
        params.status = 1
        params.place = '24'
        params.fields = {include: 'employeeName,rowId'}
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params) // 市场经理
          .then((request) => {
            this.options_marketMgrId = request.data.data
            if (Number(getUser().place) !== 24) {
              this.formInline.marketMgrId = ''
            }
          })
      },
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      onSubmit () {
        let marketMgrIdParam = {}
        marketMgrIdParam.companyId = this.formInline.companyId
        marketMgrIdParam.countyDept = this.formInline.countyDept
        marketMgrIdParam.marketMgrId = this.formInline.marketMgrId
        marketMgrIdParam.deptId = this.formInline.deptId
        marketMgrIdParam.visitDate = this.getTime(Date.parse(this.formInline.visitDate))
        api.requestJava('POST', BasePath.MARKETMGR_STATISTICS, marketMgrIdParam, {})
          .then(request => {
            if (Number(request.data.code) === 200) {
              if (request.data.data.length > 0) {
                this.tableData = request.data.data
                let coordinates = []
                var i = 0
                this.tableData.forEach((e) => {
                  let coordinate = {}
                  e.planNums = Number(request.data.data[i].visitNums) + '/' + request.data.data[i].planNums
                  e.visitRate = Number(request.data.data[i].visitRate)
                  coordinate.lng = request.data.data[i].lastMgrX
                  coordinate.lat = request.data.data[i].lastMgrY
                  coordinate.name = request.data.data[i].visitorName
                  coordinates.push(coordinate)
                  i++
                })
                this.refreshMap(coordinates)
              } else {
                this.refreshMap([]) // 刷新地图
              }
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          }).catch(() => {
            this.$message({ type: 'info', message: '操作异常!' })
          })
      },
      detailRow (index, rows) {
        this.$router.push({name: 'MapMonitor', params: {uId: rows[index].visitor, visitDate: this.getTime(Date.parse(this.formInline.visitDate)), companyId: rows[index].companyId, countyDept: rows[index].countyDept}})
      },
      refreshMap (info) {
        this.$emit('confirmBack', info)
      }
    },
    components: {
      _TABLE, InputTemp, uploadTemp, DatePickerTemp, compositeInput, _TREECOMPONENT
    }
  }
</script>
<style scoped>
  .el-form-item{
    padding: 10px 20px;
    margin-bottom: 0px;
    margin-right: 0px!important;
  }
</style>
