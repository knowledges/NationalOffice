<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="closeModalEve" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <el-form :model="dialogObj.data.form" label-width="80px" ref="query" :rules="addrules">
      <el-row>
        <el-col :gutter="24">
          <el-col :span='12'>
            <el-form-item prop="materialCd" label="物料条码">
              <el-input v-model="dialogObj.data.form.materialCd" :disabled="dialogObj.data.form.disabled"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='12'>
            <el-form-item prop="materialNm" label="物料名称">
              <el-input v-model="dialogObj.data.form.materialNm"></el-input>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='24'>
            <el-form-item prop="spec" label="规格">
              <el-input v-model="dialogObj.data.form.spec"></el-input>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='12'>
            <el-form-item prop="unit" label="单位">
              <el-input v-model="dialogObj.data.form.unit"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='12'>
            <el-form-item prop="granularity" label="管理粒度">
              <el-select v-model="dialogObj.data.form.granularity" :clearable="true" placeholder="请选择" :disabled="true">
                <el-option
                  v-for="item in optionsGranularity"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
        <el-col :span='24'>
          <el-form-item prop="properties" label="详细描述">
            <el-input v-model="dialogObj.data.form.properties" ></el-input>
          </el-form-item>
        </el-col>
      </el-col>
        <el-col :gutter="24">
          <el-col :span='24'>
            <el-form-item prop="propertiesPic" label="商品图片">
              <div id="propertiesPic">
                <uploadTemp style="margin:20px;" :files="dialogObj.data.form.propertiesPic" ref="propertiesPic"></uploadTemp>
              </div>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='24'>
            <el-form-item>
              <el-button @click="resetForm('addForm')">取 消</el-button>
              <el-button type="success" @click="submitForm('query')">确 定</el-button>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
    </el-form>
  </el-dialog>
</template>
<script>
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import log from '@/log'
  export default {
    props: ['dialogObj'],
    data () {
      var validatePass = (rule, value, callback) => {
        this.onChangeValue((request) => {
          if (this.dialogObj.data.form.disabled === false) {
            if (value === '') {
              callback(new Error('请输入物料代码'))
            } else if (Number(request) === 1) {
              callback(new Error('物料代码已被占用'))
            } else {
              callback()
            }
          } else {
            callback()
          }
        })
      }
      return {
        optionsGranularity: [{
          value: '1',
          label: '人员'
        }, {
          value: '2',
          label: '部门'
        }],
        addrules: {
          materialCd: [
            {trigger: 'blur', validator: validatePass}
          ],
          materialNm: [
            {required: true, message: '请输入物料名称', trigger: 'blur'}
          ],
          unit: [
            {required: true, message: '请输入单位', trigger: 'blur'}
          ],
          granularity: [
            {required: true, message: '请选择管理粒度', trigger: 'blur'}
          ]
        },
        value: '',
        form: {}
      }
    },
    methods: {
      closeModalEve () {
        this.dialogObj.dialogVisible = false
        this.$emit('confirmBack', false)
      },
      resetForm (formName) {
        this.dialogObj.dialogVisible = false
        this.$emit('confirmBack', false)
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dialogObj.dialogVisible = false
            this.dialogObj.data.form.propertiesPic = this.$refs.propertiesPic.getFiles()
            this.$emit('confirmBack', this.dialogObj)
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      onChangeValue (callback) {
        let params = {}
        params.materialCd = this.dialogObj.data.form.materialCd
        api.requestJava('POST', BasePath.VISIT_INVYG_SELECT, params)
          .then(request => {
            if (Number(request.data.code) === 200) {
              callback(request.data.count)
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }
    },
    components: {
      uploadTemp
    },
    watch: {}
  }
</script>

<style scoped>
  .item__label_popup {
    text-align: right;
    vertical-align: middle;
    float: right;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 8px 11px 0;
    box-sizing: border-box;
    /* display: inline-block; */
  }
  .el-input, .el-input__inner {
    /*width: '';*/
    display: inline-block;
  }
</style>
