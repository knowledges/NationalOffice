<template>
  <div>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="closeModalEve" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <el-form :model="dialogObj.data.form" label-width="90px"  :rules="addrules" ref="addForm">
      <el-row :gutter="20">
        <el-col :span="12">
          <el-form-item label="品规名称">
            <el-input v-model="dialogObj.data.form.goodsDesc"></el-input>
            <!--<el-select v-model="dialogObj.data.form.goodsDesc"   filterable  :clearable="true" placeholder="请选择品规名称">-->
              <!--<el-option-->
                <!--v-for="item in optionsCat"-->
                <!--:key="item.rowId"-->
                <!--:label="item.goodsDesc"-->
                <!--:value="item.goodsDesc">-->
              <!--</el-option>-->
            <!--</el-select>-->
            <!--<el-input v-model="dialogObj.data.form.goodsDesc"></el-input>-->
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="拟引入时间">
            <el-date-picker
              v-model="dialogObj.data.form.impDate"
              type="date"
              format="yyyy-MM-dd"
              :editable=false
              :clearable=false
              placeholder="选择开始时间">
            </el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="12">
          <el-form-item label="零售指导价"><el-input v-model="dialogObj.data.form.goodsPrice"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="12">
          <el-form-item label="口味特点"><el-input v-model="dialogObj.data.form.taste"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="10">
          <el-form-item label="市场定位"><el-input v-model="dialogObj.data.form.marketPosition"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-form-item label="宣传口号"><el-input
            type="textarea" resize="none"
            :rows="3"
            placeholder="请输入内容"
            v-model="dialogObj.data.form.propaganda">
          </el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="24">
        </el-col>
      </el-row>
      <el-form-item label="文件上传">
        <uploadTemp style="margin:20px;" :files="dialogObj.data.form.files" ref="uploadPic"></uploadTemp>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="resetForm ('addForm')">取 消</el-button>
      <el-button type="success" @click="submitForm('addForm')" >确 定</el-button>
    </div>
  </el-dialog>
  </div>
</template>

<script>
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
  import api from '@/api'
  import log from '@/log'
  export default {
    mounted () {
      // debugger
      this.getDesc()
    },
    props: ['dialogObj'],
    data () {
      return {
        filmode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤
        fileName: ['value'],
        filType: 0, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        keyup: true, // 输入筛选；true：之前展示；false：之后展示
        addrules: {},
        optionsCat: [],
        files: [
          {
            fileName: 'baidu.gif',
            fileData: 'https://www.baidu.com/img/baidu_jgylogo3.gif',
            src: 'https://www.baidu.com/img/baidu_jgylogo3.gif'
          }
        ],
        value: '',
        form: {}
      }
    },
    methods: {
      getDesc () {
        // debugger
        api.requestJava('POST', '/baseinfo/cigarettes/selectList.do', {'isCadrebrand': 'N', 'fields': {'include': 'goodsDesc'}})
          .then((request) => {
            if (Number(request.data.code) === 200) {
              // debugger
              this.optionsCat = request.data.data
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      closeModalEve () {
        this.dialogObj.dialogVisible = false
        this.$emit('confirmBack', false)
      },
      resetForm (formName) {
        this.dialogObj.dialogVisible = false
        this.$emit('confirmBack', false)
      },
      submitForm (formName) {
        if (this.dialogObj.data.form.goodsDesc === '') {
          this.$message({type: 'info', message: '请输入新品规格'})
          return
        }
        if (this.dialogObj.data.form.impDate === '') {
          this.$message({type: 'info', message: '请输入拟引入时间'})
          return
        }
        let reg = /^[1-9]\d*$/
        if (RegExp(reg).test(this.dialogObj.data.form.goodsPrice) === false) {
          this.$message({type: 'info', message: '零售指导价请输入数字值'})
          return
        }
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dialogObj.data.form.files = this.$refs.uploadPic.getFiles()
            this.dialogObj.dialogVisible = false
            this.$emit('confirmBack', this.dialogObj)
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      _upload_submit () {
        this.$refs.uploadTemp.submitUpload()
      }
    },
    components: {
      uploadTemp
    }
  }
</script>

<style scoped>
  .item__label_popup {
    text-align: right;
    vertical-align: middle;
    float: right;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 8px 11px 0;
    box-sizing: border-box;
    /* display: inline-block; */
  }
  .el-input, .el-input__inner {
    /*width: '';*/
    display: inline-block;
  }
</style>
