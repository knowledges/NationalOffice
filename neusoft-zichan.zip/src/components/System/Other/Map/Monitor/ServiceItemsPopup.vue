<template>
  <div class="container" style="margin-top: 0px!important">
    <tabModule
      :coloumHeader="coloumHeader"
      :coloumDate="array"
    ></tabModule>
  </div>
</template>
<script>
  import tabModule from '@/components/Template/Restructure/Table.vue'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import { getCodeList } from '@/config/info'
  export default {
    props: {
      custId: {
        type: String,
        default: ''
      }
    },
    mounted () {
      getCodeList('VISIT_MODE', (data) => {
        this.changeValueDate.visitMode.group = data
        console.log(JSON.stringify(this.changeValueDate.visitMode.group))
      }) // 拜访方式
      let cust = JSON.parse(this.custId)
      this.init(cust.rowId)
    },
    data () {
      return {
        coloumHeader: [
          {
            prop: 'customerName',
            label: '客户名称',
            coloumProp: {width: '160px'}
          },
          {
            prop: 'addr',
            label: '经营地址',
            coloumProp: {width: '160px'}
          },
          {
            prop: 'permitNo',
            label: '许可证号',
            coloumProp: {width: '110px'}
          },
          {
            prop: 'legalPerson',
            label: '法人',
            coloumProp: {width: '80px'}
          },
          {
            prop: 'customerGrade',
            label: '档级',
            coloumProp: {width: '80px'}
          },
          {
            prop: 'expectedTime',
            label: '拜访时间',
            coloumProp: {width: '100px'}
          },
          {
            prop: 'visitMode',
            label: '拜访方式',
            coloumProp: {formatter: this.changeValue, width: '80px'}
          },
          {
            prop: 'title',
            label: '服务内容',
            coloumProp: { type: 'array', width: '100px' }
          },
          {
            prop: 'notes',
            label: '服务详情',
            coloumProp: { type: 'array', width: '180px' }
          },
          {
            prop: 'files',
            label: '照片展示',
            coloumProp: { type: 'img', width: '120px' }
          }
        ],
        array: [],
        changeValueDate: {
          visitMode: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          }
        }
      }
    },
    methods: {
      init (val) {
        let param = {}
        param.customerId = val
        console.log('serviceItem::::::' + JSON.stringify(param))
        api.requestJava('POST', BasePath.COMMON_SELSECTVISIT, param)
          .then((reponse) => {
            if (Number(reponse.data.code) === 200) {
              this.array = reponse.data.data
            }
          })
      },
      closeModalEve () {
        this.dialogObj.dialogVisible = false
      },
      changeValue (row, column) {
        if (Number(row.visitMode) === 0) {
          row.visitMode = '不拜访'
        } else if (Number(row.visitMode) === 1) {
          row.visitMode = '现场拜访'
        } else if (Number(row.visitMode) === 2) {
          row.visitMode = '电话拜访'
        }
      }  // 转换list中的code
    },
    components: {
      tabModule
    },
    watch: {
      custId (val, old) {
        let cust = JSON.parse(val)
        this.init(cust.rowId)
      }
    }
  }
</script>

<style scoped>
  .item__label_popup {
    text-align: right;
    vertical-align: middle;
    float: right;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 8px 11px 0;
    box-sizing: border-box;
    /* display: inline-block; */
  }
  .el-input, .el-input__inner {
    /*width: '';*/
    display: inline-block;
  }
  .container-fluid_new {
    background: #FFF;
  }
</style>
