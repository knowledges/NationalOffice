<!-- 徐晓菁 -->
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false"  :close-on-press-escape="false" :before-close="cancleClk">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-form-item label="岗位代码">
        <el-input  v-model="dialogObj.data.form.placeCode"></el-input>
      </el-form-item>
      <el-form-item label="岗位名称">
        <el-input v-model="dialogObj.data.form.placeName"></el-input>
      </el-form-item>
      <el-form-item label="所属部门">
        <el-select v-model="dialogObj.data.form.deptId" placeholder="请选择所属部门">
          <template v-for="item in dialogObj.data.form.deptIdGroup">
            <el-option  :key="item.rowId"  :label="item.unitName" :value="item.rowId"></el-option>
          </template>
        </el-select>
      </el-form-item>
      <el-form-item label="是否主管岗位">
        <el-switch on-text="" off-text="" v-model="dialogObj.data.form.isLeader"></el-switch>
      </el-form-item>
      <el-form-item label="状态">
        <el-switch on-text="" off-text="" v-model="dialogObj.data.form.status"></el-switch>
      </el-form-item>
      <el-form-item label="职责">
        <el-input type="textarea" resize="none" v-model="dialogObj.data.form.responsilibility"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
      <el-button type="success" @click="updateClk('addForm')">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
//  import api from '@/api'
//  import BasePath from '@/config/BasePath'
//  import { getUser } from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
    },
    data () {
      return {
        deptIdGroup: [],
        addrules: {
          placeCode: [
            {required: true, message: '请输入岗位类型代码', trigger: 'blur'}
          ],
          placeName: [
            {required: true, message: '请输入岗位类型名称', trigger: 'blur'}
          ],
          deptId: [
            {required: true, message: '请选择所属部门', trigger: 'blur'}
          ]
        }
      }
    },
    methods: {
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      },
      updateClk (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      }
    }
  }
</script>

