<!--李晶-->
<style rel="stylesheet/scss" lang="scss" scoped></style>
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span="24">
          <_BTN_FILTER :isMore="isMore" :btnGroups="btnGroups" :fileName="fileName" :filterMethod="inputChange"
                       :tableData="tableData"/>
        </el-col>
      </el-col>
    </el-row>
    <tableVue
      ref="tableGrid"
      stripe
      maxHeight="500"
      :data="dataSource"
      @update:data="tabChange" :reqParams="reqParams"
      :columns="columns"
      :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
      :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData>
    </tableVue>
    <_POPUP :dialogObj='dialogObj_base' @confirmBack="confirmBack_base"/>
  </div>
</template>
<script>
  import tableVue from '@/components/Template/table/table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import _POPUP from '@/components/CustomerService/Materiel/MaterielMaintain/Popup.vue'
  import { getUser } from '@/config/info'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import log from '@/log'
  export default {
    name: 'MaterielMaintain',
    props: {},
    mounted () {
      this.init()
    },
    data () {
      return {
        isSelect: true,
        isMore: true, // 查询更多条件
        searchForm: {
          gatherDate: new Date()
        },
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['materialCd', 'materialNm'],
        /** 定义按钮 **/
        btnGroups: [
//          {
//            name: '',
//            className: 'btn-primary',
//            iconName: 'fa-th',
//            event: this.isMoreClk
//          },
//          {
//            name: '查询',
//            className: 'btn-success',
//            iconName: 'fa-search',
//            event: this.query
//          },
          {
            name: '新建',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.addClk
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        selectSells: [],
        totalCount: 0, // 表格总记录数
        hasPagination: true, // 是否有分页
        columns: [ // 表格列
          { label: '条码', prop: 'materialCd', columnsProps: {width: 220} },
          { label: '名称', prop: 'materialNm', columnsProps: {width: 200} },
          { label: '规格', prop: 'spec', columnsProps: {width: 300} },
          { label: '单位', prop: 'unit', columnsProps: {width: 100} },
          { label: '操作', prop: 'operation', columnsProps: {type: 'button'}, cptProperties: [{ label: '编辑', value: 'modify', type: 'warning', icon: 'edit', eventClick: this.modify }, { label: '删除', value: 'del', type: 'danger', icon: 'delete', eventClick: this.del }] }
        ],
        tableData: [],
        tableType: '4',
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        /** 弹出层 **/
        dialogObj_base: {
          title: '物料信息维护',
          type: 'addConfigure',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              materialCd: '',
              materialNm: '',
              spec: '',
              unit: '',
              granularity: '1',
              properties: '',
              propertiesPic: []
            }
          }
        },
        sessionFailedDialogObj: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        }
      }
    },
    methods: {
      init () {
        let param = {}
        param.companyId = getUser().companyId
        param.haveAttach = '1'
        this.reqParams.url = BasePath.VISIT_INVYG_SELECT
        this.reqParams.params = param
        api.requestJava('POST', BasePath.VISIT_INVYG_SELECT, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      clearObject () {
        console.log('this.temp_base:', this.temp_base)
        let temp = {
          title: '物料信息维护',
          type: 'addConfigure',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              materialCd: '',
              materialNm: '',
              spec: '',
              unit: '',
              granularity: '1',
              properties: '',
              propertiesPic: []
            }
          }
        }
        Object.assign(this.dialogObj_base, temp)
      },
      del (index, row) {
        this.$confirm('是否确定删除？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let params = {}
          params.rowId = row.rowId
          api.requestJava('POST', BasePath.VISIT_INVYG_DELETE, params) // 查询
            .then(request => {
              if (Number(request.data.code) === 200) {
                this.$message({ type: 'success', message: '删除成功!' })
                this.init()
              } else {
                this.$notify.error({ title: '提示', message: Number(request.data.code) })
                throw new Error(JSON.stringify(request))
              }
            })
        })
      },  // 删除
      addClk () {
        this.clearObject()
        this.dialogObj_base.dialogVisible = true
      },
      modify (index, row) {
        console.log(JSON.stringify(row))
        this.dialogObj_base.data.form.disabled = true
        Object.assign(this.dialogObj_base.data.form, row)
        this.dialogObj_base.data.form.propertiesPic = row.files
        this.dialogObj_base.dialogVisible = true
      }, // 修改
      confirmBack_base (msg) {
        if (msg) {
          if (msg.data.form.rowId === '') {
            this.queryExit()
          } else {
            this._upload_submit()
          }
        } else {
          this.clearObject()
        }
      },
      queryExit () {
        let params = {}
        params.materialCd = this.dialogObj_base.data.form.materialCd
        api.requestJava('POST', BasePath.VISIT_INVYG_SELECT, params)
          .then(request => {
            console.log(request.data.data.length)
            if (Number(request.data.code) === 200 && request.data.data.length <= 0) {
              this._upload_submit()
            } else {
              this.$notify.error({ title: '提示', message: '物料条码已被占用' })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      _upload_submit () {
        let params = this.dialogObj_base.data.form
        let files = []
        let propertiesPicTemp = params.propertiesPic
        var i = 0
        if (propertiesPicTemp.length > 0) {
          propertiesPicTemp.forEach((e) => {
            let properties = {}
            properties.fileName = propertiesPicTemp[i].fileName
            properties.fileType = 'display_properties_photo'
            properties.fileData = propertiesPicTemp[i].fileData
            files.push(properties)
            i++
          })
        }
        params.files = files
        params.haveAttach = '1'
        params.createdBy = getUser().personId
        params.companyId = getUser().companyId
//        params.materialId = params.rowId
        if (params.rowId === '') {
          api.requestJava('POST', BasePath.VISIT_INVYG_INSERT, params)
            .then(request => {
              if (Number(request.data.code) === 200) {
                this.$notify.success({ title: '提示', message: '新增成功' })
                this.init()
              } else {
                this.$notify.error({ title: '提示', message: '新增错误' })
                throw new Error(JSON.stringify(request))
              }
            })
        } else {
          console.log(JSON.stringify(params))
          api.requestJava('POST', BasePath.VISIT_INVYG_UPDATE, params)
            .then(request => {
              console.log(request.data.code)
              if (Number(request.data.code) === 200) {
                this.$notify.success({ title: '提示', message: '更新成功' })
                this.init()
              } else {
                this.$notify.error({ title: '提示', message: '更新错误' })
                throw new Error(JSON.stringify(request))
              }
            })
            .catch(err => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        }
      },
      headerClick () {},
      sortChange (msg) {},
      rowClick (msg) {},
      onendChange (val) {
        var tmp = JSON.parse(val)
        if (Object.prototype.toString.call(tmp) === '[object Array]') {
          this.dataSource = tmp
        } else {
          this.dataSource = []
          this.dataSource.push(tmp)
        }
      }, // 过滤器修改事件
      sessionFailedBack (msg) {
        let headers = msg.data.form
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.sessionFailedDialogObj.dialogVisible = false
            }
          })
          .catch((err) => { console.log(err) })
      }, // 会话失效
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      }
    },
    components: {
      tableVue,
      _BTN_FILTER,
      _POPUP
    },
    watch: {}
  }
</script>
