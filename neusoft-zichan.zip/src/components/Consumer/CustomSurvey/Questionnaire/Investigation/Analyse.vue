<template>
  <div class="container-fluid">
    <div id="analyse">
      <Selection @callback="condition" />
      <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
      <div class="questionStyle" v-if="staticData.length <= 0" style="min-height: 220px">
        <p style="font-size: 16px;color: #ccc; text-align: center; margin-top: 200px;"><i class="fa fa-area-chart"></i> 暂无数据...</p>
      </div>
      <div class="questionStyle" v-for="(item, index) in staticData" :key="item.id">
        <div v-if="item.inputType === 'input'">
          <CompletionVue :question="item" :idx="index"></CompletionVue>
        </div>
        <div v-if="item.inputType === 'radio'">
          <RadioQuestionVue :question="item" :idx="index"></RadioQuestionVue>
        </div>
        <div v-if="item.type === 'multiselect'">
          <CheckBoxQuestionVue :question="item.question" :idx="index"></CheckBoxQuestionVue>
        </div>
        <div v-if="item.type === 'rate'">
          <RateQuestionVue :question="item.question" :idx="index"></RateQuestionVue>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import CompletionVue from './module/analyse/Completion.vue'
import RadioQuestionVue from './module/analyse/RadioQuestion.vue'
import CheckBoxQuestionVue from './module/analyse/CheckBoxQuestion.vue'
import RateQuestionVue from './module/analyse/RateQuestion.vue'
import Selection from './assembly/Selection.vue'
import _POPUP from '@/components/Template/Popup/Popup.vue'
import log from '@/log'
import api from '@/api'
import BasePath from '@/config/BasePath'
export default {
  components: {
    CompletionVue,        // 填空题分析
    RadioQuestionVue,     // 单选题分析
    CheckBoxQuestionVue,  // 多选题分析
    RateQuestionVue,      // 评分题分析
    Selection,             // 筛选条件
    _POPUP
  },
  data () {
    return {
      logInvalid: {
        title: '会话失效',
        type: 'sessionFailured',
        dialogVisible: false,
        size: 'tiny',
        data: {
          form: {
            userCode: '',
            password: ''
          }
        }
      },
      staticData: [
      ]
    }
  },
  methods: {
    formAnalysisList (params) {
//      {formId: '41077695139831808', planId: '41321854257881088', marketMgrId: '1'}
      api.requestJava('POST', BasePath.FW_COMMON_FORMANALYSIS, params)
        .then((request) => {
          if (Number(request.data.code) === 200) {
            console.log('staticData', request.data.data)
            this.staticData = request.data.data
          } else if (Number(request.data.code) === 401) {
            this.logInvalid.dialogVisible = true
          } else {
            throw new Error(JSON.stringify(request))
          }
        })
        .catch((err) => {
          this.$store.commit('TOGGLE_LOADING')
          let culprit = this.$route.name
          log.work(err, culprit)
        })
    },
    condition (msg) {
      this.formAnalysisList(JSON.parse(msg))
    },
    logEve (msg) {
      let headers = {}
      headers.userCode = msg.data.form.userCode
      headers.password = msg.data.form.password
      let array = [headers, this]
      this.$store.dispatch('login', array)
        .then((msg) => {
          if (msg === 'success') {
            this.logInvalid.dialogVisible = false
            this.$router.go(0)  //  刷新父页面
          }
        })
        .catch((err) => { console.log(err) })
    } //  session 失效
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .questionStyle {
    margin: 10px;
  }
</style>
