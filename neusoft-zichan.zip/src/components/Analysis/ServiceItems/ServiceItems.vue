<!--李晶-->
<!--服务项目统计-->
<style rel="stylesheet/scss" lang="scss" scoped></style>
<template>
  <div class="container-fluid" style="height: 99%">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <div class="text-right">
          <el-date-picker
            v-model="timer"
            type="daterange"
            @change="rangeTime"
            placeholder="选择日期范围">
          </el-date-picker>
          <!--<DatePickerTemp @on-change="rangeTime" :types="daterange" :quick="quick"/>-->
          <el-button type="primary" @click="findClk">查询</el-button>
        </div>
      </el-col>
    </el-row>
    <div style="height: calc(100% - 94px)">
      <iframe id="myIframe" :src="htl" frameborder="0" allowtransparency="true" width="100%" height="100%" scrolling="yes"></iframe>
    </div>
  </div>
</template>
<script>
  import config from '@/config'
  import {getUser} from '@/config/info'
  import {dateFormat} from '@/utils/dateFormat'
  import DatePickerTemp from '@/components/Template/DatePicker/DatePickerTemp.vue'
  export default {
    name: 'ReportVisitStatistics',
    props: {},
    mounted () {
      var date = new Date()
      this.timer = [new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 1), new Date(date.getFullYear(), date.getMonth(), date.getDate(), 23, 59)]
      this.start_expected = dateFormat(Date.parse(this.timer[0]), 'YYYY-MM-DD')
      this.end_expected = dateFormat(Date.parse(this.timer[1]), 'YYYY-MM-DD')
      this.findClk()
    },
    data () {
      return {
        timer: [],
        start_expected: '',
        end_expected: '',
        daterange: 'daterange',
        quick: true,
        company_id: '',
        county_dept: '',
        htl: ''
      }
    },
    methods: {
      rangeTime (val) {
        var tmp = val.split(' - ')
        this.start_expected = tmp[0]
        this.end_expected = tmp[1]
      },
      findClk () {
        var reportId = ''
        if (this.start_expected === '' && this.end_expected === '') {
          this.$notify({
            title: '警告',
            message: '时间范围不能为空',
            type: 'warning'
          })
        } else {
          // 省公司
          if (Number(getUser().unitLevel) === 1) {
            reportId = 'e28b8ab2-3ba8-4c03-b5e8-8c5baccf6d66'
            this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&begin_date=' + this.start_expected + '&end_date=' + this.end_expected
          } else if (Number(getUser().unitLevel) === 2) {
            if (getUser().countyId === null || getUser().countyId === 'null') { // 市公司
              reportId = '2e89f725-90f7-4b27-97ba-2b573230dec2'
              this.company_id = getUser().companyId
              this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&begin_date=' + this.start_expected + '&end_date=' + this.end_expected + '&company_id=' + this.company_id
              // 分公司
            } else if (getUser().countyId !== null) {
              reportId = '5ffd6662-7307-4da5-849b-ae3152fb6bed'
              this.county_dept = getUser().countyId
              this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&begin_date=' + this.start_expected + '&end_date=' + this.end_expected + '&company_id=' + getUser().companyId + '&county_name=' + encodeURI(getUser().countyUnitName)
            }
          }
        }
      }
    },
    components: {
      DatePickerTemp
    },
    watch: {}
  }
</script>

