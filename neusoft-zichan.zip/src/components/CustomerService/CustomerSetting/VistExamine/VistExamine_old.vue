<!-- 徐晓菁 -->
<template>
  <div>
    <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk"  :size='dialogObj.size'  v-popupdra-directive="{'show': dialogObj.dialogVisible}">
      <div class="container-fluid_new">
       <el-row class="filter_style">
        <el-col :gutter="24">
          <el-col :span="24">
              <_BTN_FILTER :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData" /></_BTN_FILTER>
          </el-col>
        </el-col>
       </el-row>
       <div>
         <_TABLE
           ref="table"
           stripe
           @update:data="tabChange"
           :reqParams="reqParams"
           maxHeight="500"
           :column-type="columnType"
           :data="dataSource"
           @select="select"
           @select-all="selectAll"
           :columns="columnHeader"
           :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
           :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
           @selection-change="selectionChange" @cell-dblclick="celldbClick">
         </_TABLE>
        </div>
      </div>
    </el-dialog>
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve"/>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
    </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import { changeListValueByCode, dateFormat } from '@/utils/common'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import MY_POPUP_CONFIG from './Popup.vue'
  import log from '@/log'
  import api from '@/api'
  import axios from 'axios'
  import BasePath from '@/config/BasePath'
  import {getCodeList, getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      getCodeList('VISIT_MODE', (data) => {
        this.changeValueDate.visitMode.group = data
      }) // 拜访方式
      getCodeList('CUSTOMER_GRADE', (data) => {
        this.changeValueDate.customerGrade.group = data
      }) // 客户档级
      getCodeList('VISITING_STATUS', (data) => {
        this.changeValueDate.status.group = data
        console.log(JSON.stringify(this.changeValueDate.status.group))
      })
      let params1 = {}
      params1.manager = getUser().personId
      params1.status = 1
      console.log('params1', params1)
      axios.all([
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params1)
      ])
      .then(axios.spread((first) => {
        this.objectCdGroup = JSON.parse(JSON.stringify(first.data.data))
      }))
    },
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        this.query()
      }
    },
    data () {
      return {
        /** 过滤的字段 **/
        columnType: 'selection',
        isLoading: true,
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        objectCdGroup: [],
        fileName: ['customerCode', 'customerDesc', 'addr', 'legalPerson'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '审核',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.save
          },
          {
            name: '批量删除',
            className: 'btn-danger',
            iconName: 'fa-remove',
            event: this.batchDelClk
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        totalCount: 0, // 表格总记录数
        reqParams: {
          url: '',
          params: {}
        },
        columnHeader: [
          {
            prop: 'customerName', // 列的值
            label: '客户名称', // 列的显示字段
            columnsProps: {width: 250, align: 'left', fixed: true}
          },
          {
            prop: 'status',
            label: '状态',
            columnsProps: {width: 100, align: 'center', formatter: this.changeValue, fixed: true, sortable: true}
          },
          {
            prop: 'addr',
            label: '经营地址',
            className: 'header', // 列的css样式（选填）
            columnsProps: {width: 300, align: 'left'}
          },
          {
            prop: 'customerCode',
            label: '客户代码',
            columnsProps: {width: 140, align: 'center'}
          },
          {
            prop: 'partyName',
            label: '法人',
            columnsProps: {width: 100, align: 'left'}
          },
          {
            prop: 'customerGrade',
            label: '档次',
            columnsProps: {width: 70, align: 'center', formatter: this.changeValue}
          },
          {
            prop: 'expectedTime',
            label: '拜访时间',
            columnsProps: {width: 120, align: 'center', fixed: 'right', formatter: this.changeValue, sortable: true}
          },
          {
            prop: 'visitMode',
            label: '拜访方式',
            columnsProps: {width: 110, align: 'center', formatter: this.changeValue}
          },
          {
            prop: 'opinions',
            label: '审核意见',
            columnsProps: {width: 250, type: 'input', align: 'center', fixed: 'right', editable: true}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 200, type: 'button', fixed: 'right'},
            cptProperties: [
              {
                label: '服务项目',
                value: 'query',
                icon: 'search',
                size: 'small',
                type: 'primary',
                eventClick: this.modify
              },
              {
                label: '删除',
                value: 'del',
                icon: 'delete',
                size: 'small',
                type: 'danger',
                eventClick: this.del
              }
            ]
          }
        ],
        changeValueDate: {
          customerGrade: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          visitMode: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          expectedTime: {
            type: 'date1'
          },
          status: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          }
        },
        tableData: [],
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        /** searchForm **/
        searchForm: {
          custmgrId: '',
          visitBegin: '',
          visitEnd: '',
          manager: ''
        },
        edit: {
          title: '服务项目查看',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              steps: []
            }
          }
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        hasPagination: true,
        sel_all: [],
        sel_all_row: [],
        sel_status: []
      }
    },
    methods: {
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      },
      modify (index, row) {
        let obj = {}
        obj = this.objectCdGroup.find((item) => {
          if (item.rowId === row.visitor) {
            return item
          }
        })
        console.log('obj', obj)
        let param = {}
        param.userId = obj.rowId
        param.userPlaceId = obj.place
        param.userPlaceCode = obj.place
        param.customerId = row.customerId
        param.currentDate = dateFormat(Date.parse(row.expectedTime), 'YYYY-MM-DD')
        param.unitId = obj.companyId
        param.deptId = obj.deptId
        console.log('param', JSON.stringify(param))
        this.findByIdUpper(param)
      }, // 修改
      findByIdUpper (param) {
        api.requestJava('POST', BasePath.VISITPLAN_PASS_STEPSSELECT, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              let kh = []
              let pp = []
              let xf = []
              for (let i = 0; i < request.data.data.length; i++) {
                let rowS = {}
                if (request.data.data[i].cat === 'kh') {
                  rowS.id = request.data.data[i].formId
                  rowS.label = request.data.data[i].title
                  kh.push(rowS)
                } else if (request.data.data[i].cat === 'pp') {
                  rowS.id = request.data.data[i].formId
                  rowS.label = request.data.data[i].title
                  pp.push(rowS)
                } else {
                  rowS.id = request.data.data[i].formId
                  rowS.label = request.data.data[i].title
                  xf.push(rowS)
                }
              }
              let treeData = []
              let step1 = {}
              step1.id = 'xh'
              step1.label = '客户'
              step1.children = kh
              let step2 = {}
              step2.id = 'pp'
              step2.label = '品牌'
              step2.children = pp
              let step3 = {}
              step3.id = 'xf'
              step3.label = '消费'
              step3.children = xf
              treeData.push(step1)
              treeData.push(step2)
              treeData.push(step3)
              this.edit.data.form.steps = treeData
              this.edit.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      save () {
        if (this.sel_all.length === 0) {
          this.$message({type: 'info', message: '请选择需要审核的数据进行操作!'})
          return
        }
        this.$confirm('确定审核通过吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.saveUpper()
        }).catch(() => {
          this.$message({type: 'info', message: '已取消保存操作!'})
        })
      },
      saveUpper () {
        let params = []
        for (let i = 0; i < this.sel_all.length; i++) {
          let rowS = {}
          rowS.rowId = this.sel_all[i].rowId
          rowS.status = '0'
          rowS.checkerId = getUser().personId
          rowS.checkerNm = getUser().userName
          rowS.opinions = this.sel_all[i].opinions
          rowS.auditDate = dateFormat(new Date().getTime(), 'YYYY-MM-DD HH:MM:SS')
          params.push(rowS)
        }
        console.log('params-save', JSON.stringify(params))
        api.requestJava('POST', BasePath.VISITPLAN_PASS, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: '保存成功', type: 'success'})
              this.sel_all_row = []
              this.query()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 保存
      del (index, row) {
        if (JSON.stringify(row.status) !== '"0"') {
          this.$confirm('确定删除此条信息吗？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.deleteUpper(row.rowId)
          }).catch(() => {
            this.$message({type: 'info', message: '已取消删除!'})
          })
        } else {
          this.$message({type: 'info', message: '已审核不可以删除!'})
        }
      },  // 删除
      batchDelClk () {
        if (this.sel_all.length > 0) {
          this.$confirm('确定删除此条信息吗？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.deletebatchUpper()
          })
          .catch(() => {
            this.$message({type: 'info', message: '已取消删除!'})
          })
        }
      },  // 批量删除
      deleteUpper (val) {
        let params = {}
        params.rowId = val
        api.requestJava('POST', BasePath.VISITPLAN_DELETE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              this.query()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 删除接口
      deletebatchUpper () {
        console.log('this.sel_all', this.sel_all)
        api.requestJava('POST', BasePath.VISITPLAN_DELETEBATCH, this.sel_all)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              this.query()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 删除接口
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      select (selection, index) {
        if (selection[0] !== undefined) {
          this.sel_all = []
          this.sel_all_row = []
          for (var i in selection) {
            let rowIds = {}
            rowIds.rowId = selection[i].rowId
            rowIds.opinions = selection[i].opinions
            this.sel_all.push(rowIds)
            this.sel_all_row.push(selection[i])
          }
        }
      }, // 选中某1条
      selectAll (data) {
        this.sel_all = []
        for (var i in data) {
          var rowIds = {}
          rowIds.rowId = data[i].rowId
          rowIds.opinions = data[i].opinions
          this.sel_all.push(rowIds)
        }
      }, // 全选
      celldbClick (row, column, cell, event) {
        this.$set(row, '_edit', !row._edit)
      },
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      query () {
        let params = {}
        params.custmgrId = this.dialogObj.data.form.custmgrId
        params.visitBegin = this.dialogObj.data.form.visitBegin
        params.visitEnd = this.dialogObj.data.form.visitEnd
//        params.whereClause = `and status in('0','4')`
        this.queryUpper(params)
      }, // 查询方法
      queryUpper (params) {
        this.sel_status = []
        this.reqParams.url = BasePath.VISITQUERY_SELECT
        this.reqParams.params = params
        api.requestJava('POST', BasePath.VISITQUERY_SELECT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.totalCount = Number(request.data.count)
              if (this.tableData.length > 0) {
                request.data.data.forEach((val, key) => {
                  this.$set(this.tableData[key], 'sPi', val.status)
                })
              }
              console.log(this.tableData)
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
//              if (this.tableData.length > 0) {

//              }
//              this.$nextTick(() => {
//                this.toggleSelection(this.sel_status)
//              })
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      sortChange (msg) {},
      rowClick (msg) {},
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      editEve (msg) {
        if (msg === 'update') {
        }
        this.edit.dialogVisible = false
        let tmp = {
          title: '服务项目查看',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              steps: []
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.table.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      onendChange (val) {}, // 过滤器修改事件
      selectionChange (rows) {}
//      toggleSelection (rows) {
//        if (rows) {
//          rows.forEach(row => {
//            this.$refs.table.toggleRowSelection(row)
//          })
//        } else {
//          this.$refs.table.clearSelection()
//        }
//      }
    },
    components: {
      _TABLE,
      _POPUP,
      MY_POPUP_CONFIG,
      _BTN_FILTER
    }
  }
</script>

<style scoped>
  .container-fluid_new {
    background: #FFF;
    margin: 0 5px 5px 5px;
  }
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-24 {
    height: 36px;
  }

</style>
