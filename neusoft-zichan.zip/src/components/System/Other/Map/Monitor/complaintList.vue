<template>
  <div class="container-fluid_new">
    <_TABLE
      ref="table"
      stripe
      maxHeight="500"
      :data="dataSource"
      :columns="columnHeader"
      @update:data="tabChange" :reqParams="reqParams"
      :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
      :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
      @selection-change="selectionChange"></_TABLE>
  </div>
</template>
<style scoped>
  .container-fluid_new {
    background: #FFF;
  }
</style>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import log from '@/log'
  export default {
    props: {
      custId: {
        type: String,
        default: ''
      }
    },
    mounted () {
      let cust = JSON.parse(this.custId)
      this.init(cust.rowId)
    },
    data () {
      return {
        /** table **/
        isSelect: false,
        isMore: true, // 查询更多条件
        currentPage: 1, // 默认当前第一页
        pageSize: 500,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        tableType: '3',
        columnHeader: [
          {
            prop: 'createdTime', // 列的值
            label: '时间', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'contents',
            label: '内容',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          },
          {
            prop: 'results',
            label: '处理结果',
            columnsProps: {align: 'left'}
          },
          {
            prop: 'custmgrNm',
            label: '处理人',
            columnsProps: {align: 'left'}
          },
          {
            prop: 'handlingTime',
            label: '处理时间',
            columnsProps: {align: 'left'}
          }
        ],
        dataSource: [],
        tableData: [],
        hasPagination: true
      }
    },
    methods: {
      selectionChange (rows) {},
      isMoreClk () {
        this.isSelect = !this.isSelect
      },
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      headerClick () {},
      sortChange (msg) {},
      rowClick (msg) {},
      init (val) {
        let param = {}
        param.customerId = val
        console.log('param', param)
        this.reqParams.url = BasePath.COMPLAINTREC_SELECT
        this.reqParams.params = param
        api.requestJava('POST', BasePath.COMPLAINTREC_SELECT, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.currentPage = 1
              this.totalCount = this.tableData.length
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }
    },
    components: {
      _TABLE
    },
    watch: {
      custId (val, old) {
        let cust = JSON.parse(val)
        this.init(cust.rowId)
      }
    }
  }
</script>
