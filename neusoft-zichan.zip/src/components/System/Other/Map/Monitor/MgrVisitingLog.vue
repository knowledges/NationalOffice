<style scoped>
  .el-form-item {
    margin: 10px 20px 0 20px;
  }
  .input_width {
    width: 160px;
  }
  .input_width1 {
    width: 120px;
  }
  .p_title {
    font-size: 12px;
    color: #ccc;
    border-top: 1px solid #ccc;
    margin: 10px 20px;
    padding: 15px;
  }
  .p_title span {
    margin: 0 5px;
  }
  .p_title span em {
    color: #0bb63d;
  }
  .el-form-div {
    background: #FFF;
    border-radius: 4px;
    margin-bottom: 5px;
  }
  .timer_div {
    padding: 5px 20px;
    color: #000;
  }
</style>
<template>
  <div>
    <_POPUP :dialogObj='dialogObj_base'/>
    <_TABLEPOPUP :dialogObj='dialogObj_table' ref="tableInfo"/>
    <el-form :inline="true" :model="formInline" class="demo-form-inline">
      <div class="el-form-div">

        <el-row>
          <el-col :span="26">
            <el-form-item label="客户经理">
              <!--<el-input v-model="formInline.custmgrId" placeholder="客户经理"></el-input>-->
              <el-select v-model="formInline.custmgrId" class="input_width1" :clearable="true" placeholder="请选择" :disabled="custmgrDisable">
                <el-option
                  v-for="item in options_custmgrId"
                  :key="item.rowId"
                  :label="item.employeeName"
                  :value="item.rowId">
                </el-option>
              </el-select>
              <el-button icon="el-icon-search" @click="onService" type="primary" plain>服务内容</el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="拜访日期">
              <el-date-picker
                class="input_width"
                v-model="formInline.visitDate"
                type="date"
                format="yyyy-MM-dd"
                placeholder="选择日期">
              </el-date-picker>
              <el-button icon="el-icon-search" @click="onSubmit" type="primary" plain>搜索</el-button>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="24">
            <div style="width: 100%;text-align: center;">
              <p class="p_title">
                <span>计划：<em> {{planCusts}}</em></span>
                <span>实访：<em> {{visitCusts}}</em></span>
                <span>计划未访：<em> {{notVistiCusts}}</em></span>
                <span>异常：<em> {{abnCusts}}</em></span>
              </p>
            </div>
          </el-col>
        </el-row>
      </div>
      <div class="el-form-div" style="margin: 0">
        <el-row style="background: #f7f7f7;">
          <el-col :span="24">
            <el-col :span="24">
              <el-col :span="12">
                <div class="timer_div">开始时间：{{visitTimeBegin}}</div>
              </el-col>
              <el-col :span="12">
                <div class="timer_div">结束时间：{{visitTimeEnd}}</div>
              </el-col>
            </el-col>
            <el-col :span="24">
              <el-col :span="12">
                <div class="timer_div">拜访总时长：{{visitAllTimes}}</div>
              </el-col>
              <el-col :span="12">
                <div class="timer_div">
                  在店总时长：{{visitCustTimes}}分钟
                </div>
              </el-col>
            </el-col>
            <!--<el-col :span="24">-->
              <!--<el-col :span="24">-->
                <!--<div class="timer_div">拜访总里程：{{visitTotalMileage}} 米</div>-->
              <!--</el-col>-->
            <!--</el-col>-->
          </el-col>
        </el-row>
        <el-row style="display: inline-block;width: 100%; height: calc(100vh - 358px);">
          <div style="position:absolute; height: calc(100vh - 363px); overflow:auto; width: 100%;"  v-if="isSelect">
            <!--<template v-for="(li,key) in obj"><span><div>{{key+1}}&#45;&#45;{{li}}</div></span></template>-->
            <el-col :span="24">
              <el-steps direction="vertical" finish-status="success">
                <template v-for="(val, key) in obj">
                  <StepVue :buttons="buttons" :info="val.info" :title="val.title" :description="val.description" :des="val.desc">
                  </StepVue>
                </template>
                <template v-if="obj.length <= 0">
                  <h5 class="text-center" style="display: inline-block; width: 100%; margin-top: 25%;">暂无数据...</h5>
                </template>
              </el-steps>
            </el-col>
          </div>
        </el-row>
      </div>
    </el-form>
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/TabPagin/Table.vue'
  import InputTemp from '@/components/Template/filter/InputTemp.vue'
  import uploadTemp from '@/components/Template/Popup/uploadTemp.vue'
  import DatePickerTemp from '@/components/Template/DatePicker/DatePickerTemp.vue'
  import compositeInput from '@/components/Template/Popup/compositeInput.vue'
  import _POPUP from './DetailPopup.vue'
  import _TABLEPOPUP from './TablePopup.vue'
  import StepVue from '@/components/Template/Step/Step.vue'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  import { dateFormat, GetDateDiff } from '@/utils/dateFormat.js'
  import api from '@/api'
  import axios from 'axios'
  import {MP} from '@/components/Template/MAP/map.js'
  //  import log from '@/log'
  export default {
    mounted () {
      this.init()
      let _this = this
      let custMgrParam = {} // 客户经理
      // custMgrParam.place = 135
      if (getUser().place === '24') {
        custMgrParam.countyDept = getUser().countyId
        custMgrParam.manager = getUser().personId
      } else if (getUser().place === '135') {
        custMgrParam.countyDept = getUser().countyId
      } else if (getUser().place === '9999') {
        custMgrParam.companyId = this.$route.params.companyId
        custMgrParam.countyDept = this.$route.params.countyDept
      } else if (getUser().unitLevel === '2') {
        custMgrParam.companyId = getUser().companyId
      }
      custMgrParam.fields = {include: 'employeeName,rowId'}
      custMgrParam.status = 1
      console.log('客户经理查询条件:' + JSON.stringify(custMgrParam))
      axios.all([
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, custMgrParam) // 市场经理
      ])
        .then(axios.spread(function (_custmgrId) {
          _this.options_custmgrId = JSON.parse(JSON.stringify(_custmgrId.data.data))
//          console.log('客户经理id:' + JSON.stringify(_this.options_custmgrId))
        }))
    },
    data () {
      return {
        visitTimeBegin: '',
        visitTimeEnd: '',
        visitAllTimes: '',
        visitCustTimes: '',
        visitTotalMileage: 0,
        isSelect: true,
        planCusts: '',
        visitCusts: '',
        notVistiCusts: '',
        abnCusts: '',
        plan1: '',
        plan2: '',
        seqNo: 0,
        obj: [],
        options_custmgrId: [],
        custmgrDisable: false,
        formInline: {
          custmgrId: getUser().personId,
          visitDate: new Date()
//          visitDate: this.getTime(Date.parse(new Date()))
        },
        buttons: [
          {
            text: '定位', // 按钮的名称
            functionName: this.locateRow // 方法名自定义 参数（info）Object 类型
          },
          {
            text: '详情',
            functionName: this.detailRow
          }
        ],
        tableData: [],
        /** 弹出层 **/
        dialogObj_base: {
          title: '客户详情',
          type: 'addConfigure',
          dialogVisible: false,
          size: 'large',
          customerId: '',
          data: {
            form: {
              customerId: ''
            }
          }
        },
        /** 弹出层 **/
        dialogObj_table: {
          title: '服务项目',
          type: 'addConfigure',
          dialogVisible: false,
          size: 'large',
          visitor: '',
          beginDate: '',
          endDate: '',
          data: {
            form: {
              visitor: '',
              beginDate: '',
              endDate: ''
            }
          }
        },
        ak: 'sFGGCnZu8HcewIdGMFGGaGypsfILG36G',
        BMap: ''
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      init () {
        this.formInline.custmgrId = this.$route.params.uId
        this.formInline.visitDate = this.$route.params.visitDate
        if (getUser().place === '135') {
          this.custmgrDisable = true
        }
        let mgrIdParam = {}
        mgrIdParam.custmgrId = this.formInline.custmgrId
        mgrIdParam.visitBegin = this.getTime(Date.parse(this.formInline.visitDate))
        mgrIdParam.visitEnd = this.getTime(Date.parse(this.formInline.visitDate))
        api.requestJava('POST', BasePath.CUSMGR_STATISTICS, mgrIdParam, {})
          .then(request => {
            if (Number(request.data.code) === 200) {
              var i = 0
              if (request.data.data.length > 0) {
                this.isSelect = true
                this.tableData = request.data.data
                this.tableData.forEach((e) => {
                  console.log('时间：' + request.data.data[i].visitTimeBegin)
                  console.log('时间：' + request.data.data[i].visitTimeEnd)
                  this.visitTimeBegin = request.data.data[i].visitTimeBegin === 'null' ? '0' : dateFormat(request.data.data[i].visitTimeBegin, 'HH:mm')
                  this.visitTimeEnd = request.data.data[i].visitTimeEnd === 'null' ? '0' : dateFormat(request.data.data[i].visitTimeEnd, 'HH:mm')
                  this.visitAllTimes = request.data.data[i].visitAllTimes === 'null' ? '0' : request.data.data[i].visitAllTimes
                  this.visitCustTimes = request.data.data[i].visitCustTimes === 'null' ? '0' : request.data.data[i].visitCustTimes
                  this.planCusts = request.data.data[i].planCusts
                  this.visitCusts = request.data.data[i].visitCusts
                  this.abnCusts = request.data.data[i].abnCusts
                  this.notVistiCusts = request.data.data[i].unVisitCusts
                  i++
                })
                let custmgrParam = {}
                custmgrParam.custmgrId = this.formInline.custmgrId
                custmgrParam.queryDate = this.getTime(Date.parse(this.formInline.visitDate))
                api.requestJava('POST', BasePath.CUSTMGR_STATUS, custmgrParam, {})
                  .then(request => {
                    if (Number(request.data.code) === 200) {
                      var i = 0
                      if (request.data.data.length !== 0) {
                        request.data.data.forEach((e) => {
                          console.log('获取的数据：' + JSON.stringify(request.data.data[i].startTime))
                          let stepDescript = {}
                          if (request.data.data[i].status === '0') { // 未拜访
                            stepDescript.title = ' 未拜访 ' + request.data.data[i].addr + ' ' + request.data.data[i].customerName
                            stepDescript.description = '签到距离：' + request.data.data[i].signDist
                          } else if (request.data.data[i].status === '1') { // 拜访中
                            stepDescript.title = dateFormat(request.data.data[i].startTime, 'HH:mm') + ' 抵达 ' + request.data.data[i].addr + ' ' + request.data.data[i].customerName
                            stepDescript.description = '服务时长 ' + GetDateDiff(request.data.data[i].startTime, request.data.data[i].endTime, 'minute') + ' 分 ' + dateFormat(request.data.data[i].startTime, 'HH:mm') + '- ****'
                            stepDescript.desc = '签到距离：' + request.data.data[i].signDist
                          } else if (request.data.data[i].status === '2' || request.data.data[i].status === '5') { // 拜访结束
                            stepDescript.title = dateFormat(request.data.data[i].startTime, 'HH:mm') + ' 抵达 ' + request.data.data[i].addr + ' ' + request.data.data[i].customerName
                            stepDescript.description = '服务时长 ' + GetDateDiff(request.data.data[i].startTime, request.data.data[i].endTime, 'minute') + ' 分 ' + dateFormat(request.data.data[i].startTime, 'HH:mm') + '-' + dateFormat(request.data.data[i].endTime, 'HH:mm')
                            stepDescript.desc = '签到距离：' + request.data.data[i].signDist
                          } else if (request.data.data[i].status === '3') { // 拜访异常
                            stepDescript.title = dateFormat(request.data.data[i].startTime, 'HH:mm') + ' 抵达 ' + ' 拜访异常 ' + request.data.data[i].addr + ' ' + request.data.data[i].customerName
                            stepDescript.description = ''
                          } else if (request.data.data[i].status === '9') { // 作废
                            stepDescript.title = ' 拜访作废 ' + request.data.data[i].addr + ' ' + request.data.data[i].customerName
                            stepDescript.description = ''
                          }
                          if (request.data.data[i].status === '1' || request.data.data[i].status === '2' || request.data.data[i].status === '3' || request.data.data[i].status === '5') {
                            let tempinfo = {}
                            tempinfo.X = request.data.data[i].x
                            tempinfo.Y = request.data.data[i].y
                            tempinfo.customerId = request.data.data[i].customerId
                            tempinfo.customerName = request.data.data[i].customerName
                            tempinfo.type = 'zoom'
                            stepDescript.info = tempinfo
                            this.obj.push(stepDescript)
//                            console.log('数据返回记录：' + JSON.stringify(request.data.data[i]))
                            if (request.data.data[i].status === 1) {
                              this.seqNo = request.data.data[i].seqNo
                            } else {
                              this.seqNo = 0
                            }
                            // 测算距离
                            if (request.data.data[i].positionX !== '' && request.data.data[i].positionY !== '' && request.data.data[i + 1].positionX !== '' && request.data.data[i + 1].positionY !== '') {
                              let positionInfo = {}
                              positionInfo.type = 'calcDis'
                              positionInfo.positionAX = request.data.data[i].positionX
                              positionInfo.positionAY = request.data.data[i].positionY
                              positionInfo.positionBX = request.data.data[i + 1].positionX
                              positionInfo.positionBY = request.data.data[i + 1].positionY
                              console.log(JSON.stringify(positionInfo))
                              this.calculateMileage(positionInfo)
                            }
                          }
                          i++
                        })
                      } else {
                      }
                    } else if (Number(request.data.code) === 401) {
                      this.sessionFailedDialogObj.dialogVisible = true
                    } else {
                      throw new Error(JSON.stringify(request))
                    }
                  }).catch(() => {
                    this.$message({ type: 'info', message: '操作异常!' })
                  }
                )
              } else {
                this.clearObj
              }
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          }).catch(() => {
            this.$message({ type: 'info', message: '操作异常!' })
          }
        )
//        this.visitTotalMileage = parseInt(Number(this.visitTotalMileage))
      },
      clearObj () {
        this.planCusts = '0'
        this.visitCusts = '0'
        this.notVistiCusts = '0'
        this.abnCusts = '0'
        this.obj = []
        this.isSelect = false
        this.visitTimeBegin = '0'
        this.visitTimeEnd = '0'
        this.visitAllTimes = '0'
        this.visitCustTimes = '0'
        this.planCusts = '0'
        this.visitCusts = '0'
        this.abnCusts = '0'
        this.notVistiCusts = '0'
      },
      onSubmit () {
        let mgrIdParam = {}
        mgrIdParam.custmgrId = this.formInline.custmgrId
        mgrIdParam.visitBegin = this.getTime(Date.parse(this.formInline.visitDate))
        mgrIdParam.visitEnd = this.getTime(Date.parse(this.formInline.visitDate))
//        console.log('mgrIdParam' + JSON.stringify(mgrIdParam))
        api.requestJava('POST', BasePath.CUSMGR_STATISTICS, mgrIdParam, {})
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              var i = 0
              if (request.data.data.length > 0) {
                this.clearObj()
                this.isSelect = true
                this.tableData.forEach((e) => {
                  console.log('时间：' + request.data.data[i].visitTimeBegin)
                  console.log('时间：' + request.data.data[i].visitTimeEnd)
                  this.visitTimeBegin = request.data.data[i].visitTimeBegin === 'null' ? '0' : dateFormat(request.data.data[i].visitTimeBegin, 'HH:mm')
                  this.visitTimeEnd = request.data.data[i].visitTimeEnd === 'null' ? '0' : dateFormat(request.data.data[i].visitTimeEnd, 'HH:mm')
                  this.visitAllTimes = request.data.data[i].visitAllTimes === 'null' ? '0' : request.data.data[i].visitAllTimes
                  this.visitCustTimes = request.data.data[i].visitCustTimes === 'null' ? '0' : request.data.data[i].visitCustTimes
                  this.planCusts = request.data.data[i].planCusts
                  this.visitCusts = request.data.data[i].visitCusts
                  this.abnCusts = request.data.data[i].abnCusts
                  this.notVistiCusts = request.data.data[i].unVisitCusts
                  i++
                })
                let info = {}
                info.type = 'refreshMap'
                info.custmgrId = this.formInline.custmgrId
                info.queryDate = this.getTime(Date.parse(this.formInline.visitDate))
                this.refreshMap(info) // 刷新地图
                let custmgrParam = {}
                custmgrParam.custmgrId = this.formInline.custmgrId
                custmgrParam.queryDate = this.getTime(Date.parse(this.formInline.visitDate))
                console.log('custmgrParam' + JSON.stringify(custmgrParam))
                api.requestJava('POST', BasePath.CUSTMGR_STATUS, custmgrParam, {})
                  .then(request => {
                    if (Number(request.data.code) === 200) {
                      var i = 0
                      if (request.data.data.length > 0) {
                        request.data.data.forEach((e) => {
                          let stepDescript = {}
                          if (request.data.data[i].status === '0') { // 未拜访
                            stepDescript.title = ' 未拜访 ' + request.data.data[i].addr + ' ' + request.data.data[i].customerName
                            stepDescript.description = ''
                          } else if (request.data.data[i].status === '1') { // 拜访中
                            stepDescript.title = dateFormat(request.data.data[i].startTime, 'HH:mm') + ' 抵达 ' + request.data.data[i].addr + ' ' + request.data.data[i].customerName
                            stepDescript.description = '服务时长 ' + GetDateDiff(request.data.data[i].startTime, request.data.data[i].endTime, 'minute') + ' 分 ' + dateFormat(request.data.data[i].startTime, 'HH:mm') + '- ****'
                            stepDescript.desc = '签到距离：' + request.data.data[i].signDist
                          } else if (request.data.data[i].status === '2' || request.data.data[i].status === '5') { // 拜访结束
                            stepDescript.title = dateFormat(request.data.data[i].startTime, 'HH:mm') + ' 抵达 ' + request.data.data[i].addr + ' ' + request.data.data[i].customerName
                            stepDescript.description = '服务时长 ' + GetDateDiff(request.data.data[i].startTime, request.data.data[i].endTime, 'minute') + ' 分 ' + dateFormat(request.data.data[i].startTime, 'HH:mm') + '-' + dateFormat(request.data.data[i].endTime, 'HH:mm')
                            stepDescript.desc = '签到距离：' + request.data.data[i].signDist
                          } else if (request.data.data[i].status === '3') { // 拜访异常
                            stepDescript.title = dateFormat(request.data.data[i].startTime, 'HH:mm') + ' 抵达 ' + ' 拜访异常 ' + request.data.data[i].addr + ' ' + request.data.data[i].customerName
                            stepDescript.description = ''
                          } else if (request.data.data[i].status === '9') { // 作废
                            stepDescript.title = ' 拜访作废 ' + request.data.data[i].addr + ' ' + request.data.data[i].customerName
                            stepDescript.description = ''
                          }
                          if (request.data.data[i].status === '1' || request.data.data[i].status === '2' || request.data.data[i].status === '3' || request.data.data[i].status === '5') {
                            let tempinfo = {}
                            tempinfo.X = request.data.data[i].x
                            tempinfo.Y = request.data.data[i].y
                            tempinfo.customerId = request.data.data[i].customerId
                            tempinfo.customerName = request.data.data[i].customerName
                            tempinfo.type = 'zoom'
                            stepDescript.info = tempinfo
                            this.obj.push(stepDescript)
//                            console.log('数据返回记录：' + JSON.stringify(stepDescript))
                            if (request.data.data[i].status === 1) {
                              this.seqNo = request.data.data[i].seqNo
                            } else {
                              this.seqNo = 0
                            }
                          }
                          i++
                        })
                      }
                    } else if (Number(request.data.code) === 401) {
                      this.sessionFailedDialogObj.dialogVisible = true
                    } else {
                      throw new Error(JSON.stringify(request))
                    }
                  }).catch(() => {
                    this.$message({ type: 'info', message: '操作异常!' })
                  }
                )
              } else {
                this.clearObj()
                let info = {}
                info.type = 'refreshMap'
                info.custmgrId = this.formInline.custmgrId
                info.queryDate = this.formInline.visitDate
                this.refreshMap(info) // 刷新地图
              }
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          }).catch(() => {
            this.$message({ type: 'info', message: '操作异常!' })
          }
        )
      },
      onService () {
        this.dialogObj_table.visitor = this.formInline.custmgrId
        this.dialogObj_table.beginDate = this.getTime(Date.parse(this.formInline.visitDate))
        this.dialogObj_table.endDate = this.getTime(Date.parse(this.formInline.visitDate))
        this.dialogObj_table.dialogVisible = true
        this.$refs.tableInfo.init()
      },
      detailRow (info) {
        let param = {}
        param.rowId = info.customerId
        param.haveAttach = '1'
        api.requestJava('POST', BasePath.CUSTOMER_SELECTONE, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.dialogObj_base.customerId = JSON.stringify(request.data.data)
              this.dialogObj_base.dialogVisible = true
            } else {
              this.$notify.error({ title: '提示', message: request.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      locateRow (info) {
//        alert(JSON.stringify(info))
        if (info.X !== '' && info.Y !== '') {
          this.$emit('confirmBack', info)
        } else {
          this.$message({ type: 'info', message: '此客户的坐标信息不全，无法定位!' })
        }
      },
      refreshMap (info) {
        this.$emit('confirmBack', info)
      },
      formatDate (time) {
        var date = new Date(time)
        return formatDate(date, 'HH:mm')
      },
      calculateMileage (info) {
        if (info.positionAX !== '' && info.positionAY !== '' && info.positionBX !== '' && info.positionBY !== '') {
          this.$emit('confirmBack', info)
        } else {
          this.$message({ type: 'info', message: '客户经理的坐标数据不全，无法测量距离!' })
        }
      },
      calcDis (info) {
        this.visitTotalMileage = this.visitTotalMileage + Math.round(Number(info))
      },
      // gps转换baidu坐标
      changeGps () {
        MP(this.ak).then((Bmap) => {
          BMap = Bmap
          var points = [
            new BMap.Point(118.7819670, 32.0523000),
            new BMap.Point(118.7332330, 32.2046830),
            new BMap.Point(118.7614330, 32.2351000),
            new BMap.Point(118.7614330, 32.2351000),
            new BMap.Point(118.7595170, 32.2335170),
            new BMap.Point(118.7342670, 32.2046170),
            new BMap.Point(118.7334670, 32.2067330),
            new BMap.Point(118.7452670, 32.2066830),
            new BMap.Point(118.7451330, 32.1937170)
          ]
          var translateCallback = function (data) {
            console.log(data.points)
          }
          var convertor = new BMap.Convertor()
          convertor.translate(points, 1, 5, translateCallback)
        })
      }
    },
    components: {
      _TABLE, InputTemp, uploadTemp, DatePickerTemp, compositeInput, _POPUP, StepVue, _TABLEPOPUP
    }
  }
</script>
