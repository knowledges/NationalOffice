<template lang="html">
  <div class="sfc-table-wrapper">
    <table class="sfc-table" :style="{'height': `${wrapperHeight}px`}">
      <tbody class="sfc-table-bg">
        <tr>
          <td v-for="day in eventsWeek" :class="{'highlight': day.moment.isBetween(...highlightTimeRange, 'day', '[]')}" :data-date="day.dateText" @mousedown="recordDate('start', $event)" @mouseup="recordDate('end', $event)" @mouseover="recordDate('between', $event)">
          </td>
        </tr>
      </tbody>
    </table>
    <table class="sfc-table sfc-events-table" ref="eventsTable">
      <tbody>
        <tr class="sfc-date">
          <!-- date -->
          <td v-for="day in eventsWeek" :class="{'not-current-month': !day.moment.isSame(monthMoment, 'month')}">{{ day.date }}</td>
        </tr>
        <tr class="sfc-events" v-for="i in maxCount">
          <!-- events wrapper -->
          <template v-for="day in eventsWeek">
            <td v-if="!day.events[i - 1]"></td>
            <template v-else-if="day.events[i - 1].placehold"></template>
            <td v-else-if="day.events[i - 1]" :colspan="day.events[i - 1].colspan">
              <div class="sfc-event-item " :class="{'is-start': day.events[i - 1].isStart, 'is-end': day.events[i - 1].isEnd}" :title="day.events[i - 1].content">
                {{ day.events[i - 1].time }}<br/>{{ day.events[i - 1].content }}
              </div>
            </td>
          </template>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import { getDurationsDays } from '../util.js'

const WAIT_TIME = 100
export default {
  props: {
    monthMoment: {
      type: Object
    },
    week: {
      type: Array,
      required: true
    },
    events: {
      type: Array,
      default: []
    },
    highlightTimeRange: {
      type: Array,
      default: []
    }
  },
  data () {
    return {
      wrapperHeight: 0
    }
  },
  computed: {
    eventsWeek () {
      let week = this.week.map((day) => {
        day.events = []
        day.dateText = day.moment.format('YYYY-MM-DD')
        this.events.forEach(function (eventItem, eventIndex) {
          if (day.moment.isBetween(eventItem.startMoment.clone().startOf('day'), eventItem.endMoment.clone().endOf('day'), null, '[]')) {
            let event
            if (eventItem.startMoment.isSame(day.moment, 'day')) {
              // event start in current day, must have a start, maybe an end
              let durationDays = eventItem.durationDays
              let state = {
                isStart: true,
                isEnd: true
              }
              if ((eventItem.durationDays + eventItem.startWeekday - 1) > 7) {
                durationDays = 7 - eventItem.startWeekday + 1
                state.isEnd = false
              }
              event = {
                time: `${eventItem.startMoment.format('MM-DD')}~${eventItem.endMoment.format('MM-DD')}`,
                content: eventItem.content,
                colspan: durationDays
              }
              Object.assign(event, state)
              let order = 0
              for (let i = 0; i < day.events.length; i++) {
                if (!day.events[i]) order = i
              }
              eventItem._order = order || day.events.length
            } else if (day.moment.isoWeekday() === 1) {
              // current day is monday, event began at least last week, not a start, maybe have an end
              let durationDays = getDurationsDays(day.moment.format('YYYY-MM-DD'), eventItem.endMoment.format('YYYY-MM-DD'))
              let state = {
                isStart: false,
                isEnd: true
              }
              if (durationDays > 7) {
                durationDays = 7
                state.isEnd = false
              }
              event = {
                time: `${eventItem.startMoment.format('MM-DD')}~${eventItem.endMoment.format('MM-DD')}`,
                content: eventItem.content,
                colspan: durationDays
              }
              Object.assign(event, state)
              let order = 0
              for (let i = 0; i < day.events.length; i++) {
                if (!day.events[i]) order = i
              }
              eventItem._order = order || day.events.length
            } else {
              event = {
                placehold: true
              }
            }
            let order = eventItem._order || day.events.length
            day.events[order] = event
          }
        })
        return day
      })
      return week
    },
    maxCount () {
      return Math.max.apply(null, this.eventsWeek.map(day => day.events.length))
    }
  },
  watch: {
    eventsWeek () {
      this.updateHeight()
    }
  },
  mounted () {
    this.updateHeight()
  },
  methods: {
    recordDate (point, e) {
      if (this._recordTimer) {
        clearTimeout(this._recordTimer)
      }
      this._recordTimer = setTimeout(() => {
        this.$emit('select', point, e)
      }, WAIT_TIME)
    },
    updateHeight () {
      this.$nextTick(() => {
        let height = this.$refs.eventsTable.clientHeight
        this.wrapperHeight = height
      })
    }
  }
}
</script>

<style scoped rel="stylesheet/scss" lang="scss">
  .sfc-button {
    display: inline-block;
    height: 24px;
    padding: 0 5px;
    border: 1px solid #666;
    border-color: #3b91ad;
    color: #3b91ad;
    border-radius: 4px;
    cursor: pointer;
    &:hover {
      color: darken(#3b91ad, 50%);
      border-color: #3b91ad;
    }
  }
  .sfc-month-hint{
    margin-bottom: 10px;
    text-align: center;
    zoom: 1;
    height: auto;
    &:before,
    &:after {
      content: " ";
      display: table;
    }
    &:after {
      clear: both;
      visibility: hidden;
      font-size: 0;
      height: 0;
    }
    .month-info{
      float: left;
    }
    .operations{
      float: right;
    }
  }
  .sfc-wrapper{
    width: 800px;
    margin: auto;
    .sfc-table-wrapper {
      position: relative;
      margin-top: -1px;
      .sfc-events-table {
        position: absolute;
        top: 0;
        left: 0;
        pointer-events: none;
      }
    }
    .sfc-table{
      width: 100%;
      table-layout: fixed;
      border-spacing: 0;
      border-collapse: collapse;
      user-select: none;
      .sfc-table-bg{
        td {
          border: 1px solid #CCC;
          height: 80px;
          background-color: white;
          color: #000;
          &.highlight{
            background-color: rgba(59, 143, 173, .1)
          }
        }
      }
    }
    .sfc-date{
      text-align: right;
      font-size: 14px;
      .not-current-month {
        color: #ddd;
      }
      td {
        padding-top: 2px;
        padding-right: 5px;
      }
    }
    .sfc-events {
      .sfc-event-item {
        margin: -1px 0 2px;
        padding: 2px;
        border: 1px solid #666;
        border-color: #3b91ad;
        background-color: #3b91ad;
        color: #fff;
        font-size: 12px;
        line-height: 1.2;
        overflow: hidden;
        text-overflow: ellipsis;
        pointer-events: auto;
        &.is-start {
          margin-left: 2px;
          border-top-left-radius: 2px;
          border-bottom-left-radius: 2px;
        }
        &.is-end {
          margin-right: 2px;
          border-top-right-radius: 2px;
          border-bottom-right-radius: 2px;
        }
      }
    }
  }
</style>
