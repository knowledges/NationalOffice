<!--赵继越-->
<template>
  <div>
    <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="closeModalEve" :size='dialogObj.size' v-popupdra-directive="{'show': dialogObj.dialogVisible}">
      <div v-if= "dialogObj.type == 'addRecord'">
        <el-form :model="dialogObj.data.form" label-width="90px"  :rules="addrules" ref="addForm">
         <el-row :gutter="20">
           <el-col :span="12">
            <el-form-item  prop="trainDate" label="培训时间" >
              <el-date-picker
                v-model="dialogObj.data.form.trainDate"
                type="date"
                format="yyyy-MM-dd"
                :editable=false
                :clearable=false
                placeholder="选择培训时间">
              </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span='12' >
            <el-form-item prop="trainAddr" label="培训地点">
              <el-input v-model="dialogObj.data.form.trainAddr" auto-complete="off" class="inputInline" value="number"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item  prop="trainerId" label="培训人员" >
              <el-select v-model="dialogObj.data.form.trainerNm" filterable :clearable="true" placeholder="请选择">
                <el-option
                  v-for="item in optionsManager"
                  :key="item.rowId"
                  :label="item.employeeName"
                  :value="item.rowId">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item prop="trainingObjs" label="培训对象">
              <el-input v-model="dialogObj.data.form.trainingObjs" auto-complete="off" class="inputInline" type='trainingObjs'></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10">
            <el-form-item  prop="contents" label="培训内容" >
              <el-input v-model="dialogObj.data.form.contents" auto-complete="off" class="inputInline" type="contents"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="24">
          </el-col>
        </el-row>
        <el-form-item label="文件上传">
          <uploadTemp style="margin:20px;" :files="dialogObj.data.form.files" ref="uploadPic"></uploadTemp>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="resetForm ('addForm')">取 消</el-button>
        <el-button type="success" @click="save('addForm')" >保 存</el-button>
        <el-button type="success" @click="saveClk('addForm')" >提 交</el-button>
      </div>
      </div>
      <div v-if= "dialogObj.type == 'eidRecord'">
        <el-form :model="dialogObj.data.form" label-width="90px"  :rules="addrules" ref="addForm">
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item  prop="trainDate" label="培训时间" >
                <el-date-picker
                  v-model="dialogObj.data.form.trainDate"
                  type="date"
                  format="yyyy-MM-dd"
                  :editable=false
                  :clearable=false
                  placeholder="选择培训时间">
                </el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="trainAddr" label="培训地点">
                <el-input v-model="dialogObj.data.form.trainAddr" auto-complete="off" class="inputInline" value="number"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item  prop="trainerId" label="培训人员" >
                <el-select v-model="dialogObj.data.form.trainerNm" filterable :clearable="true" placeholder="请选择">
                  <el-option
                    v-for="item in optionsManager"
                    :key="item.rowId"
                    :label="item.employeeName"
                    :value="item.rowId">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item prop="trainingObjs" label="培训对象">
                <el-input v-model="dialogObj.data.form.trainingObjs" auto-complete="off" class="inputInline" type='trainingObjs'></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="10">
              <el-form-item  prop="contents" label="培训内容" >
                <el-input v-model="dialogObj.data.form.contents" auto-complete="off" class="inputInline" type="contents"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="24">
            </el-col>
          </el-row>
          <el-form-item label="文件上传">
            <uploadTemp style="margin:20px;" :files="dialogObj.data.form.files" ref="uploadPic"></uploadTemp>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="resetForm ('addForm')">取 消</el-button>
          <el-button type="success" @click="updateClk('addForm')" >保 存</el-button>
          <el-button type="success" @click="upClk('addForm')" >提 交</el-button>
        </div>
      </div>
      <div v-if= "dialogObj.type == 'view'">
        <el-form :model="dialogObj.data.form" label-width="90px"  :rules="addrules" ref="addForm">
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item  prop="trainDate" label="培训时间" >
                <el-date-picker
                  v-model="dialogObj.data.form.trainDate"
                  type="date"
                  format="yyyy-MM-dd"
                  :editable=false
                  :clearable=false
                  disabled = "true"
                  placeholder="选择培训时间">
                </el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="trainAddr" label="培训地点">
                <el-input v-model="dialogObj.data.form.trainAddr" auto-complete="off" class="inputInline" value="number" disabled = "true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item  prop="trainerId" label="培训人员" >
                <el-select v-model="dialogObj.data.form.trainerNm" filterable :clearable="true"  disabled = "true" placeholder="请选择">
                  <el-option
                    v-for="item in optionsManager"
                    :key="item.rowId"
                    :label="item.employeeName"
                    :value="item.rowId">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item prop="trainingObjs" label="培训对象">
                <el-input v-model="dialogObj.data.form.trainingObjs" auto-complete="off" class="inputInline" type='trainingObjs' disabled = "true"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="10">
              <el-form-item  prop="contents" label="培训内容" >
                <el-input v-model="dialogObj.data.form.contents" auto-complete="off" class="inputInline" type="contents" disabled = "true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="24">
            </el-col>
          </el-row>
          <el-form-item label="文件上传">
            <uploadTemp style="margin:20px;" :files="dialogObj.data.form.files" ref="uploadPic" :operation="false"></uploadTemp>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="resetForm ('addForm')">取 消</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  import api from '@/api'
  export default {
    mounted () {
      this.getManager()
    },
    props: ['dialogObj'],
    data () {
      return {
        dialogVisible: false,
        formLabelWidth: '120px',
        filmode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤
        fileName: ['value'],
        filType: 0, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        tableData: [],
        optionsManager: [],
        deptIdGroup: [],
        addrules: {},
        files: [
          {
            fileName: 'baidu.gif',
            fileData: 'https://www.baidu.com/img/baidu_jgylogo3.gif',
            src: 'https://www.baidu.com/img/baidu_jgylogo3.gif'
          }
        ],
        value: '',
        form: {}
      }
    },
    methods: {
      closeModalEve () {
        this.dialogObj.dialogVisible = false
        this.$emit('confirmBack', false)
      },
      resetForm (formName) {
        this.dialogObj.dialogVisible = false
        this.$emit('confirmBack', false)
      },
      updateClk1 (formName) {
        console.log('测试1', this.dialogObj.data.form.trainerId)
        this.dialogObj.data.form.status = '0'
        let params = {}
        params.rowId = trainerId
        api.requestJava('POST', BasePath.EMPLOYEE_SELECTONE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.dialogObj.data.form.custmgrName = request.data.data.employeeName
              if (this.dialogObj.data.form.trainerNm === this.dialogObj.data.form.custmgrName) {
                this.getDeptId(formName)
              } else {
                this.getDept(formName)
              }
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      updateClk (formName) {
        // debugger
        console.log('测试1', this.dialogObj.data.form.trainerId)
        this.dialogObj.data.form.status = '0'
        let params = {}
        params.rowId = this.dialogObj.data.form.trainerId
        api.requestJava('POST', BasePath.EMPLOYEE_SELECTONE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              // debugger
              this.dialogObj.data.form.custmgrName = request.data.data.employeeName
              if (this.dialogObj.data.form.trainerNm === this.dialogObj.data.form.custmgrName) {
                this.getDeptId(formName)
              } else {
                // debugger
                this.getDept(formName)
              }
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      getCustmgrName (trainerId) {
        let params = {}
        params.rowId = trainerId
        api.requestJava('POST', BasePath.EMPLOYEE_SELECTONE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              // debugger
              this.dialogObj.data.form.custmgrName = request.data.data.employeeName
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      save (formName) {
//        debugger
        if (this.dialogObj.data.form.trainerNm === '') {
          this.$message({type: 'info', message: '请选择培训人员'})
          return
        }
        if (this.dialogObj.data.form.trainDate === '') {
          this.$message({type: 'info', message: '请选择培训时间'})
          return
        }
        console.log('测试1', this.dialogObj.data.form.trainerId)
        this.dialogObj.data.form.status = '0'
        if (this.dialogObj.data.form.trainerNm === getUser().userName) {
          this.getDeptId(formName)
        } else {
          this.getDept(formName)
        }
      },
      getManager () {
        let params = {}
        params.companyId = getUser().companyId
        params.status = 1
        console.log(params.companyId)
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, {params, 'fields': {'include': 'rowId,employeeName'}})
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.optionsManager = request.data.data
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      getDept (formName) {
        let params = {}
        params.rowId = this.dialogObj.data.form.trainerNm
        console.log('测试3', params.rowId)
        api.requestJava('POST', 'system/employees/selectOne.do', params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              // debugger
              this.dialogObj.data.form.deptId = request.data.data.deptId
              console.log('deptId', this.dialogObj.data.form.deptId)
              this.dialogObj.data.form.companyId = request.data.data.companyId
              console.log('companyId', this.dialogObj.data.form.companyId)
              this.dialogObj.data.form.trainerNm = request.data.data.employeeName
              console.log('trainerNm', this.dialogObj.data.form.trainerNm)
              this.dialogObj.data.form.trainerId = request.data.data.rowId
              console.log('trainerId', this.dialogObj.data.form.trainerId)
              params.rowId = this.dialogObj.data.form.rowId
              console.log('rowId', this.dialogObj.data.form.rowId)
              this.$refs[formName].validate((valid) => {
                if (valid) {
                  this.dialogObj.data.form.files = this.$refs.uploadPic.getFiles()
                  this.dialogObj.dialogVisible = false
                  this.$emit('confirmBack', this.dialogObj)
                } else {
                  console.log('error submit!!')
                  return false
                }
              })
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      getDeptId (formName) {
        let params = {}
        params.rowId = this.dialogObj.data.form.trainerId
        console.log('测试2', params.rowId)
        api.requestJava('POST', BasePath.EMPLOYEE_SELECTONE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.dialogObj.data.form.deptId = request.data.data.deptId
              console.log('deptId', this.dialogObj.data.form.deptId)
              this.dialogObj.data.form.companyId = request.data.data.companyId
              console.log('companyId', this.dialogObj.data.form.companyId)
              this.dialogObj.data.form.trainerNm = request.data.data.employeeName
              console.log('trainerNm', this.dialogObj.data.form.trainerNm)
              this.dialogObj.data.form.trainerId = request.data.data.rowId
              console.log('trainerId', this.dialogObj.data.form.trainerId)
              params.rowId = this.dialogObj.data.form.rowId
              console.log('rowId', this.dialogObj.data.form.rowId)
              this.$refs[formName].validate((valid) => {
                if (valid) {
                  this.dialogObj.data.form.files = this.$refs.uploadPic.getFiles()
                  this.dialogObj.dialogVisible = false
                  this.$emit('confirmBack', this.dialogObj)
                } else {
                  console.log('error submit!!')
                  return false
                }
              })
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      saveClk (formName) {
        if (this.dialogObj.data.form.trainerNm === '') {
          this.$message({type: 'info', message: '请选择培训人员'})
          return
        }
        if (this.dialogObj.data.form.trainDate === '') {
          this.$message({type: 'info', message: '请选择培训时间'})
          return
        }
        this.dialogObj.data.form.status = '1'
        if (this.dialogObj.data.form.trainerNm === getUser().userName) {
          this.getDeptId(formName)
        } else {
          this.getDept(formName)
        }
      },
      upClk (formName) {
        this.dialogObj.data.form.status = '1'
        let params = {}
        params.rowId = this.dialogObj.data.form.trainerId
        api.requestJava('POST', BasePath.EMPLOYEE_SELECTONE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              // debugger
              this.dialogObj.data.form.custmgrName = request.data.data.employeeName
              if (this.dialogObj.data.form.trainerNm === this.dialogObj.data.form.custmgrName) {
                this.getDeptId(formName)
              } else {
                // debugger
                this.getDept(formName)
              }
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      _upload_submit () {
        this.$refs.uploadTemp.submitUpload()
      }
    },
    components: {
      uploadTemp
    }
  }
</script>

<style scoped>
  .item__label_popup {
    text-align: right;
    vertical-align: middle;
    float: right;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 8px 11px 0;
    box-sizing: border-box;
    /* display: inline-block; */
  }
  .el-input, .el-input__inner {
    /*width: '';*/
    display: inline-block;
  }
</style>
