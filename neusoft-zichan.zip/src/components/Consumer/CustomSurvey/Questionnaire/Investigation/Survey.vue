<!--张文艺-->
<style scoped rel="stylesheet/scss" lang="scss">
  @import "./css/Survey.css";
  .container{
    padding: 0px 20px
  }
  .btn{
    width:100%;
    height:40px;
  }
  .li_surveyQuItemBody{
    margin: 10px 0;
    padding:0 20px;
  }
</style>
<template>
  <div class="container">
    <div class="question-body">
      <div id="S_body">
        <div class="main col-xs-12 col-sm-12">
          <div class="title">
            <div class="head" title="标题">
              <h3 class="text-center">{{questionnaire.title}}</h3>
            </div>
            <div class="des" title="描述">
              <p class="text-left">{{questionnaire.descText}}</p>
            </div>
          </div>
          <div id="survey">
            <ul id="dwSurveyQuContentAppUl">
              <!-- 内容 -->
              <template v-for="(item, key) in questionnaire.content">
                <!-- 段落 -->
                <template v-if="item.inputType == '段落'">
                  <_PARAGRAPH :Paragraph="item"/>
                </template>
                <!-- 单选、多选 、文本框 -->
                <template v-if="item.inputType == 'radio' || item.inputType == 'multiselect' || item.inputType == 'input'">
                  <_BASICS :Basics.sync="item" :_key="key" :Disabled="disabled"/>
                </template>
                <!-- 多项文本框 -->
                <template v-if="item.inputType == '多项填空题' || item.inputType == 'score'">
                  <_BTABLE :BTable="item"/>
                </template>
                <!-- 级联 -->
                <template v-if="item.inputType == 'city' || item.inputType == 'goods'">
                  <_CASCADER :Cascader="item" :header="header" :tmpProduct=tmpProduct :tmpCity=tmpCity />
                </template>
              </template>
              <li class="li_surveyQuItemBody surveyQu_1" v-if="disabled == 1">
                <div class="text-center">
                  <button class="btn btn-success" @click="submit" :disabled="isDisabled">提&nbsp;交</button>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import _PARAGRAPH from './Survey/Paragraph.vue'
  import _BASICS from './Survey/Basics.vue'
  import _BTABLE from './Survey/BasiceTable.vue'
  import _CASCADER from './Survey/Cascader.vue'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import { dateFormat } from '@/utils/dateFormat.js'
  import { mapState } from 'vuex'
  export default {
    computed: {
      ...mapState([
        'userInfo'
      ])
    },
    name: 'Survey',
    created () {
      this.$store.dispatch('setLoading', JSON.stringify({'status': false}))
      let params = JSON.parse(decodeURI(this.$route.params.str))
      this.questionnaire.fromId = params.formId
      this.stepId = params.stepId
      this.questionnaire.userId = params.userId
      this.questionnaire.customerId = params.customerId
      this.questionnaire.brandId = params.brandId
      this.companyId = params.companyId
      this.personId = params.personId
      this.disabled = params.disabled
      this.visitingRecId = params.visitingRecId
      this.planId = params.planId
      this.visitor = params.visitor
      this.visitorName = params.visitorName
      this.customerName = params.customerName
      // 客户端传递转码后的坐标无效（页面跳转404），所以将坐标轴进行‘改造’
      if (params.x !== undefined && params.x !== null && params.x !== '' && params.y !== undefined && params.y !== null && params.y !== '') {
        var px = params.x.replace('$', '.')
        var py = params.y.replace('$', '.')
        this.x = Number(px)
        this.y = Number(py)
      } else {
        this.x = ''
        this.y = ''
      }
      let headers = {}
      headers.userCode = 'admin'
      headers.password = '123456'
      api.requestJava('POST', 'login.do', {}, {'headers': headers})
        .then((request) => {
          if (Number(request.data.code) === 200) {
            this.header.userCode = request.data.data.userCode
            this.header.authToken = request.data.data.authToken
            this.getCascader('goods')
            this.getCascader('city')
            setTimeout(() => {
              this.init()
            }, 500)
          }
        })
        .catch((err) => {
          console.error(err)
        })
    },
    mounted () {
    },
    data () {
      return {
        header: {
          userCode: '',
          authToken: ''
        },
        subParams: [],
        questionnaire: {
          fromId: '',
          title: '',
          descText: '非常感谢您的参与！如有涉及个人信息，我们将严格保密。',
          formId: '',
          content: [{
            val: ''
          }]
        }, // 问卷内容
        companyId: '',
        personId: '',
        disabled: '',
        visitingRecId: '',
        planId: '',
        visitor: '',
        visitorName: '',
        customerName: '',
        questionnaireanswer: '',
        dataList: [],
        startTime: '',
        endTime: '',
        x: '',
        y: '',
        tmpCity: [],
        tmpProduct: [],
        isDisabled: false
      }
    },
    methods: {
      getCascader (type) {
        let url = ''
        var params = {}
        if (type === 'city') {
          url = BasePath.SELECT_TREELIST
          params.treeRoot = '86'
          params.fluzzy = {'in': 'level:1,2'}
        } else if (type === 'goods') {
          url = BasePath.COMMODITY_ALL
//          url = BasePath.COMMODITY_SELECT
          params.status = 'Y'
          params.isConfiscated = 'N'
          params.sorter = 'goods_code'
        }
        api.requestJava('POST', url, params, {'headers': this.header})
          .then((request) => {
            if (Number(request.data.code) === 200) {
//              console.log(request.data.data)
              if (type === 'city') {
                this.tmpCity = request.data.data.children
              } else if (type === 'goods') {
                this.tmpProduct = request.data.data.children
              }
            } else {
              console.log('获取失败~')
            }
          })
      },
      init () {
        // this.questionnaire.content = JSON.parse(localStorage.getItem('subject'))
        console.log('== 开始请求了==')
        var params = {}
        params.formId = this.questionnaire.fromId
        if (Number(this.stepId) !== 0) {
          params.stepId = this.stepId
        }
        api.requestJava('POST', BasePath.FW_ITEMS_GETFULLFORM, params, {'headers': this.header})
          .then((request) => {
            console.log('== 请求结束开始渲染 ==')
            if (Number(request.data.code) === 200) {
              setTimeout(() => {
                this.$store.dispatch('setLoading', JSON.stringify({'status': false}))
              }, 100)
              this.startTime = dateFormat(new Date().getTime(), 'YYYY-MM-DD HH:mm:ss')
              this.questionnaireanswer = request.data.data
              this.questionnaire.title = request.data.data.title
              // this.questionnaire.descText = request.data.data.descText
              /* TODO  缺少严谨 */
              if (this.questionnaireanswer.itemsList && this.questionnaireanswer.itemsList.length > 0) {
                let temp = []
                this.questionnaireanswer.itemsList.map((data, index) => {
                  if (data.inputType !== '段落') {
                    if (data.inputType === 'score') {
                      this.$set(data, 'val', null)
                    } else if (data.inputType === 'city' || data.inputType === 'goods' || data.inputType === 'multiselect') {
                      if (data.dataList && data.dataList.length > 0) {
                        this.$set(data, 'val', JSON.parse(data.dataList[0].val))
                        this.$set(data, 'option', [])
                      } else {
                        this.$set(data, 'val', [])
                        this.$set(data, 'option', [])
                      }
                    } else {
                      if (data.dataList && data.dataList.length > 0) {
                        this.$set(data, 'val', data.dataList[0].val)
                      } else {
                        this.$set(data, 'val', [])
                      }
                    }
                  }
                  temp.push(data)
                })
                this.questionnaire.content = temp
              }
            } else if (Number(request.status) === 401) {
//              setTimeout(() => {
//                this.$store.dispatch('setLoading', JSON.stringify({'status': false}))
//              }, 100)
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
//              setTimeout(() => {
//                this.$store.dispatch('setLoading', JSON.stringify({'status': false}))
//              }, 100)
              throw new Error(JSON.stringify(request))
            }
          })
      },
      goBack () {
        window.history.back()
      },
      submit () {
        this.isDisabled = true
        var isTrue = true
        var title = ''
        this.endTime = dateFormat(new Date().getTime(), 'YYYY-MM-DD HH:mm:ss')
        this.dataList = []
        this.questionnaire.content.map((v, k) => {
          if (v.inputType !== '段落') {
            let params = {}
            if (v.inputType === 'score') {
              let paraminfos = []
              v.enumList.map((data, index) => {
                paraminfos.push(data.val)
              })
              params.val = JSON.stringify(paraminfos)
            } else {
              /* 必填项判断 */
              if (Number(v.mustFlag) === 1) {
                if (v.val.length <= 0 || v.val === '' || v.val === '[{}]' || v.val === '{}') {
                  isTrue = false
                  title = v.title + '为必填项'
                }
              }
              if (Object.prototype.toString.call(v.val) === '[object Array]') {
                let strify = ''
                if (v.inputType === 'goods') {
                  if (v.val.length <= 1) {
                    strify = JSON.stringify(v.val[0])
                  } else {
                    strify = JSON.stringify(v.val[1])
                  }
                } else {
                  strify = JSON.stringify(v.val)
                }
//                let strify = JSON.stringify(v.val)
                params.val = strify
              } else {
                params.val = v.val
              }
            }
            params.companyId = this.companyId
            params.itemId = v.rowId
            params.itemCode = v.itemCode
            params.title = v.title.replace(/[\n]/ig, '').trim()
            params.inputType = v.inputType
            this.dataList.push(params)
          }
        })
        let paraminfo = {}
        paraminfo.companyId = this.companyId
        paraminfo.formId = this.questionnaireanswer.rowId
        paraminfo.formCode = this.questionnaireanswer.formCode
        paraminfo.title = this.questionnaireanswer.title
        paraminfo.onSchedule = 'N'
        paraminfo.visitingRecId = this.visitingRecId
        paraminfo.visitor = this.visitor
        paraminfo.visitorName = this.visitorName
        paraminfo.cusotmerName = this.customerName
        if (Number(this.planId) > 0) {
          paraminfo.planId = this.planId
        }
        paraminfo.customerId = this.questionnaire.customerId
        paraminfo.startTime = this.startTime
        paraminfo.endTime = this.endTime
        paraminfo.beginDate = this.startTime
        paraminfo.endDate = this.endTime
        paraminfo.dataList = this.dataList
        paraminfo.positionX = this.x
        paraminfo.positionY = this.y
        paraminfo.createdBy = this.questionnaire.userId
        console.log('paraminfo:', paraminfo)
        if (isTrue) {
          api.requestJava('POST', BasePath.CL_STEPS, paraminfo, {'headers': this.header})
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.$router.go(0)
              } else if (Number(request.status) === 401) {
                this.sessionFailedDialogObj.dialogVisible = true
              } else {
                throw new Error(JSON.stringify(request))
              }
            })
        } else {
          this.$message({ message: title, type: 'warning' })
//          this.$store.dispatch('setLoading', JSON.stringify({'status': false, 'msg': title}))
        }
      }
    },
    components: {
      _PARAGRAPH,
      _BASICS,
      _BTABLE,
      _CASCADER
    }
  }
</script>
