export default {
// build  crm 省局生产环境 外网
  root: '/crm',
  casurl: 'http://apps.js.tobacco.com.cn/',
  serverURL: 'http://apps.js.tobacco.com.cn/custsrv/',
  FILE_ADDR: 'http://apps.js.tobacco.com.cn/filesrv/',
  REPORT_FORM: 'http://apps.js.tobacco.com.cn',
  IFRAME_FORM: 'http://apps.js.tobacco.com.cn/crm/',
  fixedLayout: false,
  hideLogoOnMobile: false
// dev  省局测试环境 外网  开发模式
//   root: '',
//   serverURL: '/api',
//   casurl: 'http://apps.js.tobacco.com.cn/',
//   FILE_ADDR: 'http://apps.js.tobacco.com.cn/filesrv/',
//   REPORT_FORM: 'http://apps.js.tobacco.com.cn', // 报表地址
//   IFRAME_FORM: 'http://localhost:8082/', // iframe 通信 地址
//   fixedLayout: false,
//   hideLogoOnMobile: false
}
