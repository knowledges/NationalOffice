<!--李晶-->
<style rel="stylesheet/scss" lang="scss" scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-24 {
    height: 36px;
  }
</style>
<template>
  <div  class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='12'>
          <div v-if="isSelect">
            <el-form ref="searchForm" :model="searchForm" label-width="100px">
              <el-col :gutter="24">
                <el-col :span='12'>
                  <el-form-item label="单据类别">
                    <el-select v-model="searchForm.billType" class="input_width" :clearable="true" placeholder="请选择" :disabled="billTypeDisable">
                      <el-option
                        v-for="item in options_billType"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='12'>
                  <el-form-item label="业务日期">
                    <el-date-picker
                      v-model="searchForm.bizDate"
                      type="daterange"
                      range-separator="至"
                      start-placeholder="开始日期"
                      end-placeholder="结束日期">
                    </el-date-picker>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-form>
          </div>
        </el-col>
        <el-col :span="12">
          <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" :tableData="tableData" @on-click="exportEve" :isMore="isMore"></_BTN_FILTER>
        </el-col>
      </el-col>
    </el-row>
    <div>
      <tableVue
        ref="tableGrid"
        stripe
        maxHeight="500"
        :data="dataSource"
        @update:data="tabChange" :reqParams="reqParams"
        :columns="columns"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
        ></tableVue>
      <_POPUP :dialogObj='dialogObj' @confirmBack="confirmBack" ref="childs" v-popupdra-directive="{'show': dialogObj.dialogVisible}"/>
    </div>
  </div>
</template>
<script>
  import tableVue from '@/components/Template/table/Table.vue'
  import { getUser, getCodeList } from '@/config/info'
  import { dateFormat } from '@/utils/dateFormat.js'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import { changeListValueByCode } from '@/utils/common'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import _POPUP from './Popup.vue'
  //  import axios from 'axios'
  import log from '@/log'
  export default {
    name: 'MaterielQuery',
    props: {},
    mounted () {
      getCodeList('RM_MTRL_BILL_TYPE', (data) => {
        this.options_billType = data
        this.changeValueDate.billType.group = data
      }) // 单据类别
      this.init()
    },
    data () {
      return {
        billTypeDisable: false,
        queryParams: {},
        isSelect: true,
        isMore: true, // 查询更多条件
        searchForm: {
          billType: '',
          bizDateL: new Date(),
          bizDateR: new Date(),
          bizDate: [new Date(), new Date()]
        },
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['billType', 'handlerNm', 'bizDate', 'customerDesc', 'status'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        options_billType: [],
        /** 弹出层 **/
        dialogObj: {
          title: '查看详情',
          type: 'query',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              rowId: '',
              billType: '',
              billNo: '',
              handlerId: '',
              handlerNm: '',
              bizDate: '',
              customerId: '',
              customerDesc: '',
              detailEntities: []
            }
          }
        },
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        selectSells: [],
        totalCount: 0, // 表格总记录数
        hasPagination: true, // 是否有分页
        columns: [ // 表格列
          { label: '单据类型', prop: 'billType', columnsProps: {width: 100, formatter: this.colFormatter_billType} },
          { label: '领用主体', prop: 'handlerNm', columnsProps: {width: 250} },
          { label: '领用日期', prop: 'bizDate', columnsProps: {width: 150} },
          { label: '发放主体', prop: 'customerDesc', columnsProps: {width: 250} },
          { label: '单据状态', prop: 'status', columnsProps: {formatter: this.colFormatter_status} },
          { label: '操作', prop: 'operation', columnsProps: {type: 'button', textAlign: 'center'}, cptProperties: [{ label: '查看', icon: 'search', value: 'look', type: 'success', size: 'small', eventClick: this.view }] }
        ],
        tableData: [],
        tableType: '4',
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        changeValueDate: {
          billType: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          }
        },
        headerClick () {},
        sortChange (msg) {},
        rowClick (msg) {}
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      init () {
        let param = {}
        param.bizDateL = this.getTime(Date.parse(this.searchForm.bizDate[0]))
        param.bizDateR = this.getTime(Date.parse(this.searchForm.bizDate[1]))
        param.companyId = getUser().companyId
        param.haveAttach = '1'
        this.querySearch(param)
      },
      query () {
        let param = {}
        param.pageSize = this.pageSize
        param.pageNum = 1
        param.billType = this.searchForm.billType
        param.bizDateL = this.getTime(Date.parse(this.searchForm.bizDate[0]))
        param.bizDateR = this.getTime(Date.parse(this.searchForm.bizDate[1]))
        param.companyId = getUser().companyId
        param.haveAttach = '1'
        this.querySearch(param)
      },
      querySearch (param) {
        this.reqParams.url = BasePath.MTRLINVENTORY_SELECTLIST
        this.reqParams.params = param
        api.requestJava('POST', BasePath.MTRLINVENTORY_SELECTLIST, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              console.log(request.data.data)
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.dataSource = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
              console.log('返回数据：' + JSON.stringify(request.data.data))
//              this.searchForm.billNo = request.data.data
//              this.billNoDisabled = true
            } else {
              this.$notify.error({ title: '提示', message: '查询接口调用失败！' })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      addClk () {
        this.$router.push({name: 'MaterielAdd', params: {uId: this.$route.params.uId}})
      },
      colFormatter_status (row, column) {
        let retStr = ''
        switch (row.status) {
          case '0':
            retStr = '编辑'
            break
          case '1':
            retStr = '提交'
            break
          case '8':
            retStr = '记账'
            break
          case '9':
            retStr = '作废'
            break
          default :
            retStr = '审核中'
        }
        return retStr
      },
      colFormatter_billType (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },
      confirmBack (msg) {
      },
      view (row, column) {
//        this.$refs.childs.clearMethod()
        // 主表数据
        this.dialogObj.data.form.billType = column.billType
        this.dialogObj.data.form.billNo = column.billNo
        this.dialogObj.data.form.bizDate = column.bizDate
        this.dialogObj.data.form.handlerId = column.handlerId
        this.dialogObj.data.form.handlerNm = column.handlerNm
        this.dialogObj.data.form.customerId = column.customerId
        this.dialogObj.data.form.customerDesc = column.customerDesc
        this.dialogObj.data.form.signature = column.files
        console.log('this.dialogObj.data.form==', this.dialogObj.data.form)
        // 细表数据
        let param = {}
        param.billId = column.rowId
        console.log('param==', param)
        api.requestJava('POST', BasePath.MTRLINVENTORY_SELECTLIST_DETAIL, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.$set(this.dialogObj.data.form, 'detailEntities', request.data.data)
              this.$refs.childs.init()
              this.dialogObj.dialogVisible = true
//              console.log('返回数据：' + JSON.stringify(this.dialogObj.data.form.detailEntities))
            } else {
              this.$notify.error({ title: '提示', message: '查询接口调用失败！' })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }
    },
    components: {
      tableVue,
      _POPUP,
      _BTN_FILTER
    },
    watch: {}
  }
</script>
