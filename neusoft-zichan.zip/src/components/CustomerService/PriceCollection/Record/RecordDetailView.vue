<style scoped>
  .el-form-item__label{
    margin: 0px!important;
  }
  .filter_style .el-col-24 {
    height: 36px;
  }
  .el-form-item {
    margin-bottom: 12px;
  }
</style>
<template>
  <div>
    <el-form ref="searchForm" :model="searchForm" label-width="120px" >
      <div class="el-form-item">
        <label class="el-form-item__label" style="width: 120px;">备注</label>
        <div class="el-form-item__content" style="margin-left: 120px;">
          <div class="inputInline el-textarea">
            <textarea resize="none" type="textarea" rows="2" autocomplete="off" validateevent="true" class="el-textarea__inner" style="resize: none;">{{dataSource[0].remarks}}</textarea>
          </div>
        </div>
      </div>
    <div>
      <tableVue
        ref="table"
        stripe
        maxHeight="500"
        @update:data="tabChange" :reqParams="reqParams"
        column-type="selection"
        :data="dataSource"
        :columns="columns"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
        @cell-dblclick="celldbClick"></tableVue>
    </div>
    </el-form>
  </div>
</template>
<script>
  import tableVue from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import { dateFormat } from '@/utils/dateFormat.js'
  import {getUser} from '@/config/info'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import log from '@/log'
  export default {
    props: {
      rowId: {
        type: String,
        default: ''
      },
      gatherer: {
        type: String,
        default: ''
      },
      gatherDate: {
        type: String,
        default: ''
      }
    },
    mounted () {
      let params = {}
      params.rowId = this.rowId
      params.gatherer = this.gatherer
      params.gatherDate = this.gatherDate
      this.init(params)
    },
    watch: {
      rowId (val, old) {
        let params = {}
        params.rowId = this.rowId
        params.gatherer = this.gatherer
        params.gatherDate = this.gatherDate
        this.init(params)
      }
    },
    data () {
      return {
        isSelect: true,
        isMore: true, // 查询更多条件
        searchForm: {
          gatherDate: this.gatherDate
        },
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['productCode', 'productName'],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        selectSells: [],
        totalCount: 0, // 表格总记录数
        hasPagination: true, // 是否有分页
        columns: [ // 表格列
          { label: '商品代码', prop: 'productCode', columnsProps: {width: 200} },
          { label: '商品名称', prop: 'productName', columnsProps: {width: 260} },
          { label: '异常范围(+-%)', prop: 'downUpRate', columnsProps: {width: 160} },
          { label: '优先级', prop: 'weight', columnsProps: {width: 120} },
          { label: '调拨价', prop: 'purchasePrice', columnsProps: {width: 120} },
          { label: '批发价', prop: 'tradePrice', columnsProps: {width: 120} },
          { label: '市场价', prop: 'price3', columnsProps: {width: 120} },
          { label: '零售价(条)', prop: 'price2', columnsProps: {width: 120} },
          { label: '零售价(包)', prop: 'price1', columnsProps: {width: 120} }
//          { label: '备注', prop: 'remarks', columnsProps: {width: 120} }
        ],
        data: [],
        tableData: [],
        dataSource: [], // 当前页的数据
        planTime: '',
        /** filter **/
        templTableData: [] // 临时记录tableDate的值
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      init (val) {
        let param = {}
        param.gatherId = val.rowId
        param.gatherer = val.gatherer
        param.gatherDate = val.gatherDate
        param.companyId = getUser().companyId
        this.reqParams.url = BasePath.GATHER_PRICE_ADD
        this.reqParams.params = param
        console.log('修改param:' + JSON.stringify(param))
        api.requestJava('POST', BasePath.GATHER_PRICE_ADD, param, {})
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.data = request.data.data
              this.tableData = request.data.data
              this.totalCount = Number(request.data.count)
              this.searchForm.remarks = request.data.data[1].remarks
              if (Number(request.data.data.length) > 0) {
                var i = 0
                var key = 0
                request.data.data.forEach((e) => {
                  if (Number(request.data.data[i].status) === 1) {
                    key = 1
                  }
                  i++
                })
                if (key === 1) {
                  let _btnGroups = []
                  let _backbtn = {}
                  _backbtn.name = '返回'
                  _backbtn.className = 'btn-info'
                  _backbtn.event = this.backClk
                  _btnGroups.push(_backbtn)
                  this.btnGroups = _btnGroups
                }
                this.$nextTick(() => {
                  this.currentPage = 1
                  this.queryData(this.currentPage, this.pageSize)
                })
              }
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      isMoreClk () {
        this.isSelect = !this.isSelect
      },
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.data.length
        this.dataSource = this.data.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      headerClick () {},
      sortChange (msg) {},
      rowClick (msg) {},
      backClk () {
        this.$router.push({name: 'Record'})
      }, // 返回
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      celldbClick (row, column, cell, event) {
        this.$set(row, '_edit', !row._edit)
        if (!row._edit) {
          if (!this.numberChange(row)) {
            row._edit = true
          } else {
            this.$set(row, '_edit', !row._edit)
          }
        }
      },
      eventKey (key, row) {
        if (key.code === 'Enter' || key.code === 'NumpadEnter') {
          if (!this.numberChange(row)) {
            return true
          } else {
            return false
          }
        }
      },
      sessionFailedBack (msg) {
        let headers = msg.data.form
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.sessionFailedDialogObj.dialogVisible = false
            }
          })
          .catch((err) => { console.log(err) })
      }, // 会话失效
      exportEve () {
        this.$refs.table.exportExcel()
      }, // 导出Elxc
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = this.currentPage
        let size = this.pageSize
        this.dataSource = JSON.parse(val).filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      numberChange (row) {
        let _this = this
        this.$nextTick(() => {
          var t
          clearTimeout(t)
          t = setTimeout(function () {
            let tradePrice = row.tradePrice
            let price3 = row.price3
            let downUpRate = row.downUpRate
            let upPrice = Number(tradePrice) * Number(1 + Number(downUpRate) / 100)
            let downPrice = Number(tradePrice) * Number(1 - Number(downUpRate) / 100)
            if (price3 > upPrice) {
              _this.$message({ type: 'error', message: row.productName + ' 市场价输入异常，高于异常范围(' + upPrice + ')！' })
              return false
            } else if (price3 < downPrice) {
              _this.$message({ type: 'error', message: row.productName + ' 市场价输入异常，低于异常范围(' + downPrice + ')！' })
              return false
            } else {
              return true
            }
          }, 1000)
        })
      },
      show () {
        this.$message('双击事件')
      },
      selectChange (index, row) {
        if (!row._edit) {
          this.$message('双击事件')
        }
      }
    },
    components: {
      tableVue,
      _BTN_FILTER
    }
  }
</script>
