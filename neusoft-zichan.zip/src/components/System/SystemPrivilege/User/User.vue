<!--张文艺-->
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :span="24" style="padding: 0 0">
        <_BTN_FILTER :isMore="isMore" :btnGroups="btnGroups" :fileName="fileName" :filterMethod="inputChange"
                     @on-click="exportEve" :tableData="tableData"/>
      </el-col>
    </el-row>
    <!--<div>-->
    <el-row>
      <el-col :span="24">
        <_TABLE  ref="tableGrid"
                 @update:data="tabChange"
                 :reqParams="reqParams"
                 stripe
                 maxHeight="500"
                 :data="dataSource"
                 :columns="columnHeader"
                 :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
                 :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
        ></_TABLE>
      </el-col>
    </el-row>
    <!--</div>-->
    <_POPUP :need=true :dialogObj='addDialogObj' @confirmBack="addBack"/>
    <_POPUP :dialogObj='updateDialogObj' @confirmBack="updateBack"/>
    <_POPUP :dialogObj='moreDialogobj'  @confirmBack="moreBack"/>
    <_POPUP :dialogObj='sessionFailedDialogObj' @confirmBack="sessionFailedBack" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import BasePath from '@/config/BasePath'
  import { getUser } from '@/config/info'
  import api from '@/api'
  import log from '@/log'
  import axios from 'axios'
  import { convertVal } from '@/utils/common'
  export default {
    mounted () {
      let companyIdParam = {} // 公司
      companyIdParam.orgRoleTypId = '202'
      companyIdParam.orgUnitId = getUser().companyId
      companyIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
      let divisionIdParam = {} // 部门
//      divisionIdParam.orgUnitId = getUser().companyId
      divisionIdParam.orgRoleTypId = '207'
      divisionIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
      axios.all([
        api.requestJava('POST', BasePath.SELECT_FACTORYIDGROUP, companyIdParam), // 公司
        api.requestJava('POST', BasePath.SELECT_FACTORYIDGROUP, divisionIdParam) // 部门
      ])
        .then(axios.spread((_companyId, _divisionId) => {
          this.options_companyId = _companyId.data.data
          this.options_divisionIdParam = _divisionId.data.data
          this.addDialogObj.data.form.optionsCompany = _companyId.data.data
          this.addDialogObj.data.form.optionsDepartment = _divisionId.data.data
          this.updateDialogObj.data.form.optionsCompany = _companyId.data.data
          this.updateDialogObj.data.form.optionsDepartment = _divisionId.data.data
          console.log('options_divisionIdParam:' + JSON.stringify(this.options_divisionIdParam))
        }))
      /** 调用初始化数据 **/
      this.init()
    },
    data () {
      return {
        /** 查询更多条件 **/
        isMore: true,
        /** 过滤的字段 **/
        fileName: ['userName', 'userCode', 'personId', 'email'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '',
            className: 'btn-primary',
            iconName: 'fa-th',
            event: this.isMoreClk
          },
          {
            name: '新增',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.addClk
          }
        ],
        /** table **/
        tableType: '4',
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        hasPagination: true,
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'userCode', // 列的值
            label: '登录账号', // 列的显示字段
            columnsProps: {width: 200, align: 'left'}
          }, {
            prop: 'userName',
            label: '姓名',
            columnsProps: {width: 150, align: 'left'}
          }, {
            prop: 'personId',
            label: '工号',
            columnsProps: {width: 150, align: 'left'}
          }, {
            prop: 'email',
            label: 'email',
            columnsProps: {width: 280, align: 'left'}
          }, {
            prop: 'divisionId',
            label: '部门',
            columnsProps: {width: 200, align: 'left', formatter: this.colFormatter_divisionId}
          }, {
            label: '操作',
            prop: 'operation',
            columnsProps: {type: 'button'},
            cptProperties: [
              {
                label: '设置',
                value: 'setting',
                icon: 'edit',
                size: 'small',
                type: 'success',
                eventClick: this.setting
              },
              {
                label: '修改',
                value: 'modify',
                icon: 'edit',
                size: 'small',
                type: 'warning',
                eventClick: this.modify
              }
//              ,
//              {
//                label: '删除',
//                value: 'del',
//                icon: 'delete',
//                size: 'small',
//                type: 'danger',
//                eventClick: this.del
//              }
            ]
          }
        ],
        /** 表格数据 **/
        tableData: [],
        dataSource: [], // 当前页的数据
        /** 弹出层 **/
        addDialogObj: {
          title: '新增用户',
          type: 'addUser',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              personId: '',
              userName: '',
              userCode: '',
              password: '',
              confirmPass: '',
              company: '',
              department: '',
              email: '',
              status: false,
              loginFlag: false,
              contactPhone: '',
              mobile: '',
              remark: '',
              files: '',
              attrFlag: '0',
              certYn: 'N',
              menuFlag: '0',
              appUserFlag: 'Y',
              usingFlag: '0',
              auditUserId: '-1',
              loginFirst: 'Y',
              companyId: '',
              divisionId: '',
              optionsCompany: [],
              optionsDepartment: []
            }
          }
        },
        updateDialogObj: {
          title: '修改用户',
          type: 'editUser',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              personId: '',
              userName: '',
              userCode: '',
              company: '',
              department: '',
              email: '',
              status: '',
              loginFlag: '',
              contactPhone: '',
              mobile: '',
              remark: '',
              companyId: '',
              divisionId: '',
              optionsCompany: [],
              optionsDepartment: []
            }
          }
        },
        sessionFailedDialogObj: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        moreDialogobj: {
          title: '查询',
          type: 'query',
          dialogVisible: false,
          data: {
            form: {
              userName: '',
              userCode: '',
              companyId: '',
              divisionId: '',
              masterId: '',
              mobile: ''
            }
          }
        },
        options_companyId: [],
        options_divisionIdParam: []
      }
    },
    methods: {
      /** 初始化数据方法 **/
      init () {
        let params = {}
        params.companyId = getUser().companyId
        params.pageSize = this.pageSize
        params.pageNum = 1
        params.haveAttach = '1'
        this.reqParams.url = BasePath.USER_SELECTLISTPAGES
        this.reqParams.params = params
        api.requestJava('POST', BasePath.USER_SELECTLISTPAGES, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.totalCount = +request.data.count
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      selectionChange (rows) {
        this.selectRows = rows
      },
      addClk () {
        this.clearObject()
        this.addDialogObj.title = '新增用户'
        this.addDialogObj.dialogVisible = true
        this.addDialogObj.data.form.optionsCompany = this.options_companyId
        this.addDialogObj.data.form.optionsDepartment = this.options_divisionIdParam
      }, // 新增
      modify (index, row) {
        Object.assign(this.updateDialogObj.data.form, row)
        this.updateDialogObj.data.form.status = (Number(row.status) === 1)
        this.updateDialogObj.data.form.loginFlag = ((row.loginFlag) === 'Y')
        /* TODO 公司和部门替换为字典 */
        this.updateDialogObj.title = '修改用户'
        this.updateDialogObj.dialogVisible = true
      }, // 修改
      setting (index, row) {
        this.$router.push({name: 'LoginInfo', params: {rowId: row.rowId}})
      }, // 设置
      del (index, row) {
        console.log(row.rowId)
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let params = {}
          params.userId = row.rowId
          let param = {}
          param.rowId = row.rowId
          api.requestJava('POST', 'system/userrole/selectList.do', params)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                var judge = request.data.data.length
                if (judge > 0) {
                  this.$confirm('此用户已分配角色，是否删除角色？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                  }).then(() => {
                    api.requestJava('POST', 'system/userrole/delete.do', params)
                      .then((request) => {
                        if (Number(request.data.code) === 200) {
                          this.delUser(param)
                        } else if (Number(request.data.code) === 401) {
                          this.sessionFailedDialogObj.dialogVisible = true
                        } else {
                          throw new Error(JSON.stringify(request))
                        }
                      })
                  }).catch(() => {
                    this.delUser(param)
                  })
                } else {
                  this.delUser(param)
                }
              } else if (Number(request.data.code) === 401) {
                this.sessionFailedDialogObj.dialogVisible = true
              } else {
                throw new Error(JSON.stringify(request))
              }
            })
        }).catch(() => {
          this.$message({type: 'info', message: '已取消删除!'})
        })
      },  // 删除
      isMoreClk () {
        this.moreDialogobj.dialogVisible = true
      }, // 更多条件
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      delUser (params) {
        api.requestJava('POST', BasePath.USER_DELETE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.init()
              this.$message({type: 'success', message: '删除成功!'})
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      addBack (msg) {
        if (msg) {
          console.log(JSON.stringify(msg))
          this.add(msg)
        } else {
          this.clearObject()
        }
      },
      add (msg) {
        let data = msg.data.form
        let paraminfo = data
        if (data.status) {
          paraminfo.status = '1'
        } else {
          paraminfo.status = '0'
        }
        if (data.loginFlag) {
          paraminfo.loginFlag = 'Y'
        } else {
          paraminfo.loginFlag = 'N'
        }
        let files = []
        let propertiesPicTemp = paraminfo.files
        var i = 0
        if (propertiesPicTemp.length > 0) {
          propertiesPicTemp.forEach((e) => {
            let properties = {}
            properties.fileName = propertiesPicTemp[i].fileName
            properties.fileType = 'user_photo'
            properties.fileData = propertiesPicTemp[i].fileData
            files.push(properties)
            i++
          })
        }
        paraminfo.files = files
        paraminfo.haveAttach = '1'
        api.requestJava('POST', BasePath.USER_INSERT, paraminfo)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.clearObject()
              this.init()
              this.$message({type: 'success', message: '新增成功!'})
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      updateBack (msg) {
        let data = msg.data.form
        let paraminfo = data
        if (data.status) {
          paraminfo.status = '1'
        } else {
          paraminfo.status = '0'
        }
        if (data.loginFlag) {
          paraminfo.loginFlag = 'Y'
        } else {
          paraminfo.loginFlag = 'N'
        }
        let files = []
        let propertiesPicTemp = paraminfo.files
        var i = 0
        if (propertiesPicTemp.length > 0) {
          propertiesPicTemp.forEach((e) => {
            let properties = {}
            properties.fileName = propertiesPicTemp[i].fileName
            properties.fileType = 'user_photo'
            properties.fileData = propertiesPicTemp[i].fileData
            files.push(properties)
            i++
          })
        }
        paraminfo.files = files
        paraminfo.haveAttach = '1'
        api.requestJava('POST', BasePath.USER_UPDATE, paraminfo)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.init()
              this.$message({type: 'success', message: '修改成功!'})
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      clearObject () {
        let temp = {
          title: '新增用户',
          type: 'addUser',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              personId: '',
              userName: '',
              userCode: '',
              password: '',
              confirmPass: '',
              company: '',
              department: '',
              email: '',
              status: false,
              loginFlag: false,
              contactPhone: '',
              mobile: '',
              remark: '',
              files: '',
              certYn: 'N',
              attrFlag: '0',
              menuFlag: '0',
              appUserFlag: 'Y',
              usingFlag: '0',
              auditUserId: '-1',
              loginFirst: 'Y',
              companyId: '',
              divisionId: '',
              optionsCompany: []
            }
          }
        }
        let tempMore = {
          title: '查询',
          type: 'query',
          dialogVisible: false,
          data: {
            form: {
              userName: '',
              userCode: '',
              mobile: '',
              companyId: '',
              divisionId: ''
            }
          }
        }
        Object.assign(this.addDialogObj, temp)
        Object.assign(this.moreDialogobj, tempMore)
      },
      sortChange (msg) {},
      rowClick (msg) {},
      moreBack (msg) {
        let param = msg.data.form
        api.requestJava('POST', '/system/user/selectListForFuzzy.do', param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              console.log(request.data.data)
              this.tableData = request.data.data
              this.queryData(this.currentPage, this.pageSize)
              this.clearObject()
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 多条件查询
      sessionFailedBack (msg) {
        let headers = msg.data.form
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.sessionFailedDialogObj.dialogVisible = false
            }
          })
          .catch((err) => { console.log(err) })
      }, // 会话失效
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      headerClick (column, event) {},
      colFormatter_divisionId (row, column) {
        return convertVal(this.options_divisionIdParam, row.divisionId, 'orgUnitId', 'orgRoleNm')
      }
    },
    components: {
      _TABLE,
      _POPUP,
      _BTN_FILTER

    }
  }
</script>
