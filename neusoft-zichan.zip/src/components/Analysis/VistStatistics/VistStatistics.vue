<!-- 徐晓菁 -->
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='24'>
          <div>
            <el-form ref="searchForm" :model="searchForm" label-width="120px">
              <el-col :gutter="24">
                <el-col :span='8'>
                  <div class="block">
                    <el-form-item label="查询周期">
                      <el-date-picker
                        v-model="datetime"
                        format="yyyy-MM-dd"
                        type="daterange"
                        :editable=false
                        :clearable=false
                        @change="datePickerChange"
                        placeholder="选择日期范围"
                        :picker-options="pickerOptions">
                      </el-date-picker>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span='8'>
                  <el-form-item label="分公司" >
                    <el-select v-model="searchForm.countyId"  placeholder="请选择分公司" @change="handleItemChange()">
                      <template v-for="item in countyIdGroup">
                        <el-option  :key="item.orgUnitId"  :label="item.orgRoleNm" :value="item.orgUnitId"></el-option>
                      </template>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='8'>
                  <el-form-item label="客户经理" >
                    <el-select v-model="searchForm.custmgrId"  placeholder="请选择客户经理"  >
                      <template v-for="item in custmgrIdGroup">
                        <el-option  :key="item.rowId"  :label="item.employeeName" :value="item.rowId"></el-option>
                      </template>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-form>
          </div>
        </el-col>
      </el-col>
      <el-col :gutter="24">
        <el-col :span="24">
          <_BTN_FILTER  :filterMethod="inputChange"  :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData" :isMore="isMore"/></_BTN_FILTER>
        </el-col>
      </el-col>
    </el-row>
     <div>
       <_TABLE
         ref="tableGrid"
         stripe
         maxHeight="500"
         @update:data="tabChange"
         :reqParams="reqParams"
         :data="dataSource"
         :columns="columnHeader"
         :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
         :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
         @selection-change="selectionChange"></_TABLE>
    </div>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import {dateFormat} from '@/utils/common'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import log from '@/log'
  import api from '@/api'
  import axios from 'axios'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  export default {
    mounted () {
      let params1 = {}
      params1.status = 1
      if (Number(getUser().place) === 24) {
        params1.manager = getUser().personId
      } else {
        params1.companyId = getUser().companyId
        params1.place = '135'
      }
      let countyIdParam = {} // 分公司
      countyIdParam.unitId = getUser().companyId
      countyIdParam.NextTypeId = '203'
      countyIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
      axios.all([
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params1),
        api.requestJava('POST', BasePath.NEXTORGUNIT_SELECT, countyIdParam)
      ])
      .then(axios.spread((first, second) => {
        this.custmgrIdGroup = first.data.data
        this.AllCustmgrIdGroup = first.data.data
        this.countyIdGroup = second.data.data
      }))
      this.initDate()
    },
    data () {
      return {
        isSelect: true,
        isMore: true, // 查询更多条件
        datetime: [new Date().setDate(1), new Date()],
        pickerOptions: {
          shortcuts: [{
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '当前月',
            onClick (picker) {
              const end = new Date()
              const start = new Date(new Date().setDate(1))
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }]
        },
        custmgrIdGroup: [], // 客户集id
        countyIdGroup: [], // 拜访情况
        AllCustmgrIdGroup: [], // 拜访情况
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['countyCode', 'countyName', 'mktMgrCode', 'custmgrCode', 'custmgrName', 'mktMgrName'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'countyName',
            label: '公司名称',
            className: 'header', // 列的css样式（选填）
            columnsProps: {width: 120, align: 'left', fixed: true}
          },
          {
            prop: 'mktMgrName',
            label: '市场经理',
            className: 'header', // 列的css样式（选填）
            columnsProps: {width: 120, align: 'left', fixed: true}
          },
          {
            prop: 'custmgrName',
            label: '客户经理',
            className: 'header', // 列的css样式（选填）
            columnsProps: {width: 120, align: 'left', fixed: true}
          },
          {
            prop: 'planCusts', // 列的值
            label: '应拜访(户)', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'passCusts',
            label: '已拜访(户)',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          },
          {
            prop: 'notCusts',
            label: '未拜访(户)',
            columnsProps: {align: 'left'}
          },
          {
            prop: 'temporaryCusts',
            label: '计划外(户)',
            columnsProps: {align: 'left'}
          },
          {
            prop: 'sumTimes',
            label: '总时长(m)',
            columnsProps: {align: 'left'}
          },
          {
            prop: 'avgTimes',
            label: '平均时长(m)',
            columnsProps: {align: 'left'}
          },
          {
            prop: 'compRate',
            label: '完成率(%)',
            columnsProps: {align: 'left'}
          }
        ],
        tableData: [],
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        /** searchForm **/
        searchForm: {
          custmgrId: '',
          countyId: '',
          beginDate: '',
          endDate: '',
          companyId: ''
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        hasPagination: true,
        sel_all_row: []
      }
    },
    methods: {
      handleItemChange () {
        if (this.searchForm.countyId !== '') {
          this.custmgrIdGroup = []
          this.searchForm.custmgrId = ''
          for (let i = 0; i < this.AllCustmgrIdGroup.length; i++) {
            if (this.AllCustmgrIdGroup[i].countyDept === this.searchForm.countyId) {
              this.custmgrIdGroup.push(this.AllCustmgrIdGroup[i])
            }
          }
        } else {
          this.custmgrIdGroup = this.AllCustmgrIdGroup
        }
      },
      datePickerChange (item) {
        this.searchForm.beginDate = this.getTime(Date.parse(this.datetime[0]))
        this.searchForm.endDate = this.getTime(Date.parse(this.datetime[1]))
        console.log('searchForm', this.searchForm)
      },
      query () {
        let params = this.searchForm
        this.queryUpper(params)
      }, // 查询方法
      queryUpper (params) {
        this.reqParams.url = BasePath.REPORT_SELECTVISTINGCOUNT
        this.reqParams.params = params
        api.requestJava('POST', BasePath.REPORT_SELECTVISTINGCOUNT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      initDate () {
        var myDate = new Date()
        this.searchForm.companyId = getUser().companyId
        this.searchForm.endDate = this.getTime(myDate.getTime())
        this.searchForm.beginDate = this.getTime(myDate.setDate(1))
        console.log('changeValueDate', this.changeValueDate)
        this.query()
      }, // 初始化时间并查询
      sortChange (msg) {},
      rowClick (msg) {},
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      dateFormatter (row, column) {
        var unixDate = row[column.property]
        return dateFormat(unixDate, 'YYYY-MM-DD HH:mm:ss')
      },  // 时间格式化
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      del (index, row) {},  // 删除
      batchDelClk () {},  // 批量删除
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      onendChange (val) {}, // 过滤器修改事件
      deleteUpper (val) {}, // 删除接口
      selectionChange (rows) {}
    },
    components: {
      _TABLE,
      _POPUP,
      _BTN_FILTER
    }
  }
</script>

<style scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-24 {
    height: 42px;
  }

</style>
