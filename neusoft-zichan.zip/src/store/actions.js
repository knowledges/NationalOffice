import api from '@/api'
import config from '@/config'
import BasePath from '@/config/BasePath'
export default {
  /**
   * 登录
   * @param commit
   * @param state 数据源
   * @param params [parameter, vue Object]
   */
  login: ({commit, state}, params) => {
    return new Promise((resolve, reject) => {
      api.requestJava('POST', 'login.do', {}, { 'headers': params[0] })
        .then(response => {
          if (Number(response.data.code) === 200) {
            commit('LOGIN_DO_SUCCESS', response.data)
            if (Number(params[2]) === 0) {
              params[1].$router.push('/home')
            }
            return resolve('success')
          } else if ((response.data.code) === 401) {
            throw new Error(JSON.stringify(response))
          } else {
            throw new Error(JSON.stringify(response))
          }
        })
        .catch(error => {
          let tmp = error
          tmp.culprit = state.route.name
          commit('CALL_BACK_ERROR', tmp)
          return reject('登录失败')
        })
    })
  },
  /**
   * 获取公司列表
   * @param commit
   * @param state 数据源
   * @param params
   * @returns {Promise} 返回结果（成功或者失败或者401）
   * TODO 缺少正式接口
   */
  getCompany: ({commit, state}, params) => {
    return new Promise((resolve, reject) => {
      let paraminfo = {}
      paraminfo.unitLevel = '2'
      let fluzzy = {}
      fluzzy.and = 'orgType:1'
      paraminfo.fluzzy = fluzzy
      let include = {}
      include.include = 'rowId,unitName'
      paraminfo.fields = include
      api.requestJava('POST', BasePath.SELECT_DEPTIDGROUP, paraminfo)
        .then(response => {
          if (Number(response.data.code) === 200 || Number(response.data.status) === 200) {
            commit('COMPANY_SUCCESS', response.data)
            return resolve('success')
          } else if (Number(response.data.code) === 401) {
            return resolve('401')
          } else {
            throw new Error(JSON.stringify(response))
          }
        })
        .catch(error => {
          let tmp = error
          tmp.culprit = state.route.name
          commit('CALL_BACK_ERROR', tmp)
          return reject('请求失败')
        })
    })
  },
  /**
   * 获取部门列表
   * @param commit
   * @param state 数据源
   * @param params 类型
   * @returns {Promise}  返回结果（成功或者失败或者401）
   * TODO 缺少正式接口
   */
  getDeparment: ({commit, state}, params) => {
    return new Promise((resolve, reject) => {
      api.requestJava('POST', BasePath.SELECT_DEPTIDGROUP, params)
        .then(response => {
          if (Number(response.data.code) === 200 || Number(response.data.status) === 200) {
            commit('DEPARMENT_SUCCESS', response.data)
            return resolve('success')
          } else if (Number(response.data.code) === 401) {
            return resolve('401')
          } else {
            throw new Error(JSON.stringify(response))
          }
        })
        .catch(error => {
          let tmp = error
          tmp.culprit = state.route.name
          commit('CALL_BACK_ERROR', tmp)
          return reject('请求失败')
        })
    })
  },
  /**
   * 权限菜单
   * @param commit
   * @param state
   * @returns {Promise}
   */
  getPowerTree: ({commit, state}, params) => {
    return new Promise((resolve, reject) => {
      // api.requestJava('POST', 'system/resources/selectTreeList.do', {'enable': 1, 'id': params.userId})
      api.requestJava('POST', 'system/resources/selectPermissionTree.do', {'enable': 1, 'id': params.userId})
        .then(response => {
          if (Number(response.data.code) === 200) {
            commit('POWER_TREE_SUCCESS', response.data)
            return resolve('success')
          } else if (Number(response.data.code) === 401) {
            return resolve('401')
          } else {
            throw new Error(JSON.stringify(response))
          }
        })
        .catch(error => {
          let tmp = error
          tmp.culprit = state.route.name
          commit('CALL_BACK_ERROR', tmp)
          return reject('获取权限失败')
        })
    })
  },
  /**
   * 获取本地权限菜单
   * @param commit
   * @param state
   */
  getLocalPowerTree: ({commit, state}) => {
    return new Promise((resolve, reject) => {
      api.requestLocal(config.root + '/static/json/Customrouting.json')
        .then(response => {
          if (Number(response.data.code) === 200) {
            commit('LOCAL_POWER_TREE_SUCCESS', response.data)
            return resolve('success')
          }
        })
        .catch(error => {
          console.log(error)
          let tmp = error
          tmp.culprit = state.route.name
          commit('CALL_BACK_ERROR', tmp)
          return reject('获取自定义权限失败')
        })
    })
  },
  /**
   * 动态设置loading 显示隐藏
   */
  setLoading: ({commit, state}, obj) => {
    commit('SET_LOADING', obj)
  },
  /**
   *
   * @param commit
   * @param state
   * @param str
   */
  setSessionMenus: ({commit, state}, str) => {
    commit('SET_SESSIONMENUS', str)
  },
  /**
   * 获取当前菜单光标
   * @param commit
   * @param state
   * @param idx
   */
  setRouteIdx: ({commit, state}, idx) => {
    commit('SET_ROUTERIDX', idx)
  }
}
