<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-form-item label="活动事项">
        <el-select v-model="dialogObj.data.form.matterId"   @change="changeXp"  :clearable="true"  placeholder="请选择活动事项"  :disabled ="this.dialogObj.disable">
          <template v-for="item in dialogObj.data.form.matterIdGroup">
            <el-option  :key="item.rowId"  :label="item.matterName" :value="item.rowId"></el-option>
          </template>
        </el-select>&nbsp;&nbsp;&nbsp;&nbsp;
        <i class="fa fa-cog fa-spin" @click="chuckCus()" ></i>&nbsp;&nbsp;<span class="notice" @click="chuckCus()">选点条件设置</span>
      </el-form-item>
      <el-form-item label="活动周期">
        <el-date-picker
          v-model="dialogObj.data.form.beginDate"
          type="date"
          format="yyyy-MM-dd"
          :editable=false
          :clearable=false
          :disabled ="this.dialogObj.disable"
          placeholder="选择开始时间">
        </el-date-picker>
        <span>至</span>
        <el-date-picker
          v-model="dialogObj.data.form.endDate"
          type="date"
          format="yyyy-MM-dd"
          :editable=false
          :clearable=false
          :disabled ="this.dialogObj.disable"
          placeholder="选择结束时间">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="活动主题">
        <el-input v-model="dialogObj.data.form.title" :disabled ="this.dialogObj.disable"></el-input>
      </el-form-item>
      <el-form-item label="活动描述">
        <el-input type="textarea" resize="none" v-model="dialogObj.data.form.notes" :disabled ="this.dialogObj.disable"></el-input>
      </el-form-item>
      <el-form-item label="收集内容"  >
        <el-select v-model="dialogObj.data.form.stepId"  multiple  :clearable="true" placeholder="请选择收集内容" :disabled ="this.dialogObj.disable">
          <template v-for="item in stepIdsGroup">
            <el-option  :key="item.rowId"  :label="item.title" :value="item.rowId"></el-option>
          </template>
        </el-select>
      </el-form-item>
      <el-form-item :label="reflabel"    v-if="isXp">
        <el-select v-model="dialogObj.data.form.ref"  filterable :clearable="true" placeholder="请选择" :disabled ="this.dialogObj.disable">
          <template v-for="item in refGroup">
            <el-option  :key="item.rowId"  :label="item.goodsDesc" :value="item.rowId"></el-option>
          </template>
        </el-select>
      </el-form-item>
      <el-form-item label="文件上传">
        <uploadTemp style="margin:7px;" :files="dialogObj.data.form.files" ref="uploadPic" :operation="operation"></uploadTemp>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
      <el-button type="success"  v-if="Number(this.dialogObj.type) == 3" @click="updateClk('addForm')" >保存</el-button>
      <el-button type="success"  v-if="Number(this.dialogObj.type) == 3"  @click="upClk('addForm')" >提交</el-button>
    </div>
  </el-dialog>
    <MY_POPUP_CONFIG :dialogObj='edit' ref='cuspop' @confirmBack="editEve" @backUrl="openImg" />
    <!--<el-dialog title="调查问卷浏览" :visible.sync="dialogTableVisible" size="large">-->
      <!--<img :src="iurl"  style="width: 100%;height: 400px;"/>-->
    <!--</el-dialog>-->
  </div>
</template>

<script>
  import api from '@/api'
  import axios from 'axios'
  import MY_POPUP_CONFIG from './cusPopup.vue'
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      if (Number(this.dialogObj.type) === 3) {
        this.operation = true
      }
    },
    data () {
      return {
        operation: false,
        files: [
          {
            fileName: 'baidu.gif',
            fileData: 'https://www.baidu.com/img/baidu_jgylogo3.gif',
            src: 'https://www.baidu.com/img/baidu_jgylogo3.gif'
          }
        ],
        isXp: false,
        reflabel: '',
        isPp: false,
        matterIdGroup: [],
        stepIdsGroup: [],
        xpGroup: [],
        spGroup: [],
        refGroup: [],
        addrules: {},
        edit: {
          title: '零售户选择器',
          type: this.dialogObj.type,
          disable: this.dialogObj.disable,
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              dataArea: {
                type: '',
                value: ''
              },
              customerGrade: [],
              geoType: [],
              businessType: [],
              routeId: [],
              starGrade: [],
              rtlcatId: [],
              operationScale: [],
              dataGrade: [],
              status: '',
              fpConds: {}
            }
          }
        },
        num: 1,
        isLoading: true
      }
    },
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        this.dialogObj.num = this.dialogObj.num + 1
        let xpparam = {}
        xpparam.unitId = getUser().companyId
        xpparam.fields = {'include': 'rowId,goodsDesc'}
        let params = {}
        params.prodUnitId = getUser().companyId
        params.onSchedule = 'Y'
        params.noProv = '1'
        params.fields = {'include': 'rowId,title'}
//        console.log('收集params:', getUser())
        axios.all([
          api.requestJava('POST', BasePath.COMMODITY_SELECT, {'status': 'Y', 'isConfiscated': 'N', 'fields': {'include': 'rowId,goodsDesc'}}),
          api.requestJava('POST', BasePath.ACTIVITY_CIGARETTES_NEW, xpparam),
          api.requestJava('POST', BasePath.FW_FROMS_SELECTLIST, params)
        ])
        .then(axios.spread((first, two, three) => {
          this.spGroup = JSON.parse(JSON.stringify(first.data.data))
          this.xpGroup = JSON.parse(JSON.stringify(two.data.data))
          this.stepIdsGroup = JSON.parse(JSON.stringify(three.data.data))
        }))
        this.changeXp1()
      }
    },
    methods: {
      changeXp () {
//        alert('num=' + this.dialogObj.num)
        if (this.dialogObj.num > 1) {
          this.dialogObj.data.form.ref = ''
        }
        this.changeXp1()
      },
      changeXp1 () {
        var matterid = this.dialogObj.data.form.matterId
        if (matterid === '381012479574016011' || matterid === '381012479574016012' || matterid === '381012479574016013') {
          if (matterid === '381012479574016011') {
//            alert('新品')
            this.isXp = true
            this.refGroup = this.xpGroup
            this.reflabel = '新品选择'
          } else if (matterid === '381012479574016012' || matterid === '381012479574016013') {
//            alert('品牌')
            this.isXp = true
            this.refGroup = this.spGroup
            this.reflabel = '品牌选择'
          }
        } else {
          this.isXp = false
        }
      },
      chuckCus () {
        this.$refs.cuspop.tmp = []
        if (this.dialogObj.data.form.fpConds !== '') {
          let param = JSON.parse(this.dialogObj.data.form.fpConds)
          this.edit.data.form.fpConds = param
          console.log('解析查询条件:', param)
          if ('customerGrade' in param && param.customerGrade !== '') {
            let customerGrade = param.customerGrade
            this.edit.data.form.customerGrade = customerGrade.replace(/'/g, '').split(',')
          }
          if ('geoType' in param && param.geoType !== '') {
            this.edit.data.form.geoType = param.geoType.replace(/'/g, '').split(',')
          }
          if ('businessType' in param && param.businessType !== '') {
            this.edit.data.form.businessType = param.businessType.replace(/'/g, '').split(',')
          }
          if ('routeId' in param && param.routeId !== '') {
            this.edit.data.form.routeId = param.routeId.replace(/'/g, '').split(',')
          }
          if ('operationScale' in param && param.operationScale !== '') {
            this.edit.data.form.operationScale = param.operationScale.replace(/'/g, '').split(',')
          }
          if ('status' in param) {
            this.edit.data.form.status = '1'
          }
          if ('starGrade' in param && param.starGrade !== '') {
            this.edit.data.form.starGrade = param.starGrade.replace(/'/g, '').split(',')
          }
          if ('rtlcatId' in param && param.rtlcatId !== '') {
            this.edit.data.form.rtlcatId = param.rtlcatId.replace(/'/g, '').split(',')
          }
          if ('companyId' in param && param.companyId !== '') {
            if (Number(getUser().unitLevel) === 1) {
              this.$refs.cuspop.tmp.push(param.companyId)
            } else {
              this.edit.data.form.companyId = param.companyId
            }
          }
          if ('countyId' in param && param.countyId !== '') {
            this.$refs.cuspop.tmp.push(param.countyId)
          }
          if ('marketmgrId' in param && param.marketmgrId !== '') {
            this.$refs.cuspop.tmp.push(param.marketmgrId)
          }
          if ('custmgrId' in param && param.custmgrId !== '') {
            this.$refs.cuspop.tmp.push(param.custmgrId)
          }
          this.edit.data.form.dataGrade = this.$refs.cuspop.tmp
        }
        console.log('数据范围数据内容', JSON.stringify(this.edit.data.form.dataGrade))
        console.log('解析查询条件去筛选页面', JSON.stringify(this.edit.data.form))
        this.edit.dialogVisible = true
      },
      editEve (msg) {
        if (msg !== 'cancle') {
//          let param = {}
//          let dataArea = {}
//          if (typeof (tempParam.COMPANY_ID) !== 'undefined') {
//            param.COMPANY_ID = tempParam.COMPANY_ID
//          }
//          if (typeof (tempParam.COUNTY_ID) !== 'undefined') {
//            param.COUNTY_ID = tempParam.COUNTY_ID
//          }
//          if (typeof (tempParam.MARKETMGR_ID) !== 'undefined') {
//            param.MARKETMGR_ID = tempParam.MARKETMGR_ID
//          }
//          if (typeof (tempParam.CUSTMGR_ID) !== 'undefined') {
//            param.CUSTMGR_ID = tempParam.CUSTMGR_ID
//          }
//          if (this.edit.data.form.customerGrade.length > 0) {
//            param.CUSTOMER_GRADE = this.edit.data.form.customerGrade
//          }
//          if (this.edit.data.form.geoType.length > 0) {
//            param.GEO_TYPE = this.edit.data.form.geoType
//          }
//          if (this.edit.data.form.businessType.length > 0) {
//            param.BUSINESS_TYPE = this.edit.data.form.businessType
//          }
//          if (this.edit.data.form.routeId.length > 0) {
//            param.ROUTE_ID = this.edit.data.form.routeId
//          }
//          if (this.edit.data.form.operationScale.length > 0) {
//            param.OPERATION_SCALE = this.edit.data.form.operationScale
//          }
//          if (this.edit.data.form.starGrade.length > 0) {
//            param.STAR_GRADE = this.edit.data.form.starGrade
//          }
//          if (this.edit.data.form.rtlcatId.length > 0) {
//            param.RTLCAT_ID = this.edit.data.form.rtlcatId
//          }
          this.dialogObj.data.form.fpConds = msg
        }
        this.edit.dialogVisible = false
        let tmp = {
          title: '零售户选择器',
          type: this.dialogObj.type,
          disable: this.dialogObj.disable,
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              dataArea: {
                type: '',
                value: ''
              },
              customerGrade: [],
              geoType: [],
              businessType: [],
              routeId: [],
              operationScale: [],
              starGrade: [],
              rtlcatId: [],
              dataGrade: [],
              status: '',
              fpConds: {}
            }
          }
        }
        Object.assign(this.edit, tmp)
        console.log('清空', this.edit)
      }, // 修改事件
      openImg (msg) {
        alert('获取open 里参数', msg)
      },
      _upload_submit () {
        this.$refs.uploadTemp.submitUpload()
      },
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      },
      updateClk (formName) {
        if (this.dialogObj.data.form.matterId === '') {
          this.$message({type: 'info', message: '请选择活动事项!'})
          return
        }
        if (this.dialogObj.data.form.stepId.length === 0) {
          this.$message({type: 'info', message: '请选择收集内容!'})
          return
        }
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dialogObj.data.form.files = this.$refs.uploadPic.getFiles()
            this.dialogObj.data.form.status = '0'
            this.isLoading = true
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      upClk (formName) {
        if (this.dialogObj.data.form.matterId === '') {
          this.$message({type: 'info', message: '请选择活动事项!'})
          return
        }
        if (this.dialogObj.data.form.stepId.length === 0) {
          this.$message({type: 'info', message: '请选择收集内容!'})
          return
        }
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dialogObj.data.form.files = this.$refs.uploadPic.getFiles()
            this.dialogObj.data.form.status = '1'
            this.isLoading = true
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      }
    },
    components: {
      uploadTemp,
      MY_POPUP_CONFIG
    }
  }
</script>
<style scoped>
  .el-form-item {
    margin-bottom: 15px;
  }
  .el-dialog__body {
    padding: 12px 20px;
    color: #48576a;
    font-size: 14px;
    height: 490px;
  }
  .el-select {
    display: inline-block;
    position: relative;
    width: 60%;
  }
  .el-dialog__body {
    color: #48576a;
    font-size: 14px;
  }
  .fa-cog{
    color: #7f9eeb;
    font-size: 21px;
  }
  .notice{
    color: #7f9eeb;
    font-size: 16px;
  }
</style>
