<!--李晶-->
<style rel="stylesheet/scss" lang="scss" scoped></style>
<template>
    <div>
      <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :modal-append-to-body="false" :close-on-click-modal="false" :close-on-press-escape="false"  :size='dialogObj.size' :before-close="closeModalEve">
        <_RecordDetail :rowId="dialogObj.rowId" :gatherDate="dialogObj.gatherDate" :gatherer="dialogObj.gatherer"></_RecordDetail>
      </el-dialog>
    </div>
</template>
<script>
  import _RecordDetail from '@/components/CustomerService/PriceCollection/Record/RecordDetailView.vue'
  export default {
    name: '',
    props: ['dialogObj'],
    mounted () {
    },
    updated () {
      console.log('进入弹出框，获得数据', this.dialogObj)
    },
    data () {
      return {
        value: '',
        form: {
          rowId: '',
          gatherer: '',
          gatherDate: ''
        }
      }
    },
    methods: {
      closeModalEve () {
        this.dialogObj.dialogVisible = false
      }
    },
    components: {
      _RecordDetail
    },
    watch: {}
  }
</script>
<style scoped>
  .item__label_popup {
    text-align: right;
    vertical-align: middle;
    float: right;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 8px 11px 0;
    box-sizing: border-box;
    /* display: inline-block; */
  }
  .el-input, .el-input__inner {
    /*width: '';*/
    display: inline-block;
  }
  .container-fluid_new {
    background: #FFF;
  }
</style>
