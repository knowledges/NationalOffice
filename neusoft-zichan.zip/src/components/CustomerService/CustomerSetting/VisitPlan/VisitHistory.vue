<!-- 徐晓菁 -->
<template>
  <div  class="container-fluid_new">
    <div>
      <_TABLE
        ref="table"
        stripe
        maxHeight="500"
        @update:data="tabChange" :reqParams="reqParams"
        :data="dataSource"
        :columns="columnHeader"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
        ></_TABLE>
    </div>
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import {changeListValueByCode} from '@/utils/common'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import {getCodeList} from '@/config/info'
  import log from '@/log'
  export default {
    props: {
      custId: {
        type: String,
        default: ''
      }
    },
    mounted () {
      getCodeList('VISIT_MODE', (data) => {
        this.changeValueDate.visitMode.group = data
      }) // 拜访方式
      console.log('我是visiHistory==', JSON.parse(this.custId))
      this.init(JSON.parse(this.custId))
    },
    data () {
      return {
        isSelect: false,
        isMore: true, // 查询更多条件
        searchForm: {
          gatherDate: new Date()
        },
        /** 过滤的字段 **/
        filName: ['company_id', 'gatherer'],
        /** 定义按钮 **/
        tableType: '3',
        btnGroups: [],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 500,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'visitDate',
            label: '拜访日期',
            columnsProps: {align: 'center'}
          },
          {
            prop: 'startTime',
            label: '开始时间',
            columnsProps: {align: 'center'}
          },
          {
            prop: 'endTime',
            label: '结束时间',
            columnsProps: {align: 'center'}
          },
          {
            prop: 'visitMode',
            label: '拜访方式',
            columnsProps: {align: 'center', formatter: this.changeValue}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 120, type: 'button'},
            cptProperties: [
              {
                label: '服务项目',
                value: 'query',
                icon: 'search',
                size: 'small',
                type: 'primary',
                eventClick: this.modify
              }
            ]
          }
        ],
        changeValueDate: {
          customerGrade: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          visitMode: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          startTime: {
            type: 'date1'
          }
        },
        planTime: '',
        dataSource: [], // 当前页的数据
        tableData: [],
        hasPagination: true,
        /** filter **/
        templTableData: [] // 临时记录tableDate的值
      }
    },
    methods: {
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      modify (index, row) {
        this.$emit('confirmBack', row.rowId)
      }, // 查询接口
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      headerClick () {},
      sortChange (msg) {},
      rowClick (msg) {},
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      init (val) {
        let param = {}
        param.customerId = val.rowId
        param.whereClause = `and status in('2','9','3')`
        param.sorter = 'start_time desc '
        console.log(JSON.stringify(param))
        this.reqParams.url = BasePath.VISI_HISTORY
        this.reqParams.params = param
        api.requestJava('POST', BasePath.VISI_HISTORY, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.tableData = []
              var i = 0
              if (request.data.data.length !== 0) {
                request.data.data.forEach((e) => {
                  let datas = {}
                  console.log('requestVistHistory:', JSON.stringify(request.data.data[i].startTime))
                  datas.visitDate = request.data.data[i].startTime.substr(0, 10)
                  datas.startTime = request.data.data[i].startTime.substr(11, 8)
                  datas.endTime = request.data.data[i].endTime.substr(11, 8)
                  datas.visitMode = request.data.data[i].visitMode
                  datas.rowId = request.data.data[i].rowId
                  this.tableData.push(datas)
                  i++
                })
              }
              this.currentPage = 1
              this.totalCount = this.tableData.length
              this.queryData(this.currentPage, this.pageSize)
            } else {
              this.$notify.error({ title: '提示', message: request.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }
    },
    watch: {
      custId (val, old) {
        this.init(JSON.parse(val))
      }
    },
    components: {
      _TABLE,
      _BTN_FILTER
    }
  }
</script>
<style scoped>
  .container-fluid_new {
    background: #FFF;
  }
</style>
