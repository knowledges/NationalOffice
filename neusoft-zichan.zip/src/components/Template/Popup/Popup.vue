  <!--author: gengchao-->
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="closeModalEve" :size='dialogObj.size' v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <div v-if="dialogObj.type == 1">
      <el-table :data="dialogObj.data.gridData" ref="multipleTable">
        <el-table-column     type="selection"> </el-table-column>
        <el-table-column property="date" label="日期" width="150"></el-table-column>
        <el-table-column property="name" label="姓名" width="200"></el-table-column>
        <el-table-column property="address" label="地址"></el-table-column>
      </el-table>
      <div slot="footer" class="dialog-footer" style="text-align: right">
        <el-button @click="dialogObj.dialogVisible = false">取 消</el-button>
        <el-button type="success" @click="dialogVisible = false">确 定</el-button>
      </div>
    </div>

    <div v-if= "dialogObj.type == 'menuMaintenance'">
      <el-form :model="dialogObj.data.form" label-width="100px" ref="query" :rules="queryrules">
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="tel" label="菜单名称" >
                <el-input v-model="dialogObj.data.form.menuName" auto-complete="off" class="inputInline" ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="phone" label="菜单图标">
                <el-input v-model="dialogObj.data.form.menuIcon" auto-complete="off" class="inputInline" ></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='24'>
              <el-form-item  prop="date" label="上级菜单" >
                <!-- <el-row>
                   <el-col>
                     <compositeInput></compositeInput>
                   </el-col>
                </el-row> -->
                <compositeInput></compositeInput>
                <!-- <el-input placeholder="请输入内容" > <template slot="append">.com</template></el-input> -->
                <!-- <el-tree :data="data" :props="defaultProps" @node-click="handleNodeClick"></el-tree> -->
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer" style="text-align: right">
        <el-button @click="resetForm('query')">取 消</el-button>
        <el-button type="success" @click="submitForm('query')">确 定</el-button>
      </div>
    </div>

    <div v-if= "dialogObj.type == 'query1'">
      <el-form :model="dialogObj.data.form" label-width="100px" ref="query" :rules="queryrules">
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="tel" label="电话" >
                <el-input v-model="dialogObj.data.form.tel" auto-complete="off" class="inputInline" type="number"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="phone" label="手机">
                <el-input v-model="dialogObj.data.form.phone" auto-complete="off" class="inputInline" type="number"></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="date" label="创建日期" >
                <DatePickerTemp @on-change="startTime" :types="date" />
                <!-- <el-input v-model="dialogObj.data.form.date" auto-complete="off" class="inputInline"></el-input> -->
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer" style="text-align: right">
        <el-button @click="resetForm('query')">取 消</el-button>
        <el-button type="success" @click="submitForm('query')">确 定</el-button>
      </div>
    </div>

    <div v-if= "dialogObj.type == 'query'">
      <el-form :model="dialogObj.data.form" label-width="100px" ref="query" :rules="queryrules">
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="userName" label="姓名" >
                <el-input v-model="dialogObj.data.form.userName" auto-complete="off" class="inputInline"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='12'>
              <el-form-item prop="userCode" label="登陆账号">
                <el-input v-model="dialogObj.data.form.userCode" auto-complete="off" class="inputInline"></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="company" label="公司" >
                <el-select v-model="dialogObj.data.form.companyId" placeholder="请选择" :disabled="true">
                  <el-option
                    v-for="item in optionsCompany"
                    :key="item.orgUnitId"
                    :label="item.orgRoleNm"
                    :value="item.orgUnitId">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="department" label="部门">
                <el-select v-model="dialogObj.data.form.divisionId" placeholder="请选择">
                  <el-option
                    v-for="item in optionsDepartment"
                    :key="item.orgUnitId"
                    :label="item.orgRoleNm"
                    :value="item.orgUnitId">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='12' >
              <el-form-item prop="mobile" label="手机">
                <el-input v-model="dialogObj.data.form.mobile" auto-complete="off" class="inputInline" type="number"></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer" style="text-align: right">
        <el-button @click="resetForm('query')">取 消</el-button>
        <el-button type="success" @click="submitForm('query')">确 定</el-button>
      </div>
    </div>

    <div v-if= "dialogObj.type == 'sessionFailured'" >
      <el-form :model="dialogObj.data.form" label-width="80px" ref="sessionFailured" :rules="sessionrules">
        <el-row>
          <el-col :span='24'>
            <el-col :span='24'>
              <el-form-item  prop="userCode" label="用户名" >
                <el-input v-model="dialogObj.data.form.userCode" auto-complete="off" class="inputInline" ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='24' >
              <el-form-item prop="password" label="密码">
                <el-input v-model="dialogObj.data.form.password" auto-complete="off" class="inputInline" type="password"></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer" style="text-align: right">
        <el-button @click="resetForm('sessionFailured')">取 消</el-button>
        <el-button type="success" @click="submitForm('sessionFailured')" @keyup.enter="submitForm('sessionFailured')" >确 定</el-button>
      </div>
    </div>

    <div v-if= "dialogObj.type == 'addUser'">
      <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="userName" label="姓名" >
                <el-input v-model="dialogObj.data.form.userName" auto-complete="off" class="inputInline"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="userCode" label="登陆账号">
                <el-input v-model="dialogObj.data.form.userCode" auto-complete="off" class="inputInline" value="number"></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="password" label="登录密码" >
                <el-input v-model="dialogObj.data.form.password" auto-complete="off" class="inputInline" type='password'></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="confirmPass" label="确认密码">
                <el-input v-model="dialogObj.data.form.confirmPass" auto-complete="off" class="inputInline" type='password'></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="companyId" label="公司" >
                <el-select v-model="dialogObj.data.form.companyId" placeholder="请选择">
                  <el-option
                    v-for="item in optionsCompany"
                    :key="item.orgUnitId"
                    :label="item.orgRoleNm"
                    :value="item.orgUnitId">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="divisionId" label="部门">
                <el-select v-model="dialogObj.data.form.divisionId" placeholder="请选择">
                  <el-option
                    v-for="item in optionsDepartment"
                    :key="item.orgUnitId"
                    :label="item.orgRoleNm"
                    :value="item.orgUnitId">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="email" label="Email" >
                <el-input v-model="dialogObj.data.form.email" auto-complete="off" class="inputInline" type="email"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="personId" label="工号">
                <el-input v-model="dialogObj.data.form.personId" auto-complete="off" class="inputInline" value="number"></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="contactPhone" label="电话" >
                <el-input v-model="dialogObj.data.form.contactPhone" auto-complete="off" class="inputInline"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="mobile" label="手机">
                <el-input v-model="dialogObj.data.form.mobile" auto-complete="off" class="inputInline"></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="status" label="状态" >
                <el-switch
                  v-model="dialogObj.data.form.status"
                  on-text=""
                  off-text="">
                </el-switch>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="loginFlag" label="是否可登录">
                <el-switch
                  v-model="dialogObj.data.form.loginFlag"
                  on-text=""
                  off-text="">
                </el-switch>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  label="照片">
                <div id="propertiesPic">
                  <uploadTemp style="margin:20px;" :files="dialogObj.data.form.propertiesPic" ref="propertiesPic"></uploadTemp>
                </div>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='24'>
              <el-form-item label="备注" prop="remark" >
                <el-input v-model="dialogObj.data.form.remark" auto-complete="off" class="inputInline"
                          type="textarea"  resize="none"
                          :rows="3"
                          placeholder="请输入内容"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer" style="text-align: right">
        <el-button @click="resetForm('addForm')">取 消</el-button>
        <el-button type="success" @click="submitForm('addForm')">确 定</el-button>
      </div>
    </div>
    <div v-if= "dialogObj.type == 'editUser'">
      <el-form :model="dialogObj.data.form" :rules="editrules" ref="editForm" label-width="100px">
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="userName" label="姓名" >
                <el-input v-model="dialogObj.data.form.userName" auto-complete="off" class="inputInline"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="userCode" label="登陆账号">
                <el-input v-model="dialogObj.data.form.userCode" auto-complete="off" class="inputInline" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="companyId" label="公司" >
                <el-select v-model="dialogObj.data.form.companyId" placeholder="请选择" :disabled="true">
                  <el-option
                    v-for="item in optionsCompany"
                    :key="item.orgUnitId"
                    :label="item.orgRoleNm"
                    :value="item.orgUnitId">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="divisionId" label="部门">
                <el-select v-model="dialogObj.data.form.divisionId" placeholder="请选择">
                  <el-option
                    v-for="item in optionsDepartment"
                    :key="item.orgUnitId"
                    :label="item.orgRoleNm"
                    :value="item.orgUnitId">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="email" label="Email" >
                <el-input v-model="dialogObj.data.form.email" auto-complete="off" class="inputInline" type="email"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="personId" label="工号">
                <el-input v-model="dialogObj.data.form.personId" auto-complete="off" class="inputInline" value="number"></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="contactPhone" label="电话" >
                <el-input v-model="dialogObj.data.form.contactPhone" auto-complete="off" class="inputInline"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="mobile" label="手机">
                <el-input v-model="dialogObj.data.form.mobile" auto-complete="off" class="inputInline"></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="status" label="状态" >
                <el-switch
                  v-model="dialogObj.data.form.status"
                  on-text=""
                  off-text="">
                </el-switch>
              </el-form-item>
            </el-col>
            <el-col :span='12' >
              <el-form-item prop="loginFlag" label="是否可登录">
                <el-switch
                  v-model="dialogObj.data.form.loginFlag"
                  on-text=""
                  off-text="">
                </el-switch>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='12'>
              <el-form-item  prop="propertiesPic" label="照片">
                  <div id="uploadTemp">
                    <uploadTemp style="margin:20px;" :files="dialogObj.data.form.files" ref="propertiesPic"></uploadTemp>
                  </div>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='24'>
              <el-form-item label="备注" prop="remark" >
                <el-input v-model="dialogObj.data.form.remark" auto-complete="off" class="inputInline"
                          type="textarea" resize="none"
                          :rows="3"
                          placeholder="请输入内容"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer" style="text-align: right">
        <el-button @click="resetForm('editForm')">取 消</el-button>
        <el-button type="success" @click="submitForm('editForm')">确 定</el-button>
      </div>
    </div>
    <div v-if= "dialogObj.type == 'editLogin'">
      <el-form :model="dialogObj.data.form" :rules="settingrules" ref="editForm" label-width="100px">
        <el-row>
          <el-col :span='24'>
            <el-col :span='12' >
              <el-form-item prop="idType" label="登录类型">
                <el-input v-model="dialogObj.data.form.idType" auto-complete="off" class="inputInline"></el-input>
                <!--<el-select v-model="dialogObj.data.form.idType" clearable filterable placeholder="请选择">-->
                  <!--<el-option-->
                    <!--v-for="item in optionstype"-->
                    <!--:key="item.label"-->
                    <!--:label="item.label"-->
                    <!--:value="item.label">-->
                  <!--</el-option>-->
                <!--</el-select>-->
              </el-form-item>
            </el-col>
            <el-col :span='12'>
              <el-form-item  prop="idNo" label="登录账号" >
                <el-input v-model="dialogObj.data.form.idNo" auto-complete="off" class="inputInline" type="email"></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span='24'>
            <el-col :span='24'>
              <el-form-item label="备注" prop="remark" >
                <el-input v-model="dialogObj.data.form.remark" auto-complete="off" class="inputInline"
                          type="textarea" resize="none"
                          :rows="3"
                          placeholder="请输入内容"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer" style="text-align: right">
        <el-button @click="resetForm('editForm')">取 消</el-button>
        <el-button type="success" @click="submitForm('editForm')">确 定</el-button>
      </div>
    </div><div v-if= "dialogObj.type == 'addNo'">
    <el-form :model="dialogObj.data.form" :rules="insertrules" ref="addForm" label-width="100px">
      <el-row>
        <el-col :span='24'>
          <el-col :span='12' >
            <el-form-item prop="idType" label="登录类型">
              <el-input v-model="dialogObj.data.form.idType" auto-complete="off" class="inputInline"></el-input>
              <!--<el-select v-model="dialogObj.data.form.idType" clearable filterable placeholder="请选择">-->
                <!--<el-option-->
                  <!--v-for="item in optionstype"-->
                  <!--:key="item.label"-->
                  <!--:label="item.label"-->
                  <!--:value="item.label">-->
                <!--</el-option>-->
              <!--</el-select>-->
            </el-form-item>
          </el-col>
          <el-col :span='12'>
            <el-form-item  prop="idNo" label="登录账号" >
              <el-input v-model="dialogObj.data.form.idNo" auto-complete="off" class="inputInline" type="email"></el-input>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span='24'>
          <el-col :span='24'>
            <el-form-item label="备注" prop="remark" >
              <el-input v-model="dialogObj.data.form.remark" auto-complete="off" class="inputInline"
                        type="textarea" resize="none"
                        :rows="3"
                        placeholder="请输入内容"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="resetForm('addFormForm')">取 消</el-button>
      <el-button type="success" @click="submitForm('addForm')">确 定</el-button>
    </div>
  </div>
  </el-dialog>
</template>

<script>
  import InputTemp from '../filter/InputTemp.vue'
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
  import DatePickerTemp from '../DatePicker/DatePickerTemp.vue'
  import compositeInput from './compositeInput.vue'
  import BasePath from '@/config/BasePath'
//  import { getCodeList } from '@/config/info'
  import { mapState } from 'vuex'
  import api from '@/api'
//  let loaded = false //  是否被执行过
  export default {
    props: {
      dialogObj: Object,
      need: { // 是否需要被加载
        type: Boolean,
        default: false
      }
    },
    data () {
      var checkNumber = (rule, value, callback) => {
        let reg = /^[1-9]\d*$/
        if (!value) {
          return callback()
        }
        if (RegExp(reg).test(value) === false) {
          callback(new Error('请输入数字值'))
        } else {
          if (!(/^1[34578]\d{9}$/.test(value))) {
            callback(new Error('手机号码有误，请重填'))
          } else {
            callback()
          }
        }
      }
      var checkUserName = (rule, value, callback) => {
        if (value.trim() === '') {
          callback(new Error('请输入姓名'))
        } else {
          callback()
        }
      }
      var checkUserCode = (rule, value, callback) => {
        if (value.trim() === '') {
          callback(new Error('请输入账号'))
        }
        if ((/[\u4e00-\u9fa5]+/).test(value)) {
          callback(new Error('账号不能包含汉字'))
        } else {
          this.queryUserCode(value, function (data) {
            if (data) {
              callback(new Error('该账号已存在'))
            } else {
              callback()
            }
          })
        }
      }
      var validatePass = (rule, value, callback) => {
        if (value.trim() === '') {
          callback(new Error('请输入密码'))
        } else {
          callback()
        }
      }
      var validatePass2 = (rule, value, callback) => {
        if (value.trim() === '') {
          callback(new Error('请再次输入密码'))
        } else if (value !== this.dialogObj.data.form.password) {
          callback(new Error('两次输入密码不一致!'))
        } else {
          callback()
        }
      }
      var checkidNo = (rule, value, callback) => {
        if (value.trim() === '') {
          callback(new Error('请输入账号'))
        }
        if ((/[\u4e00-\u9fa5]+/).test(value)) {
          callback(new Error('账号不能包含汉字'))
        } else {
          if (value !== this.dialogObj.data.form.oldIdNo) {
            this.queryUserCode(value, function (data) {
              if (data) {
                callback(new Error('该账号已存在'))
              } else {
                callback()
              }
            })
          } else {
            callback()
          }
        }
      }
      var checkidType = (rule, value, callback) => {
        if (value.trim() === '') {
          callback(new Error('请输入类型'))
        } else {
          callback()
        }
      }
      return {
        dialogVisible: false,
        formLabelWidth: '120px',
        fileList: [{name: 'food.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}, {name: 'food2.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}],
        filmode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤
        fileName: ['value'],
        filType: 0, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        keyup: true, // 输入筛选；true：之前展示；false：之后展示
        valcomp: '',
        valdevp: '',
//        keyupend: false,
        date: 'date',
        optionsCompany: [], // 数据源
        optionsDepartment: [], // 数据源
        addrules: {
          userName: [
            {required: true, validator: checkUserName, trigger: 'blur'}
          ],
          userCode: [
            {required: true, validator: checkUserCode, trigger: 'blur'}
          ],
          password: [
            {required: true, validator: validatePass, trigger: 'blur'}
          ],
          confirmPass: [
            {required: true, validator: validatePass2, trigger: 'blur'}
          ],
          contactPhone: [
            { validator: checkNumber, trigger: 'blur' }
          ],
          mobile: [
            {required: true, validator: checkNumber, trigger: 'blur'}
          ],
          companyId: [
            {required: true, message: '请选择公司名称', trigger: 'blur'}
          ],
          divisionId: [
            {required: true, message: '请选择部门名称', trigger: 'blur'}
          ]
        },
        editrules: {
          userName: [
            {validator: checkUserName, trigger: 'blur'}
          ],
          contactPhone: [
            { validator: checkNumber, trigger: 'blur' }
          ],
          mobile: [
            { validator: checkNumber, trigger: 'blur' }
          ]
        },
        queryrules: {
        },
        sessionrules: {
          userCode: [
            {required: true, message: '请输入用户名', trigger: 'blur'}
          ],
          password: [
            {required: true, message: '请输入密码', trigger: 'blur'}
          ]
        },
        settingrules: {
          idNo: [
            { validator: checkidNo, trigger: 'blur' }
          ],
          idType: [
            { validator: checkidType, trigger: 'blur' }
          ]
        },
        insertrules: {
          idNo: [
            { validator: checkidNo, trigger: 'blur' }
          ],
          idType: [
            { validator: checkidType, trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      submitForm (formName) {
        // this._upload_submit()
        this.$refs[formName].validate((valid) => {
          this.dialogObj.data.form.files = this.$refs.propertiesPic.getFiles()
          if (valid) {
            this.dialogObj.dialogVisible = false
            this.$emit('confirmBack', this.dialogObj)
            setTimeout(() => {
              this.$refs[formName].resetFields()
            }, 1000)
          } else {
            return false
          }
        })
      },
      closeModalEve () {
        this.$emit('confirmBack', false)
        this.dialogObj.dialogVisible = false
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
        this.$emit('confirmBack', false)
        this.dialogObj.dialogVisible = false
      },
      queryUserCode (userCode, callback) {
        let paraminfo = {}
        paraminfo.userCode = userCode
        api.requestJava('POST', BasePath.USER_SELECTLIST, paraminfo)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              var judge = request.data.data.length
              if (judge > 0) {
                callback(true)
              } else {
                callback(false)
              }
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      queryId (userCode, callback) {
        let param = {}
        console.log('=====', userCode)
        param.idNo = userCode
        api.requestJava('POST', '/system/userid/selectList.do', param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              var judge = request.data.data.length
              console.log('=====', judge)
              if (judge > 0) {
                callback(true)
              } else {
                callback(false)
              }
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      confirm () {
        this.dialogObj.dialogVisible = false
        this.$emit('confirmBack', this.dialogObj)
      },
      cancel () {
        this.dialogObj.dialogVisible = false
      },
//      onbeforChangeAdd (val) {
//        if (val !== null && val !== 'undefined' && val !== '') {
//          this.queryOrgByType(val)
//        } else {
//          this.optionsDepartment = []
//        }
//      },
//      onbeforChangeQuery (val) {
//        if (val !== null && val !== 'undefined' && val !== '') {
//          this.queryOrgByType()
//        } else {
//          this.optionsDepartment = []
//        }
//      },
      onendChange (val) { },
      startTime (val) {
        this.dialogObj.data.form.date = val
      },
      loadAll () { },
      queryOrgByType (companyId) {
        // 请求 公司
        let paraminfo = {}
        paraminfo.companyId = companyId
        let fluzzy = {}
        fluzzy.and = 'orgType:200'
        paraminfo.fluzzy = fluzzy
        this.$store.dispatch('getDeparment', paraminfo)
          .then((data) => {
            if (data === 'success') {
//              this.optionsDepartment = this.deparment
            } else if (data === '401') {
              this.$message('登录失效')
            }
          }).catch((err) => { console.log(err) })
      } // 查询公司
    },
    mounted () {
      // 请求ajax
//      if (!loaded && this.need) {
//        loaded = !loaded
//        this.$store.dispatch('getCompany')
//          .then((data) => {
//            if (data === 'success') {
//              this.optionsCompany = this.company
//            } else if (data === '401') {
//              this.$message('登录失效')
//            }
//          }).catch((err) => { console.log(err) })
//        getCodeList('SM_USER_ID_TYPE', (data) => {
//          this.optionstype = data
//        })
//      }
    },
    updated () {
      this.optionsCompany = this.dialogObj.data.form.optionsCompany
      this.optionsDepartment = this.dialogObj.data.form.optionsDepartment
    },
//    updated: function () {
//      this.$store.dispatch('getCompany')
//        .then((data) => {
//          if (data === 'success') {
//            this.optionsCompany = this.company
//          } else if (data === '401') {
//            this.$message('登录失效')
//          }
//        }).catch((err) => { console.log(err) })
//    },
    components: {
      InputTemp, uploadTemp, DatePickerTemp, compositeInput
    },
    computed: {
      size: function () {
        if (this.dialogObj.type === 'menuMaintenance') {
          return 'tiny'
        }
        return 'small'
      },
      ...mapState([
        'company',
        'deparment'
      ])
    }
  }
</script>

<style scoped>
  .item__label_popup {
    text-align: right;
    vertical-align: middle;
    float: right;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 8px 11px 0;
    box-sizing: border-box;
    /* display: inline-block; */
  }
  .el-input, .el-input__inner {
    /*width: '';*/
    display: inline-block;
  }
</style>
