<!--赵继越-->
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='12'>
          <div>
            <el-form ref="searchForm" :model="searchForm" label-width="120px">
              <el-col :gutter="24">
                <el-col :span='15'>
                  <el-form-item label="状态" >
                    <el-select v-model="searchForm.status" filterable :clearable="true" placeholder="请选择审核状态">
                      <el-option
                        v-for="item in optionsStatus"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-form>
          </div>
        </el-col >
        <el-col :span="12" style="padding: 0 0">
        <_BTN_FILTER :isMore="isMore" :btnGroups="btnGroups" :fileName="fileName" :filterMethod="inputChange"
                     @on-click="exportEve" :tableData="tableData"/>
      </el-col>
      </el-col>
    </el-row>
    <div>
      <_TABLE
        ref="tableGrid"
        @update:data="tabChange" :reqParams="reqParams"
        stripe
        maxHeight="500"
        :data="dataSource"
        :columns="columnHeader"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData></_TABLE>
    </div>
    <_POPUP :dialogObj='sessionFailedDialogObj' @confirmBack="sessionFailedBack" />
    <MY_POPUP_CONFIG :dialogObj='updateDialogObj' @confirmBack="addOrUpdateBack"/>
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import MY_POPUP_CONFIG from './Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import { changeListValueByCode, dateFormat } from '@/utils/common'
  import api from '@/api'
  import log from '@/log'
  import { getUser, getCodeList } from '@/config/info'
  import BasePath from '@/config/BasePath'
  export default {
    mounted () {
      /** 调用初始化数据 **/
      getCodeList('FW_DISPLAY_TMP_STATUS', (data) => {
        this.optionsStatus = data
      })
      this.initDate()
      this.init()
    },
    data () {
      return {
        rowId: '',
        handlerNm: '',
        isSelect: true,
        isMore: true, // 查询更多条件
        hasPagination: true, // 是否有分页
        datetime: [new Date().setDate(1), new Date()],
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['customerCode', 'customerDesc', 'applicantNm', 'descText', 'createdTime'],
        optionsStatus: [],
        btnGroups: [
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        /** table **/
        tableType: '3',
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'customerCode', // 列的值
            label: '客户代码', // 列的显示字段
            columnsProps: {width: 150, align: 'left'}
          }, {
            prop: 'customerDesc',
            label: '客户名称',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          }, {
            prop: 'applicantNm',
            label: '申请人',
            columnsProps: {width: 100, align: 'left'}
          }, {
            prop: 'descText',
            label: '变更内容',
            columnsProps: {width: 120, align: 'left'}
          }, {
            prop: 'createdTime',
            label: '申请时间',
            columnsProps: {width: 300, align: 'left'}
          }, {
            prop: 'status',
            label: '记录状态',
            columnsProps: {width: 150, align: 'center', formatter: this.changeValue}
          }, {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 100, type: 'button'},
            cptProperties: [
              {
                label: '审批',
                value: 'modify',
                icon: 'edit',
                size: 'small',
                type: 'warning',
                eventClick: this.modify
              }
            ]
          }
        ],
        tableData: [],
        dataSource: [], // 当前页的数据
        /** 弹出层 **/
        updateDialogObj: {
          title: '变更信息审批',
          type: 'editUser',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              customerCode: '',
              customerDesc: '',
              createdTime: '',
              oldValue: '',
              newValue: '',
              status: '',
              handlerNm: '',
              handlerId: '',
              applicantNm: '',
              descText: '',
              radio2: '',
              opinion: '',
              haveAttach: '1',
              files: []
            }
          }
        },
        sessionFailedDialogObj: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** filter **/
        /** searchForm **/
        searchForm: {
          receiveTime: '',
          companyId: '',
          beginDate: '',
          endDate: '',
          status: ''
        },
        moreDialogobj: {
          title: '查询',
          type: 'query',
          dialogVisible: false,
          data: {
            form: {
              applicantNm: '',
              descText: ''
            }
          }
        },
        moreS: [
          {
            colunm: 'status',
            type: 'string'
          }
        ],
        changeValueDate: {
          status: {
            type: 'text',
            group: [
              {value: '0', label: '保存'},
              {value: '1', label: '已提交'},
              {value: '2', label: '审核通过'},
              {value: '3', label: '审核不通过'},
              {value: '4', label: '已更改'}
            ],
            key: 'value',
            value: 'label'
          }
        }
      }
    },
    methods: {
      init () {
        let param = {}
        param.personId = getUser().personId
        param.status = '1'
        param.haveAttach = '1'
        this.reqParams.url = BasePath.EXCHANGEINFO_SELECTLIST
        this.reqParams.params = param
        api.requestJava('POST', BasePath.EXCHANGEINFO_SELECTLIST, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      query () {
        let params = {}
        params.status = this.searchForm.status
//        params.whereClause = 'and createdTime between' + this.searchForm.beginDate + 'and ' +
//        params.uploadDateL = this.searchForm.beginDate
//        params.uploadDateR = this.searchForm.endDate
        params.personId = getUser().personId
        params.haveAttach = '1'
        console.log('====', params)
        this.queryUpper(params)
      }, // 查询方法
      queryUpper (params) {
        api.requestJava('POST', BasePath.EXCHANGEINFO_SELECTLIST, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      celldbClick (row, column, cell, event) {
        this.$set(row, 'editable', !row.editable)
      },
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      modify (index, row) {
        /* TODO 公司和部门替换为字典 */
        if (row.status === '1') {
          Object.assign(this.updateDialogObj.data.form, row)
          /* TODO 公司和部门替换为字典 */
          this.updateDialogObj.title = '变更信息审批'
          this.updateDialogObj.type = 'editUser'
          this.updateDialogObj.dialogVisible = true
        } else {
          console.log('====', row.status)
          this.updateDialogObj.title = '变更信息审批'
          this.updateDialogObj.type = 'updateUser'
          console.log('====', row.files)
          Object.assign(this.updateDialogObj.data.form, row)
          this.updateDialogObj.dialogVisible = true
        }
      }, // 修改d
      addOrUpdateBack (msg) {
        let data = msg.data.form
        let paraminfo = data
        api.requestJava('POST', BasePath.EXCHANGEINFO_UPDATE, paraminfo)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.clearObject()
              this.initDate()
              this.init()
              this.$message({type: 'success', message: '审核成功!', duration: 1000})
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      clearObject () {
        let temp = {
          title: '变更信息审批',
          type: 'editUser',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              customerCode: '',
              customerDesc: '',
              createdTime: '',
              oldValue: '',
              newValue: '',
              status: '',
              handlerNm: '',
              handlerId: '',
              applicantNm: '',
              descText: '',
              radio2: '',
              haveAttach: '1',
              files: []
            }
          }
        }
        Object.assign(this.updateDialogObj, temp)
      },
      save (index, row) {
        this.$confirm('确定不同意吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.saveStatus(index, row)
        }).catch(() => {
          this.$message({type: 'info', message: '已取消保存操作!'})
        })
      },
      saveUpper (index, row) {
        let param = {}
        param.handlerId = getUser().personId
        console.log(getUser().personId)
        param.handlerNm = getUser().userName
        console.log(getUser().userName)
        param.rowId = row.rowId
        console.log(row.rowId)
        param.opinion = row.opinion
        console.log(row.opinion)
        param.status = '2'
        api.requestJava('POST', BasePath.EXCHANGEINFO_UPDATE, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.init()
              this.$message({type: 'success', message: '修改成功!'})
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },
      saveStatus (index, row) {
        let param = {}
        param.handlerId = getUser().personId
        param.handlerNm = getUser().userName
        param.rowId = row.rowId
        param.opinion = row.opinion
        param.status = '3'
        api.requestJava('POST', BasePath.EXCHANGEINFO_UPDATE, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.init()
              this.$message({type: 'success', message: '修改成功!'})
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      initDate () {
        var myDate = new Date()
        this.searchForm.endDate = this.getTime(myDate.getTime())
        this.searchForm.beginDate = this.getTime(myDate.setDate(1))
        console.log('searchForm', this.searchForm)
        //  this.query()
      }, // 初始化时间并查询
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      select (selection, index) {
        if (selection[0] !== undefined) {
          this.sel_all = []
          this.sel_allRole = []
          for (var i in selection) {
            let param = {}
            param.rowId = selection[i].rowId
            this.sel_all.push(param)
          }
          console.log(this.sel_all)
        }
      }, // 选中某1条
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      isMoreClk () {
        this.moreDialogobj.dialogVisible = true
      },
      sessionFailedBack (msg) {
        let headers = msg.data.form
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.sessionFailedDialogObj.dialogVisible = false
            }
          })
          .catch((err) => { console.log(err) })
      }, // 会话失效
      sortChange (msg) {},
      rowClick (msg) {},
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      headerClick (column, event) {}
    },
    components: {
      _TABLE,
      _POPUP,
      _BTN_FILTER,
      MY_POPUP_CONFIG
    }
  }

</script>
<style scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label{
    margin: 0px!important;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }

  .filter_style .el-col-24 {
    height: 36px;
  }
  .el-form-item {
    margin-bottom: 12px;
  }
</style>
