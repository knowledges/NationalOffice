<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
      <div>
        <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="cat" label="受理类型" >
                  <el-select v-model="dialogObj.data.form.cat"  disabled filterable :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_cat"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="receiveTime" label="受理日期">
                  <el-input v-model="dialogObj.data.form.receiveTime"  :disabled="true"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="deptId" label="受理部门">
                  <el-select v-model="dialogObj.data.form.deptId" disabled :clearable="true" placeholder="请选择所属部门">
                    <template v-for="item in deptIdGroup">
                      <el-option  :key="item.rowId"  :label="item.unitName" :value="item.rowId"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item prop="licenseNo"  label="许可证号码">
                  <el-input v-model="dialogObj.data.form.licenseNo" :disabled="true" ></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="custmgrNm" label="所属客户经理">
                  <el-input v-model="dialogObj.data.form.custmgrNm"   :disabled="true" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item  prop="customerName" label="客户名称" >
                  <el-input v-model="dialogObj.data.form.customerName"   :disabled="true" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item  prop="tel" label="联系电话" >
                  <el-input v-model="dialogObj.data.form.tel" auto-complete="off" :disabled="true"  class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item  prop="addr" label="经营地址" >
                  <el-input v-model="dialogObj.data.form.addr"   :disabled="true" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='24'>
                <el-form-item  prop="contents" label="详细内容"  >
                  <el-input type="textarea"  resize="none"  :disabled="true" v-model="dialogObj.data.form.contents"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
        </el-form>
        <div slot="footer" class="dialog-footer" style="text-align: right">
          <el-button @click="cancleClk('addForm')">取 消</el-button>
        </div>
      </div>
    </el-dialog>
</template>
<script>
  import { getUser, getCodeList } from '@/config/info'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import axios from 'axios'
  export default {
    mounted () {
      getCodeList('YC_SEX', (data) => {
        this.options_cat = data
      })
    },
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        let params1 = {}
        params1.companyId = getUser().companyId
        params1.whereClause = ` and ORG_TYPE like '2%' `
        axios.all([
          api.requestJava('POST', BasePath.SELECT_DEPTIDGROUP, params1)
        ])
        .then(axios.spread((first) => {
          this.deptIdGroup = JSON.parse(JSON.stringify(first.data.data))
        }))
      }
    },
    props: ['dialogObj'],
    data () {
      return {
        options_cat: [],
        dialogVisible: false,
        formLabelWidth: '120px',
        filmode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤
        fileName: ['value'],
        filType: 0, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        keyup: false, // 输入筛选；true：之前展示；false：之后展示
        tableData: [],
        optionsManager: [],
        deptIdGroup: [],
        addrules: {},
        queryrules: {},
        isLoading: true
      }
    },
    methods: {
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      }
    },
    components: {}
  }
</script>
