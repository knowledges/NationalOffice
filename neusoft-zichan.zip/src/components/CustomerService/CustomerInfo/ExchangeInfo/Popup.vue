<template>
  <div>
    <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="closeModalEve" :size='dialogObj.size' v-popupdra-directive="{'show': dialogObj.dialogVisible}">
      <div v-if="dialogObj.type == 'editUser'">
        <el-form :model="dialogObj.data.form" :rules="addrules" ref="editForm" label-width="100px">
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="createdTime" label="申请日期">
                  <el-input v-model="dialogObj.data.form.createdTime" auto-complete="off" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item  prop="customerCode" label="客户代码" >
                  <el-input v-model="dialogObj.data.form.customerCode"  auto-complete="off" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="customerDesc" label="客户名称">
                  <el-input v-model="dialogObj.data.form.customerDesc" auto-complete="off" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item prop="descText" label="变更内容">
                  <el-input v-model="dialogObj.data.form.descText" auto-complete="off" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="oldValue" label="变更前">
                  <el-input v-model="dialogObj.data.form.oldValue" auto-complete="off" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item prop="newValue" label="变更后">
                  <el-input v-model="dialogObj.data.form.newValue" auto-complete="off" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='24'>
                <el-form-item prop="files" label="图片">
                  <div id="propertiesPic">
                    <uploadTemp style="margin:20px;" :files="dialogObj.data.form.files" ref="propertiesPic"></uploadTemp>
                  </div>
                <!--<template v-for="item in dialogObj.data.form.files">-->
                  <!--<img v-bind:src="gatherer+item.fileData" height="160" style="margin-left: 5px;"/>-->
                  <!--<uploadTemp style="margin:20px;" :files="dialogObj.data.form.files" ref="propertiesPic"></uploadTemp>-->
                <!--</template>-->
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='24'>
                <el-form-item label="审核意见">
                  <el-input type="textarea" v-model="dialogObj.data.form.opinion"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row style="text-align: right">
            <el-col :span='24'style="text-align: right">
              <el-col :span='24'style="text-align: right">
                <template>
                  <el-radio-group v-model="dialogObj.data.form.status">
                    <el-radio :label="2">同意</el-radio>
                    <el-radio :label="3">不同意</el-radio>
                  </el-radio-group>
                </template>
              </el-col>
            </el-col>
          </el-row>
        </el-form>
        <div slot="footer" class="dialog-footer" style="text-align: right">
          <el-button @click="resetForm('editForm')">取 消</el-button>
          <el-button type="success" @click="editSubmitForm('editForm')">审批</el-button>
        </div>
      </div>
      <div v-if="dialogObj.type == 'updateUser'">
        <el-form :model="dialogObj.data.form" :rules="addrules" ref="editForm" label-width="100px">
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="createdTime" label="申请日期">
                  <el-input v-model="dialogObj.data.form.createdTime" auto-complete="off" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item  prop="customerCode" label="客户代码" >
                  <el-input v-model="dialogObj.data.form.customerCode"  auto-complete="off" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="customerDesc" label="客户名称">
                  <el-input v-model="dialogObj.data.form.customerDesc" auto-complete="off" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item prop="descText" label="变更内容">
                  <el-input v-model="dialogObj.data.form.descText" auto-complete="off" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="oldValue" label="变更前">
                  <el-input v-model="dialogObj.data.form.oldValue" auto-complete="off" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item prop="newValue" label="变更后">
                  <el-input v-model="dialogObj.data.form.newValue" auto-complete="off" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='24'>
                <el-form-item prop="files" label="图片">
                  <template v-for="item in dialogObj.data.form.files">
                    <uploadTemp style="margin:20px;" :files="dialogObj.data.form.files" ref="propertiesPic"></uploadTemp>
                  </template>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='24'>
                <el-form-item label="审核意见">
                  <el-input type="textarea" v-model="dialogObj.data.form.opinion" auto-complete="off" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row style="text-align: right">
            <el-col :span='24' style="text-align: right">
              <el-col :span='24' style="text-align: right" >
                <template>
                  <el-radio-group v-model="radio2">
                    <el-radio :label="2">同意</el-radio>
                    <el-radio :label="3">不同意</el-radio>
                  </el-radio-group>
                </template>
              </el-col>
            </el-col>
          </el-row>
        </el-form>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
  import InputTemp from '@/components/Template/filter/InputTemp.vue'
  import DatePickerTemp from '@/components/Template/DatePicker/DatePickerTemp.vue'
  import config from '@/config'
  import {getUser} from '@/config/info'
  export default {
    mounted () {
      console.log(this.gatherer)
//      console.log('下标1：', Number(this.dialogObj.data.form.status))
//      console.log('我的radio2的值1：', this.radio2)
    },
    props: ['dialogObj'],
    updated () {
      this.radio2 = Number(this.dialogObj.data.form.status)
//      console.log('下标2：', Number(this.dialogObj.data.form.status))
//      console.log('我的radio2的值2：', this.radio2)
    },
    data () {
      return {
        radio2: '',
        gatherer: config.FILE_ADDR,
        dialogVisible: false,
        formLabelWidth: '120px',
        filmode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤
        fileName: ['value'],
        filType: 0, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        keyup: true, // 输入筛选；true：之前展示；false：之后展示
        tableData: [],
        optionsManager: [],
        deptIdGroup: [],
        addrules: {
//          tel: [
//            {validator: checkeTel, trigger: 'blur'}
//          ]
        }
      }
    },
    methods: {
      editSubmitForm (formName) {
        if (this.dialogObj.data.form.status !== '1') {
          this.dialogObj.data.form.handlerId = getUser().personId
          console.log(getUser().personId)
          this.dialogObj.data.form.handlerNm = getUser().userName
          console.log(getUser().userName)
          this.dialogObj.data.form.opinions
          this.dialogObj.data.form.stauts
          this.$refs[formName].validate((valid) => {
            if (valid) {
              // this.$refs.uploadTemp.submitUpload()
              this.dialogObj.dialogVisible = false
              this.$emit('confirmBack', this.dialogObj)
              setTimeout(() => {
                this.$refs[formName].resetFields()
              }, 1000)
            } else {
              console.log('error submit!!')
              return false
            }
          })
        }
      },
      closeModalEve () {
        this.$emit('confirmBack', false)
        this.dialogObj.dialogVisible = false
        this.valcomp = this.valdevp = ''
      },
      resetForm (formName) {
        if (this.dialogObj.type === 'editUser') {
          this.$emit('confirmBack', false)
          this.dialogObj.dialogVisible = false
          this.valcomp = this.valdevp = ''
        } else {
          this.$refs[formName].resetFields()
          this.$emit('confirmBack', false)
          this.dialogObj.dialogVisible = false
          this.valcomp = this.valdevp = ''
        }
      },
      startTime (val) {
        this.dialogObj.data.form.date = val
      }
    },
    components: {
      InputTemp,
      uploadTemp,
      DatePickerTemp
    }
  }
</script>
