<!--张文艺-->
<template>
  <div>
    <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :size='dialogObj.size'>
      <div v-if="dialogObj.type == 'addCustomerColl'">
        <el-form :model="dialogObj.data.form" :rules="addCustomerColl" label-width="100px" ref="addCustomerColl">
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="name" label="客户集名称" >
                  <el-input v-model="dialogObj.data.form.name" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <!--<el-col :span='12' >-->
                <!--<el-form-item prop="code" label="客户集代码">-->
                  <!--<el-input v-model="dialogObj.data.form.code" auto-complete="off" class="inputInline"></el-input>-->
                <!--</el-form-item>-->
              <!--</el-col>-->
            </el-col>
          </el-row>
          <!--<el-row>-->
            <!--<el-col :span='24'>-->
              <!--<el-col :span='12'>-->
                <!--<el-form-item  prop="shortCd" label="客户集简码" >-->
                  <!--<el-input v-model="dialogObj.data.form.shortCd" auto-complete="off" class="inputInline"></el-input>-->
                <!--</el-form-item>-->
              <!--</el-col>-->
              <!--<el-col :span='12' >-->
                <!--<el-form-item prop="shortNm" label="客户集简称">-->
                  <!--<el-input v-model="dialogObj.data.form.shortNm" auto-complete="off" class="inputInline"></el-input>-->
                <!--</el-form-item>-->
              <!--</el-col>-->
            <!--</el-col>-->
          <!--</el-row>-->
          <el-row v-if="place != 135">
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="notes" label="是否特殊" >
                  <el-checkbox v-model="dialogObj.data.form.notes" :disabled="custmgrDisable"></el-checkbox>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
        </el-form>
        <div slot="footer" class="dialog-footer" style="text-align: right">
          <el-button @click="resetForm('addCustomerColl')">取 消</el-button>
          <el-button type="success" @click="submitForm('addCustomerColl')">确 定</el-button>
        </div>
      </div>
      <div v-if="dialogObj.type == 'query'">
        <el-form :model="dialogObj.data.form" label-width="100px" ref="query">
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="tel" label="客户代码" >
                  <el-input v-model="dialogObj.data.form.customerCode" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="phone" label="客户名称">
                  <el-input v-model="dialogObj.data.form.vipGrade" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="tel" label="经营业态" >
                  <el-input v-model="dialogObj.data.form.businessType" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="phone" label="市场类型">
                  <el-input v-model="dialogObj.data.form.geoType" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="tel" label="销售规模" >
                  <el-input v-model="dialogObj.data.form" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="phone" label="客户级别">
                  <el-input v-model="dialogObj.data.form.vipGrade" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="tel" label="订货批次" >
                  <el-input v-model="dialogObj.data.form.orderRate" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
        </el-form>
        <div slot="footer" class="dialog-footer" style="text-align: right">
          <el-button @click="resetForm('query')">取 消</el-button>
          <el-button type="primary" @click="submitForm('query')">确 定</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import {getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      if (getUser().place === '135') {
        this.custmgrDisable = true
      }
    },
    data () {
      return {
        place: Number(getUser().place),
        optionsCompany: [],
        dialogVisible: false,
        size: '120px',
        custmgrDisable: false,
        addCustomerColl: {
          name: [{required: true, message: '请输入客户集名称', trigger: 'blur'}],
          companyId: [{required: true, message: '请选择公司', trigger: 'blur'}]
        }
      }
    },
    methods: {
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dialogObj.dialogVisible = false
            this.$emit('confirmBack', this.dialogObj)
            setTimeout(() => {
              this.$refs[formName].resetFields()
            }, 1000)
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
        this.$emit('confirmBack', false)
        this.dialogObj.dialogVisible = false
      },
      changeCheckBoxValuetBooleantoNum (src) {
        if (src.notes === true) { src.notes = 1 } else { src.notes = 0 } // 是否特殊
      }
    }
  }
</script>
