<template>
  <div>
  <el-input placeholder="请输入内容" v-model="input5":disabled="true">
    <template slot="prepend"><div id="clean" class="el-icon-close" @click="clean" style="cursor:pointer;"></div></template>
    <el-button slot="append" icon="menu" @click="expendClk"></el-button>
  </el-input>
    <div id="tree" v-if="expend">
      <_TREE :search=searchable :data='treeData' :node-click="showTree" :nodeKey="nodeKey"
             :showCheckBox=showCheckBox :expandAll=expandAll ref='tree' :highlight='true'
             :defaultCheckedKeys="defaultCheckedKeys" ></_TREE>
    </div>

</div>
</template>
<script>
  import _TREE from '@/components/Template/Tree/Tree.vue'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import log from '@/log'
  export default {
    props: {
      filterVal: {
        type: String,
        default: ''
      } // 外界传过来的值
    },
    data () {
      return {
        expend: false,
        input3: '',
        input4: '',
        input5: '',
        select: '',
        filterText: '',
        nodeKey: 'id',
        defaultCheckedKeys: [],
        expandAll: true,
        searchable: true, // 是否带搜索框
        showCheckBox: false, // 是否带复选框
        treeData: [],
        defaultProps: {
          children: 'children',
          label: 'label'
        }
      }
    },
    mounted () {
      this.init()
    },
    computed: {
      // 计算属性的 getter
    },
    components: {
      _TREE
    },
    methods: {
      init () {
        let params = {}
        api.requestJava('POST', BasePath.MODULE_SELECTTREELIST, params)
          .then((request) => {
            this.input5 = this.filterVal
            if (Number(request.data.code) === 200) {
              var tempArray = []
              tempArray.push(request.data.data)
              this.treeData = tempArray
            } else if (Number(request.data.code) === 401) {
              this.$notify.error({ title: '查询失败', message: request.data.message })
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
    .catch((err) => {
      this.$store.commit('TOGGLE_LOADING')
      let culprit = this.$route.name
      log.work(err, culprit)
    })
      },
      filterNode (value, data) {
        if (!value) return true
        return data.label.indexOf(value) !== -1
      },
      clean () {
        this.input5 = ''
      },
      expendClk () {
        this.expend = !this.expend
      },
      showTree (data) {
        this.input5 = data.label
        this.$emit('setParentId', data.id)
        this.expend = !this.expend
      },
      watch: {
        filterVal (val, oldval) {
          this.input5 = this.filterVal
        }
      }
    }
}
</script>

