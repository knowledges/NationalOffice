<!-- 徐晓菁 -->
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='12'>
          <div v-if="isSelect">
            <el-form ref="searchForm" :model="searchForm" label-width="120px">
              <el-col :gutter="24">
                <el-col :span='12'>
                  <el-form-item label="拜访方式" >
                    <el-select v-model="searchForm.visitMode"  :clearable="true" placeholder="请选择拜访方式">
                      <template v-for="item in visitTypeGroup">
                        <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                      </template>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='12'>
                  <div class="block">
                    <el-form-item label="查询周期">
                      <el-date-picker
                        v-model="datetime"
                        format="yyyy-MM-dd"
                        type="daterange"
                        :editable=false
                        :clearable=false
                        @change="datePickerChange"
                        placeholder="选择日期范围"
                        :picker-options="pickerOptions">
                      </el-date-picker>
                    </el-form-item>
                  </div>
                </el-col>
              </el-col>
            </el-form>
          </div>
        </el-col>
        <el-col :span="12">
            <_BTN_FILTER  :filterMethod="inputChange"  :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData" :isMore="isMore"/></_BTN_FILTER>
        </el-col>
      </el-col>
    </el-row>
     <div>
       <_TABLE
         ref="table"
         stripe
         maxHeight="500"
         :data="dataSource"
         @update:data="tabChange" :reqParams="reqParams"
         :columns="columnHeader"
         :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
         :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
         @selection-change="selectionChange"></_TABLE>
    </div>
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve"/>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import { changeListValueByCode, dateFormat } from '@/utils/common'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import MY_POPUP_CONFIG from './Popup.vue'
  import log from '@/log'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import {getCodeList, getUser} from '@/config/info'
  export default {
    mounted () {
      getCodeList('VISIT_MODE', (data) => {
        this.visitTypeGroup = data.splice(1, 2)
        this.changeValueDate.visitMode.group = this.visitTypeGroup
      }) // 拜访方式
      getCodeList('CUSTOMER_GRADE', (data) => {
        this.changeValueDate.customerGrade.group = data
      }) // 客户档级
      this.initDate()
    },
    data () {
      return {
        isSelect: true,
        isMore: true, // 查询更多条件
        datetime: [new Date().setDate(1), new Date()],
        pickerOptions: {
          shortcuts: [{
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '当前月',
            onClick (picker) {
              const end = new Date()
              const start = new Date(new Date().setDate(1))
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }]
        },
        rtlcatIdGroup: [], // 客户集id
        visitStatusGroup: [], // 拜访情况
        customerGradeGroup: [], // 客户档级
        routeIdGroup: [], // 送货线路id
        visitTypeGroup: [], // 拜访方式..
        operationScaleGroup: [], // 经营规模..
        geoTypeGroup: [], // 市场类型id..
        busnessTypeGroup: [], // 经营业态id..
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['customerCode', 'customerDesc', 'addr', 'legalPerson'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'customerDesc', // 列的值
            label: '客户名称', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'addr',
            label: '经营地址',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          },
          {
            prop: 'customerCode',
            label: '客户代码',
            columnsProps: {width: 140, align: 'center'}
          },
          {
            prop: 'legalPerson',
            label: '法人',
            columnsProps: {width: 100, align: 'left'}
          },
          {
            prop: 'customerGrade',
            label: '档次',
            columnsProps: {width: 70, align: 'center', formatter: this.changeValue}
          },
          {
            prop: 'startTime',
            label: '拜访时间',
            columnsProps: {width: 110, align: 'center', formatter: this.changeValue}
          },
          {
            prop: 'visitMode',
            label: '拜访方式',
            columnsProps: {width: 110, align: 'center', formatter: this.changeValue}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 120, type: 'button'},
            cptProperties: [
              {
                label: '服务项目',
                value: 'query',
                icon: 'search',
                size: 'small',
                type: 'primary',
                eventClick: this.modify
              }
            ]
          }
        ],
        changeValueDate: {
          customerGrade: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          visitMode: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          startTime: {
            type: 'date1'
          }
        },
        tableData: [],
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        /** searchForm **/
        searchForm: {
          custmgrId: '',
          visitMode: '',
          visitBegin: '',
          visitEnd: ''
        },
        edit: {
          title: '服务项目查看',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              companyId: '',
              flowId: '',
              visitor: '',
              visitorName: '',
              customerId: '',
              customerName: '',
              partyName: '',
              startTime: '',
              endTime: '',
              positionX: '',
              positionY: '',
              serialNo: '',
              summery: '',
              onSchedule: '',
              expectedTime: '',
              status: '',
              createdBy: '',
              createdTime: '',
              visitMode: '',
              steps: []
            }
          }
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        hasPagination: true,
        sel_all_row: []
      }
    },
    methods: {
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      isMoreClk () {
        this.isSelect = !this.isSelect
      },
      datePickerChange (item) {
        this.searchForm.visitBegin = this.getTime(Date.parse(this.datetime[0]))
        this.searchForm.visitEnd = this.getTime(Date.parse(this.datetime[1]))
        console.log('searchForm', this.searchForm)
      },
      query () {
        let params = {}
        params.custmgrId = this.searchForm.custmgrId
        if (this.searchForm.visitMode !== '') {
          params.visitMode = this.searchForm.visitMode
        }
        params.visitBegin = this.searchForm.visitBegin
        params.visitEnd = this.searchForm.visitEnd
        params.whereClause = `and status in('2','9','3')`
        console.log('params', JSON.stringify(params))
        this.queryUpper(params)
      }, // 查询方法
      queryUpper (params) {
        console.log('params', params)
        this.reqParams.url = BasePath.VISITQUERY_SELECT
        this.reqParams.params = params
        api.requestJava('POST', BasePath.VISITQUERY_SELECT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.dataSource = request.data.data
              this.tableData = request.data.data
              this.totalCount = Number(request.data.count)
//              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      initDate () {
        var myDate = new Date()
        this.searchForm.custmgrId = getUser().personId
        this.searchForm.visitEnd = this.getTime(myDate.getTime())
        this.searchForm.visitBegin = this.getTime(myDate.setDate(1))
        console.log('changeValueDate', this.changeValueDate)
        this.query()
      }, // 初始化时间并查询
      sortChange (msg) {},
      rowClick (msg) {},
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      dateFormatter (row, column) {
        var unixDate = row[column.property]
        return dateFormat(unixDate, 'YYYY-MM-DD HH:mm:ss')
      },  // 时间格式化
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      select (selection, index) {}, // 选中某1条
      selectAll (data) {}, // 全选
      modify (index, row) {
        this.findByIdUpper(row)
      }, // 修改// 修改
      findByIdUpper (row) {
        let param = {}
        param.visitingRecId = row.rowId
        param.haveAttach = '1'
        console.log('param', param)
        api.requestJava('POST', BasePath.VISITQUERY_STEPSSELECT, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              Object.assign(this.edit.data.form, row)
              this.edit.data.form.steps = request.data.data
              this.edit.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      editEve (msg) {
        if (msg === 'update') {
        }
        this.edit.dialogVisible = false
        let tmp = {
          title: '服务项目查看',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              companyId: '',
              flowId: '',
              visitor: '',
              visitorName: '',
              customerId: '',
              customerName: '',
              partyName: '',
              startTime: '',
              endTime: '',
              positionX: '',
              positionY: '',
              serialNo: '',
              summery: '',
              onSchedule: '',
              expectedTime: '',
              status: '',
              createdBy: '',
              createdTime: '',
              visitMode: '',
              steps: []
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      del (index, row) {},  // 删除
      batchDelClk () {},  // 批量删除
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.table.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      onendChange (val) {}, // 过滤器修改事件
      deleteUpper (val) {}, // 删除接口
      selectionChange (rows) {}
    },
    components: {
      _TABLE,
      _POPUP,
      MY_POPUP_CONFIG,
      _BTN_FILTER
    }
  }
</script>

<style scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-24 {
    height: 36px;
  }

</style>
