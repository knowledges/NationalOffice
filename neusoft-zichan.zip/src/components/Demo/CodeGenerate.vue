<style scoped>
</style>
<template>
  <div class="container-fluid">
    <_BTN_FILTER :isMore="isMore" :fileName="fileName"
                 @on-click="exportEve"
                 :btnGroups="btnGroups" :tableData="tableData"/>
    <div>
      <el-row class="el-row">
        <el-col :span="24">
          <_TABLE :columns="columnHeader" :tableData="dataSource" :tableHeight="400"
                  :sortChange="sortChange" :rowClick="rowClick" :btnMode=true :btns="btns"
                  :pageSizes="pageSizes" :currentPage=currentPage :pageSize=pageSize
                  :totalCount=totalCount :queryData=this.queryData
                  :checkBox=true :columnType=columnType
                  :tableType="tableType"
                  :select="select" :selectAll="selectAll"></_TABLE>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/TabPagin/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import api from '@/api'
  import log from '@/log'
  export default {
    mounted () {
//      this.queryData(this.currentPage, this.pageSize)
      this.init()
    },
    data () {
      return {
        /** table **/
        columnType: 'selection',
        tableType: '4',
        currentPage: 1, // 默认当前第一页
        pageSize: 10,  // 默认每页20条数据
        pageSizes: [2, 5, 10, 20, 40, 50], // 分页数选择项
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            value: 'userCode', // 列的值
            label: '登录账号', // 列的显示字段
            align: 'left' // 列的对齐方式，[left, center, right]，选填，默认是left
          }, {
            value: 'userName',
            align: 'left',
            label: '姓名'
          }, {
            value: 'personId',
            label: '工号',
            align: 'left'
          }, {
            value: 'email',
            label: 'email',
            align: 'left'
          }, {
            value: 'company',
            label: '公司',
            align: 'left'
          }
        ], // 表格头部列
        tableData: [], // 真个表格的数据
        btns: {
          btnArr: [
            {
              label: '修改', // 按钮的名称
              value: 'modify', // 按钮的值
              functionName: this.modify, // 按钮的方法
              type: 'warning',
              icon: 'edit'
            },
            {
              label: '删除',
              value: 'del',
              functionName: this.del,
              type: 'danger',
              icon: 'delete'
            }
          ],
          value: 'operation',
          label: '操作',
          width: 180
        }, // 操作按钮
        dataSource: [], // 当前页的数据
        /** filter **/
        isMore: true, // 更多操作按钮
        fileName: ['userName', 'userCode', 'peresonId', 'email'], // 需要过滤的数组在 columnHeader 中查找
        btnGroups: [
          {
            name: '新增',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.addClk
          },
          {
            name: '批量删除',
            className: 'btn-danger',
            iconName: 'fa-remove',
            event: this.batchDelClk
          }
        ], //  按钮组
        /** 实际操作 **/
        sel_all: []
      }
    },
    methods: {
      init () {
        api.requestJava('POST', 'user/selectList.do', {})
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 请求 table 数据
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      select (selection, index) {
        /* TODO 已经存在就不用再添加了 */
        if (selection[0] !== undefined) {
          this.sel_all = []
          for (var i in selection) {
            this.sel_all.push(selection[i].id)
          }
        }
      }, // 选中某1条
      selectAll (data) {
        /* TODO 已经存在就不用再添加了 */
        this.sel_all = []
        for (var i in data) {
          this.sel_all.push(data[i].id)
        }
      }, // 全选
      addClk () {
        this.$message('这是新增')
      }, // 新增
      batchDelClk () {
        this.$message('批量删除')
      },  // 批量删除
      exportEve () {
        this.$message('开始调用 导出exlc')
      }, // 导出按钮点击事件
      isMoreClk () {
        this.$message('更多条件')
      }, // 更多按钮点击事件
      onendChange (val) {
        var tmp = JSON.parse(val)
        if (Object.prototype.toString.call(tmp) === '[object Array]') {
          this.dataSource = tmp
        } else {
          this.dataSource = []
          this.dataSource.push(tmp)
        }
      }, // 接受过滤器改变后返回数组|对象
      modify (index, row) {
        this.$message('调用了修改')
      }, // 修改
      del (index, row) {
        this.$message('确定删除此条信息吗')
      },  // 删除
      sortChange (msg) {},
      rowClick (msg) {}
    },
    components: {
      _TABLE,
      _BTN_FILTER
    }
  }
</script>
