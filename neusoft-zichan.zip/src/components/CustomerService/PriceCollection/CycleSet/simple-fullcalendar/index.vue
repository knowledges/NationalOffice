<template>
  <div class="sfc-wrapper">
    <table class="sfc-table sfc-table-head">
      <caption class="clearfix">
        <div class="sfc-div sfc-plan" style="position: relative;width: 40%">
          <el-button  type="success"  @click="save()" ><i  class="fa fa-plus"></i>&nbsp;&nbsp;保存</el-button>
        </div>
        <div class="sfc-div sfc-flx"  style="width: 60%">
          <div class="form-group" style="width: 100%">
            <div class="input-group clearflx" style="width: 100%">
              <div>
                <button class="btn btn-link sfc-div" @click="changeMonth('prev')">
                  <i class="el-icon-caret-left"></i>
                </button>
              </div>
              <div class="text-center sfc-div" style="width: 20%">
                <div class="text-center sfc-div" style="width: 20%">
                  <el-date-picker
                    v-model="monthText"
                    type="month"
                    :editable=false
                    :clearable=false
                    style="opacity: 0;position: absolute;center: 0;z-index: 9; cursor: pointer;width: 16%"
                    @change="monthChange"
                    placeholder="选择月份"
                    :picker-options="pickerOptions">
                  </el-date-picker>
                </div>
                <!--<h1>{{ monthText }}</h1>-->
                <input type="text" class="form-control" v-model="monthText">
              </div>
              <div>
                <button class="btn btn-link sfc-div" @click="changeMonth('next')">
                  <i class="el-icon-caret-right"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
        <div class="sfc-div sfc-plan">
        </div>
      </caption>
      <thead>
        <tr>
          <td v-for="weekday in weekdays"  @click="tdSelect(weekday)" style="cursor:pointer;">{{ weekday }}</td>
        </tr>
      </thead>
    </table>
    <template v-for="week in weekArr">
      <weekline :month-moment="monthMoment" :week="week" :events="events" :highlight-time-range="selectedTimeRangeResult" @select="onSelect"></weekline>
    </template>
  </div>
</template>

<script>
import weekline from './components/weekline'
import moment from 'moment'
import { getDurationsDays, getTime } from './util.js'
export default {
  components: {
    weekline
  },
  props: {
    formatter: {
      type: String,
      default: 'YYYY-MM-DD'
    },
    events: {
      type: Array,
      default: []
    }
  },
  data () {
    return {
      pickerOptions: {
        shortcuts: [{
          text: '当前月',
          onClick (picker) {
            var myDate = new Date()
            var year = myDate.getFullYear()
            var month = myDate.getMonth() + 1
            picker.$emit('pick', year + '-' + month)
          }
        }]
      },
      monthMoment: null,
      weekdays: ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日'],
      weekArr: [],
      monthText: '',
      selectedTimeRange: {
        start: null,
        between: null,
        end: null
      }
    }
  },
  computed: {
    tidyEvents () {
      let events = this.events.map((eventItem, index) => {
        let s = moment(eventItem.start, this.formatter)
        let e = moment(eventItem.end, this.formatter)
        return Object.assign({}, eventItem, {
          startMoment: s,
          endMoment: e,
          startDate: s.date(),
          startWeekday: s.isoWeekday(),
          durationDays: getDurationsDays(s.format('YYYY-MM-DD'), e.format('YYYY-MM-DD')),
          startTime: getTime(s.format('YYYY-MM-DD'))
        })
      })
      events.sort(function (a, b) {
        return a.startTime - b.startTime
      })
      return events
    },
    selectedTimeRangeResult () {
      let timeRange = this.selectedTimeRange
      let start = timeRange.start
      let end = timeRange.end || timeRange.between
      if (start && end) {
        return start > end ? [end, start] : [start, end]
      } else return []
    }
  },
  beforeMount () {
    this.monthMoment = moment()
    this.setMonthInfo()
  },
  methods: {
    monthChange (val) {
      this.monthMoment = moment()
      let str = new Date(val)
      this.monthMoment._d = str
      this.setMonthInfo()
    },
    backClk () {
      this.changeMonth('reset')
    },
    getMonthInfo () {
      // if (!month) return []
      let monthMoment = this.monthMoment
      let dayCount = monthMoment.clone().endOf('month').date()
      var dayArr = []
      for (let i = 0; i < dayCount; i++) {
        let date = i + 1
        let dayMoment = monthMoment.clone().date(date)
        let weekday = dayMoment.isoWeekday()
        dayArr.push({
          month: dayMoment.month(),
          date,
          weekday,
          moment: dayMoment
        })
      }
      // fill date to complete weeks
      let d = dayArr[0].weekday
      while (--d) {
        let dayMoment = monthMoment.clone().startOf('month').isoWeekday(d)
        dayArr.unshift({
          month: dayMoment.month(),
          date: dayMoment.date(),
          weekday: d,
          moment: dayMoment
        })
      }

      d = dayArr[dayArr.length - 1].weekday
      while (++d <= 7) {
        let dayMoment = monthMoment.clone().endOf('month').isoWeekday(d)
        dayArr.push({
          month: dayMoment.month(),
          date: dayMoment.date(),
          weekday: d,
          moment: dayMoment
        })
      }

      // splice into weeks
      let weekArr = []
      while (dayArr.length >= 7) {
        weekArr.push(dayArr.splice(0, 7))
      }

      return weekArr
    },
    changeMonth (direction) {
      switch (direction) {
        case 'prev':
          this.monthMoment.add(-1, 'month')
          break
        case 'next':
          this.monthMoment.add(1, 'month')
          break
        case 'reset':
          this.monthMoment = moment()
          break
        default:
      }
      this.weekArr = this.getMonthInfo()
      this.monthText = this.monthMoment.format('YYYY-MM')
    },
    save () {
      this.$emit('confirmBack', 'update')
    },
    setMonthInfo () {
      this.weekArr = this.getMonthInfo()
      this.monthText = this.monthMoment.format('YYYY-MM')
      this.$emit('confirmBack', this.monthText)
    },
    tdSelect (weekday) {
      let wday = ''
      switch (weekday) {
        case '星期日':
          wday = 0
          break
        case '星期一':
          wday = 1
          break
        case '星期二':
          wday = 2
          break
        case '星期三':
          wday = 3
          break
        case '星期四':
          wday = 4
          break
        case '星期五':
          wday = 5
          break
        case '星期六':
          wday = 6
          break
        default:
      }
      let timeRange = this.selectedTimeRange
      timeRange.start = wday
      timeRange.between = null
      timeRange.end = 2
      this.selectedTimeRange = timeRange
      this.addEvent()
    },
    onSelect (point, e) {
      let el = e.target
      let timeRange = this.selectedTimeRange
      timeRange.start = el.getAttribute('data-date')
      timeRange.between = null
      timeRange.end = 1
      this.selectedTimeRange = timeRange
      this.addEvent()
    },
    addEvent () {
      let start = this.selectedTimeRange.start
      let end = this.selectedTimeRange.end
      this.$emit('timeRangeSelected', {
        start,
        end
      })
      this.selectedTimeRange.start = null
      this.selectedTimeRange.between = null
      this.selectedTimeRange.end = null
    }
  }
}
</script>

<style scoped rel="stylesheet/scss" lang="scss">
  .input-group .form-control {
    text-align: center;
    position: relative;
    z-index: 2;
    font-size: 23px;
    width: 100%;
    margin-bottom: 0;
    border-color: rgba(210, 214, 222, 0.03);
  }
  .el-date-editor.el-input {
    width: 100%;
  }
  .el-input__inner {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background-color: #fff;
    background-image: none;
    /* border-radius: 4px; */
    border: 1px solid #bfcbd9;
    box-sizing: border-box;
    color: #1f2d3d;
    font-size: inherit;
    height: 36px;
    line-height: 1;
    cursor:pointer;
    outline: 0;
    padding: 3px 10px;
    transition: border-color .2s cubic-bezier(.645,.045,.355,1);
  }
  .sfc-wrapper{
    /*max-width: 1305px;*/
    width: 100%;
    margin: auto;
    .sfc-table-wrapper {
      position: relative;
      margin-top: -1px;
      .sfc-events-table {
        position: absolute;
        top: 0;
        left: 0;
        pointer-events: none;
      }
    }
    .sfc-table-head{
      width: 100%;
      text-align: center;
      td {
        border: 1px solid #CCC;
        background-color: #FFF;
        height: 40px;
        color: #000;
      }
    }
  }
  .form-group {
    margin: auto;
    width: 30%;
    align-content: center;
  }
  .sfc-div {
    float: left;
  }
  .sfc-flx{
    width: calc(100% - 240px);
  }
  .sfc-plan {
    width: 120px;
  }
</style>
