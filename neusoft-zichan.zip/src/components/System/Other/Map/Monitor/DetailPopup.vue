<template>
  <div>
    <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :modal-append-to-body="false" :close-on-click-modal="false" :close-on-press-escape="false"  :size='dialogObj.size' :before-close="closeModalEve">
      <el-tabs type="border-card">
        <el-tab-pane>
          <span slot="label"><i class="el-icon-date"></i> 基本档案</span>
          <_CustomerDetail :custId="dialogObj.customerId"></_CustomerDetail>
        </el-tab-pane>
        <el-tab-pane>
          <span slot="label"><i class="el-icon-date"></i> 货源信息</span>
          <_GoodResourceList :custId="dialogObj.customerId"></_GoodResourceList>
        </el-tab-pane>
        <el-tab-pane>
          <span slot="label"><i class="el-icon-date"></i> 反馈信息</span>
          <_ComplaintList :custId="dialogObj.customerId"></_ComplaintList>
        </el-tab-pane>
        <el-tab-pane v-if=isShow>
          <span slot="label"><i class="el-icon-date"></i> 历史订单</span>
          <_CustOrderList :custId="dialogObj.customerId" @confirmBack="ddEve"></_CustOrderList>
        </el-tab-pane>
        <el-tab-pane>
          <span slot="label"><i class="el-icon-date"></i> 当日订单</span>
          <_DayOrderList :custId="dialogObj.customerId"></_DayOrderList>
        </el-tab-pane>
        <el-tab-pane v-if=isShow>
          <span slot="label"><i class="el-icon-date"></i> 经营分析</span>
          <_BusinessAnalysis :custId="dialogObj.customerId"></_BusinessAnalysis>
        </el-tab-pane>
        <el-tab-pane v-if=isShow>
          <span slot="label"><i class="el-icon-date"></i> 客户分析报告</span>
          <_CustSalesAnalysis :custId="dialogObj.customerId"></_CustSalesAnalysis>
        </el-tab-pane>
        <el-tab-pane>
          <span slot="label"><i class="el-icon-date"></i> 历史拜访</span>
          <_VisitHistory :custId="dialogObj.customerId" @confirmBack="bfEve"></_VisitHistory>
        </el-tab-pane>
        <el-tab-pane>
          <span slot="label"><i class="el-icon-date"></i> 服务项目</span>
          <_ServiceItem :custId="dialogObj.customerId"></_ServiceItem>
        </el-tab-pane>
      </el-tabs>
    </el-dialog>
    <MY_POPUP_SALES :dialogObj='sales' @confirmBack="salesEve"/>
    <MY_POPUP_VISIT :dialogObj='visit' @confirmBack="visitEve"/>
  </div>
</template>
<script>
  import _CustomerDetail from '@/components/CustomerService/CustomerInfo/Customer/CustomerDetail.vue'
  import _VisitHistory from '@/components/CustomerService/CustomerSetting/VisitPlan/VisitHistory.vue'
  import _CustOrderList from './CustOrderList.vue'
  import _GoodResourceList from './goodResourceList.vue'
  import _BusinessAnalysis from './businessAnalysis.vue'
  import _DayOrderList from './dayOrderList.vue'
  import _ComplaintList from './complaintList.vue'
  import MY_POPUP_SALES from './salesPopup.vue'
  import MY_POPUP_VISIT from '@/components/CustomerService/CustomerSetting/VisitQuery/Popup.vue'
  import _CustSalesAnalysis from './CustSalesAnalysisEdit.vue'
  import _ServiceItem from './ServiceItemsPopup.vue'
  import log from '@/log'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import { getUser } from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
//      alert(1)
//      console.log('进入弹出框，获得数据', this.dialogObj)
//      alert(1)
      if (Number(getUser().unitLevel) === 1) {
        this.isShow = false
      }
    },
    updated () {
      console.log('进入弹出框，获得数据', this.dialogObj)
      if (Number(getUser().unitLevel) === 1) {
        this.isShow = false
      }
    },
    data () {
      return {
        isShow: true,
        value: '',
        form: {
          customerId: ''
        },
        sales: {
          title: '订单商品明细',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              custId: '',
              custName: '',
              itemId: '',
              itemName: '',
              qtyNeed: '',
              qtyOrd: '',
              price: '',
              amt: ''
            }
          }
        },
        visit: {
          title: '服务项目查看',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              companyId: '',
              flowId: '',
              visitor: '',
              visitorName: '',
              customerId: '',
              customerName: '',
              partyName: '',
              startTime: '',
              endTime: '',
              positionX: '',
              positionY: '',
              serialNo: '',
              summery: '',
              onSchedule: '',
              expectedTime: '',
              status: '',
              createdBy: '',
              createdTime: '',
              visitMode: '',
              steps: []
            }
          }
        }
      }
    },
    methods: {
      salesEve (msg) {
        this.sales.dialogVisible = false
        let tmp = {
          title: '订单商品明细',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              custId: '',
              custName: '',
              itemId: '',
              itemName: '',
              qtyNeed: '',
              qtyOrd: '',
              price: '',
              amt: ''
            }
          }
        }
        Object.assign(this.sales, tmp)
      }, // 修改事件
      visitEve (msg) {
        this.visit.dialogVisible = false
        let tmp = {
          title: '服务项目查看',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              companyId: '',
              flowId: '',
              visitor: '',
              visitorName: '',
              customerId: '',
              customerName: '',
              partyName: '',
              startTime: '',
              endTime: '',
              positionX: '',
              positionY: '',
              serialNo: '',
              summery: '',
              onSchedule: '',
              expectedTime: '',
              status: '',
              createdBy: '',
              createdTime: '',
              visitMode: '',
              steps: []
            }
          }
        }
        Object.assign(this.visit, tmp)
      },
      bfEve (msg) {
        let param = {}
        param.visitingRecId = msg
        param.haveAttach = '1'
        api.requestJava('POST', BasePath.VISITQUERY_STEPSSELECT, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              Object.assign(this.visit.data.form, request.data.data)
              this.visit.data.form.steps = request.data.data
              this.visit.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      ddEve (msg) {
        let param = JSON.parse(msg)
        console.log('订单明细', param)
        api.requestJava('POST', BasePath.ORDER_HISTORY_DETAIL, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              let data = request.data.data
              let list = []
              for (var i = 0; i < data.length; i++) {
                let row = {}
                var price = data[i].price / 1
                price = price.toFixed(2)
                var orderQty = data[i].orderQty / 1
                orderQty = orderQty.toFixed(2)
                var orderAmt = data[i].orderAmt / 1
                orderAmt = orderAmt.toFixed(2)
                row.cigProductNm = data[i].cigProductNm
                row.orderQty = orderQty
                row.price = price
                row.orderAmt = orderAmt
                list.push(row)
              }
              this.sales.data.form.products = list
              this.sales.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      init () {
//        console.log('进入弹出框，获得数据', this.dialogObj)
      },
      closeModalEve () {
        this.dialogObj.dialogVisible = false
      }
    },
    components: {
      _CustomerDetail,
      _VisitHistory,
      _CustOrderList,
      _ComplaintList,
      MY_POPUP_SALES,
      MY_POPUP_VISIT,
      _BusinessAnalysis,
      _GoodResourceList,
      _DayOrderList,
      _ServiceItem,
      _CustSalesAnalysis
    }
  }
</script>

<style scoped>
  .item__label_popup {
    text-align: right;
    vertical-align: middle;
    float: right;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 8px 11px 0;
    box-sizing: border-box;
    /* display: inline-block; */
  }
  .el-input, .el-input__inner {
    /*width: '';*/
    display: inline-block;
  }
  .container-fluid_new {
    background: #FFF;
  }
</style>
