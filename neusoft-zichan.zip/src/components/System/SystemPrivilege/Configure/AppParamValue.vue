<!-- 徐晓菁 -->
<style scoped>
</style>
<template>
  <div class="container-fluid">
    <_BTN_FILTER  @on-change="inputChange" :btnGroups="btnGroups" :fileName="fileName" :tableData="tableData"  @on-click="exportEve"> </_BTN_FILTER>
    <div>
      <_TABLE
        ref="table"
        stripe
        maxHeight="500"
        column-type="selection"
        :data="dataSource"
        :columns="columnHeader"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
        @selection-change="selectionChange"></_TABLE>
    </div>
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve"  v-popupdra-directive="{'show': edit.dialogVisible}"/>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import MY_POPUP_CONFIG from './Popup/Popup.vue'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import log from '@/log'
  import { getUser } from '@/config/info'
  import { changeListValueByCode } from '@/utils/common'
  export default {
    mounted () {
      this.queryUpper()
    },
    data () {
      return {
        /** 过滤的字段 **/
        fileName: ['paramCode', 'paramName', 'paramDesc', 'valueCode'],
        /** 定义按钮 **/
        btnGroups: [],
        hasPagination: true,
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 10,  // 默认每页20条数据
        pageSizes: [2, 5, 10, 20, 40, 50], // 分页数选择项
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'paramCode', // 列的值
            label: '参数编码', // 列的显示字段
            columnsProps: {width: 150, align: 'left'}
          },
          {
            prop: 'paramName',
            className: 'header', // 列的css样式（选填）
            label: '参数名称',
            columnsProps: {width: 200, align: 'left'}
          },
          {
            prop: 'valueCode',
            label: '参数值',
            columnsProps: {width: 150, align: 'left'}
          },
          {
            prop: 'lastUpdTime',
            label: '最近更改时间',
            columnsProps: {width: 150, align: 'center', formatter: this.changeValue}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 200, type: 'button'},
            cptProperties: [
              {
                label: '修改',
                value: 'modify',
                icon: 'edit',
                size: 'small',
                type: 'warning',
                eventClick: this.modify
              },
              {
                label: '删除',
                value: 'del',
                icon: 'delete',
                size: 'small',
                type: 'danger',
                eventClick: this.del
              }
            ]
          }
        ],
        tableData: [
          {
            rowId: 'BS20170001',
            paramCode: 'ftp_address',
            paramName: 'ftp地址',
            paramDesc: '连云港存储图片ftp地址',
            valueCode: 'ftp://10.42.64.115',
            lastUpdTime: '2017-10-11 11:11:11',
            appId: '',
            paramGrpCode: '',
            paramGrpName: '',
            paramDataType: '',
            valueName: '',
            srcFlag: '',
            lovCode: '',
            modifyFlag: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: ''
          },
          {
            rowId: 'BS20170001',
            paramCode: 'ftp_user',
            paramName: 'ftp地址用户名',
            paramDesc: '连云港存储图片ftp地址用户名',
            valueCode: 'rms',
            lastUpdTime: '2017-10-11 11:11:11',
            appId: '',
            paramGrpCode: '',
            paramGrpName: '',
            paramDataType: '',
            valueName: '',
            srcFlag: '',
            lovCode: '',
            modifyFlag: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: ''
          },
          {
            rowId: 'BS20170001',
            paramCode: 'ftp_password',
            paramName: 'ftp地址密码',
            paramDesc: '连云港存储图片ftp地址密码',
            valueCode: 'rms',
            lastUpdTime: '2017-10-11 11:11:11',
            appId: '',
            paramGrpCode: '',
            paramGrpName: '',
            paramDataType: '',
            valueName: '',
            srcFlag: '',
            lovCode: '',
            modifyFlag: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: ''
          },
          {
            rowId: 'BS20170001',
            paramCode: 'ftp_port',
            paramName: 'ftp地址端口',
            paramDesc: '连云港存储图片ftp地址端口',
            valueCode: '21',
            lastUpdTime: '2017-10-11 11:11:11',
            appId: '',
            paramGrpCode: '',
            paramGrpName: '',
            paramDataType: '',
            valueName: '',
            srcFlag: '',
            lovCode: '',
            modifyFlag: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: ''
          },
          {
            rowId: 'BS20170001',
            paramCode: 'ftp_phote_address',
            paramName: 'ftp图片保存地址',
            paramDesc: 'ftp图片保存地址',
            valueCode: '/ws/download/photo/',
            lastUpdTime: '2017-10-11 11:11:11',
            appId: '',
            paramGrpCode: '',
            paramGrpName: '',
            paramDataType: '',
            valueName: '',
            srcFlag: '',
            lovCode: '',
            modifyFlag: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: ''
          }
        ],
        tableType: '3',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        /** 弹出层 **/
        edit: {
          title: '参数编辑',
          type: '2',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              paramId: '',
              entityId: '',
              appId: '',
              paramCode: '',
              paramName: '',
              valueCode: '',
              valueName: '',
              lastUpdTime: '',
              originFlag: '',
              originApp: ''
            }
          }
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        changeValueDate: {
          modifyFlag: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          lastUpdTime: {
            type: 'date'
          }
        }
      }
    },
    methods: {
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = this.currentPage
        let size = this.pageSize
        this.dataSource = JSON.parse(val).filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.table.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      select (selection, index) { }, // 选中某1条
      selectAll (data) { }, // 全选
      addClk () {
        this.edit.dialogVisible = true
      }, // 新增
      modify (index, row) {
        Object.assign(this.edit.data.form, row)
        this.edit.dialogVisible = true
      }, // 修改
      del (index, row) {
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.deleteUpper(row.rowId)
        }).catch(() => {
          this.$message({type: 'info', message: '已取消删除!'})
        })
      },  // 删除
      onendChange (val) {}, // 过滤器修改事件
      deleteUpper (val) {
        let params = {}
        params.rowId = val
        api.requestJava('POST', BasePath.APPPARAMVALUE_DELETE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              this.queryUpper()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 删除接口
      queryUpper () {
        let param = {}
        param.entityId = getUser().companyId
        param.modifyFlag = 3
        api.requestJava('POST', BasePath.APPPARAMVALUE_SELECT, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      editEve (msg) {
        if (msg === 'update') {
          this.saveUpper()
        }
        this.edit.dialogVisible = false
        let tmp = {
          title: '参数编辑',
          type: '2',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              paramId: '',
              entityId: '',
              appId: '',
              paramCode: '',
              paramName: '',
              valueCode: '',
              valueName: '',
              lastUpdTime: '',
              originFlag: '',
              originApp: ''
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      saveUpper () {
        let params = this.edit.data.form
        var url = BasePath.APPPARAMVALUE_UPDATE
        if (this.edit.data.form.rowId === '') {
          url = BasePath.APPPARAMVALUE_INSERT
        }
        api.requestJava('POST', url, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              this.queryUpper()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 保存
      sortChange (msg) {},
      rowClick (msg) {},
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      selectionChange (rows) {}
    },
    components: {
      _TABLE,
      _POPUP,
      _BTN_FILTER,
      MY_POPUP_CONFIG

    }
  }
</script>
