<!--  Auther:luoshuo -->
<!--  单选题分析 -->
<template>
  <div>
    <div class="radioTitle">
      <div>{{idx + 1}}、{{question.itemTitle}}[单选题]</div>
    </div>
    <div>
      <table id="radio" class="radioTableStyle">
        <tbody>
          <tr v-for="item in question.detailList" :key="item.id" class="radioTrOptions">
            <td width="2%" height="30px">&nbsp;</td>
            <td width="48%">{{item.val}}</td>
            <td width="40%"><el-progress :stroke-width="strokeWidth" text-inside :percentage="item.percent"></el-progress></td>
            <td width="20%">&nbsp;&nbsp;{{item.selected}}次</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div>
      <el-tabs v-model="radioModel" type="card" @tab-click="handleClick">
        <el-tab-pane label="柱状图" name="histogram">
           <ve-histogram :data="radioChartData" :settings="radioChartSettings" :labelMap="labelMap" width="100%"></ve-histogram>
        </el-tab-pane>
        <el-tab-pane label="饼图" name="pie">
          <ve-pie :data="radioChartData" :settings="radioChartSettings" width="700px" class="radioMargin"></ve-pie>
        </el-tab-pane>
        <el-tab-pane label="条形图" name="bar">
          <ve-bar :data="radioChartData" :settings="radioChartSettings" width="700px" class="radioMargin"></ve-bar>
        </el-tab-pane>
        <el-tab-pane label="折线图" name="line">
          <ve-line :data="radioChartData" :settings="radioChartSettings" width="700px" class="radioMargin"></ve-line>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      strokeWidth: 18,
      radioModel: 'histogram',
      labelMap: '次数',
      radioChartData: {
        columns: ['val', 'selected', 'percent'],
        rows: [
        ]
      },
      radioChartSettings: {
        metrics: ['selected'],
        dimension: ['val'],
        labelMap: {
          'selected': '总数'
        }
      }
    }
  },
  methods: {
    handleClick (tab, event) {
//      this.radioModel = tab.name
//      this.$set(this.radioChartSettings, 'type', tab.name)
//      if (tab.name !== 'pie') {
//        this.$set(this.radioChartSettings, 'metrics', ['radioCount'])
//        this.$set(this.radioChartSettings, 'dimension', ['value'])
//      } else {
//        this.$set(this.radioChartSettings, 'metrics', 'radioCount')
//        this.$set(this.radioChartSettings, 'dimension', 'value')
//      }
    }
  },
  props: {
    question: {
      type: Object,
      required: true
    },
    idx: Number
  },
  mounted () {
    this.$nextTick(() => {
      this.radioChartData.rows = this.question.detailList
    })
  }
}
</script>
<style>
.radioTitle {
  color: #625F5F;
  font-size: x-large;
  display: inline-block;
}
.radioTableStyle {
  border: 1px solid #c5b6b6;
  width: 100%;
  margin: 5px;
}
.radioTrOptions {
  color: rgb(155, 150, 150);
  font: '14px/20px "Microsoft Yahei","微软雅黑","SimSun","宋体","Arial Narrow",HELVETICA';
  font-size: large;
}
.radioMargin {
  margin: 0 auto;
}
</style>
