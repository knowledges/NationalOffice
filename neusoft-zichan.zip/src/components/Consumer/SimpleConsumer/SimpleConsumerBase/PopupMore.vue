<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false">
    <el-form :model="dialogObj.data.form" label-width="80px" ref="query">
      <el-row>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="degree" label="学历" >
              <el-select v-model="dialogObj.data.form.degree" multiple :clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_degree"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8' >
            <el-form-item prop="work" label="职业" >
              <el-select v-model="dialogObj.data.form.work"  multiple :clearable="true" placeholder="请选择"  :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_work"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8' >
            <el-form-item prop="avgComsumption" label="卷烟月均消费（元）" >
              <el-select v-model="dialogObj.data.form.avgComsumption" multiple :clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_avgComsumption"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
      <el-row>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="regularPrice" label="常抽卷烟价位（元/包）" >
              <el-select v-model="dialogObj.data.form.regularPrice" multiple :clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_regularPrice"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8' >
            <el-form-item prop="quant" label="每天的吸烟量（包）" >
              <el-select v-model="dialogObj.data.form.quant" multiple :clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_quant"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8' >
            <el-form-item prop="trend" label="趋势" >
              <el-select v-model="dialogObj.data.form.trend" multiple :clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_trend"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
      <el-row>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="lastNewCig" label="最近尝试的新品卷烟" >
              <el-select v-model="dialogObj.data.form.lastNewCig" filterable multiple :clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_spGroup"
                  :key="item.rowId"
                  :label="item.goodsDesc"
                  :value="item.rowId">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="likebestNewCig" label="最喜欢哪种类型的新品" >
              <el-select v-model="dialogObj.data.form.likebestNewCig" filterable multiple :clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_likebestNewCig"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="recentlySpecCig" label="最近尝试的异型卷烟" >
              <el-select v-model="dialogObj.data.form.recentlySpecCig" filterable multiple :clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_recentlySpecCig"
                  :key="item.rowId"
                  :label="item.goodsDesc"
                  :value="item.rowId">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :gutter="24">
            <el-col :span='8'>
              <el-form-item prop="likebestSpecPack" label="最喜欢的异型包装" >
                <el-select v-model="dialogObj.data.form.likebestSpecPack" filterable multiple :clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                  <el-option
                    v-for="item in options_likebestSpecPack"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>

          </el-col>
        </el-col>
      </el-row>
      <el-row>
        <el-col :gutter="24">
          <el-col :span='24'>
            <el-form-item style="float: right">
              <el-button @click="resetForm('addForm')">取 消</el-button>
              <el-button type="success" @click="submitForm('query')">确 定</el-button>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
    </el-form>
  </el-dialog>
</template>
      <script>
        import {getCodeList, getUser} from '@/config/info'
        import api from '@/api'
        import axios from 'axios'
        import BasePath from '@/config/BasePath'
        export default {
          props: ['dialogObj'],
          mounted () {
            getCodeList('YC_SEX', (data) => {
              this.options_sex = data
            }) // 性别
            getCodeList('FW_CONSUMER_REGULAR_PRICE', (data) => {
              this.options_regularPrice = data
            }) // 性别
            getCodeList('FW_CONSUMER_WORK', (data) => {
              this.options_work = data
            }) // 职业
            getCodeList('FW_CONSUMER_DEGREE', (data) => {
              this.options_degree = data
            }) // 学历
            getCodeList('FW_CONSUMER_INCOME', (data) => {
              this.options_income = data
            }) // 收入
            getCodeList('FW_CONSUMER_AVG_COMSUMPTION', (data) => {
              this.options_avgComsumption = data
            }) // 月均花费
            getCodeList('FW_CONSUMER_QUANT', (data) => {
              this.options_quant = data
            }) // 每天的吸烟量
            getCodeList('FW_CONSUMER_TREND', (data) => {
              this.options_trend = data
            }) // 趋势
            getCodeList('FW_CONSUMER_LIKEBEST_NEW_CIG', (data) => {
              this.options_likebestNewCig = data
            }) // 最喜欢哪种类型的新品
            getCodeList('FW_CONSUMER_LIKEBEST_SPEC_PACK', (data) => {
              this.options_likebestSpecPack = data
            }) // 最喜欢的异型包装
            let _this = this
            let custMgrParam = {} // 客户经理
            custMgrParam.place = 135
            custMgrParam.status = 1
            custMgrParam.county_dept = getUser().companyId
            custMgrParam.fields = {include: 'employeeName,rowId'}
            axios.all([
              api.requestJava('POST', BasePath.EMPLOYEE_SELECT, custMgrParam), // 市场经理
              api.requestJava('POST', BasePath.COMMODITY_SELECT, {'status': 'Y', 'isConfiscated': 'N'}), // 新品卷烟
              api.requestJava('POST', BasePath.COMMODITY_SELECT, {'status': 'Y', 'isConfiscated': 'N'}) // 异形卷烟
            ])
              .then(axios.spread(function (_custmgrId, _spGroup, _recentlySpecCigId) {
                _this.options_custMgr = _custmgrId.data.data
                _this.options_spGroup = _spGroup.data.data
                _this.options_recentlySpecCig = _recentlySpecCigId.data.data
              }))
          },
          data () {
            return {
              options_degree: [],
              options_work: [],
              options_avgComsumption: [],
              options_regularPrice: [],
              options_quant: [],
              options_trend: [],
              options_spGroup: [],
              options_likebestNewCig: [],
              options_recentlySpecCig: [],
              options_likebestSpecPack: [],
              value: '',
              form: {},
              moreS: [
                {
                  colunm: 'degree',
                  type: 'string'
                },
                {
                  colunm: 'work',
                  type: 'string'
                },
                {
                  colunm: 'avgComsumption',
                  type: 'string'
                },
                {
                  colunm: 'regularPrice',
                  type: 'string'
                },
                {
                  colunm: 'quant',
                  type: 'string'
                },
                {
                  colunm: 'trend',
                  type: 'string'
                },
                {
                  colunm: 'lastNewCig',
                  type: 'string'
                },
                {
                  colunm: 'likebestNewCig',
                  type: 'string'
                },
                {
                  colunm: 'recentlySpecCig',
                  type: 'string'
                },
                {
                  colunm: 'likebestSpecPack',
                  type: 'string'
                }
              ]
            }
          },
          methods: {
            clearMethod () {
              this.dialogObj.data.form.roleCode = ''
              this.dialogObj.data.form.roleName = ''
              this.dialogObj.data.form.remark = ''
              this.dialogObj.data.form.attrFlag = ''
            },
            resetForm (formName) {
//              this.$refs[formName].resetFields()
              this.dialogObj.dialogVisible = false
              this.clearMethod()
            },
            submitForm (formName) {
              this.$refs[formName].validate((valid) => {
                if (valid) {
                  this.dialogObj.dialogVisible = false
                  let params = {}
                  for (let i = 0; i < this.moreS.length; i++) {
                    params[this.moreS[i].colunm] = this.toMoreChange(this.dialogObj.data.form[this.moreS[i].colunm], this.moreS[i].type)
                  }
                  console.log(JSON.stringify(params))
                  this.$emit('confirmBack', params)
                } else {
                  return false
                }
              })
            },
            toMoreChange (values, type) {
              let result = ''
              for (let i = 0; i < values.length; i++) {
                if (type === 'int') {
                  result = result + values[i] + ','
                } else if (type === 'string') {
                  result = result + "'" + values[i] + "'" + ','
                }
              }
              if (result.length > 0) {
                result = result.substr(0, result.length - 1)
              }
              // alert(result)
              return result
            }
          }
        }
      </script>

      <style scoped>
        .item__label_popup {
          text-align: right;
          vertical-align: middle;
          float: right;
          font-size: 14px;
          color: #48576a;
          line-height: 1;
          padding: 11px 8px 11px 0;
          box-sizing: border-box;
          /* display: inline-block; */
        }
        .el-input, .el-input__inner {
          /*width: '';*/
          display: inline-block;
        }
      </style>
