<template>
  <div class="container-fluid">
    <div>
        <tableVue
          ref="table"
          @update:data="tabChange"
          :reqParams="reqParams"
          stripe
          maxHeight="500"
          :data="dataSource"
          :columns="columnHeader"
          :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
          :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData >
        </tableVue>
    </div>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import tableVue from '@/components/Template/table/Table.vue'
  import { getUser } from '@/config/info'
  import log from '@/log'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  export default{
    name: 'Investigation',
    mounted () {
      this.init({})
    },
    data () {
      return {
        status: [
          {
            label: '设计',
            value: '0'
          }, {
            label: '发布',
            value: '1'
          }, {
            label: '结束',
            value: '2'
          }
        ], // 状态数据集
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        hasPagination: true,
        tableType: '3',
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'title', // 列的值
            label: '表单', // 列的显示字段
            columnsProps: {type: 'text'}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 300, type: 'button'},
            cptProperties: [
              {
                size: 'small',
                eventClick: this.find,
                label: '查询', // 按钮的名称
                value: 'find', // 按钮的值
                type: 'success',
                icon: 'search'
              }
            ]
          }
        ], // 表格头部列
        tableData: [], // 真个表格的数据
        dataSource: [], // 当前页的数据
        reqParams: {
          url: '',
          params: {}
        }
      }
    },
    methods: {
      init (params) {
        params.prodUnitId = getUser().companyId
        params.fluzzy = {'in': 'rowId: ' + this.$route.params.fromId}
        params.fields = {'include': 'rowId,formCode,title,userName,prodUnitName,createdTime,status,originApp'}
//        params.formCode = '新建工作表单'
        params.pageNum = this.currentPage
        params.pageSize = this.pageSize
        /* 将已有的参数赋值给分页参数 */
        this.$set(this.reqParams, 'url', BasePath.FW_FROMS_SELECTLIST)
        this.$set(this.reqParams, 'params', params)
        api.requestJava('POST', BasePath.FW_FROMS_SELECTLIST, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.totalCount = Number(request.data.count)
              if (this.tableData !== undefined && this.tableData !== null && this.tableData !== '') {
                this.tableData.forEach((val, key) => {
                  for (let i in this.status) {
                    if (Number(val.status) === Number(this.status[i].value)) {
                      val.state = this.status[i].label
                      break
                    }
                  }
                })
                this.currentPage = 1
                this.queryData(this.currentPage, this.pageSize)
              } else {
                this.tableData = []
              }
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      /* 查询 */
      find (index, row) {
        /* TODO */
        this.$router.push({name: 'ActivityFind', params: {fromId: row.rowId, companyId: getUser().companyId, activityId: this.$route.params.activityId, fromIds: this.$route.params.fromId, reportId: row.originApp}})
      },
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      rowClick (msg) {},
      headerClick (msg) {},
      sortChange (msg) {},
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      selectionChange () { }
    },
    components: {
      _POPUP,
      tableVue
    },
    watch: {
    }
  }
</script>
