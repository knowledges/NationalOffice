<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :size='dialogObj.size'>
    <el-form :model="dialogObj.data.form"  label-width="160px" ref="query" :rules="addrules">
      <el-row>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="appType" label="申请类型" >
              <el-select v-model="dialogObj.data.form.appType" :clearable="true" placeholder="请选择">
              <el-option
                v-for="item in options_appType"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="permitNo" label="专卖证号" >
              <el-input v-model="dialogObj.data.form.permitNo" @change="datePickerChange" ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="custName" label="客户名称" >
              <el-input v-model="dialogObj.data.form.custName" ></el-input>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="smpCollect" label="分类" >
                <el-checkbox-group v-model="dialogObj.data.form.smpCollect">
                  <el-checkbox label="1">市局</el-checkbox>
                  <el-checkbox label="2">省局</el-checkbox>
                  <el-checkbox label="3">国家局</el-checkbox>
                </el-checkbox-group>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="collectType" label="采集方式" >
              <el-select v-model="dialogObj.data.form.collectType" :clearable="true" placeholder="请选择">
                <el-option
                  v-for="item in options_collectType"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="collectType" label="是否启用" >
              <el-switch
                v-model="dialogObj.data.form.status">
              </el-switch>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="dateAdded" label="申请日期" >
              <el-date-picker
                v-model="dialogObj.data.form.dateAdded"
                type="date"
                placeholder="选择申请日期"
                :disabled="dialogObj.data.form.disabled"
              >
              </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="appDesc" label="说明" >
              <el-input
                type="textarea"
                :rows="2"
                placeholder="请输入内容"
                v-model="dialogObj.data.form.appDesc">
              </el-input>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='24'>
            <el-form-item style="float: right">
              <el-button @click="resetForm('addForm')">取 消</el-button>
              <el-button type="success" @click="submitForm('query', '0')" :disabled="dialogObj.data.form.disabled">保 存</el-button>
              <el-button type="success" @click="submitForm('query', '1')" :disabled="dialogObj.data.form.disabled">提 交</el-button>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
    </el-form>
  </el-dialog>
</template>
      <script>
        import {getCodeList, getUser} from '@/config/info'
        import BasePath from '@/config/BasePath'
        import api from '@/api'
//        import axios from 'axios'
//        import log from '@/log'
        export default {
          props: ['dialogObj'],
          mounted () {
            getCodeList('BM_CUST_APP_TYPE', (data) => {
              this.options_appType = data
            }) // 申请类型
            getCodeList('BM_CUST_COLLECT_TYPE', (data) => {
              this.options_collectType = data
            }) // 采集方式
            getCodeList('APP_STATUS', (data) => {
              this.options_appStatus = data
            }) // 采集方式
          },
          data () {
            return {
              appType: '', // 申请类型
              permitNo: '', // 专卖证号
              customerId: '', // 客户id
              custCode: '', // 客户代码
              custName: '', // 客户名称
              custmgrId: '', // 客户经理id
              smpCollect: [], // 分类
              collectType: '', // 采集方式
              status: '',
              dateAdded: '', // 申请日期
              appDesc: '', // 申请描述
              options_appType: [],
              options_collectType: [],
              options_appStatus: [],
              appState: '',
              addrules: {
                appType: [
                  {required: true, message: '请选择申请类型', trigger: 'blur'}
                ],
                permitNo: [
                  {required: true, message: '请输入专卖证号', trigger: 'blur'}
                ],
                custName: [
                  {required: true, message: '无客户信息请重新输入专卖证号', trigger: 'blur'}
                ],
                collectType: [
                  {required: true, message: '请选择采集方式', trigger: 'blur'}
                ]
              }
            }
          },
          methods: {
            init () {
              this.getCustomer()
            },
            getCustomer () {
              if (this.dialogObj.data.form.customerId !== '') {
                let params = {}
                params.rowId = this.dialogObj.data.form.customerId
                if (params.rowId !== '') {
                  api.requestJava('POST', BasePath.CUSTOMER_SELECTONE, params)
                    .then((request) => {
                      if (Number(request.data.code) === 200) {
                        this.dialogObj.data.form.custCode = request.data.data.customerCode
                        this.dialogObj.data.form.custName = request.data.data.customerDesc
                        this.dialogObj.data.form.custmgrId = request.data.data.custmgrId
                        this.dialogObj.data.form.customerId = request.data.data.rowId
                        this.dialogObj.data.form.permitNo = request.data.data.permitNo
                      } else if (Number(request.data.code) === 401) {
                        this.$message('无该客户')
                      } else {
                        this.$notify.error({title: '提示', message: request.data.message})
                      }
                    })
                }
              }
            },
            clearMethod () {
              this.dialogObj.data.form.appType = ''
              this.dialogObj.data.form.permitNo = ''
              this.dialogObj.data.form.custCode = ''
              this.dialogObj.data.form.custName = ''
              this.dialogObj.data.form.custmgrId = ''
              this.dialogObj.data.form.smpCollect = []
              this.dialogObj.data.form.collectType = ''
              this.dialogObj.data.form.dateAdded = ''
              this.dialogObj.data.form.appDesc = ''
              this.dialogObj.data.form.appState = ''
              this.dialogObj.data.form.disabled = false
            },
            resetForm (formName) {
              this.dialogObj.dialogVisible = false
              this.dialogObj.data.form.disabled = false
              this.clearMethod()
            },
            submitForm (formName, appState) {
              this.dialogObj.data.form.appState = appState
              this.$refs[formName].validate((valid) => {
                if (valid) {
                  this.dialogObj.dialogVisible = false
                  this.$emit('confirmBack', this.dialogObj)
                } else {
                  return false
                }
              })
            },
            datePickerChange () {
              let params = {}
              params.permitNo = this.dialogObj.data.form.permitNo
              if (params.permitNo !== '') {
                api.requestJava('POST', BasePath.CUSTOMER_SELECTONE, params)
                  .then((request) => {
                    if (Number(request.data.code) === 200) {
                      if (Number(getUser().personId) === Number(request.data.data.custmgrId)) {
                        this.dialogObj.data.form.customerCode = request.data.data.customerCode
                        this.dialogObj.data.form.customerDesc = request.data.data.customerDesc
                        this.dialogObj.data.form.customerId = request.data.data.rowId
                        this.init()
                      } else {
                        this.$message('无该客户的客户经理和当前用不对应，不可操作！')
                      }
                    } else if (Number(request.data.code) === 401) {
                      this.$message('无该客户')
                    } else {
                      this.$notify.error({title: '提示', message: request.data.message})
                    }
                  })
              }
            }
          }
        }
      </script>

      <style scoped>
        .item__label_popup {
          text-align: right;
          vertical-align: middle;
          float: right;
          font-size: 14px;
          color: #48576a;
          line-height: 1;
          padding: 11px 8px 11px 0;
          box-sizing: border-box;
          /* display: inline-block; */
        }
        .el-input, .el-input__inner {
          /*width: '';*/
          display: inline-block;
        }
      </style>
