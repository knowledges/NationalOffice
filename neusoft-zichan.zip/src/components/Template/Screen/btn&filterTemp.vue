<!--author qiu.bl-->
<style scoped>
  .row {
    padding: 5px 0;
  }
</style>
<template>
  <div class="col-md-12 col-sm-12 clearfix" style="padding-right: 0">
        <div style="float: right" class="btn-group" v-if="open">
          <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            展开 <span class="caret"></span>
          </button>
          <ul class="dropdown-menu">
            <li>
              <a href="javascript:;;" @click="openClk(true)">
                <i class="fa fa-plus-square"></i>
                全部展开
              </a>
            </li>
            <li>
              <a href="javascript:;;" @click="openClk(false)">
                <i class="fa fa-minus-square"></i>
                全部收起
              </a>
            </li>
          </ul>
        </div>
        <div style="float: right; margin-left: 5px" class="btn-group" role="group" aria-label="btn group">
          <template v-for="group in btnGroups">
            <button type="button" class="btn" :class="group.className" @click="group.event">
              <i class="fa" :class="group.iconName"></i>
              {{group.name}}
            </button>
          </template>
          <button type="button" class="btn btn-success" @click="exclClk">
            <i class="fa fa-file-text"></i>
            导出Excel
          </button>
        </div>
        <div style="float:right" class="input-group clearfix">
          <_INPUT :filmode="filmode" :filType="filType" :fileName="fileName" :keyupend="keyupend"
                  :datasource="tableData"  :filterMethod="filterMethod" style="float:right"/>
        </div>
      </div>
</template>
<script>
import _INPUT from '../../Template/filter/InputTemp.vue'
export default {
  props: {
    filmode: {
      type: Number,
      default: 0
    },
    filType: {
      type: Number,
      default: 1
    },
    fileName: {
      type: Array,
      default: []
    },
    keyupend: {
      type: Boolean,
      default: false
    },
    tableData: {
      type: Array,
      default: []
    },
    isMore: {
      type: Boolean,
      default: false
    },
    open: {
      type: Boolean,
      default: false
    },
    btnGroups: {
      type: Array,
      default: []
    },
    filterMethod: Function
  },
  mounted () {},
  methods: {
    openClk (isTrue) {
      this.$parent.$parent.$parent.showClk(isTrue)
    },
    moreClk () {
      this.$parent.isMoreClk()
    },
//    onendChange (val) {
//      this.$emit('on-change', val)
//    },
    exclClk () {
      this.$emit('on-click', '开始调用')
    }
  },
  components: {
    _INPUT
  }
}
</script>
