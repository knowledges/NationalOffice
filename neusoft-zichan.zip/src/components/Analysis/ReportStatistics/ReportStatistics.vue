<!--邱宝林-->
<!--价格采集汇总统计-->
<style rel="stylesheet/scss" lang="scss" scoped></style>
<template>
    <div class="container-fluid" style="height: 99%">
      <el-row class="filter_style">
        <el-col :gutter="24">
          <div class="text-right">
            <DatePickerTemp  @on-change="startTime" :types="date"/>
            <el-button type="primary" @click="findClk">查询</el-button>
          </div>
        </el-col>
      </el-row>
      <div style="height: calc(100% - 94px)">
        <iframe id="myIframe" :src="htl" frameborder="0" allowtransparency="true" width="100%" height="100%" scrolling="yes"></iframe>
      </div>
    </div>
</template>
<script>
  import config from '@/config'
  import {getUser} from '@/config/info'
  import DatePickerTemp from '@/components/Template/DatePicker/DatePickerTemp.vue'
  export default {
    name: 'ReportStatistics',
    props: {},
    mounted () {
    },
    data () {
      return {
        gatherDate: '',
        date: 'date',
        htl: ''
      }
    },
    methods: {
      startTime (val) {
        this.gatherDate = JSON.parse(val)
        this.findClk()
      },
      findClk () {
        if (this.gatherDate === '') {
          this.$notify({
            title: '警告',
            message: '时间不能为空',
            type: 'warning'
          })
        } else {
          var reportId = ''
          var companyId = ''
          var areaId = ''
          // 省公司
          if (Number(getUser().unitLevel) === 1) {
            reportId = '8f5573b5-7097-427c-abed-eb25ef59dec9'
            this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&gatherDate=' + this.gatherDate
          } else if (Number(getUser().unitLevel) === 2) {
            // 市公司
            if (getUser().countyId === null || getUser().countyId === 'null') {
              reportId = 'b0497e7d-7e9d-4eb3-8149-f03603a875c1'
              companyId = getUser().companyId
              this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&companyId=' + companyId + '&gatherDate=' + this.gatherDate
              // 分公司
            } else if (getUser().countyId !== null) {
              reportId = 'e6b4bb67-b8c3-4fb1-9f39-2cc06ef4a6f1'
              areaId = getUser().countyId
              this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&areaId=' + areaId + '&gatherDate=' + this.gatherDate
              // 订单组
            } else if (getUser().countyId !== null && getUser().deptId !== null && getUser().place === 24) {
              reportId = '7ef0ab76-bb8f-4a1b-9a5e-1dc433250bfd'
              areaId = getUser().deptId
              this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&areaId=' + areaId + '&gatherDate=' + this.gatherDate
            }
          }
        }
      }
    },
    components: {
      DatePickerTemp
    },
    watch: {}
  }
</script>
