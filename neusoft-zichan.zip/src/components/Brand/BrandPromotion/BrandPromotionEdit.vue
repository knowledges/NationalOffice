<--何欣-->
<template>
  <div class="container-fluid">
    <el-row :gutter="20">
      <el-col :span="6" :offset="18"><el-button type="primary" @click="updateForm()" >保存</el-button>
        <el-button type="primary" @click="addForm()" >提交</el-button>
        <el-button  type="primary" @click="cancleClk('')">返回</el-button></el-col>
    </el-row>
    <el-form ref="form" :model="form" label-width="90px">
      <el-row :gutter="20">
        <el-col :span="16">
            <el-form-item label="品规名称">
              <el-input v-model="form.goodsDesc"></el-input>
            </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="拟引入时间">
            <el-date-picker
              v-model="form.impDate"
              type="date"
              format="yyyy-MM-dd"
              :editable=false
              :clearable=false
              placeholder="选择开始时间">
            </el-date-picker>
          </el-form-item>
       </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="16">
      <el-form-item label="零售指导价"><el-input v-model="form.goodsPrice"></el-input>
      </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="16">
          <el-form-item label="口味特点"><el-input v-model="form.taste"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="市场定位"><el-input v-model="form.marketPosition"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
        <el-row>
        <el-col :span="24">
          <el-form-item label="宣传口号"><el-input
            type="textarea"  resize="none"
            :rows="3"
            placeholder="请输入内容"
            v-model="form.propaganda">
          </el-input>
          </el-form-item>
        </el-col>
        </el-row>
      <el-row :gutter="20"><el-col :span="24"><el-form-item label="文件上传">
        <uploadTemp :files="form.files" ref="uploadPic"></uploadTemp>
      </el-form-item>
      </el-col>
      </el-row>
    </el-form>
  </div>
</template>
<script>
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
  import api from '@/api'
  export default {
    data () {
      return {
        btnGroups: [
          {
            name: '保存',
            className: 'btn-info',
            iconName: 'fa-add',
            event: this.save
          },
          {
            name: '提交',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.addForm
          },
          {
            name: '返回',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        form: {
          rowId: '',
          goodsDesc: '',
          impDate: '',
          goodsPrice: '',
          propaganda: '',
          marketPosition: '',
          taste: '',
          status: '',
          files: [
          ]
        }
      }
    },
    methods: {
    /*  cancleClk () {
        this.$emit('confirmBack', 'cancle')
      },
      updateClk (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dialogObj.data.form.status = '0'
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      }, */
     /* clearObject () {
        let temp = {
          name: '',
          impDate: '',
          goodsPrice: '',
          propaganda: '',
          marketPosition: '',
          taste: '',
          files: [
          ]
        }
      },   */
      addForm () {
        let params = {}
        params.rowId = this.form.rowId
        params.goodsDesc = this.form.goodsDesc
        params.impDate = this.form.impDate
        params.goodsPrice = this.form.goodsPrice
        params.marketPosition = this.form.marketPosition
        params.taste = this.form.taste
        params.haveAttach = 1
        params.status = 1
        let files = []
        for (let i = 0; i < this.form.files.length; i++) {
          if (this.form.files[i].fileName === '') {
            return
          }
          console.log('files', this.form.files[i])
          let rowS = {}
          rowS.fileName = this.form.files[i].fileName
          rowS.fileType = 'visit_attach_photo'
          if ('src' in this.form.files[i]) {
            let src = this.form.files[i].src
            if (src.split(',').length > 0) {
              rowS.fileData = src.split(',')[1]
            }
          } else {
            rowS.fileData = this.form.files[i].fileData
          }
          files.push(rowS)
        }
        params.files = files
        console.log('params', JSON.stringify(params))
        var url = '/visit/cigarettesnew/update.do'
        if (this.form.rowId === '') {
          url = '/visit/cigarettesnew/insert.do'
        }
        api.requestJava('POST', url, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      } //  调插入接口
    },
    components: {
      _BTN_FILTER,
      uploadTemp
    }
  }
 </script>
<style>
 .el-form{
   padding-top: 30px;
  }
</style>
