<!-- 徐晓菁 -->
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :span="24" style="padding: 0 0">
        <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" :tableData="tableData" @on-click="exportEve" ></_BTN_FILTER>
      </el-col>
    </el-row>
    <div>
      <_TABLE
        ref="tableGrid"
        stripe
        @update:data="tabChange"
        :reqParams="reqParams"
        maxHeight="500"
        :data="dataSource"
        :columns="columnHeader"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
        @selection-change="selectionChange"></_TABLE>
      </div>
      <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve" v-popupdra-directive="{'show': edit.dialogVisible}"/>
      <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import { changeListValueByCode } from '@/utils/common'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import MY_POPUP_CONFIG from './Popup/Popup.vue'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import log from '@/log'
  import {getCodeList} from '@/config/info'
  export default {
    mounted () {
      getCodeList('AD_APP_PARAM_MODIFY_FLAG', (data) => {
        this.changeValueDate.modifyFlag.group = data
      }) // 零售业态
      this.queryUpper()
    },
    data () {
      return {
        /** 过滤的字段 **/
        fileName: ['paramCode', 'paramName', 'paramDesc', 'valueCode'],
        modifyFlagGroup: [],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '新增',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.addClk
          },
          {
            name: '批量删除',
            className: 'btn-danger',
            iconName: 'fa-remove',
            event: this.batchDelClk
          }
        ],
        hasPagination: true,
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'paramCode', // 列的值
            label: '参数编码', // 列的显示字段
            columnsProps: {width: 150, align: 'left'}
          }, {
            prop: 'paramName',
            className: 'header', // 列的css样式（选填）
            label: '参数名称',
            columnsProps: {width: 200, align: 'left'}
          }, {
            prop: 'paramDesc',
            label: '描述信息',
            columnsProps: {width: 200, align: 'left'}
          }, {
            prop: 'valueCode',
            label: '参数值',
            columnsProps: {width: 150, align: 'left'}
          }, {
            prop: 'lastUpdTime',
            label: '最近更改时间',
            columnsProps: {width: 150, align: 'center', formatter: this.changeValue}
          }, {
            prop: 'modifyFlag',
            label: '维护标识',
            columnsProps: {width: 100, align: 'center', formatter: this.changeValue}
          }, {
            prop: 'paramGrpName',
            label: '参数分组',
            columnsProps: {width: 120, align: 'center'}
          }, {
            label: '操作',
            prop: 'operation',
            columnsProps: {type: 'button'},
            cptProperties: [
              {
                label: '修改',
                value: 'modify',
                icon: 'edit',
                size: 'small',
                type: 'warning',
                eventClick: this.modify
              },
              {
                label: '删除',
                value: 'del',
                icon: 'delete',
                size: 'small',
                type: 'danger',
                eventClick: this.del
              }
            ]
          }
        ],
        changeValueDate: {
          modifyFlag: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          lastUpdTime: {
            type: 'date'
          }
        },
        tableData: [],
        tableType: '4',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        /** 弹出层 **/
        edit: {
          title: '参数编辑',
          type: '1',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              paramCode: '',
              paramName: '',
              paramDesc: '',
              valueCode: '',
              lastUpdTime: '',
              appId: '',
              paramGrpCode: '',
              paramGrpName: '',
              paramDataType: '',
              valueName: '',
              srcFlag: '',
              lovCode: '',
              modifyFlag: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: ''
            }
          }
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        sel_all_row: []
      }
    },
    methods: {
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = this.currentPage
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      addClk () {
        this.edit.dialogVisible = true
      }, // 新增
      modify (index, row) {
        if (Number(row.modifyFlag) !== 3) {
          this.$message({type: 'info', message: '该记录不可修改记录!'})
          return
        }
        Object.assign(this.edit.data.form, row)
        this.edit.dialogVisible = true
      }, // 修改
      del (index, row) {
        if (Number(row.modifyFlag) !== 3) {
          this.$message({type: 'info', message: '该记录不可修改删除!'})
          return
        }
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.deleteUpper(row.rowId)
        }).catch(() => {
          this.$message({type: 'info', message: '已取消删除!'})
        })
      },  // 删除
      batchDelClk () {
        for (let i = 0; i < this.sel_all.length; i++) {
          if (Number(this.sel_all_row[i].modifyFlag) !== 3) {
            this.$message({type: 'info', message: '选择记录中有不可修改记录!'})
            return
          }
        }
        if (this.sel_all.length > 0) {
          this.$confirm('确定删除此条信息吗？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.deletebatchUpper()
          })
          .catch(() => {
            this.$message({type: 'info', message: '已取消删除!'})
          })
        }
      },  // 批量删除
      onendChange (val) {}, // 过滤器修改事件
      deleteUpper (val) {
        let params = {}
        params.rowId = val
        api.requestJava('POST', BasePath.APPPARAM_DELETE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              this.queryUpper()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 删除接口
      deletebatchUpper () {
        console.log('this.sel_all', this.sel_all)
        api.requestJava('POST', BasePath.APPPARAM_DELETEBATCH, this.sel_all)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              this.queryUpper()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 删除接口
      queryUpper () {
        let params = {}
        params.pageSize = this.pageSize
        params.pageNum = 1
        this.reqParams.url = BasePath.APPPARAM_SELECT
        this.reqParams.params = params
        api.requestJava('POST', BasePath.APPPARAM_SELECT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.totalCount = +request.data.count
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      editEve (msg) {
        if (msg === 'update') {
          this.saveUpper()
        }
        this.edit.dialogVisible = false
        let tmp = {
          title: '参数编辑',
          type: '1',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              paramCode: '',
              paramName: '',
              paramDesc: '',
              valueCode: '',
              lastUpdTime: '',
              appId: '',
              paramGrpCode: '',
              paramGrpName: '',
              paramDataType: '',
              valueName: '',
              srcFlag: '',
              lovCode: '',
              modifyFlag: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: ''
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      headerClick (column, event) {
        console.log(column)
      },
      saveUpper () {
        let params = this.edit.data.form
        params.appId = '-1'
        console.log('params', JSON.stringify(params))
        var url = BasePath.APPPARAM_UPDATE
        if (this.edit.data.form.rowId === '') {
          url = BasePath.APPPARAM_INSERT
        }
        api.requestJava('POST', url, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              this.queryUpper()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 保存
      sortChange (msg) {},
      rowClick (msg) {},
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      selectionChange (rows) {}
    },
    components: {
      _TABLE,
      _POPUP,
      _BTN_FILTER,
      MY_POPUP_CONFIG
    }
  }
</script>
