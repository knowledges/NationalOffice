<!--李晶-->
<style scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-24 {
    height: 36px;
  }
</style>
<template>
  <div  class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='12'>
          <div v-if="isSelect">
            <el-form ref="searchForm" :model="searchForm" label-width="100px">
              <el-col :gutter="24">
                <el-col :span='12'>
                  <el-form-item prop="countyId" label="数据范围">
                    <_cascader @on-change="getChangeValue"/>
                  </el-form-item>
                </el-col>
                <el-col :span='12'>
                  <el-form-item label="发展日期">
                    <el-date-picker
                      v-model="searchForm.addDate"
                      type="daterange"
                      range-separator="至"
                      start-placeholder="开始日期"
                      end-placeholder="结束日期">
                    </el-date-picker>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-form>
          </div>
        </el-col>
        <el-col :span="12">
          <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" :tableData="tableData" @on-click="exportEve" :isMore="isMore"></_BTN_FILTER>
        </el-col>
      </el-col>
    </el-row>
    <div>
      <tableVue
        ref="tableGrid"
        stripe
        maxHeight="500"
        :data="dataSource"
        @update:data="tabChange" :reqParams="reqParams"
        :columns="columns"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData></tableVue>
    </div>
  </div>
</template>
<script>
  import tableVue from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import {getUser, getCodeList} from '@/config/info'
  import {dateFormat} from '@/utils/dateFormat.js'
  import BasePath from '@/config/BasePath'
  import { changeListValueByCode } from '@/utils/common'
  import api from '@/api'
  import log from '@/log'
  import axios from 'axios'
  import _cascader from '@/components/Template/Cascader/Cascader.vue'
  export default {
    mounted () {
      let _this = this
      getCodeList('YC_SEX', (data) => {
        this.changeValueDate.sex.group = data
      }) // 性别
      let custMgrParam = {} // 客户经理
      custMgrParam.place = 135
      custMgrParam.status = 1
      custMgrParam.countyDept = getUser().countyId
      if (getUser().place === '24') {
        custMgrParam.manager = getUser().personId
      }
      custMgrParam.fields = {include: 'employeeName,rowId'}
      axios.all([
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, custMgrParam), // 市场经理
        api.requestJava('POST', BasePath.COMMODITY_SELECT, {'status': 'Y', 'isConfiscated': 'N', 'include': 'goodsDesc,rowId'}), // 新品卷烟
        api.requestJava('POST', BasePath.COMMODITY_SELECT, {'status': 'Y', 'isConfiscated': 'N', 'include': 'goodsDesc,rowId'}) // 异形卷烟
      ])
        .then(axios.spread(function (_custMgr, _spGroup, _recentlySpecCigId) {
          _this.options_custMgr = JSON.parse(JSON.stringify(_custMgr.data.data))
          _this.changeValueDate.lastNewCig.group = _spGroup.data.data
          _this.changeValueDate.recentlySpecCig.group = _recentlySpecCigId.data.data
        }))
      this.init()
    },
    data () {
      return {
        tmp: [],
        queryParam: {
          companyId: '',
          countyId: '',
          marketMgrId: '',
          custmgrId: ''
        },
        custmgrDisable: false,
        queryParams: {},
        isSelect: true,
        isMore: true, // 查询更多条件
        searchForm: {
          addDateL: new Date(),
          addDateR: new Date(),
          addDate: [new Date(), new Date()],
          custMgr: ''
        },
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['code', 'name', 'mobile', 'nativePlace', 'sex', 'birthday', 'degree'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        selectSells: [],
        totalCount: 0, // 表格总记录数
        hasPagination: true, // 是否有分页
        columns: [ // 表格列
          { label: '客户经理', prop: 'visitorName', columnsProps: {width: 350} },
          { label: '日期', prop: 'expectedTime', columnsProps: {width: 350} },
          { label: '里程数（公里）', prop: 'countNum', columnsProps: {} }
        ],
        tableData: [],
        tableType: '4',
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        sessionFailedDialogObj: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        changeValueDate: {
          sex: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          lastNewCig: {
            type: 'text',
            group: [],
            key: 'rowId',
            value: 'goodsDesc'
          },
          recentlySpecCig: {
            type: 'text',
            group: [],
            key: 'rowId',
            value: 'goodsDesc'
          }
        },
        options_custMgr: []
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      isMoreClk () {
        this.dialogObj_base.dialogVisible = true
      },
      init () {
        this.clear()
        let param = {}
        param.visitBegin = this.getTime(Date.parse(this.searchForm.addDate[0]))
        param.visitEnd = this.getTime(Date.parse(this.searchForm.addDate[1]))
        /* TODO 将 getChangeValue 内容添加到这里 */
        if (Number(getUser().unitLevel) === 1) { // 展示所有
          this.queryParam.companyId = getUser().companyId
          this.tmp.forEach((val, key) => {
            switch (key) {
              case 0:
                this.queryParam.companyId = val
                break
              case 1:
                this.queryParam.countyId = val
                break
              case 2:
                this.queryParam.marketMgrId = val
                break
              case 3:
                this.queryParam.custmgrId = val
                break
            }
          })
        } else if (Number(getUser().unitLevel) === 2) { // 展示该市下的所有分公司
          if (getUser().countyId === 'null') {
            this.queryParam.companyId = getUser().companyId
            this.tmp.forEach((val, key) => {
              switch (key) {
                case 0:
                  this.queryParam.countyId = val
                  break
                case 1:
                  this.queryParam.marketMgrId = val
                  break
                case 2:
                  this.queryParam.custmgrId = val
                  break
              }
            })
          } else if (getUser().countyId !== 'null' && Number(getUser().place) === 9999) {
            if (this.tmp.length > 0) {
              this.tmp.forEach((val, key) => {
                switch (key) {
                  case 0:
                    this.queryParam.marketMgrId = val
                    break
                  case 1:
                    this.queryParam.custmgrId = val
                    break
                }
              })
            } else {
              this.queryParam.companyId = getUser().companyId
              this.queryParam.countyId = getUser().countyId
            }
          } else if (getUser().countyId !== 'null' && getUser().deptId !== 'null' && Number(getUser().place) === 24) {
            this.queryParam.marketMgrId = getUser().personId
            this.queryParam.custmgrId = this.tmp[0]
          } else if (Number(getUser().place) === 135) {
            this.queryParam.custmgrId = getUser().personId
          }
        }
        Object.assign(param, this.queryParam)
        console.log('param:' + JSON.stringify(param))
        this.reqParams.url = BasePath.VISIT_DISTANCE
        this.reqParams.params = param
        api.requestJava('POST', BasePath.VISIT_DISTANCE, param, {})
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.dataSource = request.data.data
              this.tableData = request.data.data
              console.log(JSON.stringify(request.data.data))
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
        this.getBillNo()
      },
      initMore (paramMore) {
        this.clear()
        let param = {}
        param.addDateL = this.getTime(Date.parse(this.searchForm.addDate[0]))
        param.addDateR = this.getTime(Date.parse(this.searchForm.addDate[1]))
        /* TODO 将 getChangeValue 内容添加到这里 */
        if (Number(getUser().unitLevel) === 1) { // 展示所有
          this.queryParam.companyId = getUser().companyId
          this.tmp.forEach((val, key) => {
            switch (key) {
              case 0:
                this.queryParam.companyId = val
                break
              case 1:
                this.queryParam.countyId = val
                break
              case 2:
                this.queryParam.marketMgrId = val
                break
              case 3:
                this.queryParam.custmgrId = val
                break
            }
          })
        } else if (Number(getUser().unitLevel) === 2) { // 展示该市下的所有分公司
          if (getUser().countyId === 'null') {
            this.queryParam.companyId = getUser().companyId
            this.tmp.forEach((val, key) => {
              switch (key) {
                case 0:
                  this.queryParam.countyId = val
                  break
                case 1:
                  this.queryParam.marketMgrId = val
                  break
                case 2:
                  this.queryParam.custmgrId = val
                  break
              }
            })
          } else if (getUser().countyId !== 'null' && Number(getUser().place) === 9999) {
            if (this.tmp.length > 0) {
              this.tmp.forEach((val, key) => {
                switch (key) {
                  case 0:
                    this.queryParam.marketMgrId = val
                    break
                  case 1:
                    this.queryParam.custmgrId = val
                    break
                }
              })
            } else {
              this.queryParam.companyId = getUser().companyId
              this.queryParam.countyId = getUser().countyId
            }
          } else if (getUser().countyId !== 'null' && getUser().deptId !== 'null' && Number(getUser().place) === 24) {
            this.queryParam.marketMgrId = getUser().personId
            this.queryParam.custmgrId = this.tmp[0]
          } else if (Number(getUser().place) === 135) {
            this.queryParam.custmgrId = getUser().personId
          }
        }
        Object.assign(param, this.queryParam)
        Object.assign(param, paramMore)
        console.log('param:' + JSON.stringify(param))
        this.reqParams.url = BasePath.CONSUMER_GETLIST
        this.reqParams.params = param
        api.requestJava('POST', BasePath.CONSUMER_GETLIST, param, {})
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.dataSource = request.data.data
              this.tableData = request.data.data
              console.log(JSON.stringify(request.data.data))
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
        this.getBillNo()
      },
      clear () {
        this.dataSource = []
        this.tableData = []
      },
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      headerClick () {},
      sortChange (msg) {},
      rowClick (msg) {},
      modify (index, row) {
        Object.assign(this.dialogObj.data.form, row)
        this.dialogObj.data.form.nativePlace = JSON.parse(row.nativePlace)
        this.dialogObj.dialogVisible = true
        this.dialogObj.data.form.disabled = false
        this.$refs.childs.init()
      }, // 修改
      search (index, row) {
        Object.assign(this.dialogObj.data.form, row)
        this.dialogObj.data.form.nativePlace = JSON.parse(row.nativePlace)
        this.dialogObj.dialogVisible = true
        this.dialogObj.data.form.disabled = true
      }, // 查看
      sessionFailedBack (msg) {
        let headers = msg.data.form
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.sessionFailedDialogObj.dialogVisible = false
            }
          })
          .catch((err) => { console.log(err) })
      }, // 会话失效
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      confirmBack (msg) {
        console.log(JSON.stringify(msg))
        if (msg) {
          this._upload_submit()
        } else {
          this.clearObject()
        }
      },
      confirmBackMore (msg) {
        console.log(JSON.stringify(msg))
        this.initMore(msg)
      },
      _upload_submit () {
        let params = this.dialogObj.data.form
        params.createdBy = getUser().userID
        params.companyId = getUser().companyId
        params.custmgrId = this.dialogObj.data.form.custMgr
        params.deptId = getUser().deptId
        console.log(typeof params.nativePlace)
        params.nativePlace = JSON.stringify(params.nativePlace)
        console.log(params.nativePlace)
        params.addDate = new Date()
        console.log('params:' + JSON.stringify(params))
        // debugger
        if (params.rowId === '') { // 新建
          api.requestJava('POST', BasePath.CONSUMER_INSERT, params)
            .then(request => {
              if (Number(request.data.code) === 200) {
                this.$message({ type: 'success', message: '新增成功!' })
                this.init()
              } else {
                this.$notify.error({ title: '提示', message: '新增错误' })
                throw new Error(JSON.stringify(request))
              }
            })
        } else {
          console.log(JSON.stringify(params))
          api.requestJava('POST', BasePath.CONSUMER_UPDATE, params)
            .then(request => {
              console.log(request.data.code)
              if (Number(request.data.code) === 200) {
                this.$message({ type: 'success', message: '更新成功!' })
                this.init()
              } else {
                this.$notify.error({ title: '提示', message: '更新错误' })
                throw new Error(JSON.stringify(request))
              }
            })
            .catch(err => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        }
      },
      addClk () {
        this.clearObject()
        this.dialogObj.dialogVisible = true
      },
      getChangeValue (val) {
        this.tmp = val
        console.log('范围：', val)
      },
      query () {
        this.init()
      },
      colFormatter_sex (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },
      colFormatter (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },
      colFormatter_birthday (row, column) {
        return dateFormat(Date.parse(new Date()), 'YYYY') - dateFormat(Date.parse(row.birthday), 'YYYY')
      },
      colFormatter_nativePlace (row, column) {
        let nat = JSON.parse(row.nativePlace)
        let result = ''
        for (let i = 0; i < nat.length; i++) {
          result = result + nat[i]
        }
        return result
      }
    },
    components: {
      tableVue,
      _BTN_FILTER,
      _cascader
    }
  }
</script>
