<style scoped>
  @import "./css/design.css";
  .container-fluid {
    margin: 0 0;
    padding: 0 0;
  }
  .question-masks{
    position: absolute;
    width: 100%;
    z-index: 99;
    top: 120px;
  }
  #dwSurveyQuContentAppUl {
    /*padding-bottom: 0!important;*/
  }
  .ui-sortable > li {
    height: auto!important
  }
</style>
<template>
  <div class="container-fluid">
    <div class="question-masks">
      <div id="tools_wrap">
        <div id="tools">
          <div class="tools_tabs">
            <div class="tools_tabs_left">
              <ul>
                <li :class="actived == 0 && 'current'" @click="liClk(0)">基本</li>
                <li :class="actived == 1 && 'current'" @click="liClk(1)">常用</li>
              </ul>
            </div>
          </div>
          <div class="tools_contents">
            <div id="tools_tab1" class="tools_tab_div" v-show="actived == 0" style="display: inline;">
              <!-- 基本题库 -->
              <div id="toolsBashQu" class="tools_item">
                <div class="toolbars">
                  <ul class="dragQuUl" draggable='true'>
                    <_RADIO />
                    <_CHECKBOX />
                    <_INPUT />
                    <_SCORE />
                    <!--<_INPUTS />-->
                  </ul>
                </div>
                <div class="tooltext">基本题型</div>
              </div>
              <!-- 辅助组件 -->
              <div id="toolsAuxiliaryQu" class="tools_item">
                <div class="toolbars">
                  <ul class="dragQuUl">
                    <_PARAGRAPH />
                  </ul>
                </div>
                <div class="tooltext">辅助组件</div>
              </div>
            </div>
            <div id="tools_tab2" class="tools_tab_div" v-show="actived == 1">
              <div id="contactPersonQuestion" class="tools_item">
                <div class="toolbars">
                  <ul class="dragQuUl">
                    <_CASCADER :types="'city'"/>
                    <_CASCADER :types="'goods'"/>
                    <!--<_INFO />-->
                  </ul>
                </div>
                <div class="tooltext">常用题型</div>
              </div>
            </div>
            <div id="toolsPubBtn" >
              <div class="toolbars" style="padding:10px  15px 10px 0px;">
                <ul>
                  <li @click="publishBtn">
                    <a href="javascript:;;" class="btn btn-primary">发布</a>
                  </li>
                  <li @click="saveBtn">
                    <a href="javascript:;;" class="btn btn-default">保存</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="question-body">
      <!--中间空白内容页面-->
      <div id="dw_body">
        <div id="dw_body_content">
          <div id="dwSurveyTitle">
            <div id="dwSurveyName" class="editAble dwSvyName">{{questionnaire.title}}</div>
          </div>
          <!--<div id="dwSurveyNote">-->
            <!--<div id="dwSurveyNoteEdit" class="editAble dwSvyNoteEdit">{{questionnaire.descText}}</div>-->
            <!--<input type="hidden" name="svyNoteSaveTag" value="1">-->
          <!--</div>-->
          <div id="dwSurveyQuContent">
            <ul id="dwSurveyQuContentAppUl" class="ui-sortable">
              <!-- TODO -->
              <template v-for="item in questionnaire.itemsList">
                <template v-if="item.inputType == 'city' || item.inputType == 'goods'">
                  <SUB_CASCADER :SUBCASCADER="item"/>
                </template>
                <template v-if="item.inputType == 'radio'">
                  <SUB_RADIO :SubRadios="item"/>
                </template>
                <template v-if="item.inputType == 'multiselect'">
                  <SUB_CHECKBOX :SubCheckBox="item"/>
                </template>
                <template v-if="item.inputType == 'input'">
                  <SUB_FILLBLANK :SubFillBlank="item"/>
                </template>
                <!--<template v-if="item.inputType == '多项填空题'">-->
                  <!--<SUB_FILLBLANKS :SubFillBlanks="item" />-->
                <!--</template>-->
                <template v-if="item.inputType == 'score'">
                  <SUB_SCORE :SubScore="item"/>
                </template>
                <template v-if="item.inputType == '段落'">
                  <SUB_PARAGRAPH :SUBPARAGRAPH="item"/>
                </template>
              </template>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!--公公编辑-->
    <div id="dwCommonEditRoot"  >
      <div class="dwCommonEdit">
        <ul class="dwComEditMenuUl" >
          <li><a href="javascript:;" class="SeniorEdit"><i class="menu_edit2_icon"></i>高级编辑</a></li>
          <li class="option_Set_Li"><a href="javascript:;" class="option_Set"><i class="menu_edit4_icon"></i>选项设置</a></li>
          <!-- <li><a href="javascript:;" class="reference_Set" style="display: none;"><i class="menu_edit4_icon"></i>引用设置</a></li> -->
        </ul>
        <ul class="dwComEditOptionUl">
          <li class="dwOptionUp"><div class=dwQuIcon></div></li>
          <li class="dwOptionDown"><div class=dwQuIcon></div></li>
          <li class="dwOptionDel"><div class=dwQuIcon></div></li>
        </ul>
        <div class="dwComEditMenuBtn"></div>
        <div id="dwComEditContent" contenteditable="true" >请问你的年级是？</div>
      </div>
    </div>
    <!-- 逻辑设置弹出层 -->
    <div id="dwCommonDialog">
      <div class="dwCommonRefIcon"><div class="dwCommonRefIcon1"></div><div class="dwCommonRefIcon2"></div></div>
      <div class="dwCommonDialogBody">
        <div  class="dwCommonDialogTitle"><span id="dwComDialogTitleText">标题文本</span><span id="dwCommonDialogClose" class="closeDialog" @click="dwCommonDialogClose"></span></div>
        <div class="dwCommonDialogContent">
          <!-- 默认显示的LOAD -->
          <!--<div class="dwQuDialogLoad dwQuDialogCon"><img alt="" src="./src/assets/images/load.gif"></div>-->
          <!-- 题目设置 -->
          <div class="dwQuSetCon dwQuFormSetDialog dwQuDialogCon" >
            <ul>
              <!-- <li><input type="checkbox" name="quChage"><label>切换为多选</label> </li> -->
              <li><label><input type="checkbox" name="setIsRequired">此题必答</label> </li>
            </ul>
            <div class="dwQuDialogBtnCon"><input type="button" value="保存" class="quDialogBtn" id="dwDialogQuSetSave" @click="dwDialogQuSetSave"/></div>
          </div>
        </div>
      </div>
    </div>
    <!-- 各种模板 -->
    <!-- 单选选项模板 -->
    <div id="quRadioItem" class="modelHtml">
      <el-radio label="2">
        <label class="editAble quCoOptionEdit"></label>
      </el-radio>
      <div class="quItemInputCase">
        <input type="hidden" name="rowId" value="">
        <input type="hidden" name="rcFlag" value="0">
      </div>
    </div>
    <!-- 多选选项模板 -->
    <div id="quCheckboxItem" class="modelHtml">
      <template>
        <el-checkbox>
          <label class="editAble quCoOptionEdit"></label>
        </el-checkbox>
      </template>
      <div class="quItemInputCase">
        <input type="hidden" name="rowId" value="">
        <input type="hidden" name="rcFlag" value="0">
      </div>
    </div>
    <!-- 多项填空题 暂时不做 -->
    <table class="modelHtml" >
      <tr id="mFillblankTableModel" >
        <td align="right" class="mFillblankTableEditTd">
          <label class="editAble quCoOptionEdit">大一</label>
          <div class="quItemInputCase">
            <input type="hidden" name="rowId" value="">
            <input type="hidden" name="quItemId" value="">
            <input type="hidden" name="quItemSaveTag" value="0">
          </div>
        </td>
        <td><input type="text" style="width:200px;padding:5px;"></td>
      </tr>
    </table>
    <!-- 评分题选项模板 -->
    <table class="modelHtml">
      <tr id="quScoreItemModel" class="quScoreOptionTr">
        <td class="quCoItemTableTd quOptionEditTd">
          <label class="editAble quCoOptionEdit">评分项</label>
          <div class="quItemInputCase">
            <input type="hidden" name="rowId" value="">
          </div>
        </td>
        <td class="quCoItemTableTd">
          <el-rate v-model="value2"></el-rate>
        </td>
        <td class="quCoItemTableTd">分</td>
      </tr>
    </table>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  /* 输入 */
  import _RADIO from './module/base/radio.vue'
  import _CHECKBOX from './module/base/checkbox.vue'
  import _INPUT from './module/base/input.vue'
  import _SCORE from './module/base/score.vue'
  import _INPUTS from './module/base/inputs.vue'
  import _PARAGRAPH from './module/base/paragraph.vue'
  import _CASCADER from './module/base/cascader.vue'
//  import _INFO from './module/base/Info.vue'
  /* 输出 */
  import SUB_RADIO from './module/output/radio.vue'
  import SUB_CHECKBOX from './module/output/checkbox.vue'
  import SUB_FILLBLANK from './module/output/fillblank.vue'
  import SUB_FILLBLANKS from './module/output/fillblanks.vue'
  import SUB_SCORE from './module/output/score.vue'
  import SUB_PARAGRAPH from './module/output/paragraph.vue'
  import SUB_CASCADER from './module/output/cascader.vue'
  import $ from 'jquery'
  require('static/js/plugins/jQuery/jquery-ui.min')
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import log from '@/log'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  export default {
    name: 'Design',
    mounted () {
      this.formId = this.$route.params.rowId
      let _this = this
      _this.init(this.formId)
      /* 拖拽事件 */
      $('.dragQuUl li').draggable({
        connectToSortable: '#dwSurveyQuContentAppUl', // 插入目的地
        appendTo: '#dwSurveyQuContentAppUl',
        zIndex: 999,
        cursor: 'move', // 和 css 样式一样
        cursorAt: {left: 40, top: 25},
        scroll: true,
        scrollSensitivity: 30,
        scrollSpeed: 30,
        helper: 'clone',
        start: function (event, ui) {
          _this.isDrag = true
          $('#tools_wrap').css({zIndex: 3})
          _this.resetQuItemHover(null) // 重置 Menu 上的 hover 事件
          _this.curEditCallback()
        },
        drag: function (event, ui) {
          _this.isDrag = true
        },
        stop: function (event, ui) {
          if (!_this.isSort) { // 修改menu 层级关系
            $('#tools_wrap').animate({zIndex: 200}, 200, function () {
              _this.resetQuItem()
              _this.bindQuHoverItem()
            })
          }
        }
      })
      /* 排序事件 */
      $('#dwSurveyQuContentAppUl').sortable({
        revert: true, // 恢复初始位置 带动画效果
        placeholder: 'showLine',
        tolerance: 'pointer',
        opacity: 0.7,
        handle: '.dwQuMove', // 只能通过move去拖拽排序
        scrollSensitivity: 30,
        scrollSpeed: 30,
        start: function (event, ui) {
          $('#tools_wrap').css({'zIndex': 30})
          $('.showLine').height(ui.item.height())
          _this.dwCommonDialogHide()
          _this.curEditCallback()
          _this.isSort = true
        },
        sort: function (event, ui) {
          _this.isSort = true
          $('.ui-sortable-placeholder').css({'background': '#f1f2f3', 'border-top': '1px dashed #ccc', 'border-bottom': '1px dashed #ccc'})
        },
        out: function (event, ui) {
          // 当一个元素拖拽移出sortable对象移出并进入另一个sortable对象后触发此事件。
          _this.isSort = false
        },
        update: function (e, ui) {
          if (!_this.isDrag) {
            // 根据排序ID，计算出是前排序，还是后排序
            $("#dwSurveyQuContentAppUl input[name='saveTag']").val(0)
          }
        },
        stop: function (e, ui) {
          if (_this.isDrag) {
            _this.isDrag = false
            _this.isSort = false
            ui.item.html(ui.item.find('.dwQuTypeModel').html())
            ui.item.removeClass('ui-draggable')
            ui.item.find('.quDragBody').removeClass('quDragBody')
          // 新加入题-选定题目标题
            ui.item.find('.surveyQuItemBody').addClass('hover')
            ui.item.addClass('li_surveyQuItemBody')
            let quType = ui.item.find(".surveyQuItemBody input[name='quType']").val()
            if (quType !== 'PAGETAG') {
              _this.editAble(ui.item.find('.surveyQuItemBody .quCoTitleEdit'))
            }
          }
          let curItemBodyOffset = ui.item.offset()
          $('html,body').animate({scrollTop: curItemBodyOffset.top - 370}, 500, function () {
            $('#tools_wrap').css({'zIndex': 200})
            _this.resetQuItem()
            _this.bindQuHoverItem()
          })
        }
      })

      $('#dwSurveyQuContentAppUl').disableSelection()

      $(document).click(function () {
        _this.curEditCallback()
        if (!_this.isDialogClick) {
          _this.dwCommonDialogHide()
          _this.resetQuItemHover(null)
        }
        _this.isDialogClick = false
      })

      $('#dwCommonEditRoot').unbind()
      $('#dwCommonEditRoot').click(function () {
        return false
      })

      $('#dwCommonDialog').click(function () {
        _this.isDialogClick = true
      })

      $('#modelUIDialog').click(function () {
        _this.isDialogClick = true
      })

      this.$nextTick(() => {
        document.getElementsByClassName('content-wrapper')[0].style.height = ''
      })
    },
    data () {
      return {
        value2: null,
        intervalSave: '',
        formId: '', // 当前问卷Id
        actived: 0, // 当前选中的 tab 【基本：0、常用：1】
        tmp: [],
        questionnaire: {
          rowId: '',
          title: '第一个问卷',
          descText: '非常感谢您的参与！如有涉及个人信息，我们将严格保密。',
          formId: '',
          placeTypeId: '',
          prodUnitId: '',
          itemsList: []
        }, // 问卷内容
        browseWidth: document.documentElement.clientWidth, // 浏览器可视化宽度
        browseHeight: document.documentElement.clientHeight, // 浏览器可视化高度
        questionBelongId: '',
        svTag: 2, // 表示题目是问卷题还是题库中题
        quCBNum: 0,
        quCBNum2: 0, // 比较值
        curEditObjOldHtml: '', // 当前编辑的html
        dwDialogObj: null,
        ueEditObj: null,
        appQuObj: null,
        myeditor: null,
        ueDialog: null,
        isSaveProgress: false,
        isDrag: false,
        isSort: false,
        curEditObj: null, // 当前编辑对象
        msg: '该功能还在赶往途中...',
        options: [],
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        }
      }
    },
    methods: {
      init (formId) {
        api.requestJava('POST', BasePath.FW_ITEMS_GETFULLFORM, {formId: formId})
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.questionnaire = request.data.data
              this.$nextTick(() => {
                this.bindQuHoverItem()
              })
            } else if (Number(request.data.code) === 401) {
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
        this.$nextTick(() => {
          this.resetQuItem()
          this.bindQuHoverItem()
        })
      },
      routeClk () {},
      liClk (idx) {
        this.actived = idx
      }, // li 的切换
      intervalSaveSurvey () {
        let saveTag = $("#dwSurveyQuContentAppUl input[name='saveTag'][value='0']")
        let nmSaveTag = $("#dw_body_content input[name='svyNmSaveTag'][value='0']")
        let noteSaveTag = $("#dw_body_content input[name='svyNoteSaveTag'][value='0']")
        if (!this.isSaveProgress && (saveTag[0] || nmSaveTag[0] || noteSaveTag[0]) && !this.isDrag && this.curEditObj === null && this.dwDialogObj === null) {
          this.$message({
            message: '自动保存中...',
            type: 'info',
            duration: 3000
          })
          this.saveSurvey(() => {
            this.isSaveProgress = false
            this.$message({
              message: '保存成功',
              type: 'success',
              duration: 1000
            })
          })
        }
      }, // 定时保存逻辑  三分钟检查一次
      saveSurvey (callback) {
        this.isSaveProgress = true
        // 保存问卷级别信息--之后才保存问卷中的题
        let svyNmSaveTag = $("input[name='svyNmSaveTag']").val()
        let svyNoteSaveTag = $("input[name='svyNoteSaveTag']").val()
        let svyAttrSaveTag = $("input[name='svyAttrSaveTag']").val()
        if (Number(svyNmSaveTag) === 0 || Number(svyNoteSaveTag) === 0 || Number(svyAttrSaveTag) === 0) {
          this.$message('saveSurvey 的 if 方法')
        } else {
          let fristQuItemBod = $('#dwSurveyQuContent .li_surveyQuItemBody').first()
          this.saveQus(fristQuItemBod, callback)
        }
      },
      /**
       * 保存标记说明
       * @param quItemBody
       * @param callback
       * saveTag  标记本题有无变动
       * quTitleSaveTag  标记题标题变动
       * quItemSaveTag 标记题选项变动
       * 0=表示有变动，未保存
       * 1=表示已经保存同步
       */
      saveQus (quItemBody, callback) {
        $('.ui-draggable-handle.li_surveyQuItemBody').removeClass('ui-draggable-handle').removeAttr('style')
        if (quItemBody[0]) {
          let quType = quItemBody.find("input[name='quType']").val()
          if (quType === 'radio' || quType === 'multiselect') {
            this.saveRadioCheckboxOption(quItemBody, callback)
          } else if (quType === 'input') {
            this.saveFillblank(quItemBody, callback)
          } else if (quType === 'score') {
            this.saveScore(quItemBody, callback)
          } else if (quType === 'ORDERQU') {
            console.log('saveOrderqu')
          } else if (quType === 'PAGETAG') {
            console.log('savePagetag')
          } else if (quType === 'PARAGRAPH') {
            this.saveParagraph(quItemBody, callback)
          } else if (quType === 'MULTIFILLBLANK') {
            this.saveMultiFillblank(quItemBody, callback)
          } else if (quType === 'city' || quType === 'goods') {
            this.saveCasCader(quItemBody, callback)
          } else if (quType === 'CHENRADIO' || quType === 'CHENCHECKBOX' || quType === 'CHENFBK' || quType === 'CHENSCORE') {
            console.log('saveChen')
          } else {
            callback()
          }
        } else {
          callback()
        }
      },
      /* 保存单选题、复选框题 */
      saveRadioCheckboxOption (quItemBody, callback) {
        let saveTag = quItemBody.find("input[name='saveTag']").val()
        if (Number(saveTag) === 0) {
          let quType = quItemBody.find("input[name='quType']").val()
          let sortNbr = quItemBody.find("input[name='sortNbr']").val()
          let hv = Number(quItemBody.find("input[name='hv']").val())
          let quItemOptions = null
          if (hv === 3) {
            // 还有是table的情况需要处理
            quItemOptions = quItemBody.find('.quCoItem table.tableQuColItem tr td')
          } else {
            quItemOptions = quItemBody.find('.quCoItem li.quCoItemUlLi')
          }
          let quItem = []
          $.each(quItemOptions, function (i) {
            let optionValue = $(this).find('label.quCoOptionEdit').text()
            let rcFlag = $(this).find("input[name='rcFlag']").val()
            // 更新 字母 title标记到选项上.
            $(this).addClass('quOption_' + i)
            let arr = {}
            arr.listTitle = optionValue
            arr.rcFlag = rcFlag
            quItem.push(arr)
          })
          // TODO 保存
          this.saveSubject(sortNbr, quType, quItem, quItemBody, callback)
        } else {
          this.saveQus(quItemBody.next(), callback)
        }
      }, // 保存单选题
      saveFillblank (quItemBody, callback) {
        var saveTag = quItemBody.find("input[name='saveTag']").val()
        if (Number(saveTag) === 0) {
          let quType = quItemBody.find("input[name='quType']").val()
          let sortNbr = quItemBody.find("input[name='sortNbr']").val()

          // TODO 保存
          this.saveSubject(sortNbr, quType, [], quItemBody, callback)
        } else {
          this.saveQus(quItemBody.next(), callback)
        }
      }, // 保存填空题
      saveScore (quItemBody, callback) {
        var saveTag = quItemBody.find("input[name='saveTag']").val()
        if (Number(saveTag) === 0) {
          let quType = quItemBody.find("input[name='quType']").val()
//          let itemCode = quItemBody.find("input[name='itemCode']").val()
          let sortNbr = quItemBody.find("input[name='sortNbr']").val()

          let quItem = []
          // 评分题选项td
          let quItemOptions = quItemBody.find('.quCoItem table.quCoItemTable tr td.quOptionEditTd')
          $.each(quItemOptions, function (i) {
            let optionValue = $(this).find('label.quCoOptionEdit').text()
//            let rcFlag = $(this).find("input[name='rcFlag']").val()
            // 更新 字母 title标记到选项上.
            $(this).addClass('quOption_' + i)

            let arr = {}
            /* TODO 这个是服务端给的ID */
            arr.listTitle = optionValue
            arr.rcFlag = '0'
            arr.val = null
            quItem.push(arr)
          })

          // ////////////////////////////////本地存储//////////////////////////////
          this.saveSubject(sortNbr, quType, quItem, quItemBody, callback)
        } else {
          this.saveQus(quItemBody.next(), callback)
        }
      }, // 保存评分题
      saveParagraph (quItemBody, callback) {
        var saveTag = quItemBody.find("input[name='saveTag']").val()
        if (Number(saveTag) === 0) {
          let quType = quItemBody.find("input[name='quType']").val()
//          let itemCode = quItemBody.find("input[name='itemCode']").val()
          let sortNbr = quItemBody.find("input[name='sortNbr']").val()

        // ////////////////////////////////本地存储//////////////////////////////
          this.saveSubject(sortNbr, quType, [], quItemBody, callback)
        } else {
          this.saveQus(quItemBody.next(), callback)
        }
      }, // 保存段落
      saveMultiFillblank (quItemBody, callback) {
        var saveTag = quItemBody.find("input[name='saveTag']").val()
        if (Number(saveTag) === 0) {
          let quType = quItemBody.find("input[name='quType']").val()
          let quId = quItemBody.find("input[name='quId']").val()
          let orderById = quItemBody.find("input[name='orderById']").val()
          let isRequired = quItemBody.find("input[name='isRequired']").val()
          let hv = quItemBody.find("input[name='hv']").val()
          let randOrder = quItemBody.find("input[name='randOrder']").val()
          let cellCount = quItemBody.find("input[name='cellCount']").val()

          var paramInt01 = quItemBody.find("input[name='paramInt01']").val()
          var paramInt02 = quItemBody.find("input[name='paramInt02']").val()

          var data = 'belongId=' + this.questionBelongId + '&orderById=' + orderById + '&tag=' + this.svTag + '&quType=' + quType + '&quId=' + quId
          data += '&isRequired=' + isRequired + '&hv=' + hv + '&randOrder=' + randOrder + '&cellCount=' + cellCount
          data += '&paramInt01=' + paramInt01 + '&paramInt02=' + paramInt02
          console.log(data)
          var quTitleSaveTag = quItemBody.find("input[name='quTitleSaveTag']").val()
          if (quTitleSaveTag === 0) {
            var quTitle = quItemBody.find('.quCoTitleEdit').html()
            quTitle = escape(encodeURIComponent(quTitle))
            data += '&quTitle=' + quTitle
          }
          var quItem = []
          // 评分题选项td
          var quItemOptions = quItemBody.find('.quCoItem table.mFillblankTable tr td.mFillblankTableEditTd')
          $.each(quItemOptions, function (i) {
            var optionValue = $(this).find('label.quCoOptionEdit').text()
            var optionId = $(this).find(".quItemInputCase input[name='quItemId']").val()
            var quItemSaveTag = $(this).find(".quItemInputCase input[name='quItemSaveTag']").val()
            let arr = {}
            /* TODO 这个是服务端给的ID */
            arr.rowId = orderById - 1
            arr.rcFlag = 2
            arr.listCode = i
            arr.listTitle = optionValue
            arr.status = 0
            arr.isRequiredFill = this.isRequiredFill
            arr.values = ''
            quItem.push(arr)
            if (quItemSaveTag === 0) {
              optionValue = escape(encodeURIComponent(optionValue))
              data += '&optionValue_' + i + '=' + optionValue
              data += '&optionId_' + i + '=' + optionId
            }
            // 更新 字母 title标记到选项上.
            $(this).addClass('quOption_' + i)
          })
          // TODO 保存
          this.saveSubject(orderById, quType, quItem, isRequired, quItemBody, callback)
        } else {
          this.saveQus(quItemBody.next(), callback)
        }
      }, // 保存多项填空题
      saveCasCader (quItemBody, callback) {
//        var saveTag = quItemBody.find("input[name='saveTag']").val()
        let quType = quItemBody.find("input[name='quType']").val()
        let sortNbr = quItemBody.find("input[name='sortNbr']").val()
        // TODO 保存
        this.saveSubject(sortNbr, quType, [], quItemBody, callback)
//        if (Number(saveTag) === 0) {
//
//        } else {
//          this.saveQus(quItemBody.next(), callback)
//        }
      },
      /**
       * 公共返回方法
       * @param orderById 排序ID
       * @param quType 题目元素类型
       * @param quItem 多选题集合【checkbox、radio】
       * @param isRequired 是否必填
       * @param quItemBody 题目元素【radio、check、input、score】
       */
      saveSubject (sortNbr, quType, quItem, quItemBody, callback) {
        let eqIdx = +sortNbr - 1
        let params = {}
        params.title = $('#dw_body_content .editAble.quCoTitleEdit').eq(eqIdx).text().trim()
        params.status = 0
        params.enumList = quItem
        params.values = ''
        params.sortNbr = sortNbr
        params.itemCode = $(quItemBody).find("input[name='itemCode']").val()
        params.visibility = 1
        params.mustFlag = $(quItemBody).find("input[name='isRequired']").val() !== undefined ? $(quItemBody).find("input[name='isRequired']").val() : 1
        params.rowId = $(quItemBody).find("input[name='rowId']").val()
        if (quType === 'radio') {
          params.inputType = 'radio'
          params.dataType = 'string'
        } else if (quType === 'multiselect') {
          params.inputType = 'multiselect'
          params.dataType = 'string'
        } else if (quType === 'input') {
          params.inputType = 'input'
          params.dataType = 'string'
        } else if (quType === 'MULTIFILLBLANK') {
          params.inputType = '多项填空题'
          params.dataType = 'string'
        } else if (quType === 'score') {
          params.inputType = 'score'
          params.dataType = 'string'
        } else if (quType === 'PARAGRAPH') {
          params.inputType = '段落'
          params.dataType = 'string'
        } else if (quType === 'city' || quType === 'goods') {
          params.inputType = quType
          params.descText = quType
          params.dataType = 'string'
        }
        this.tmp.push(params)
        console.log('params:', params)
        // 执行保存下一题
        this.saveQus(quItemBody.next(), callback)
        // 同步-更新题目排序号
        this.quCBNum2++
        this.exeQuCBNum()
      },
      saveBtn () {
        this.tmp = []
        this.curEditCallback()
        this.dwCommonDialogHide()
        this.resetQuItemHover(null)
        this.$message('保存中...')
        this.saveSurvey(() => {
          this.isSaveProgress = false
          this.$message('保存成功')
        })
      }, // 手动保存
      publishBtn () {
        console.log('哈哈数据===', this.tmp)
        if (this.tmp.length > 0) {
          this.questionnaire.itemsList = this.tmp
          api.requestJava('POST', BasePath.FW_ITEMS_SAVEFULLFORM, this.questionnaire)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.$router.push({name: 'CustomSurvey', params: {uId: 0}})
              } else if (Number(request.data.code) === 401) {
                this.logInvalid.dialogVisible = true
              } else {
                console.log(request.data.message)
                this.$notify.error({title: '提示', message: request.data.message})
                throw new Error(JSON.stringify(request))
              }
            })
            .catch((err) => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        } else {
          this.$message('题库不能为空且保存题库')
        }
      },
      dwDialogQuSetSave () {
        /* 将必填的参数赋值到当前数据里 */
        if (this.dwDialogObj != null) {
          let quItemBody = $(this.dwDialogObj).parents('.surveyQuItemBody')
          let setIsRequired = $("#dwCommonDialog input[name='setIsRequired']:checked")
          let setRandOrder = $("#dwCommonDialog input[name='setRandOrder']:checked")
          let setHv = $("#dwCommonDialog select[name='setHv']").val()
          let setCellCount = $("#dwCommonDialog input[name='setCellCount']").val()
          let setAutoContacts = $("#dwCommonDialog input[name='setAutoContacts']:checked")
          let setContactsField = $("#dwCommonDialog select[name='setContactsField']").val()
          quItemBody.find("input[name='isRequired']").val(setIsRequired[0] ? 1 : 0)
          quItemBody.find("input[name='hv']").val(setHv)
          quItemBody.find("input[name='randOrder']").val(setRandOrder[0] ? 1 : 0)
          quItemBody.find("input[name='cellCount']").val(setCellCount)
          quItemBody.find("input[name='saveTag']").val(0)

          let quType = quItemBody.find("input[name='quType']").val()
          if (quType === 'radio' || quType === 'multiselect' || quType === 'input') {
            quItemBody.find("input[name='contactsAttr']").val(setAutoContacts[0] ? 1 : 0)
            quItemBody.find("input[name='contactsField']").val(setContactsField)
          } else if (quType === 'score') {
            quItemBody.find("input[name='paramInt01']").val(1)
            let paramInt02 = $('#dwCommonDialog .scoreMinMax .maxScore')
            if (paramInt02[0]) {
              quItemBody.find("input[name='paramInt02']").val(paramInt02.val())
            }
            // 根据分数设置评分选项
            let paramInt01Val = 1
            let paramInt02Val = paramInt02.val()
            let scoreNumTableTr = quItemBody.find('.scoreNumTable tr')
            $.each(scoreNumTableTr, function () {
              $(this).empty()
              for (let i = paramInt01Val; i <= paramInt02Val; i++) {
                $(this).append('<td>' + i + '</td>')
              }
            })
          } else if (quType === 'MULTIFILLBLANK') {
            let paramInt01 = $('#dwCommonDialog .minMaxLi .minNum')
            if (paramInt01[0]) {
              quItemBody.find("input[name='paramInt01']").val(paramInt01.val())
            }
            quItemBody.find("input[name='paramInt02']").val(10)
          }
//          let selVal = $('.option_range').val()
//          if (selVal === 1) {
//            // 横排 transverse
//            if (oldHv === 3) {
//              quTableOptoin2Li(quItemBody)
//            }
//            quItemBody.find('.quCoItem ul').addClass('transverse')
//          } else if (selVal === 2) {
//            if (oldHv === 3) {
//              quTableOptoin2Li(quItemBody)
//            } else {
//              // 竖排
//              quItemBody.find('.quCoItem ul').removeClass('transverse')
//              quItemBody.find('.quCoItem ul li').width('')
//            }
//          } else if (selVal === 3) {
//            // 转换到tr中去
//            if (oldHv === 3) {
//              if (oldCellCount !== setCellCount) { // 列数发生了变化
//                // 调查quTableOption2Table(quItemBody);
//                quTableOption2Table(quItemBody)
//              }
//            } else {
//              quLiOption2Table(quItemBody)
//            }
//          } else if (selVal === 4) {
//            // 下拉选项
//          }
        }
        this.dwCommonDialogHide()
        return false
      },
      dwCommonDialogClose () {
        this.dwCommonDialogHide()
        this.resetQuItemHover(null)
      },
      /**
       * 重置 Menu 上的 hover 事件
       * @param quItemBody
       * @returns
       */
      resetQuItemHover (quItemBody) {
        $('.surveyQuItemBody').removeClass('hover')
        $('.surveyQuItemBody').find("input[name='hoverTag']").val('0') //
        if (quItemBody !== null) {
          quItemBody.addClass('hover')
          quItemBody.find("input[name='hoverTag']").val('hover')
        }
      },
      /**
       * 编辑回调
       * @returns
       */
      curEditCallback () {
        if (this.curEditObj !== null) {
          let dwEditHtml = $('#dwComEditContent').html()
          this.setCurEditContent(dwEditHtml)
        }
        // 移除当前标题click事件
        $('#dwSurveyNote').removeClass('click')
      },
      setCurEditContent (dwEditHtml) {
        let thClass = $(this.curEditObj).attr('class')
        if (dwEditHtml === '' && thClass.indexOf('dwSvyNoteEdit') < 0) {
          // 当前元素编辑内容为空移除该元素
          this.deleteDwOption()
        } else if (dwEditHtml !== this.curEditObjOldHtml) {
          // 更新编辑内容
          $(this.curEditObj).html(dwEditHtml)
          // 修改保存状态
          this.setSaveTag0()
        }
        this.dwCommonEditHide()
      },
      /**
       *  每当 模拟input的标题改变后就改变 saveTag 的 状态
       */
      setSaveTag0 () {
        let quItemBody = $(this.curEditObj).parents('.surveyQuItemBody')
        quItemBody.find("input[name='saveTag']").val(0)
        let thClass = $(this.curEditObj).attr('class')
        if (thClass.indexOf('quCoTitleEdit') > 0) {
          // 题目标题
          $(this.curEditObj).parent().find("input[name='quTitleSaveTag']").val(0)
        } else if (thClass.indexOf('quCoOptionEdit') > 0) {
          // 题目选项
          $(this.curEditObj).parent().find("input[name='quItemSaveTag']").val(0)
        } else if (thClass.indexOf('dwSvyNoteEdit') >= 0) {
          // 问卷欢迎语
          $("input[name='svyNoteSaveTag']").val(0)
        } else if (thClass.indexOf('dwSvyName') >= 0) {
          $("input[name='svyNmSaveTag']").val(0)
        }
      },
      /* 隐藏编辑框 */
      dwCommonEditHide () {
        $('#dwCommonEditRoot').hide()
        $('.dwComEditMenuUl').hide()
        this.curEditObj = null
      },
      /* 重置 item 排序序号 */
      resetQuItem () {
        if (this.isDrag) {
          this.isDrag = false
        }
        let surveyQuItems = $('#dwSurveyQuContent .surveyQuItemBody')
        let indexNum = 1
        $.each(surveyQuItems, function (i) {
          $(this).find(".quInputCase input[name='sortNbr']").val(i + 1)
          let quType = $(this).find("input[name='quType']").val()
          if (quType !== 'PAGETAG' && quType !== 'PARAGRAPH') {
            $(this).find('.quCoTitle .quCoNum').text((indexNum++) + '、')
          }
        })
        // 更新分标标记
        let pageTags = $("#dwSurveyQuContent .surveyQuItemBody input[name='quType'][value='PAGETAG']")
        let pageTagSize = pageTags.size() + 1
        $.each(pageTags, function (i) {
          let quItemBody = $(this).parents('.surveyQuItemBody')
          let pageQuContent = quItemBody.find('.pageQuContent')
          pageQuContent.text('下一页（' + (i + 1) + '/' + pageTagSize + '）')
        })
      },
      /**
       * 初始化-绑定被拖拽进来的元素中所有事件
       * item hover
       * 单选框 hover click
       * 复选框 hover click
       * input hover click
       * 设置、删除、add、adds、address、移动........
       * @returns
       */
      bindQuHoverItem () {
        let _this = this
        // TODO 高级编辑
        // TODO 选项设置
        $("input[name='quOption_isNote']").unbind()
        $("input[name='quOption_isNote']").click(function () {
          let optionCk = $(this).prop('checked')
          if (optionCk) {
            $('.quOptionFillContentLi,.quOptionFillRequiredLi').show()
            $('#modelUIDialog').dialog('option', 'height', 230)
          } else {
            $('.quOptionFillContentLi,.quOptionFillRequiredLi').hide()
          }
        })
        // item 内容 hover 显示隐藏
        $('#dwSurveyQuContent .surveyQuItemBody').unbind()
        $('#dwSurveyQuContent .surveyQuItemBody').hover(function () {
          // 显示
          if (_this.isDrag) {
            // $(this).addClass("showLine");
            _this.appQuObj = $(this)
          } else {
            // 显示
            $(this).addClass('hover')
            $('.pageBorderTop').removeClass('nohover')
            // 如果是填空
            _this.appQuObj = $(this)
          }
        }, function () {
          $('.pageBorderTop').addClass('nohover')
          $(this).removeClass('showLine')
          let hoverTag = $(this).find("input[name='hoverTag']").val()
          if (hoverTag !== 'hover') {
            $(this).removeClass('hover')
          }
          _this.appQuObj = null
        })

        $('#dwSurveyQuContent .surveyQuItemBody').click(function () {
          _this.curEditCallback()
          _this.dwCommonDialogHide()
          $('.surveyQuItemBody').removeClass('hover')
          $('.surveyQuItemBody').find("input[name='hoverTag']").val('0')
          $(this).addClass('hover')
          return false
        })
        // 选项内容 redio
        $('.quCoItemUlLi').unbind()
        $('.quCoItemUlLi').hover(function () {
          if (!_this.isDrag) {
            $(this).addClass('hover')
          }
        }, function () {
          let thClass = $(this).attr('class')
          if (thClass.indexOf('menuBtnClick') <= 0) {
            $(this).removeClass('hover')
          }
        })

        // 绑定编辑
        $('#dwSurveyQuContent .editAble').unbind()
        $('#dwSurveyQuContent .editAble').click(function () {
          _this.editAble($(this))
          return false
        })

        // 绑定题目删除事件
        $('.dwQuDelete').unbind()
        $('.dwQuDelete').click(function () {
          let quBody = $(this).parents('.surveyQuItemBody')
          _this.$confirm('确认要删除此题吗', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            let quId = quBody.find("input[name='quId']").val()
            if (quId !== '') {
              _this.rmvQuestionnaires(quId)
              quBody.hide('slow', function () { $(this).parent().remove(); _this.resetQuItem() })
            } else {
              quBody.hide('slow', function () { $(this).parent().remove(); _this.resetQuItem() })
            }
          }).catch(() => {
            _this.$message({ type: 'info', message: '已取消删除' })
          })
          return false
        })

        $('.questionUp').unbind()
        $('.questionUp').click(function () {
          let nextQuBody = $(this).parents('.li_surveyQuItemBody')
          let prevQuBody = $(nextQuBody).prev()
          if (prevQuBody[0]) {
            let prevQuBodyHtml = prevQuBody.html()
            $(nextQuBody).after("<li class='li_surveyQuItemBody'>" + prevQuBodyHtml + '</li>')
            let newNextObj = $(nextQuBody).next()
            newNextObj.hide()
            newNextObj.slideDown('slow')
            prevQuBody.slideUp('slow', function () {
              prevQuBody.remove()
              _this.resetQuItem()
              _this.bindQuHoverItem()
            })
            nextQuBody.find("input[name='saveTag']").val(0)
            newNextObj.find("input[name='saveTag']").val(0)
          } else {
            _this.$message('已经是第一个了！')
          }
        })

        $('.questionDown').unbind()
        $('.questionDown').click(function () {
          let prevQuBody = $(this).parents('.li_surveyQuItemBody')
          let nextQuBody = $(prevQuBody).next()
          if (nextQuBody[0]) {
            let nextQuBodyHtml = nextQuBody.html()
            $(prevQuBody).before("<li class='li_surveyQuItemBody' >" + nextQuBodyHtml + '</li>')
            let newPrevObj = $(prevQuBody).prev()
            newPrevObj.hide()
            newPrevObj.slideDown('slow')
            nextQuBody.slideUp('slow', function () { nextQuBody.remove(); _this.resetQuItem(); _this.bindQuHoverItem() })

            prevQuBody.find("input[name='saveTag']").val(0)
            newPrevObj.find("input[name='saveTag']").val(0)
          } else {
            alert('已经是最后一个了！')
          }
        })
        // 设置-标题文本-此题必答
        $('.dwQuSet').unbind()
        $('.dwQuSet').click(function () {
          _this.showDialog($(this))
          let quItemBody = $(this).parents('.surveyQuItemBody')
          _this.resetQuItemHover(quItemBody)
          return false
        })
        // 设置-标题文本-逻辑设置
        $('.dwQuLogic').unbind()
        $('.dwQuLogic').click(function () {
          _this.showDialog($(this))
          let quItemBody = $(this).parents('.surveyQuItemBody')
          let quType = quItemBody.find("input[name='quType']").val()
          // 默认加载图标
          let fristQuItemBody = $('#dwSurveyQuContent .li_surveyQuItemBody').first()
          _this.saveQus(fristQuItemBody, function () {
            $('.dwQuDialogCon').hide()
            $('#dwCommonDialog .dwQuDialogLogic').show()

            _this.resetQuItemHover(quItemBody)
            _this.bindDialogRemoveLogic()

            $('#dwQuLogicTable').empty()
            // 逻辑数据回显示
            let quLogicItems = quItemBody.find('.quLogicItem')
            if (quLogicItems[0]) {
              $.each(quLogicItems, function () {
                let skQuId = $(this).find("input[name='skQuId']").val()
                let cgQuItemId = $(this).find("input[name='cgQuItemId']").val()
                let logicType = $(this).find("input[name='logicType']").val()
              // 设置分数 geLe scoreNum
                let geLe = ''
                let scoreNum = ''
                if (quType === 'score') {
                  geLe = $(this).find("input[name='geLe']").val()
                  scoreNum = $(this).find("input[name='scoreNum']").val()
                }

                let thClass = $(this).attr('class')
                thClass = thClass.replace('quLogicItem', '')
                thClass = thClass.replace(' ', '')
              // 回显相应的选项
                this.addQuDialogLogicTr(false, function () {
                  // 执行成功--设置值

                  let lastTr = $('#dwQuLogicTable').find('tr').last()
                  lastTr.attr('class', thClass)
                  lastTr.find('.logicQuOptionSel').val(cgQuItemId)
                  lastTr.find('.logicQuSel').val(skQuId)
                  lastTr.find('.logicType').val(logicType)

                  lastTr.find('.logicQuOptionSel').change()
                  lastTr.find('.logicQuSel').change()

                // 设置分数 geLe scoreNum
                  if (quType === 'score') {
                    lastTr.find('.logicScoreGtLt').val(geLe)
                    lastTr.find('.logicScoreNum').val(scoreNum)
                  }
                }, function () {})
              })
            } else {
              $('.dwQuDialogAddLogic').click()
            }
          })
          return false
        })
        // 添加行选项
        $('.addOption,.addColumnOption,.addRowOption').unbind()
        $('.addOption,.addColumnOption,.addRowOption').click(function () {
          let quItemBody = $(this).parents('.surveyQuItemBody')
          let quType = quItemBody.find("input[name='quType']").val()
          if (quType === 'radio') {
            // 添加单选选项
            _this.editAble(_this.addRadioItem(quItemBody, ''))
          } else if (quType === 'multiselect') {
            _this.editAble(_this.addCheckboxItem(quItemBody, ''))
          } else if (quType === 'score') {
            _this.editAble(_this.addScoreItem(quItemBody, '新选项'))
          } else if (quType === 'ORDERQU') {
//           _this.editAble(addOrderquItem(quItemBody, '新选项'))
          } else if (quType === 'MULTIFILLBLANK') {
            _this.editAble(_this.addMultiFillblankItem(quItemBody, '新选项'))
          } else if (quType === 'CHENRADIO' || quType === 'CHENCHECKBOX' || quType === 'CHENFBK' || quType === 'CHENSCORE') { // 矩陈单选题,矩阵多选题
//            _this.editAble(addChenItem($(this), quItemBody, '新选项'))
          }
          _this.bindQuHoverItem()
          return false
        })
        // 批量添加事件
        $('.addMoreOption,.addMoreRowOption,.addMoreColumnOption').unbind()
        $('.addMoreOption,.addMoreRowOption,.addMoreColumnOption').click(function () {
          _this.showDialog($(this))
          let quItemBody = $(this).parents('.surveyQuItemBody')
          _this.resetQuItemHover(quItemBody)
          return false
        })
        // 填空题选项设置
        $('.quFillblankItem .dwFbMenuBtn').unbind()
        $('.quFillblankItem .dwFbMenuBtn').click(function () {
          // showDialog($(this));
          this.showUIDialog($(this))
          return false
        })

        $('.dwOptionUp').unbind()
        $('.dwOptionUp').click(function () {
          // 判断类型区别table跟ul中的排序
          let quItemBody = $(_this.curEditObj).parents('.surveyQuItemBody')
          let quType = quItemBody.find("input[name='quType']").val()
          let hv = quItemBody.find("input[name='hv']").val()
          if (hv === 3) {
            let nextTd = $(_this.curEditObj).parents('td')
            let prevTd = nextTd.prev()
            if (prevTd[0]) {
              dwOptionUp(prevTd, nextTd)
            } else {
              let nextTr = $(_this.curEditObj).parents('tr')
              let prevTr = nextTr.prev()
              if (prevTr[0]) {
                prevTd = prevTr.find('td').last()
                _this.$message('需要调用dwOptionUp1')
                dwOptionUp1(prevTr, nextTr)
              } else {
                alert('已经是第一个了！')
              }
            }
          } else {
            let nextLi = null
            let prevLi = null
            let nextLiAfterHtml = ''
            if (quType === 'radio' || quType === 'multiselect' || quType === 'ORDERQU') {
              nextLi = $(_this.curEditObj).parents('li.quCoItemUlLi')
              prevLi = nextLi.prev()
              let prevLiHtml = prevLi.html()
              nextLiAfterHtml = "<li class='quCoItemUlLi'>" + prevLiHtml + '</li>'
            } else if (quType === 'score') {
              nextLi = $(_this.curEditObj).parents('tr.quScoreOptionTr')
              prevLi = nextLi.prev()
              let prevLiHtml = prevLi.html()
              nextLiAfterHtml = "<tr class='quScoreOptionTr'>" + prevLiHtml + '</tr>'
            } else if (quType === 'MULTIFILLBLANK') {
              nextLi = $(_this.curEditObj).parents('tr.mFillblankTableTr')
              prevLi = nextLi.prev()
              let prevLiHtml = prevLi.html()
              nextLiAfterHtml = "<tr class='mFillblankTableTr'>" + prevLiHtml + '</tr>'
            } else if (quType === 'CHENRADIO' || quType === 'CHENCHECKBOX' || quType === 'CHENSCORE' || quType === 'CHENFBK') {
              nextLi = $(_this.curEditObj).parents('tr.quChenRowTr')
              if (nextLi[0]) {
                prevLi = nextLi.prev()
                let prevLiHtml = prevLi.html()
                nextLiAfterHtml = "<tr class='quChenRowTr'>" + prevLiHtml + '</tr>'
              } else {
                nextLi = $(_this.curEditObj).parents('td.quChenColumnTd')
                prevLi = nextLi.prev()
                let prevLiHtml = prevLi.html()
                nextLiAfterHtml = "<td class='quChenColumnTd'>" + prevLiHtml + '</td>'
              }
            }
            if (nextLi !== null) {
              if (prevLi[0]) {
                $(nextLi).after(nextLiAfterHtml)
                prevLi.hide()
                prevLi.remove()
                let editOffset = nextLi.find('label.editAble').offset()
                $('#dwCommonEditRoot').show()
                $('#dwCommonEditRoot').offset({top: editOffset.top, left: editOffset.left})
                _this.bindQuHoverItem()
                $(_this.curEditObj).click()
                $(nextLi).find("input[name='quItemSaveTag']").val(0)
                $(nextLi).next().find("input[name='quItemSaveTag']").val(0)
                let quItemBody = $(_this.curEditObj).parents('.surveyQuItemBody')
                quItemBody.find("input[name='saveTag']").val(0)
              } else {
                alert('已经是第一个了！')
              }
            }
          }
          return false
        })

        function dwOptionUp (prevTd, nextTd) {
          let prevTdHtml = prevTd.html()
          $(nextTd).after('<td>' + prevTdHtml + '</td>')
          prevTd.hide()
          prevTd.remove()
          let editOffset = nextTd.find('label.editAble').offset()
          $('#dwCommonEditRoot').show()
          $('#dwCommonEditRoot').offset({top: editOffset.top, left: editOffset.left})
          _this.bindQuHoverItem()
          $(_this.curEditObj).click()
          $(nextTd).find("input[name='quItemSaveTag']").val(0)
          $(nextTd).next().find("input[name='quItemSaveTag']").val(0)
          let quItemBody = $(_this.curEditObj).parents('.surveyQuItemBody')
          quItemBody.find("input[name='saveTag']").val(0)
        }

        function dwOptionUp1 (prevTr, nextTr) {
          let prevTd = prevTr.find('td').last()
          let nextTd = nextTr.find('td').first()

          let prevTdHtml = prevTd.html()
          let nextTdHtml = nextTd.html()

          prevTd.before('<td>' + nextTdHtml + '</td>')
          $(nextTd).after('<td>' + prevTdHtml + '</td>')

          prevTd.hide()
          prevTd.remove()

          nextTd.hide()
          nextTd.remove()

          prevTd = prevTr.find('td').last()
          nextTd = nextTr.find('td').first()

          _this.curEditObj = prevTd.find('label.editAble')
          let editOffset = prevTd.find('label.editAble').offset()
          $('#dwCommonEditRoot').show()
          $('#dwCommonEditRoot').offset({top: editOffset.top, left: editOffset.left})
          _this.bindQuHoverItem()
          $(_this.curEditObj).click()
          $(prevTd).find("input[name='quItemSaveTag']").val(0)
          $(nextTd).find("input[name='quItemSaveTag']").val(0)
          let quItemBody = $(_this.curEditObj).parents('.surveyQuItemBody')
          quItemBody.find("input[name='saveTag']").val(0)
        }

        $('.dwOptionDown').unbind()
        $('.dwOptionDown').click(function () {
          // 判断类型区别table跟ul中的排序
          let quItemBody = $(_this.curEditObj).parents('.surveyQuItemBody')
          let quType = quItemBody.find("input[name='quType']").val()
          let hv = quItemBody.find("input[name='hv']").val()
          if (hv === 3) {
            let prevTd = $(_this.curEditObj).parents('td')
            let nextTd = prevTd.next()
            if (nextTd[0]) {
              dwOptionDown(prevTd, nextTd)
            } else {
              let nextTr = $(_this.curEditObj).parents('tr')
              let prevTr = nextTr.prev()
              if (prevTr[0]) {
                prevTd = prevTr.find('td').last()
                _this.$message('需要调用dwOptionUp1')
                dwOptionUp1(prevTr, nextTr)
              } else {
                alert('已经是第一个了！')
              }
            }
          } else {
            let prevLi = null
            let nextLi = null
            let prevLiBeforeHtml = ''
            if (quType === 'radio' || quType === 'multiselect' || quType === 'ORDERQU') {
              prevLi = $(_this.curEditObj).parents('li.quCoItemUlLi')
              nextLi = prevLi.next()
              let nextLiHtml = nextLi.html()
              prevLiBeforeHtml = "<li class='quCoItemUlLi'>" + nextLiHtml + '</li>'
            } else if (quType === 'score') {
              prevLi = $(_this.curEditObj).parents('tr.quScoreOptionTr')
              nextLi = prevLi.next()
              let nextLiHtml = nextLi.html()
              prevLiBeforeHtml = "<tr class='quScoreOptionTr'>" + nextLiHtml + '</tr>'
            } else if (quType === 'MULTIFILLBLANK') {
              prevLi = $(_this.curEditObj).parents('tr.mFillblankTableTr')
              nextLi = prevLi.next()
              let nextLiHtml = nextLi.html()
              prevLiBeforeHtml = "<tr class='mFillblankTableTr'>" + nextLiHtml + '</tr>'
            } else if (quType === 'CHENRADIO' || quType === 'CHENCHECKBOX' || quType === 'CHENSCORE' || quType === 'CHENFBK') {
              prevLi = $(_this.curEditObj).parents('tr.quChenRowTr')
              if (prevLi[0]) {
                nextLi = prevLi.next()
                let nextLiHtml = nextLi.html()
                prevLiBeforeHtml = "<tr class='quChenRowTr'>" + nextLiHtml + '</tr>'
              } else {
                prevLi = $(_this.curEditObj).parents('td.quChenColumnTd')
                nextLi = prevLi.next()
                let nextLiHtml = nextLi.html()
                prevLiBeforeHtml = "<td class='quChenColumnTd'>" + nextLiHtml + '</td>'
              }
            }

            if (nextLi[0]) {
              $(prevLi).before(prevLiBeforeHtml)
              nextLi.hide()
              nextLi.remove()
              let editOffset = prevLi.find('label.editAble').offset()
              $('#dwCommonEditRoot').show()
              $('#dwCommonEditRoot').offset({top: editOffset.top, left: editOffset.left})
              _this.bindQuHoverItem()
              $(_this.curEditObj).click()
              $(prevLi).find("input[name='quItemSaveTag']").val(0)
              $(prevLi).prev().find("input[name='quItemSaveTag']").val(0)
              let quItemBody = $(_this.curEditObj).parents('.surveyQuItemBody')
              quItemBody.find("input[name='saveTag']").val(0)
            } else {
              alert('已经是最后一个了！')
            }
          }

          return false
        })

        function dwOptionDown (prevTd, nextTd) {
          let nextTdHtml = nextTd.html()
          $(prevTd).before('<td>' + nextTdHtml + '</td>')
          nextTd.hide()
          nextTd.remove()
          let editOffset = prevTd.find('label.editAble').offset()
          $('#dwCommonEditRoot').show()
          $('#dwCommonEditRoot').offset({top: editOffset.top, left: editOffset.left})
          _this.bindQuHoverItem()
          $(_this.curEditObj).click()
          $(prevTd).find("input[name='quItemSaveTag']").val(0)
          $(prevTd).next().find("input[name='quItemSaveTag']").val(0)
          let quItemBody = $(_this.curEditObj).parents('.surveyQuItemBody')
          quItemBody.find("input[name='saveTag']").val(0)
        }

        $('.dwOptionDel').unbind()
        $('.dwOptionDel').click(function () {
          _this.deleteDwOption()
          return false
        })

      // TODO 三级联动
      },
      // 显示弹出层
      showUIDialog (thDialogObj) {
        this.$message('显示弹出层')
      },
      /**
       * 点击标题，更改标题为编辑状态
       */
      editAble (editAbleObj) {
//        debugger
        this.dwCommonDialogHide()
        this.curEditCallback()
        let quItemBody = $(editAbleObj).parents('.surveyQuItemBody')
        this.resetQuItemHover(quItemBody)
        let thClass = $(editAbleObj).attr('class')
        let editOffset = $(editAbleObj).offset()
        $('#dwCommonEditRoot').removeClass()
        if (thClass.indexOf('quCoTitleEdit') > 0) {
          // 题目标题
          $('#dwCommonEditRoot').addClass('quEdit')
        } else if (thClass.indexOf('quCoOptionEdit') > 0) {
          // 题目选项
          $('#dwCommonEditRoot').addClass('quOptionEdit')
        } else if (thClass.indexOf('dwSvyNoteEdit') >= 0) {
          // 问卷欢迎语
          $('#dwCommonEditRoot').addClass('svyNoteEdit')
        } else if (thClass.indexOf('dwSvyName') >= 0) {
          $('#dwCommonEditRoot').addClass('svyName')
        }
        let itemCode = quItemBody.find("input[name='itemCode']").val()
        let rowId = quItemBody.find("input[name='rowId']").val()
        /* copy 的表单是不能修改的 */
        if (itemCode === rowId || rowId === undefined) {
          $('#dwCommonEditRoot').show()
          $('#dwCommonEditRoot').offset({top: editOffset.top, left: editOffset.left})
          $('#dwComEditContent').focus()
        }
        $('#dwComEditContent').html($(editAbleObj).html())
        let dwEditWidth = $(editAbleObj).width()

        if (thClass.indexOf('dwSvyNoteEdit') < 0 && thClass.indexOf('dwSvyName') < 0) {
          let hv = quItemBody.find("input[name='hv']").val()
          if (hv === 3) {
            let dwEditText = $(editAbleObj).text()
            if (dwEditText === '') {
              dwEditWidth = $(editAbleObj).parents('td').width() - 52
            }
            dwEditWidth > 600 ? dwEditWidth = 600 : dwEditWidth
          } else {
            dwEditWidth < 200 ? dwEditWidth = 200 : dwEditWidth > 600 ? dwEditWidth = 600 : dwEditWidth
          }
        } else {
          dwEditWidth = 680
        }

        $('#dwCommonEditRoot .dwCommonEdit').css('width', dwEditWidth)
        this.setSelectText($('#dwComEditContent'))
        this.curEditObj = $(editAbleObj)
        this.curEditObjOldHtml = $(editAbleObj).html()
      },
      setSelectText (el) {
        try {
          window.getSelection().selectAllChildren(el[0]) // 全选
          window.getSelection().collapseToEnd(el[0]) // 光标置后
        } catch (err) {
          console.error(err)
        }
      },
      rmvQuestionnaires (quId) {
        this.$message('删除题目')
      },
      bindDialogRemoveLogic () {
        this.$message(this.msg)
      },
      /* 某隐藏层隐藏 */
      dwCommonDialogHide () {
        $('#dwCommonDialog').hide()
        $('.menuBtnClick').removeClass('menuBtnClick')
        this.dwDialogObj = null
      },
      /* 添加逻辑选项 */
      addQuDialogLogicTr (autoClass, trueCallback, falseCallback) {
        this.$message('添加逻辑选项')
      },
      /* 添加单选题选项 */
      addRadioItem (quItemBody, itemText) {
        // 得判断是否是table类型
        let hv = Number(quItemBody.find("input[name='hv']").val())
        let cellCount = quItemBody.find("input[name='cellCount']").val()
        let newEditObj = null
        if (hv === 3) {
          // 表格处理
          let quRadioItemHtml = $('#quRadioItem').html()
          let quTableObj = quItemBody.find('.quCoItem table.tableQuColItem')
          let emptyTdDiv = quTableObj.find('div.emptyTd')
          if (emptyTdDiv[0]) {
            // 表示有空位
            let emptyTd = emptyTdDiv.first().parents('td')
            emptyTd.empty()
            emptyTd.append(this.quRadioItemHtml)
          } else {
            // 木有空位，根据cellCount生成新的tr,td
            let appendTr = '<tr>'
            for (let i = 0; i < cellCount; i++) {
              appendTr += '<td>'
              if (i === 0) {
                appendTr += quRadioItemHtml
              } else {
                appendTr += "<div class='emptyTd'></div>"
              }
              appendTr += '</td>'
            }
            appendTr += '</tr>'
            quTableObj.append(appendTr)
          }
          let tdWidth = parseInt(600 / cellCount)
          let tdLabelWidth = tdWidth - 10
          quItemBody.find('.quCoItem .tableQuColItem tr td').width(tdWidth)
          quItemBody.find('.quCoItem .tableQuColItem tr td label').width(tdLabelWidth)
          newEditObj = quItemBody.find('.quCoItem table').find('.editAble').last()
        } else {
          // ul li处理
          let quRadioItemHtml = $('#quRadioItem').html()
          let quCoItemUl = quItemBody.find('.quCoItem ul')
          quCoItemUl.append("<li class='quCoItemUlLi'>" + quRadioItemHtml + '</li>')
          quItemBody.find("input[name='saveTag']").val(0)
          newEditObj = quCoItemUl.find('li:last .editAble')
        }
        newEditObj.text(itemText)
        if (itemText === '') {
//          newEditObj.css('display', 'inline')
        }
        return newEditObj
      },
      addCheckboxItem (quItemBody, itemText) {
        let hv = quItemBody.find("input[name='hv']").val()
        let cellCount = quItemBody.find("input[name='cellCount']").val()
        let newEditObj = null
        if (hv === 3) {
          // 表格处理
          let quRadioItemHtml = $('#quCheckboxItem').html()
          let quTableObj = quItemBody.find('.quCoItem table.tableQuColItem')
          let emptyTdDiv = quTableObj.find('div.emptyTd')
          if (emptyTdDiv[0]) {
            // 表示有空位
            let emptyTd = emptyTdDiv.first().parents('td')
            emptyTd.empty()
            emptyTd.append(quRadioItemHtml)
          } else {
            // 木有空位，根据cellCount生成新的tr,td
            let appendTr = '<tr>'
            for (let i = 0; i < cellCount; i++) {
              appendTr += '<td>'
              if (i === 0) {
                appendTr += quRadioItemHtml
              } else {
                appendTr += "<div class='emptyTd'></div>"
              }
              appendTr += '</td>'
            }
            appendTr += '</tr>'
            quTableObj.append(appendTr)
          }
          let tdWidth = parseInt(600 / cellCount)
          let tdLabelWidth = tdWidth - 10
          quItemBody.find('.quCoItem .tableQuColItem tr td').width(tdWidth)
          quItemBody.find('.quCoItem .tableQuColItem tr td label').width(tdLabelWidth)
          newEditObj = quItemBody.find('.quCoItem table').find('.editAble').last()
        } else {
          // ul li处理
          let quRadioItemHtml = $('#quCheckboxItem').html()
          let quCoItemUl = quItemBody.find('.quCoItem ul')
          quCoItemUl.append("<li class='quCoItemUlLi'>" + quRadioItemHtml + '</li>')
          quItemBody.find("input[name='saveTag']").val(0)
          newEditObj = quCoItemUl.find('li:last .editAble')
        }
        newEditObj.text(itemText)
        if (itemText === '') {
          newEditObj.css('display', 'inline')
        }
        return newEditObj
      },
      addMultiFillblankItem (quItemBody, itemText) {
        // 得判断是否是table类型
        var newEditObj = null
      // ul li处理
        var quScoreItemHtml = $('#mFillblankTableModel').html()
        var quCoItemTable = quItemBody.find('table.mFillblankTable')
        quCoItemTable.append("<tr class='mFillblankTableTr'>" + quScoreItemHtml + '</tr>')
        quItemBody.find("input[name='saveTag']").val(0)
        newEditObj = quCoItemTable.find('tr.mFillblankTableTr:last .editAble')
        newEditObj.text(itemText)
        if (itemText === '') {
          newEditObj.css('display', 'inline')
        }
        return newEditObj
      },
      addScoreItem (quItemBody, itemText) {
        // 得判断是否是table类型
        let newEditObj = null
        // ul li处理
        let quScoreItemHtml = $('#quScoreItemModel').html()
        let quCoItemTable = quItemBody.find('table.quCoItemTable')
        quCoItemTable.append("<tr class='quScoreOptionTr'>" + quScoreItemHtml + '</tr>')
        quItemBody.find("input[name='saveTag']").val(0)

        let scoreNumTableTr = quCoItemTable.find('tr.quScoreOptionTr:last  .scoreNumTable tr')
        let paramInt02 = quItemBody.find("input[name='paramInt02']").val()
        scoreNumTableTr.empty()
        for (let i = 1; i <= paramInt02; i++) {
          scoreNumTableTr.append('<td>' + i + '</td>')
        }
        quCoItemTable.find("tr.quScoreOptionTr:last input[name='quItemSaveTag']").val(0)

        newEditObj = quCoItemTable.find('tr.quScoreOptionTr:last .editAble')

        newEditObj.text(itemText)
        if (itemText === '') {
          newEditObj.css('display', 'inline')
        }
        return newEditObj
      },
      /* 删除单选、复选框按钮 */
      deleteRadioCheckBoxOption () {
        // 判断是否是table类型
        let quItemBody = $(this.curEditObj).parents('.surveyQuItemBody')
        let hv = quItemBody.find("input[name='hv']").val()
        let optionParent = null
        if (hv === 3) {
          optionParent = $(this.curEditObj).parents('td')
        } else {
          optionParent = $(this.curEditObj).parents('li.quCoItemUlLi')
        }
        let quOptionId = $(optionParent).find("input[name='quItemId']").val()
        if (quOptionId !== '' && quOptionId !== '0') {
          this.delQuOptionCallBack(optionParent)
        } else {
          this.delQuOptionCallBack(optionParent)
        }
      },
      /* 删除文本输入框、评分 */
      deleteScoreFillblankOption () {
        var optionParent = null
        optionParent = $(this.curEditObj).parents('tr.mFillblankTableTr')
        var quOptionId = $(optionParent).find("input[name='quItemId']").val()
        if (quOptionId !== '' && quOptionId !== '0') {
          this.$message('调用删除接口')
//          this.delQuOptionCallBack(optionParent)
        } else {
          this.delQuOptionCallBack(optionParent)
        }
      },
      /* 删除元素回调方法 */
      delQuOptionCallBack (optionParent) {
        let quItemBody = $(optionParent).parents('.surveyQuItemBody')
        let quType = quItemBody.find("input[name='quType']").val()
        if (quType === 'multiselect' || quType === 'radio') {
          let hv = Number
          if (hv === 3) {
            // emptyTd
            let optionTr = $(optionParent).parents('tr')
            let optionNextTr = optionTr.next()
            if (optionNextTr[0]) {
              // 则后面还有是中间选项，则删除，再依次后面的td往前移动
              $(optionParent).remove()
              this.moveTabelTd(optionNextTr)
            } else {
              // 非中间选项，删除-再添加一个空td
              $(optionParent).remove()
              this.movePareseLastTr(optionTr)
            }
          } else {
            optionParent.remove()
          }
        } else if (quType === 'CHENRADIO' || quType === 'CHENCHECKBOX' || quType === 'CHENFBK' || quType === 'CHENSCORE') {
          let quCoChenTable = optionParent.parents('table.quCoChenTable')
          let optionParentClass = optionParent.attr('class')
          if (optionParentClass.indexOf('Column') >= 0) {
            let removeTrs = quCoChenTable.find('tr:gt(0)')
            $.each(removeTrs, function () {
              $(this).find('td:last').remove()
            })
            optionParent.remove()
          } else {
            optionParent.parent().remove()
          }
        } else {
          optionParent.remove()
        }
        this.dwCommonEditHide()
        this.bindQuHoverItem()
      },
      deleteDwOption () {
        if (this.curEditObj !== null) {
          let quItemBody = $(this.curEditObj).parents('.surveyQuItemBody')
          let quType = quItemBody.find("input[name='quType']").val()
          if (quType === 'radio' || quType === 'multiselect') {
            // 删除单选、复选选项
            this.deleteRadioCheckBoxOption()
          } else if (quType === 'score') {
            this.deleteScoreFillblankOption()
          } else if (quType === 'ORDERQU') {
//            deleteOrderquOption();
          } else if (quType === 'MULTIFILLBLANK') {
            this.deleteScoreFillblankOption()
          } else if (quType === 'CHENRADIO' || quType === 'CHENCHECKBOX' || quType === 'CHENFBK' || quType === 'CHENSCORE') {
//            deleteChenOption();
          }
        }
      },
      moveTabelTd (nextTr) {
        if (nextTr[0]) {
          let prevTr = nextTr.prev()
          let nextTds = nextTr.find('td')
          $(nextTds.get(0)).appendTo(prevTr)
        // 判断当前next是否是最后一个，是则：判断如果没有选项，则删除tr,如果有选项，则填一个空td
          let nextNextTr = nextTr.next()
          if (!nextNextTr[0]) {
            this.movePareseLastTr(nextTr)
          }
          this.moveTabelTd($(nextTr).next())
        }
      },
      movePareseLastTr (nextTr) {
        let editAbles = nextTr.find('.editAble')
        if (editAbles[0]) {
          // 有选项，则补充一个空td
          let editAbleTd = editAbles.parents('td')
          editAbleTd.clone().prependTo(nextTr)
          nextTr.find('td').last().html("<div class='emptyTd'></div>")
        } else {
          nextTr.remove()
        }
      },
      exeQuCBNum () {
        if (this.quCBNum === this.quCBNum2) {
          this.quCBNum = 0
          this.quCBNum2 = 0
        // 全部题排序号同步一次
        // 对如新增插入题-需要同步调整其它题的排序
        // 对如删除题-需要同步调整其它题的排序
        }
      },
      setShowDialogOffset (thDialogObj) {
        var thObjClass = thDialogObj.attr('class')
        if (thObjClass.indexOf('dwFbMenuBtn') < 0 && thObjClass.indexOf('quCoOptionEdit') < 0) {
          var thOffset = thDialogObj.offset()
          $('#dwCommonDialog').show(0, function () {
            var thOffsetTop = thOffset.top
            var thOffsetLeft = thOffset.left + 40
            var dwCommonRefIcon = $('#dwCommonDialog').find('.dwCommonRefIcon')
            dwCommonRefIcon.removeClass('right')
            dwCommonRefIcon.removeClass('left')
            // 自动根据x坐标来判断，取代之前固定的方式，更加灵活
            this.browseWidth = $(window).width()
            this.browseHeight = $(window).height()
            if ((thOffsetLeft - 100) > this.browseWidth / 2) {
              thOffsetLeft = thOffsetLeft - $('#dwCommonDialog').width() - 50
              dwCommonRefIcon.addClass('right')
            } else {
              dwCommonRefIcon.addClass('left')
            }
            $('#dwCommonDialog').offset({ top: thOffsetTop, left: thOffsetLeft })
          })
        }
      },
      /* 显示弹出层 */
      showDialog (thDialogObj) {
        let thObjClass = thDialogObj.attr('class')
        this.curEditCallback()
        let quItemBody = $(thDialogObj).parents('.surveyQuItemBody')
        $('#dwCommonDialog .dwQuDialogCon').hide()
        if (thObjClass.indexOf('addMoreOption') >= 0) {
          $('#dwCommonDialog .dwQuAddMore').show()
        } else if (thObjClass.indexOf('dwQuSet') >= 0) {
          $('#dwCommonDialog .dwQuSetCon').show()
          let quType = quItemBody.find("input[name='quType']").val()
          let isRequired = quItemBody.find("input[name='isRequired']").val()
          let hv = quItemBody.find("input[name='hv']").val()
          let randOrder = quItemBody.find("input[name='randOrder']").val()
          let cellCount = quItemBody.find("input[name='cellCount']").val()
          let paramInt01 = quItemBody.find("input[name='paramInt01']")
          let paramInt02 = quItemBody.find("input[name='paramInt02']")

          let contactsAttr = quItemBody.find("input[name='contactsAttr']").val()
          let contactsField = quItemBody.find("input[name='contactsField']").val()

          $("#dwCommonDialog input[name='setIsRequired']").prop('checked', false)
          $("#dwCommonDialog input[name='setRandOrder']").prop('checked', false)
          $("#dwCommonDialog select[name='setHv']").val(2)
          $("#dwCommonDialog input[name='setAutoContacts']").prop('checked', false)
          $('#dwCommonDialog .contactsFieldLi').hide()
          $('#dwCommonDialog .contactsAttrLi').hide()
          $('#dwCommonDialog .optionAutoOrder').hide()
          $('#dwCommonDialog .optionRangeHv').hide()
          $('#dwCommonDialog .scoreMinMax').hide()
          $('#dwCommonDialog .minMaxLi').hide()

          if (Number(isRequired) === 1) {
            $("#dwCommonDialog input[name='setIsRequired']").prop('checked', true)
          }
          if (Number(randOrder) === 1) {
            $("#dwCommonDialog input[name='setRandOrder']").prop('checked', true)
          }
          if (hv === 3) {
            $('#dwCommonDialog .option_range_3').show()
          } else {
            $('#dwCommonDialog .option_range_3').hide()
          }
          $("#dwCommonDialog select[name='setHv']").val(hv)
          $("#dwCommonDialog input[name='setCellCount']").val(cellCount)

        // 单选，多选 才启用选项随机排列
          if (quType === 'radio' || quType === 'multiselect') {
            $('#dwCommonDialog .optionAutoOrder').show()
            $('#dwCommonDialog .optionRangeHv').show()
          } else if (quType === 'ORDERQU') {
            $('#dwCommonDialog .optionAutoOrder').show()
          } else if (quType === 'score') {
            $('#dwCommonDialog .optionAutoOrder').show()
            $('#dwCommonDialog .scoreMinMax').show()
            if (paramInt02[0]) {
              $('#dwCommonDialog .scoreMinMax .maxScore').val(paramInt02.val())
            }
          } else if (quType === 'MULTIFILLBLANK') {
            $('#dwCommonDialog .optionAutoOrder').show()
            $('#dwCommonDialog .minMaxLi').show()
            $('#dwCommonDialog .minMaxLi .minSpan .lgleftLabel').text('最少回答')
            $('#dwCommonDialog .minMaxLi .maxSpan').hide()
            $('#dwCommonDialog .minMaxLi .lgRightLabel').text('项')
            if (paramInt01[0]) {
              $('#dwCommonDialog .minMaxLi .minNum').val(paramInt01.val())
            }
          }

          // 单选，多选，填空题情况下才启用关联到联系设置项
          if ((quType === 'radio' || quType === 'multiselect' || quType === 'input')) {
            $('#dwCommonDialog .contactsAttrLi').show()
            if (contactsAttr === 1) {
              $("#dwCommonDialog input[name='setAutoContacts']").prop('checked', true)
              $('#dwCommonDialog .contactsFieldLi').show()
              $("#dwCommonDialog select[name='setContactsField']").val(contactsField)
            }
          }
        } else if (thObjClass.indexOf('dwQuLogic') >= 0) {
          $('#dwCommonDialog .dwQuDialogLoad').show()
        } else if (thObjClass.indexOf('dwFbMenuBtn') >= 0) {
          $('#dwCommonDialog .dwQuFillDataTypeOption').show()
          let checkTypeVal = quItemBody.find("input[name='checkType']").val()
          if (checkTypeVal === '') {
            checkTypeVal = 'NO'
          }
          let checkType = $("#dwCommonDialog select[name='quFill_checkType']")
          checkType.val(checkTypeVal)
        } else if (thObjClass.indexOf('quCoOptionEdit') >= 0) {
          $('#dwCommonDialog .dwQuRadioCheckboxOption').show()
        // 设置回显值 isNote checkType
          let quOptionIsNote = $("#dwCommonDialog input[name='quOption_isNote']")
          let quOptionCheckType = $("#dwCommonDialog select[name='quOption_checkType']")
          let quOptionIsRequiredFill = $("#dwCommonDialog input[name='quOption_isRequiredFill']")

          let quOptionParent = $(thDialogObj).parent()
          let isNoteVal = quOptionParent.find("input[name='isNote']").val()
          let checkTypeVal = quOptionParent.find("input[name='checkType']").val()
          let isRequiredFillVal = quOptionParent.find("input[name='isRequiredFill']").val()

          if (isNoteVal === '1') {
            quOptionIsNote.prop('checked', true)
            $('.quOptionFillContentLi,.quOptionFillRequiredLi').show()
          } else {
            quOptionIsNote.prop('checked', false)
            $('.quOptionFillContentLi,.quOptionFillRequiredLi').hide()
          }
          if (checkTypeVal === '') {
            checkTypeVal = 'NO'
          }
          quOptionCheckType.val(checkTypeVal)
          if (isRequiredFillVal === '1') {
            quOptionIsRequiredFill.prop('checked', true)
          } else {
            quOptionIsRequiredFill.prop('checked', false)
          }
        } else {
          // 暂时加的
          $('#dwCommonDialog .dwQuAddMore').show()
        }
        this.dwDialogObj = thDialogObj
        this.setShowDialogOffset(thDialogObj)
      },
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      } //  session 失效
    },
    components: {
      _RADIO,
      _CHECKBOX,
      _INPUT,
      _SCORE,
      _INPUTS,
      _PARAGRAPH,
      _CASCADER,
//      _INFO,
      SUB_RADIO,
      SUB_CHECKBOX,
      SUB_FILLBLANK,
      SUB_FILLBLANKS,
      SUB_SCORE,
      SUB_PARAGRAPH,
      SUB_CASCADER,
      _POPUP
    }
  }
</script>

