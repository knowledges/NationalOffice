<!--author: qiu.bl-->
<style scoped></style>
<template>
  <div v-if="icon" class="el-autocomplete">
    <el-autocomplete
      class="inline-input"
      v-model="state1"
      maxlength="8"
      :fetch-suggestions="querySearch"
      custom-item="my-item-zh"
      placeholder="请输入内容"
      :trigger-on-focus="keyup"
      @select="handleSelect"
      icon="close"
      :on-icon-click="handleIconClick"
    ></el-autocomplete>
  </div>
  <div v-else class="el-autocomplete">
    <el-autocomplete
      class="inline-input"
      v-model="state1"
      maxlength="8"
      :fetch-suggestions="querySearch"
      placeholder="请输入内容"
      :trigger-on-focus="keyup"
      @select="handleSelect"
      icon="close"
      :on-icon-click="handleIconClick"
    ></el-autocomplete>
  </div>
</template>
<script>
  import Vue from 'vue'
  Vue.component('my-item-zh', {
    functional: true,
    render: function (h, ctx) {
      var item = ctx.props.item
      return h('li', ctx.data, [
        h('div', { attrs: { class: 'name' } },
          [h('i', { attrs: { class: item.icon } }), '  ' + item.label]
        )])
    },
    props: {
      item: { type: Object, required: true }
    }
  })
  export default {
    name: 'filter',
    props: {
      filmode: { // 过滤方式；0:代表本地过滤，1：服务器过滤
        type: Number,
        default: 0
      },
      datasource: {
        type: Array, // 数据源
        default: []
      },
      filType: { // 过滤类型；0：单列数据过滤，1：整条数据过滤
        type: Number,
        default: 1
      },
      fileName: {
        type: Array,
        default: ['value']
      },
      keyup: {
        type: Boolean,
        default: false
      },
      icon: {
        type: Boolean,
        default: false
      },
      vals: {
        type: String,
        default: ''
      },
      filterMethod: Function
    },
    mounted () {
      if (this.filmode === 0) {
        this.restaurants = this.datasource
      }
      this.state1 = this.vals
    },
    data () {
      return {
        restaurants: [],
        state1: ''
      }
    },
    methods: {
      querySearch (queryString, cb) {
        let restaurants = this.restaurants
        let results = []
        results = queryString ? restaurants.filter(this.AllFilter(queryString)) : restaurants
        // 调用 callback 返回建议列表的数据
        cb(results)
        if (results.length > 0) {
          this.filterMethod(results)
        } else {
          this.filterMethod([])
        }
      }, // 查询
      AllFilter (queryString) {
        return (restaurants) => {
          let isTrue = false
          for (let i in restaurants) {
            for (let j in this.fileName) {
              /* 将内容转换字符串是为了防止有数值类型 */
              this.fileName[j] === i && restaurants[i].toString().toLocaleUpperCase().indexOf(queryString.toLocaleUpperCase()) >= 0 ? isTrue = true : isTrue
            }
          }
          return isTrue
        }
      },
      handleSelect (item) {
        this.filterMethod(item)
      },
      handleIconClick () {
        this.state1 = ''
        this.filterMethod(this.datasource)
      }
    },
    watch: {
      datasource (newv, oldv) {
        this.restaurants = newv
      },
      vals (newv, old) {
        this.state1 = newv
      },
      state1 (newv, old) {
        if (newv === '') {
          this.filterMethod(this.datasource)
          this.state1 = newv
        } else {
          this.state1 = newv
        }
      }
    }
  }
</script>

