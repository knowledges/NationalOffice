<style rel="stylesheet/scss" lang="scss" scoped>
  .mult-tree-left {
    display: block;
    width: 100%;
    height: 36px;
    line-height: 36px;
    float: left;
  }
  .mult-tree-node__content {
    i {
      font-size: 26px;
      color: #20a0ff;
      vertical-align: middle;
      /*transition: all 0.6s;*/
    }
    span {
      font-size: 14px;
      margin-left: 5px;
    }
  }
  .mult-tree-node__children {
    margin-left: 15px;
  }
  .more {
    float: left;
    width: 15px;
    height: 36px;
    cursor: pointer;
  }
  .checked { float: left;margin-left: 10px; cursor: pointer;}
  .start {
    /*animation: rotateStart .5s alternate forwards;*/
  }
  @keyframes rotateStart {
    from { transform: rotate(0deg)}
    to {
      transform: rotate(90deg);
    }
  }
</style>
<template>
  <div class="mult-tree-node">
    <div class="mult-tree-node__content clearfix">
      <div class="mult-tree-left clearfix">
        <div class="more" @click="showTree">
          <i class="fa" :class="isShow ? 'fa-caret-down' : 'fa-caret-right'" v-if="model.children && model.children.length > 0"></i>
        </div>
        <div class="checked" @click="selected(model)">
          <i class="fa" :class="getClassName(model)"></i>
          <span>{{model.label}}</span>
        </div>
      </div>
    </div>
    <div class="mult-tree-node__children" v-show="isShow">
      <multi-tree v-for="(child, key) in model.children" :model="child" :key="key" :getTransmit="getTransmit" :selectCondition="selectCondition"></multi-tree>
    </div>
  </div>
</template>
<script>
  var [countyId, marketmgrId, custmgrId] = [[], [], []]
  export default {
    name: 'multiTree',
    props: {
      selectCondition: Object,
      model: Object,
      getTransmit: Function
    },
    mounted () {
      if (this.selectCondition !== undefined && this.selectCondition.countyId !== undefined && this.selectCondition.countyId !== '') {
        countyId = this.selectCondition.countyId.split(',')
      }
      if (this.selectCondition !== undefined && this.selectCondition.marketmgrId !== undefined && this.selectCondition.marketmgrId !== '') {
        marketmgrId = this.selectCondition.marketmgrId.split(',')
      }
      if (this.selectCondition !== undefined && this.selectCondition.custmgrId !== undefined && this.selectCondition.custmgrId !== '') {
        custmgrId = this.selectCondition.custmgrId.split(',')
      }
    },
    data () {
      return {
        isShow: false
      }
    },
    methods: {
      showTree () {
        this.isShow = !this.isShow
      },
      selected (item) {
        var isTrue = item.select !== undefined ? item.select : false
        this.$set(item, 'select', !isTrue)
        if (Number(item.place) === 24) {
          marketmgrId.indexOf(item.id) >= 0 ? marketmgrId.splice(marketmgrId.indexOf(item.id), 1) : marketmgrId.push(item.id)
          this.getTransmit(marketmgrId, 3)
        } else if (Number(item.place) === 135) {
          custmgrId.indexOf(item.id) >= 0 ? custmgrId.splice(custmgrId.indexOf(item.id), 1) : custmgrId.push(item.id)
          this.getTransmit(custmgrId, 4)
        } else {
          countyId.indexOf(item.id) >= 0 ? countyId.splice(countyId.indexOf(item.id), 1) : countyId.push(item.id)
          this.getTransmit(countyId, 2)
        }
      },
      getClassName (item) {
        return item.select ? 'fa-check-square' : 'fa-square-o'
      }
    }
  }
</script>
