// import Raven from 'raven-js'

export default {
  /**
   * 工作日志工厂
   * @param err 出错报告
   * @param culprit 出错模版
   * @author qiu.bl
   */
  work (err, culprit) {
    () => {
      console.err(err)
    }
    // Raven.captureMessage('TypeError' + err,
    //   {
    //     tags: { locale: 'en-us' },
    //     logger: 'vue',
    //     culprit: culprit, // 出错模块
    //     level: 'error' // 出错等级默认值error； error／warning／info／debug
    //   })
  }
}
