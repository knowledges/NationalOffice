<template>
  <div class="container-fluid_new">
      <el-collapse>
        <el-collapse-item title="总体" name="overall">
          <div>
            <el-col :gutter="24">
              <el-col :span='24'>
                <span>销量（条）</span>
              </el-col>
            </el-col>
            <el-table :data="salesVolume"  >
              <el-table-column prop="qty1" label="本月" ></el-table-column>
              <el-table-column prop="qty2" label="上月" ></el-table-column>
              <el-table-column prop="qty4" label="同期"></el-table-column>
              <el-table-column prop="qty5" label="同比（%）" ></el-table-column>
              <el-table-column prop="qty3" label="环比（%）"></el-table-column>
            </el-table>
            <el-col :gutter="24">
              <el-col :span='24'>
                <span>销额（万元）</span>
              </el-col>
            </el-col>
            <el-table :data="salesVolume" >
              <el-table-column prop="amt1" label="本月" ></el-table-column>
              <el-table-column prop="amt2" label="上月" ></el-table-column>
              <el-table-column prop="amt4" label="同期"></el-table-column>
              <el-table-column prop="amt5" label="同比（%）" ></el-table-column>
              <el-table-column prop="amt3" label="环比（%）"></el-table-column>
            </el-table>
            <el-col :gutter="24">
              <el-col :span='24'>
                <span>规格数(个)</span>
              </el-col>
            </el-col>
            <el-table :data="salesVolume" >
              <el-table-column prop="spec1" label="本月" ></el-table-column>
              <el-table-column prop="spec2" label="上月" ></el-table-column>
              <el-table-column prop="spec4" label="同期"></el-table-column>
              <el-table-column prop="spec5" label="同比（%）" ></el-table-column>
              <el-table-column prop="spec3" label="环比（%）"></el-table-column>
            </el-table>
          </div>
        </el-collapse-item>
        <el-collapse-item title="分客户销售额排行 " name="custSale" stripe="true">
          <div>
            <div> 当前客户:{{custName}} 销量：{{custSaleQty}} 销售额:{{custSaleAmt}} 销量排名：第{{custSaleRank}} 名</div>
            <el-table :data="customer" :row-class-name="tableRowClassName">
              <el-table-column prop="cuCustomerCd" label="客户代码" ></el-table-column>
              <el-table-column prop="cuCustomerNm" label="客户名称" ></el-table-column>
              <el-table-column prop="orderQty" label="销量" sortable></el-table-column>
              <el-table-column prop="orderAmt" label="销售额" sortable></el-table-column>
            </el-table>
          </div>
        </el-collapse-item>
        <el-collapse-item title="分规格销售额排行" name="specSale">
          <div>
            <el-table :data="specifications"  >
              <el-table-column prop="cigProductCd" label="卷烟代码" ></el-table-column>
              <el-table-column prop="cigProductNm" label="卷烟名称" ></el-table-column>
              <el-table-column prop="orderQty" label="销量" sortable></el-table-column>
              <el-table-column prop="orderAmt" label="销售额" sortable></el-table-column>
            </el-table>
          </div>
        </el-collapse-item>
      </el-collapse>
  </div>
</template>
<style scoped>
  .container-fluid_new {
    background: #FFF;
  }
  .el-col-20 {
    width: 83.33333%;
    height: 30px;
  }
  .el-col-10{
    height: 150px;
  }
  .el-col-6 {
    width: 33.33%;
    height: 30px;
  }
  .notic {
    margin-left: 0px!important;
  }
</style>
<script>
  import api from '@/api'
  import log from '@/log'
  import BasePath from '@/config/BasePath'
  import {dateFormat} from '@/utils/common'
  let token = localStorage.getItem('token') // 要保证取到
  export default {
    props: {
      custId: {
        type: String,
        default: ''
      }
    },
    name: 'accident',
    mounted () {
      this.initOverall(JSON.parse(this.custId)) // 总体
      this.initCustSale(JSON.parse(this.custId)) // 分客户销售额排行
      this.initSpecSale(JSON.parse(this.custId)) // 分规格销售额排行
    },
    data () {
      return {
        custName: '',
        custMgrIdGroup: [],
        orderSche: [],
        myHeaders: {Authorization: token},
        imgNum: 4,
        activeName: '1',
        rowId: '',
        salesVolume: [],
        customer: [],
        specifications: [],
        custSaleQty: '0',
        custSaleAmt: '0',
        custSaleRank: ''
      }
    },
    methods: {
      initOverall (val) {
        let queryParam = {}
        queryParam.rowId = val.custmgrId
        api.requestJava('POST', BasePath.EMPLOYEE_SELECTONE, queryParam)
          .then(request => {
            let param = {}
            var myDate = new Date()
            var yearText = dateFormat(myDate.getTime(), 'YYYYMM')
            param.orgCustmgrCd = request.data.data.employeeCode
            param.dtMonthId = yearText
            param.custCd = val.customerCode
            api.requestJava('POST', BasePath.CUSTOMER_SALESVOLUME, param)
              .then(request => {
                if (Number(request.data.code) === 200) {
                  let data = request.data.data
                  let row = {}
                  row.qty1 = (data.qty1 / 1).toFixed(2)
                  row.qty2 = (data.qty2 / 1).toFixed(2)
                  row.qty3 = (data.qty3 / 1).toFixed(2)
                  row.qty4 = (data.qty4 / 1).toFixed(2)
                  row.qty5 = (data.qty5 / 1).toFixed(2)
                  row.amt1 = (data.amt1 / 1).toFixed(2)
                  row.amt2 = (data.amt2 / 1).toFixed(2)
                  row.amt3 = (data.amt3 / 1).toFixed(2)
                  row.amt4 = (data.amt4 / 1).toFixed(2)
                  row.amt5 = (data.amt5 / 1).toFixed(2)
                  row.spec1 = (data.spec1 / 1).toFixed(2)
                  row.spec2 = (data.spec2 / 1).toFixed(2)
                  row.spec3 = (data.spec3 / 1).toFixed(2)
                  row.spec4 = (data.spec4 / 1).toFixed(2)
                  row.spec5 = (data.spec5 / 1).toFixed(2)
                  this.salesVolume.push(row)
                } else {
                  this.$notify.error({ title: '提示', message: request.message })
                  throw new Error(JSON.stringify(request))
                }
              })
              .catch(err => {
                let culprit = this.$route.name
                log.work(err, culprit)
              })
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      initCustSale (val) {
        let queryParam = {}
        queryParam.rowId = val.custmgrId
        api.requestJava('POST', BasePath.EMPLOYEE_SELECTONE, queryParam)
          .then(request => {
            let param = {}
            var myDate = new Date()
            var yearText = dateFormat(myDate.getTime(), 'YYYYMM')
            param.orgCustmgrCd = request.data.data.employeeCode
            param.dtMonthId = yearText
            api.requestJava('POST', BasePath.CUSTOMER_CUSTOMER, param)
              .then(request => {
                if (Number(request.data.code) === 200) {
                  this.customer = request.data.data
                  var i = 1
                  this.customer.forEach((val, key) => {
                    if (Number(val.cuCustomerCd) === Number(JSON.parse(this.custId).customerCode)) {
                      this.custSaleQty = val.orderQty
                      this.custSaleAmt = val.orderAmt
                      this.custSaleRank = i
                      this.custName = val.cuCustomerNm
                    }
                    i++
                  })
                  if (Number(this.custSaleAmt) === 0) {
                    this.custSaleRank = i
                  }
                } else {
                  this.$notify.error({ title: '提示', message: request.message })
                  throw new Error(JSON.stringify(request))
                }
              })
              .catch(err => {
                let culprit = this.$route.name
                log.work(err, culprit)
              })
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      initSpecSale (val) {
        let queryParam = {}
        queryParam.rowId = val.custmgrId
        api.requestJava('POST', BasePath.EMPLOYEE_SELECTONE, queryParam)
          .then(request => {
            let param = {}
            var myDate = new Date()
            var yearText = dateFormat(myDate.getTime(), 'YYYYMM')
            param.orgCustmgrCd = request.data.data.employeeCode
            param.dtMonthId = yearText
            api.requestJava('POST', BasePath.CUSTOMER_SPECIFICATIONS, param)
              .then(request => {
                if (Number(request.data.code) === 200) {
                  this.specifications = request.data.data
                } else {
                  this.$notify.error({ title: '提示', message: request.message })
                  throw new Error(JSON.stringify(request))
                }
              })
              .catch(err => {
                let culprit = this.$route.name
                log.work(err, culprit)
              })
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      startTime () {},
      tableRowClassName (row, index) {
        if (index === (this.custSaleRank - 1)) {
          return 'info-row'
        }
        return ''
      }
    },
    queryrules: {
    },
    components: {
    },
    watch: {
      custId (val, old) {
        console.log('========customerDetail=========', val)
        this.salesVolume = []
        this.custName = JSON.parse(this.custId).customerDesc
        this.initCustSale(JSON.parse(this.custId))
        this.initOverall(JSON.parse(this.custId))
      }
    }
  }
</script>
