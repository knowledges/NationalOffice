<style scoped>
  .el-form-item__label{
    margin: 0px!important;
  }
  .filter_style .el-col-24 {
    height: 36px;
  }
  .el-form-item {
    margin-bottom: 12px;
  }
</style>
<template>
  <div class="container-fluid">
    <el-form ref="searchForm" :model="searchForm" label-width="120px" >
    <div>
      <el-form-item label="备注">
        <el-input type="textarea" resize="none" v-model="searchForm.remarks" auto-complete="off" class="inputInline"></el-input>
      </el-form-item>
      <el-col :gutter="24">
        <el-col :span='8'>
          <div v-if="isSelect">
            <el-col :gutter="24">
              <el-col :span='10'>
                <el-form-item label="录入人" >
                  {{gatherer}}
                </el-form-item>
              </el-col>
              <el-col :span='14'>
                <div class="block">
                  <el-form-item label="采集日期">
                    {{searchForm.gatherDate}}
                  </el-form-item>
                </div>
              </el-col>
            </el-col>
          </div>
        </el-col>
        <el-col :span="16">
          <_BTN_FILTER :isMore="isMore" :btnGroups="btnGroups" :fileName="fileName" :filterMethod="inputChange" @on-click="exportEve"
                       :tableData="tableData"/>
        </el-col>
      </el-col>
      <tableVue
        ref="tableGrid"
        stripe
        maxHeight="500"
        :data="dataSource"
        @update:data="tabChange" :reqParams="reqParams"
        :columns="columns"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
        @cell-dblclick="celldbClick"></tableVue>
    </div>
    </el-form>
  </div>
</template>
<script>
  import tableVue from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import { dateFormat } from '@/utils/dateFormat.js'
  import {getUser} from '@/config/info'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import log from '@/log'
  let params = ''
  export default {
    mounted () {
      params = JSON.parse(decodeURI(this.$route.params.rowId))
      console.log('params::::' + JSON.stringify(params))
      this.searchForm.gatherDate = params.gatherDate
      this.gatherer = getUser().userName
      this.init()
    },
    data () {
      return {
        rowId: '',
        isSelect: true,
        isMore: true, // 查询更多条件
        searchForm: {
          gatherDate: new Date()
        },
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['productCode', 'productName'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '返回',
            className: 'btn-info',
            iconName: 'fa-backward',
            event: this.backClk
          },
          {
            name: '保存',
            className: 'btn-primary',
            iconName: 'fa-save',
            event: this.saveClk
          },
          {
            name: '提交',
            className: 'btn-primary',
            iconName: 'fa-save',
            event: this.submitClk
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 500,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        selectSells: [],
        totalCount: 0, // 表格总记录数
        hasPagination: false, // 是否有分页
        columns: [ // 表格列
          { label: '商品代码', prop: 'productCode', columnsProps: {width: 120} },
          { label: '商品名称', prop: 'productName', columnsProps: {width: 160} },
          { label: '异常范围(+-%)', prop: 'downUpRate', columnsProps: {width: 160} },
          { label: '优先级', prop: 'weight', columnsProps: {width: 120} },
          { label: '调拨价', prop: 'purchasePrice', columnsProps: {width: 120} },
          { label: '批发价', prop: 'tradePrice', columnsProps: {width: 120} },
          { label: '市场价', prop: 'price3', columnsProps: {type: 'input'}, eventChange: this.selectChange, eventKey: this.eventKey },
          { label: '零售价(条)', prop: 'price2', columnsProps: {type: 'input'}, eventKey: this.eventKey },
          { label: '零售价(包)', prop: 'price1', columnsProps: {type: 'input'}, eventKey: this.eventKey }

        ],
        data: [],
        tableData: [],
        dataSource: [], // 当前页的数据
        planTime: '',
        /** filter **/
        templTableData: [] // 临时记录tableDate的值
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      init () {
        let param = {}
        param.gatherDate = params.gatherDate
        param.companyId = getUser().companyId
        param.gatherer = getUser().personId
        param.salesUnitId = getUser().countyId
        this.reqParams.url = BasePath.GATHER_PRICE_ADD
        this.reqParams.params = param
        console.log('新建param:' + JSON.stringify(param))
        if (Number(params.rowId) === 0) { // 新建
          api.requestJava('POST', BasePath.GATHER_PRICE_ADD, param)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.data = request.data.data
                this.tableData = request.data.data
                if (Number(request.data.data.length) > 0) {
                  this.totalCount = Number(request.data.count) <= 0 ? 1 : Number(request.data.count)
                  var i = 0
                  var key = 0
                  request.data.data.forEach((e) => {
                    if (Number(request.data.data[i].status) === 1) {
                      key = 1
                    }
                    if (Number(request.data.data[i].price3) === 0) {
                      this.data[i].price3 = request.data.data[i].lastPrice
                      this.tableData[i].price3 = request.data.data[i].lastPrice
                    }
                    if (Number(request.data.data[i].price2) === 0) {
                      this.data[i].price2 = request.data.data[i].retailPriceStrip
                      this.tableData[i].price2 = request.data.data[i].retailPriceStrip
                    }
                    if (Number(request.data.data[i].price1) === 0) {
                      this.data[i].price1 = request.data.data[i].retailPricePack
                      this.tableData[i].price1 = request.data.data[i].retailPricePack
                    }
                    i++
                  })
                  if (key === 1) {
                    let _btnGroups = []
                    let _backbtn = {}
                    _backbtn.name = '返回'
                    _backbtn.className = 'btn-info'
                    _backbtn.event = this.backClk
                    _btnGroups.push(_backbtn)
                    this.btnGroups = _btnGroups
                  } else {
//                    let _btnGroups = []
//                    let _backbtn = {}
//                    _backbtn.name = '返回'
//                    _backbtn.className = 'btn-info'
//                    _backbtn.event = this.backClk
//                    let _savebtn = {}
//                    _savebtn.name = '保存'
//                    _savebtn.className = 'btn-primary'
//                    _savebtn.iconName = 'fa-save'
//                    _savebtn.event = this.saveClk
//                    _btnGroups.push(_backbtn)
//                    _btnGroups.push(_savebtn)
//                    this.btnGroups = _btnGroups
                  }
                  this.$nextTick(() => {
                    this.currentPage = 1
                    this.queryData(this.currentPage, this.pageSize)
                  })
                }
              }
            })
            .catch(err => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        } else {
          param.gatherId = params.rowId
          param.gatherer = params.gatherer
          param.companyId = getUser().companyId
          this.reqParams.url = BasePath.GATHER_PRICE_ADD
          this.reqParams.params = param
          console.log('修改param:' + JSON.stringify(param))
          api.requestJava('POST', BasePath.GATHER_PRICE_ADD, param, {})
            .then(request => {
              if (Number(request.data.code) === 200) {
                this.totalCount = Number(request.data.count) <= 0 ? 1 : Number(request.data.count)
                this.data = request.data.data
                this.tableData = request.data.data
                this.searchForm.remarks = request.data.data[1].remarks
                if (Number(request.data.data.length) > 0) {
                  var i = 0
                  var key = 0
                  request.data.data.forEach((e) => {
                    if (Number(request.data.data[i].status) === 1) {
                      key = 1
                    }
                    console.log(JSON.stringify(request.data.data[i]))
                    this.data[i].price3 = request.data.data[i].price3
                    this.data[i].price2 = request.data.data[i].price2
                    this.data[i].price1 = request.data.data[i].price1
                    i++
                  })
                  if (key === 1) {
                    let _btnGroups = []
                    let _backbtn = {}
                    _backbtn.name = '返回'
                    _backbtn.className = 'btn-info'
                    _backbtn.event = this.backClk
                    _btnGroups.push(_backbtn)
                    this.btnGroups = _btnGroups
                  }
                  this.$nextTick(() => {
                    this.currentPage = 1
                    this.queryData(this.currentPage, this.pageSize)
                  })
                }
              }
            })
            .catch(err => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        }
      },
      isMoreClk () {
        this.isSelect = !this.isSelect
      },
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.data.length
        this.dataSource = this.data.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      headerClick () {},
      sortChange (msg) {},
      rowClick (msg) {},
      backClk () {
        this.$router.push({name: 'Record'})
      }, // 返回
      celldbClick (row, column, cell, event) {
        this.setStatus()
        this.$set(row, '_edit', !row._edit)
        if (!row._edit) {
          if (!this.numberChange(row)) {
            row._edit = true
          } else {
            this.$set(row, '_edit', !row._edit)
          }
        }
      },
      setStatus () {
        this.data.forEach((val, key) => {
          if (val._edit !== undefined) {
            val._edit = false
          }
        })
      },
      eventKey (key, row) {
        if (key.code === 'Enter' || key.code === 'NumpadEnter') {
          if (!this.numberChange(row)) {
            return true
          } else {
            return false
          }
        }
      },
      saveClk () {
        let param = {}
        param.companyId = getUser().companyId
        param.salesUnitId = getUser().countyId
        param.gatherer = getUser().personId
        param.gatherDate = params.gatherDate
        param.status = '0'
        param.remarks = this.searchForm.remarks
        param.priceDetail = this.dataSource
        api.requestJava('POST', BasePath.GATHER_PRICE_UPDATE, param, {})
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.$message({ type: 'info', message: '已保存!' })
              params.rowId = request.data.data
              console.log('保存：' + JSON.stringify(params))
              this.init()
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      saveAndSubmit () {
        let param = {}
        param.companyId = getUser().companyId
        param.salesUnitId = getUser().countyId
        param.gatherer = getUser().personId
        param.gatherDate = params.gatherDate
        param.status = '0'
        param.remarks = this.searchForm.remarks
        param.priceDetail = this.dataSource
        let _this = this
        let flag = 0
        this.dataSource.forEach(function (item, index) {
          if (Number(item.price3) === 0 || Number(item.price2) === 0 || Number(item.price2) === 0) {
            _this.$message({ type: 'info', message: '录入的价格不能为0，请重新录入！' })
            flag = 1
          }
        })
        console.log('保存：' + JSON.stringify(param))
        if (flag === 0) {
          api.requestJava('POST', BasePath.GATHER_PRICE_UPDATE, param, {})
            .then(request => {
              if (Number(request.data.code) === 200) {
                let param = {}
                param.rowId = request.data.data
                param.status = '1'
                console.log(JSON.stringify(param))
                api.requestJava('POST', BasePath.GATHER_PRICE_SUBMIT, param, {})
                  .then(request => {
                    if (Number(request.data.code) === 200) {
                      this.$message({type: 'info', message: '已提交!'})
                      this.$router.push('/Record')
                    }
                  })
                  .catch(err => {
                    let culprit = this.$route.name
                    log.work(err, culprit)
                  })
                this.init()
              }
            })
            .catch(err => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        }
      },
      submitData () {
        let param = {}
        param.rowId = params.rowId
        param.status = '1'
        console.log(JSON.stringify(param))
        let _this = this
        let flag = 0
        this.dataSource.forEach(function (item, index) {
          if (Number(item.price3) === 0 || Number(item.price2) === 0 || Number(item.price2) === 0) {
            _this.$message({ type: 'info', message: '录入的价格不能为0，请重新录入！' })
            flag = 1
          }
        })
        console.log('保存：' + JSON.stringify(param))
        if (flag === 0) {
          api.requestJava('POST', BasePath.GATHER_PRICE_SUBMIT, param, {})
            .then(request => {
              if (Number(request.data.code) === 200) {
                this.$message({type: 'info', message: '已提交!'})
                this.$router.push('/Record')
              }
            })
            .catch(err => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        }
      },
      submitClk () {
        this.$confirm('是否确定提交？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          if (Number(params.rowId) === 0) {
            this.saveAndSubmit() // 保存并且提交
          } else {
            this.submitData() // 提交数据
          }
        }).catch(() => {
          this.$message({ type: 'info', message: '已取消提交!' })
        })
      },
      sessionFailedBack (msg) {
        let headers = msg.data.form
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.sessionFailedDialogObj.dialogVisible = false
            }
          })
          .catch((err) => { console.log(err) })
      }, // 会话失效
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      numberChange (row) {
        let _this = this
        this.$nextTick(() => {
          var t
          clearTimeout(t)
          t = setTimeout(function () {
            let tradePrice = row.tradePrice
            let price3 = row.price3
            let downUpRate = row.downUpRate
            let upPrice = (Number(tradePrice) * Number(1 + Number(downUpRate) / 100)).toFixed(2)
            let downPrice = (Number(tradePrice) * Number(1 - Number(downUpRate) / 100)).toFixed(2)
            if (price3 > upPrice) {
              _this.$message({ type: 'error', message: row.productName + ' 市场价输入异常，高于异常范围(' + upPrice + ')！' })
              return false
            } else if (price3 < downPrice) {
              _this.$message({ type: 'error', message: row.productName + ' 市场价输入异常，低于异常范围(' + downPrice + ')！' })
              return false
            } else {
              return true
            }
          }, 1000)
        })
      },
      show () {
        this.$message('双击事件')
      },
      selectChange (index, row) {
        if (!row._edit) {
          this.$message('双击事件')
        }
      }
    },
    components: {
      tableVue,
      _BTN_FILTER
    }
  }
</script>
