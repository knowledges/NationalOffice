<template>
  <div class="container-fluid">
    <el-row :gutter="24" style="margin: 5px 0 8px 0">
      <el-col :span="24" style="padding: 0 0">
        <_BTN_FILTER :btnGroups="btnGroups"/>
      </el-col>
    </el-row>
    <el-form   label-width="100px" :model="custForm" ref="form" :rules="queryrules">
    <el-collapse v-model="activeName" accordion>
      <el-collapse-item title="识别信息" name="1">
        <div>
              <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="customerCode" label="客户代码" >
                    <el-input v-model="custForm.customerCode"  :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='12' >
                  <el-form-item prop="customerDesc" label="客户名称">
                    <el-input v-model="custForm.customerDesc" :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="shortCode" label="助记码">
                    <el-input v-model="custForm.shortCode" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="shortName" label="简称" >
                    <el-input v-model="custForm.shortName" auto-complete="off" class="inputInline" :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="contactperson" label="联系人">
                    <el-input v-model="custForm.contactperson" auto-complete="off" class="inputInline" :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="tel" label="联系电话">
                    <el-input v-model="custForm.tel" auto-complete="off" class="inputInline" :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="alternatePhone" label="备用电话">
                    <el-input v-model="custForm.alternatePhone" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='12'>
                  <el-form-item  prop="addr" label="地址" >
                    <el-input v-model="custForm.addr" auto-complete="off" class="inputInline" :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="legalPerson" label="法人代表">
                    <el-input v-model="custForm.legalPerson" auto-complete="off" class="inputInline" :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="legalTel" label="法人电话">
                    <el-input v-model="custForm.legalTel" auto-complete="off" class="inputInline" :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="nationalCode" label="标准编码" >
                    <el-input v-model="custForm.nationalCode" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="postalCode" label="邮政编码">
                    <el-input v-model="custForm.postalCode" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="licenseNo" label="营业执照号">
                    <el-input v-model="custForm.licenseNo" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="issueDate" label="发证日期">
                    <el-input v-model="custForm.issueDate" auto-complete="off" class="inputInline" :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="validDate" label="有效日期" >
                    <el-input v-model="custForm.validDate" auto-complete="off" class="inputInline" :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="annulDate" label="年审日期">
                    <el-input v-model="custForm.annulDate" auto-complete="off" class="inputInline" :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="networkedDate" label="入网时间">
                    <el-input v-model="custForm.networkedDate" auto-complete="off" class="inputInline" :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="permitType" label="许可证类型">
                    <el-input v-model="custForm.permitType" auto-complete="off" class="inputInline" :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="permitNo" label="许可证号" >
                    <el-input v-model="custForm.permitNo" auto-complete="off" class="inputInline" :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="monopolyAdm" label="专卖管理员">
                    <el-select v-model="custForm.monopolyAdm" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_monopolyAdm"
                        :key="item.rowId"
                        :label="item.employeeName"
                        :value="item.rowId">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="regionalism" label="行政区划">
                    <el-select v-model="custForm.regionalism" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_regionalism"
                        :key="item.rowId"
                        :label="item.regionName"
                        :value="item.rowId">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="geoType" label="市场类型">
                    <el-select v-model="custForm.geoType" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_geoType"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="businessType" label="零售业态" >
                    <el-select v-model="custForm.businessType" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_businessType"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="groupType" label="群体类型">
                    <el-select v-model="custForm.groupType" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_groupType"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="coagent" label="经营性质">
                    <el-select v-model="custForm.coagent" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_coagent"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="isLawful" label="守法情况">
                    <el-select v-model="custForm.isLawful" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_isLawful"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="svericeTel" label="短信发送号码" >
                    <el-input v-model="custForm.svericeTel" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="mail" label="电子邮件">
                    <el-input v-model="custForm.mail" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="coagent" label="学历">
                    <el-input v-model="custForm.degree" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="birthDate" label="出生日期">
                    <DatePickerTemp @on-change="startTime" :types="date" />
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="familySituation" label="家庭情况" >
                    <el-input v-model="custForm.familySituation" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="homeAddr" label="家庭地址">
                    <el-input v-model="custForm.homeAddr" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="coagent" label="爱好特长">
                    <el-input v-model="custForm.hobby" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="status" label="状态">
                    <el-checkbox v-model="custForm.status"></el-checkbox>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
        </div>
      </el-collapse-item>
      <el-collapse-item title="基本信息" name="2">
        <div>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="companyId" label="公司" >
                    <el-select v-model="custForm.companyId" :clearable="true" placeholder="请选择" :disabled="true">
                      <el-option
                        v-for="item in options_companyId"
                        :key="item.orgUnitId"
                        :label="item.orgRoleNm"
                        :value="item.orgUnitId">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="countyId" label="分公司">
                    <el-select v-model="custForm.countyId" @change= "countyChange" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_countyId"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="marketOrg" label="服务科">
                    <el-select v-model="custForm.marketOrg" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_marketOrg"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="thesystem" label="所属系统">
                    <el-select v-model="custForm.thesystem" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_thesystem"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="tradeCircleType" label="商圈类型" >
                    <el-select v-model="custForm.tradeCircleType" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_tradeCircleType"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="isChain" label="是否连锁">
                    <el-checkbox v-model="custForm.isChain"></el-checkbox>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="isNight" label="是否夜店">
                    <el-checkbox v-model="custForm.isNight"></el-checkbox>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="confiscateCustFlg" label="是否罚没定点户">
                    <el-checkbox v-model="custForm.confiscateCustFlg"></el-checkbox>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="hours" label="营业时间" >
                    <el-select v-model="custForm.hours" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_hours"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="terms" label="信息终端">
                    <el-select v-model="custForm.terms" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_terms"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="logoType" label="门头标识">
                    <el-select v-model="custForm.logoType" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_logoType"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <!--<el-form-item prop="reserveType1" label="客户层级">-->
                    <!--<el-input v-model="custForm.reserveType1" auto-complete="off" class="inputInline" :disabled="true"></el-input>-->
                  <!--</el-form-item>-->
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="customerGrade" label="客户级别" >
                    <el-select v-model="custForm.customerGrade" :clearable="true" placeholder="请选择" :disabled="true">
                      <el-option
                        v-for="item in options_customerGrade"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="operationScale" label="经营规模">
                    <el-select v-model="custForm.operationScale" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_operationScale"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="totalLimit" label="总量限量">
                    <el-input v-model="custForm.totalLimit" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="detailLimit" label="单品限量">
                    <el-input v-model="custForm.detailLimit" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="engageArea" label="营业面积" >
                    <el-input v-model="custForm.engageArea" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="mainFormat" label="主营业态">
                    <el-select v-model="custForm.mainFormat" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_mainFormat"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="sampleForm" label="出样形式">
                    <el-select v-model="custForm.sampleForm" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_sampleForm"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="salesEnvironmental" label="销售环境">
                    <el-select v-model="custForm.salesEnvironmental" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_salesEnvironmental"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="shopPlace" label="店铺地段" >
                    <el-select v-model="custForm.shopPlace" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_shopPlace"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="displayInstallation" label="陈列款式">
                    <el-input v-model="custForm.displayInstallation" auto-complete="off" class="inputInline" :disabled="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="advertisementArea" label="广告面积">
                    <el-select v-model="custForm.advertisementArea" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_advertisementArea"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="operationAgeLimit" label="经营年限">
                    <el-select v-model="custForm.operationAgeLimit" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_operationAgeLimit"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="displayCapability" label="前柜" >
                    <el-select v-model="custForm.displayCapability" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_displayCapability"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="softwareCapability" label="软件使用能力">
                    <el-select v-model="custForm.softwareCapability" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_softwareCapability"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="recommendCapability" label="推介能力">
                    <el-select v-model="custForm.recommendCapability" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_recommendCapability"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="communicationCapability" label="沟通能力">
                    <el-select v-model="custForm.communicationCapability" :clearable="true" placeholder="请选择">
                      <el-option
                        v-for="item in options_communicationCapability"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='12' >
                  <el-form-item prop="contactpersonZipcode" label="通信邮编">
                    <el-input v-model="custForm.contactpersonZipcode" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='12' >
                  <el-form-item prop="communicateAddr" label="通信地址">
                    <el-input v-model="custForm.communicateAddr" auto-complete="off" class="inputInline" type="number"></el-input>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="reserveTag1" label="是否标准店" >
                    <el-checkbox v-model="custForm.reserveTag1"></el-checkbox>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="seflCustFlg" label="是否重点客户">
                    <el-checkbox v-model="custForm.seflCustFlg"></el-checkbox>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="funcCustFlg" label="是否功能店">
                    <el-checkbox v-model="custForm.funcCustFlg"></el-checkbox>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="reserveTag2" label="信息采集点">
                    <el-checkbox v-model="custForm.reserveTag2"></el-checkbox>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
        </div>
      </el-collapse-item>
      <el-collapse-item title="业务信息" name="3">
      <div>
          <el-row>
            <el-col :gutter="20">
              <el-col :span='6'>
                <el-form-item  prop="custmgrId" label="客户经理" >
                  <el-select v-model="custForm.custmgrId" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_custmgrId"
                      :key="item.rowId"
                      :label="item.employeeName"
                      :value="item.rowId">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            <el-col :span='6' >
                <el-form-item prop="visitsalesmanId" label="电话订货员">
                  <el-select v-model="custForm.visitsalesmanId" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_visitsalesmanId"
                      :key="item.rowId"
                      :label="item.employeeName"
                      :value="item.rowId">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="orderMethod" label="订货方式">
                  <el-select v-model="custForm.orderMethod" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_orderMethod"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="orderRate" label="订货频次">
                  <el-select v-model="custForm.orderRate" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_orderRate"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :gutter="20">
              <el-col :span='6'>
                <el-form-item  prop="starGrade" label="客户星级" >
                  <el-select v-model="custForm.starGrade" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_starGrade"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="appointedTime" label="约定时间">
                  <el-input v-model="custForm.appointedTime" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="orderSche" label="订货排程">
                  <el-checkbox-group v-model="orderSche">
                    <el-checkbox label="1">一</el-checkbox>
                    <el-checkbox label="2">二</el-checkbox>
                    <el-checkbox label="3">三</el-checkbox>
                    <el-checkbox label="4">四</el-checkbox>
                    <el-checkbox label="5">五</el-checkbox>
                    <el-checkbox label="6">六</el-checkbox>
                    <el-checkbox label="7">日</el-checkbox>
                  </el-checkbox-group>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :gutter="20">
              <el-col :span='6'>
                <el-form-item  prop="senderMethod" label="送货方式" >
                  <el-select v-model="custForm.senderMethod" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_senderMethod"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="senderTime" label="送货时间">
                  <el-select v-model="custForm.senderTime" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_senderTime"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="deliveryAddr" label="送货地址">
                  <el-input v-model="custForm.deliveryAddr" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :gutter="20">
              <el-col :span='6'>
                <el-form-item  prop="routeId" label="线路" >
                  <el-input v-model="custForm.routeId"  auto-complete="off" class="inputInline"></el-input>
                  <!--<el-select v-model="custForm.routeId" placeholder="请选择">-->
                    <!--<el-option-->
                      <!--v-for="item in options_routeId"-->
                      <!--:key="item.value"-->
                      <!--:label="item.label"-->
                      <!--:value="item.value">-->
                    <!--</el-option>-->
                  <!--</el-select>-->
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="deliveredOrd" label="送货次序号">
                  <el-input v-model="custForm.deliveredOrd"  auto-complete="off" class="inputInline"></el-input>
                  <!--<el-select v-model="custForm.deliveredOrd" placeholder="请选择">-->
                    <!--<el-option-->
                      <!--v-for="item in options_deliveredOrd"-->
                      <!--:key="item.value"-->
                      <!--:label="item.label"-->
                      <!--:value="item.value">-->
                    <!--</el-option>-->
                  <!--</el-select>-->
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="delivererId" label="送货员">
                  <el-select v-model="custForm.delivererId" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_delivererId"
                      :key="item.rowId"
                      :label="item.employeeName"
                      :value="item.rowId">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="x" label="地理坐标X">
                  <el-input v-model="custForm.x" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :gutter="20">
              <el-col :span='6'>
                <el-form-item  prop="y"  label="地理坐标Y" >
                  <el-input v-model="custForm.y"  auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="paymentMode" label="结算方式">
                  <el-select v-model="custForm.paymentMode" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_paymentMode"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="bankId" label="银行">
                  <el-select v-model="custForm.bankId" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_bankId"
                      :key="item.rowId"
                      :label="item.bankdesc"
                      :value="item.rowId">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="depositaryBank" label="开户银行">
                  <el-input v-model="custForm.depositaryBank" auto-complete="off" class="inputInline" type="number"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :gutter="20">
              <el-col :span='6'>
                <el-form-item  prop="cardOwner" label="持卡人" >
                  <el-input v-model="custForm.cardOwner" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="accountNo" label="帐号">
                  <el-input v-model="custForm.accountNo" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="taxpayerType" label="纳税人分类">
                  <el-select v-model="custForm.taxpayerType" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_taxpayerType"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="invoiceType" label="发票类型">
                  <el-select v-model="custForm.invoiceType" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_invoiceType"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :gutter="20">
              <el-col :span='12'>
                <el-form-item  prop="customerLabel" label="发票台头" >
                  <el-input v-model="custForm.customerLabel" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="taxNo" label="税号">
                  <el-input v-model="custForm.taxNo" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="isAllowInq" label="可查余额">
                  <el-select v-model="custForm.isAllowInq" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_isAllowInq"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :gutter="20">
              <el-col :span='6' >
                <el-form-item prop="reserveType4" label="未扣款订单是否作废">
                  <el-select v-model="custForm.reserveType4" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_reserveType4"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="visitCycle" label="拜访顺序">
                  <el-input v-model="custForm.visitCycle" auto-complete="off" class="inputInline" type="number"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="visitBatch" label="拜访批次">
                  <!--<el-input v-model="custForm.visitBatch" auto-complete="off" class="inputInline" type="number"></el-input>-->
                  <el-select v-model="custForm.visitBatch" :clearable="true" placeholder="请选择">
                  <el-input v-model="custForm.visitBatch"  auto-complete="off" class="inputInline"></el-input>
                  <el-option
                  v-for="item in options_visitBatch"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                  </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='6' >
                <el-form-item prop="qty1Limit" label="订单保存时合计的倍数">
                  <el-select v-model="custForm.qty1Limit" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_qty1Limit"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
      </div>
      </el-collapse-item>
      <el-collapse-item title="形象信息" name="4">
        <div>
          <el-row>
            <el-col :gutter="20">
              <el-col :span='8'>
                <el-form-item  prop="companyId" label="法人" align="center" >
                </el-form-item>
                <div id="uploadPic1">
                  <uploadTemp style="margin:20px;" :files="custForm.filesLegal" ref="uploadPicLegal"></uploadTemp>
                </div>
              </el-col>
              <el-col :span='8'>
                <el-form-item  prop="companyId" label="成列展柜" align="center" >
                </el-form-item>
                <div id="uploadPic2">
                  <uploadTemp style="margin:20px;" :files="custForm.filesDisplay" ref="uploadPicDisplay"></uploadTemp>
                </div>
              </el-col>
              <el-col :span='8'>
                <el-form-item  prop="companyId" label="店面" align="center" >
                </el-form-item>
                <div id="uploadPic3">
                  <uploadTemp style="margin:20px;" :files="custForm.filesStorefront" ref="uploadPicStorefront"></uploadTemp>
                </div>
              </el-col>
            </el-col>
          </el-row>
        </div>
      </el-collapse-item>
    </el-collapse>
    </el-form>
  </div>
</template>
<style scoped>
   /* @import url("//unpkg.com/element-ui@2.0.1/lib/theme-chalk/index.css"); */
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>
<script>
  import InputTemp from '@/components/Template/filter/InputTemp.vue'
  import DatePickerTemp from '@/components/Template/DatePicker/DatePickerTemp.vue'
  import compositeInput from '@/components/Template/Popup/compositeInput.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
  import api from '@/api'
  import log from '@/log'
  import config from '@/config'
  import {getUser, getCodeList} from '@/config/info'
  import BasePath from '@/config/BasePath'
  import axios from 'axios'
  let token = localStorage.getItem('token') // 要保证取到
  export default {
    name: 'accident',
    mounted () {
      this.rowId = this.$route.params.rowId
      this.init()
      this.loadLevel1()
      this.loadLevel2()
      this.loadLevel3()
    },
    data () {
      return {
        flag: 0,
        orderSche: [],
        myHeaders: {Authorization: token},
        imgNum: 4,
        activeName: '1',
        rowId: '',
        custForm: {
          rowId: this.rowId,
          customerCode: '',
          customerDesc: '',
          shortCode: '',
          shortName: '',
          contactperson: '',
          tel: '',
          alternatePhone: '',
          addr: '',
          legalPerson: '',
          legalTel: '',
          nationalCode: '',
          postalCode: '',
          licenseNo: '',
          issueDate: '',
          validDate: '',
          annulDate: '',
          networkedDate: '',
          permitType: '',
          permitNo: '',
          monopolyAdm: '',
          regionalism: '',
          geoType: '',
          businessType: '',
          groupType: '',
          coagent: '',
          isLawful: '',
          svericeTel: '',
          mail: '',
          degree: '',
          birthDate: '',
          familySituation: '',
          homeAddr: '',
          hobby: '',
          status: '',
          companyId: '',
          countyId: '',
          marketOrg: '',
          thesystem: '',
          tradeCircleType: '',
          isChain: '',
          isNight: '',
          confiscateCustFlg: '',
          hours: '',
          terms: '',
          logoType: '',
          reserveType1: '',
          customerGrade: '',
          operationScale: '',
          totalLimit: '',
          detailLimit: '',
          engageArea: '',
          mainFormat: '',
          sampleForm: '',
          salesEnvironmental: '',
          shopPlace: '',
          displayInstallation: '',
          advertisementArea: '',
          operationAgeLimit: '',
          displayCapability: '',
          softwareCapability: '',
          recommendCapability: '',
          communicationCapability: '',
          contactpersonZipcode: '',
          communicateAddr: '',
          reserveTag1: '',
          seflCustFlg: '',
          funcCustFlg: '',
          reserveTag2: '',
          custmgrId: '',
          visitsalesmanId: '',
          orderMethod: '',
          orderRate: '',
          batchNo: '',
          appointedTime: '',
          orderSche: [],
          senderMethod: '',
          senderTime: '',
          deliveryAddr: '',
          routeId: '',
          deliveredOrd: '',
          delivererId: '',
          x: '',
          y: '',
          paymentMode: '',
          bankId: '',
          depositaryBank: '',
          cardOwner: '',
          accountNo: '',
          taxpayerType: '',
          invoiceType: '',
          customerLabel: '',
          taxNo: '',
          isAllowInq: '',
          reserveType4: '',
          visitCycle: '',
          visitBatch: '',
          qty1Limit: '',
          haveAttach: '',
          starGrade: '',
          files: [
            {
              fileName: 'baidu.gif',
              fileData: 'https://www.baidu.com/img/baidu_jgylogo3.gif',
              src: 'https://www.baidu.com/img/baidu_jgylogo3.gif'
            }
          ],
          filesLegal: [],
          filesDisplay: [],
          filesStorefront: []
        },
        options_customerGrade: [],
        options_monopolyAdm: [],
        options_regionalism: [],
        options_geoType: [],
        options_businessType: [],
        options_groupType: [],
        options_coagent: [],
        options_isLawful: [],
        options_countyId: [],
        options_marketOrg: [],
        options_visitBatch: [],
        options_thesystem: [{
          value: '1',
          label: '系统外'
        }, {
          value: '2',
          label: '系统内'
        }],
        options_tradeCircleType: [],
        options_hours: [],
        options_terms: [],
        options_logoType: [],
        options_operationScale: [],
        options_mainFormat: [],
        options_sampleForm: [],
        options_salesEnvironmental: [],
        options_shopPlace: [],
        options_advertisementArea: [],
        options_operationAgeLimit: [],
        options_displayCapability: [],
        options_softwareCapability: [],
        options_recommendCapability: [],
        options_communicationCapability: [],
        options_custmgrId: [],
        options_visitsalesmanId: [],
        options_orderMethod: [],
        options_orderRate: [],
        options_batchNo: [{
          value: '1',
          label: '11'
        }, {
          value: '2',
          label: '32'
        }],
        options_senderMethod: [],
        options_senderTime: [],
//        options_routeId: [{
//          value: '1',
//          label: '21车4线路'
//        }, {
//          value: '2',
//          label: '丰县三产车组'
//        }],
//        options_deliveredOrd: [{
//          value: '1',
//          label: '30'
//        }, {
//          value: '2',
//          label: '40'
//        }],
        options_delivererId: [],
        options_companyId: [],
        options_paymentMode: [],
        options_bankId: [],
        options_taxpayerType: [],
        options_invoiceType: [],
        options_isAllowInq: [{
          value: '1',
          label: '是'
        }, {
          value: '2',
          label: '否'
        }],
        options_reserveType4: [{
          value: '1',
          label: '是'
        }, {
          value: '2',
          label: '否'
        }],
        options_qty1Limit: [{
          value: '1',
          label: '5'
        }, {
          value: '2',
          label: '25'
        }],
        options_starGrade: [],
        status: true,
        isChain: false,
        isNight: true,
        reserveTag1: false,
        seflCustFlg: true,
        funcCustFlg: false,
        reserveTag2: false,
        confiscateCustFlg: true,
        queryrules: {
          roleCode: [
            {required: true, message: '请输入角色代码', trigger: 'blur'}
          ],
          roleName: [
            {required: true, message: '请输入角色名称', trigger: 'blur'}
          ]
        },
        imageUrl: '',
        date: 'date',
      /** 定义按钮 **/
        btnGroups: [
          {
            name: '返回',
            className: 'btn-info',
            iconName: 'fa-backward',
            event: this.backClk
          },
          {
            name: '保存',
            className: 'btn-primary',
            iconName: 'fa-save',
            event: this.saveClk
          }
        ],
        companyCode: ''
      }
    },
    methods: {
      loadLevel1 () {
        getCodeList('YC_GEO_TYPE', (data) => {
          this.options_geoType = data
        }) // 市场类型
        getCodeList('YC_BUSINESS_TYPE', (data) => {
          this.options_businessType = data
        }) // 零售业态
        getCodeList('YC_OPERATION_SCALE', (data) => {
          this.options_operationScale = data
        }) // 经营规模
        getCodeList('YC_TRADE_CIRCLE_TYPE', (data) => {
          this.options_tradeCircleType = data
        }) // 商圈
        getCodeList('YC_CUST_SENDER_METHOD', (data) => {
          this.options_senderMethod = data
        }) // 送货方式
        getCodeList('YC_SENDER_TIME', (data) => {
          this.options_senderTime = data
        }) // 送货响应时间
        getCodeList('YC_PAYMENT_MODE', (data) => {
          this.options_paymentMode = data
          console.log('options_paymentMode', data)
        }) // 结算方式
        getCodeList('CUSTOMER_GROUP_TYPE', (data) => {
          this.options_groupType = data
        }) // 群体类型
        getCodeList('MAIN_FORMAT', (data) => {
          this.options_mainFormat = data
        }) // 主营业态
        getCodeList('ORDER_RATE', (data) => {
          this.options_orderRate = data
        }) // 订货频次
        getCodeList('AL_INVOICE_TYPE', (data) => {
          this.options_invoiceType = data
        }) // 发票类型
        getCodeList('COAGENT', (data) => {
          this.options_coagent = data
        }) // 经营性质
        getCodeList('IS_LAWFUL', (data) => {
          this.options_isLawful = data
        }) // 守法情况
        let _this = this
        let monopolyAdmParam = {} // 专卖管理员
        monopolyAdmParam.status = 1
        monopolyAdmParam.place = '039'
        monopolyAdmParam.companyId = getUser().companyId
        monopolyAdmParam.countyDept = getUser().countyId
        monopolyAdmParam.fields = {include: 'employeeName,rowId'}
        let regionalismParam = {} // 行政区划
        if (Number(getUser.unitLevel) === 1) {
          regionalismParam.whereClause = 'and PARENT_REGION like "32%" '
        } else {
          regionalismParam.parentRegion = getUser().companyCode.substr(0, 6)
        }
        regionalismParam.level = '3' // 区
        regionalismParam.fields = {include: 'regionName,rowId'}
        axios.all([
          api.requestJava('POST', BasePath.EMPLOYEE_SELECT, monopolyAdmParam), // 专卖管理员
          api.requestJava('POST', BasePath.REGIONALISMS_SELECT, regionalismParam) // 行政区划
        ])
          .then(axios.spread(function (_monopolyAdmId, _regionalismId) {
            _this.options_monopolyAdm = JSON.parse(JSON.stringify(_monopolyAdmId.data.data))
            _this.options_regionalism = JSON.parse(JSON.stringify(_regionalismId.data.data))
          }))
      },
      loadLevel2 () {
        getCodeList('HOURS', (data) => {
          this.options_hours = data
        }) // 营业时间
        getCodeList('TERMS', (data) => {
          this.options_terms = data
        }) // 信息终端
        getCodeList('LOGO_TYPE', (data) => {
          this.options_logoType = data
        }) // 门头标识
        getCodeList('SAMPLE_FORM', (data) => {
          this.options_sampleForm = data
        }) // 出样形式
        getCodeList('SHOP_PLACE', (data) => {
          this.options_shopPlace = data
        }) // 店铺地段
        getCodeList('ADVERTISEMENT_AREA', (data) => {
          this.options_advertisementArea = data
        }) // 广告面积
        getCodeList('OPERATION_AGE_LIMIT', (data) => {
          this.options_operationAgeLimit = data
        }) // 经营年限
        getCodeList('DISPLAY_CAPABILITY', (data) => {
          this.options_displayCapability = data
        }) // 前柜
        getCodeList('SOFTWARE_CAPABILITY', (data) => {
          this.options_softwareCapability = data
        }) // 软件使用能力
        getCodeList('RECOMMEND_CAPABILITY', (data) => {
          this.options_recommendCapability = data
        }) // 推介能力
        getCodeList('COMMUNICATION_CAPABILITY', (data) => {
          this.options_communicationCapability = data
        }) // 沟通能力
        let _this = this
        let companyIdParam = {} // 公司
        companyIdParam.orgRoleTypId = '202'
        companyIdParam.orgUnitId = getUser().companyId
        companyIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
        let countyIdParam = {} // 分公司
        countyIdParam.orgRoleTypId = '203'
//        countyIdParam.orgUnitId = getUser().countyId
        countyIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
        let marketOrgParam = {} // 服务科
//        marketOrgParam.orgUnitId = getUser().deptId
        marketOrgParam.orgRoleTypId = '207'
        marketOrgParam.fields = {include: 'orgRoleNm,orgUnitId'}
        axios.all([
          api.requestJava('POST', BasePath.SELECT_FACTORYIDGROUP, companyIdParam), // 公司
          api.requestJava('POST', BasePath.SELECT_FACTORYIDGROUP, countyIdParam), // 分公司
          api.requestJava('POST', BasePath.SELECT_FACTORYIDGROUP, marketOrgParam) // 服务科
        ])
          .then(axios.spread(function (_companyId, _countyId, _marketOrg) {
            _this.options_companyId = _companyId.data.data
//            _this.options_countyId = _countyId.data.data
//            _this.options_marketOrg = _marketOrg.data.data
          }))
      },
      loadLevel3 () {
        getCodeList('TAXPAYER_TYPE', (data) => {
          this.options_taxpayerType = data
        }) // 纳税人分类
        getCodeList('SALES_ENVIRONMENTAL', (data) => {
          this.options_salesEnvironmental = data
        }) // 销售环境
        getCodeList('ACCEPTANCE_MODE', (data) => {
          this.options_orderMethod = data
        }) // 订货方式
        getCodeList('CUSTOMER_GRADE', (data) => {
          this.options_customerGrade = data
        }) // 客户级别
        getCodeList('CUSTOMER_VISIT_BATCH', (data) => {
          this.options_visitBatch = data
          console.log('CUSTOMER_VISIT_BATCH::' + JSON.stringify(this.options_visitBatch))
        }) // 拜访批次
        let _this = this
        let custmgrParam = {} // 客户经理
        custmgrParam.place = '135'
        custmgrParam.companyId = getUser().companyId
        custmgrParam.countyDept = getUser().countyId
        custmgrParam.fields = {include: 'employeeName,rowId'}
        custmgrParam.status = 1
        let visitsalesmanParam = {}  // 电话订货员
        visitsalesmanParam.place = '069'
        visitsalesmanParam.companyId = getUser().companyId
        visitsalesmanParam.countyDept = getUser().countyId
        visitsalesmanParam.fields = {include: 'employeeName,rowId'}
        visitsalesmanParam.status = 1
        let delivererParam = {}  // 送货员
        delivererParam.place = '091'
        delivererParam.companyId = getUser().companyId
        delivererParam.countyDept = getUser().countyId
        delivererParam.fields = {include: 'employeeName,rowId'}
        delivererParam.status = 1
        let monopolyAdmParam = {} // 专卖管理员
        monopolyAdmParam.place = '039'
        monopolyAdmParam.companyId = getUser().companyId
        monopolyAdmParam.countyDept = getUser().countyId
        monopolyAdmParam.fields = {include: 'employeeName,rowId'}
        let regionalismParam = {} // 行政区划
        if (Number(getUser.unitLevel) === 1) {
          regionalismParam.whereClause = 'and PARENT_REGION like "32%" '
        } else {
          regionalismParam.parentRegion = getUser().companyCode.substr(0, 6)
        }
        regionalismParam.level = '3' // 区
        regionalismParam.fields = {include: 'regionName,rowId'}
        let bankIdParam = {} // 银行
        bankIdParam.fields = {include: 'bankdesc,rowId'}
        let companyIdParam = {} // 公司
        companyIdParam.orgRoleTypId = '202'
        companyIdParam.orgUnitId = getUser().countyId
        companyIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
        let countyIdParam = {} // 分公司
        countyIdParam.orgRoleTypId = '203'
        countyIdParam.orgUnitId = getUser().countyId
        countyIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
        let marketOrgParam = {} // 服务科
        marketOrgParam.orgUnitId = getUser().countyId
        marketOrgParam.orgRoleTypId = '207'
        marketOrgParam.fields = {include: 'orgRoleNm,orgUnitId'}
        let starGradeParam = {} // 客户星级
        starGradeParam.companyId = getUser().companyId
        starGradeParam.typeCode = 'STAR_GRADE'
        console.log('starGradeParam:' + JSON.stringify(starGradeParam))
        axios.all([
          api.requestJava('POST', BasePath.EMPLOYEE_SELECT, custmgrParam), // 客户经理
          api.requestJava('POST', BasePath.EMPLOYEE_SELECT, visitsalesmanParam), // 订货员
          api.requestJava('POST', BasePath.EMPLOYEE_SELECT, delivererParam), // 送货员
          api.requestJava('POST', BasePath.BANK_SELECT, bankIdParam), // 银行
          api.requestJava('POST', BasePath.CUSTOMER_STARGRADE, starGradeParam) // 客户星级

        ])
          .then(axios.spread(function (_custmgrId, _visitsalesmanId, _delivererId, _bankId, _starGrade) {
            _this.options_custmgrId = _custmgrId.data.data
            _this.options_visitsalesmanId = _visitsalesmanId.data.data
            _this.options_delivererId = _delivererId.data.data
            _this.options_bankId = _bankId.data.data
            _this.options_starGrade = _starGrade.data.data
            console.log('客户星级：' + JSON.stringify(_this.options_starGrade))
          }))
      },
      init () {
        this.customerCode = ''
        this.customerDesc = ''
        this.shortCode = ''
        let param = {}
        param.rowId = this.rowId
        param.haveAttach = '1'
//        api.requestLocal('static/json/customer.json', headers)
        console.log('CUSTOMER_SELECTONE_param:' + JSON.stringify(param))
        api.requestJava('POST', BasePath.CUSTOMER_SELECTONE, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              console.log('request', request.data)
              console.log('countyIdcountyIdcountyId' + request.data.data.countyId)
              // getNextDept
              let paramNextDept = {}
              paramNextDept.deptId = request.data.data.companyId
              paramNextDept.roleType = '203'
              this.getNextDept(paramNextDept, 1)  // 获取分公司
              let paramCountyIdNextDept = {}
              paramCountyIdNextDept.deptId = request.data.data.countyId
              paramCountyIdNextDept.roleType = '207'
              this.getNextDept(paramCountyIdNextDept, 2) // 获取部门
              Object.assign(this.custForm, request.data.data)
              let tempfiles = request.data.data.files
              var i = 0
              tempfiles.forEach((e) => {
                if (tempfiles[i].fileType === 'legal_attach_photo') {
                  this.custForm.filesLegal.push(tempfiles[i])
                }
                if (tempfiles[i].fileType === 'display_attach_photo') {
                  this.custForm.filesDisplay.push(tempfiles[i])
                }
                if (tempfiles[i].fileType === 'storeFront_attach_photo') {
                  this.custForm.filesStorefront.push(tempfiles[i])
                }
                i++
              })
              this.changeCheckBoxValueNumtoBoolean(this.custForm) // checkBox 值转换
            } else {
              this.$notify.error({ title: '提示', message: request.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      changeCheckBoxValueNumtoBoolean (src) {
        console.log('src.isChain::::' + src.isChain)
        if (Number(src.status) === 1) src.status = true // 状态
        if (src.isChain === 'Y') src.isChain = true // 是否连锁
        if (Number(src.isNight) === 1) src.isNight = true // 是否夜店
        if (Number(src.confiscateCustFlg) === 1) src.confiscateCustFlg = true // 是否罚没定点户
        if (Number(src.reserveTag1) === 1) src.reserveTag1 = true // 是否标准店
        if (Number(src.seflCustFlg) === 1) src.seflCustFlg = true // 是否重点客户
        if (Number(src.funcCustFlg) === 1) src.funcCustFlg = true // 是否功能店
        if (Number(src.reserveTag2) === 1) src.reserveTag2 = true // 信息采集点
        this.orderSche = src.orderSche.substr(1, src.orderSche.length - 2).split(',')
      },
      changeCheckBoxValuetBooleantoNum (src) {
        if (src.status === true) { src.status = 1 } else { src.status = 0 } // 状态
        if (src.isChain === true) { src.isChain = 'Y' } else { src.isChain = 'N' } // 是否连锁
        if (src.isNight === true) { src.isNight = 1 } else { src.isNight = 0 } // 是否夜店
        if (src.confiscateCustFlg === true) { src.confiscateCustFlg = 1 } else { src.confiscateCustFlg = 0 } // 是否罚没定点户
        if (src.reserveTag1 === true) { src.reserveTag1 = 1 } else { src.reserveTag1 = 0 } // 是否标准店
        if (src.seflCustFlg === true) { src.seflCustFlg = 1 } else { src.seflCustFlg = 0 } // 是否重点客户
        if (src.funcCustFlg === true) { src.funcCustFlg = 1 } else { src.funcCustFlg = 0 } // 是否功能店
        if (src.reserveTag2 === true) { src.reserveTag2 = 1 } else { src.reserveTag2 = 0 } // 信息采集点
//        alert(this.orderSche)
      },
      handleAvatarSuccess (res, file) {
        this.imageUrl = URL.createObjectURL(file.raw)
      },
      beforeAvatarUpload (file) {
        let fd = new FormData()
        let reader = new FileReader()
        reader.readAsDataURL(file)
        fd.append('file', file)
        const isJPG = file.type === 'image/jpeg'
        const isLt2M = file.size / 1024 / 1024 < 2
        if (!isJPG) {
          this.$notify.error('上传头像图片只能是 JPG 格式!')
        }
        if (!isLt2M) {
          this.$notify.error('上传头像图片大小不能超过 2MB!')
        }
        return isJPG && isLt2M
      },
      startTime () {},
      backClk () {
        this.$router.push('/Customer')
      },
      saveClk () {
        this.changeCheckBoxValuetBooleantoNum(this.custForm) // 转换数据
        this.custForm.orderSche = "'" + this.orderSche + "'" // this.orderSche
        let params = this.custForm
        // 添加附件上传
//        this.custForm.files = []
        let files = []
        let tempLegalfiles = this.$refs.uploadPicLegal.getFiles()
        let tempDisplayfiles = this.$refs.uploadPicDisplay.getFiles()
        let tempStoreFrontfiles = this.$refs.uploadPicStorefront.getFiles()
        var i = 0
        if (tempLegalfiles.length > 0) {
          tempLegalfiles.forEach((e) => {
            let legal = {}
            legal.fileName = tempLegalfiles[i].fileName
            legal.fileType = 'legal_attach_photo'
            legal.fileData = tempLegalfiles[i].fileData
//            legal.fileData = this.edit.data.form.files[i].fileData
            files.push(legal)
            i++
          })
        }
        var j = 0
        if (tempDisplayfiles.length > 0) {
          tempDisplayfiles.forEach((e) => {
            let display = {}
            display.fileName = tempDisplayfiles[j].fileName
            display.fileType = 'display_attach_photo'
            display.fileData = tempDisplayfiles[j].fileData
            files.push(display)
            j++
          })
        }
        var k = 0
        if (tempStoreFrontfiles.length > 0) {
          tempStoreFrontfiles.forEach((e) => {
            let storeFront = {}
            storeFront.fileName = tempStoreFrontfiles[k].fileName
            storeFront.fileType = 'storeFront_attach_photo'
            storeFront.fileData = tempStoreFrontfiles[k].fileData
            files.push(storeFront)
            k++
          })
        }
        params.files = files
        params.haveAttach = '1'
        console.log(JSON.stringify(params))
        api.requestJava('POST', BasePath.CUSTOMER_UPDATE, params)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.$message({ type: 'success', message: '保存成功!' })
              this.backClk()
            } else {
              this.$notify.error({ title: '提示', message: '更新错误' })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      getNextDept (params, level) {
        this.flag = 0
        api.requestJava('POST', BasePath.CUSTOMER_NEXTDEPT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (Number(level) === 1) {
                this.options_countyId = request.data.data
              }
              if (Number(level) === 2) {
                this.options_marketOrg = request.data.data
                this.options_marketOrg.forEach((val, key) => {
                  if (Number(this.custForm.marketOrg) === Number(val.value)) {
                    this.flag = 1
                  }
                })
                if (this.flag === 0) {
                  this.custForm.marketOrg = ''
                }
                console.log('options_marketOrg:' + JSON.stringify(this.options_marketOrg))
              }
            }
          })
      },
      countyChange (val) {
        let params = {}
        params.deptId = Number(val)
        params.roleType = '207'
        this.getNextDept(params, 2)
      },
      UploadUrl () {
        return config.imageURL
      },
      getFileUrl (obj) {
        let url
        url = window.URL.createObjectURL(obj.files.item(0))
        return url
      }
    },
    queryrules: {
    },
    components: {
      InputTemp, DatePickerTemp, uploadTemp, compositeInput, _BTN_FILTER
    }
  }
</script>
