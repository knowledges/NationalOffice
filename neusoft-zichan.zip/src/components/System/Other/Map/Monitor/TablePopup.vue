<style scoped>
  .el-dialog {
    padding-bottom: 0!important;
  }
</style>
<template>
  <div>
    <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :modal-append-to-body="false" :close-on-click-modal="false" :close-on-press-escape="false"  :size='dialogObj.size' :before-close="closeModalEve">
        <tabModule
          :coloumHeader="coloumHeader"
          :coloumDate="array"
        ></tabModule>
    </el-dialog>
  </div>
</template>
<script>
  import tabModule from '@/components/Template/Restructure/Table.vue'
  import api from '@/api'
//  import { changeListValueByCode } from '@/utils/common'
  import BasePath from '@/config/BasePath'
  import { getUser, getCodeList } from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      getCodeList('VISIT_MODE', (data) => {
        this.changeValueDate.visitMode.group = data
        console.log(JSON.stringify(this.changeValueDate.visitMode.group))
      }) // 拜访方式
//      this.init()
    },
    updated () {
      console.log('updated进入弹出框，获得数据', this.dialogObj)
      if (Number(getUser().unitLevel) === 1) {
        this.isShow = false
      }
    },
    data () {
      return {
        coloumHeader: [
          {
            prop: 'customerName',
            label: '客户名称',
            coloumProp: {width: '160px'}
          },
          {
            prop: 'addr',
            label: '经营地址',
            coloumProp: {width: '160px'}
          },
          {
            prop: 'permitNo',
            label: '许可证号',
            coloumProp: {width: '110px'}
          },
          {
            prop: 'legalPerson',
            label: '法人',
            coloumProp: {width: '80px'}
          },
          {
            prop: 'customerGrade',
            label: '档级',
            coloumProp: {width: '80px'}
          },
          {
            prop: 'expectedTime',
            label: '拜访时间',
            coloumProp: {width: '100px'}
          },
          {
            prop: 'visitMode',
            label: '拜访方式',
            coloumProp: {formatter: this.changeValue, width: '80px'}
          },
          {
            prop: 'title',
            label: '服务内容',
            coloumProp: { type: 'array', width: '100px' }
          },
          {
            prop: 'notes',
            label: '服务详情',
            coloumProp: { type: 'array', width: '180px' }
          },
          {
            prop: 'files',
            label: '照片展示',
            coloumProp: { type: 'img', width: '120px' }
          }
        ],
        array: [],
        changeValueDate: {
          visitMode: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          }
        }
      }
    },
    methods: {
      init () {
        var params = {}
        params.visitor = this.dialogObj.visitor
        params.companyId = this.dialogObj.companyId
        params.beginDate = this.dialogObj.beginDate
        params.endDate = this.dialogObj.endDate
        api.requestJava('POST', BasePath.COMMON_SELSECTVISIT, params)
          .then((reponse) => {
            if (Number(reponse.data.code) === 200) {
              this.array = reponse.data.data
            }
          })
      },
      closeModalEve () {
        this.dialogObj.dialogVisible = false
      },
      changeValue (row, column) {
        if (Number(row.visitMode) === 0) {
          row.visitMode = '不拜访'
        } else if (Number(row.visitMode) === 1) {
          row.visitMode = '现场拜访'
        } else if (Number(row.visitMode) === 2) {
          row.visitMode = '电话拜访'
        }
      }  // 转换list中的code
    },
    components: {
      tabModule
    }
  }
</script>

<style scoped>
  .item__label_popup {
    text-align: right;
    vertical-align: middle;
    float: right;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 8px 11px 0;
    box-sizing: border-box;
    /* display: inline-block; */
  }
  .el-input, .el-input__inner {
    /*width: '';*/
    display: inline-block;
  }
  .container-fluid_new {
    background: #FFF;
  }
</style>
