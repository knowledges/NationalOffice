<template lang="html">
  <div class="sfc-table-wrapper">
    <table class="sfc-table" :style="{'height': `${wrapperHeight}px`}">
      <tbody class="sfc-table-bg">
        <tr>
          <td v-for="day in eventsWeek" :class="{'highlight': day.moment.isBetween(...highlightTimeRange, 'day', '[]')}" style="cursor:pointer;" :data-date="day.dateText" @click="recordDate('start', $event)" >
          </td>
        </tr>
      </tbody>
    </table>
    <table class="sfc-table sfc-events-table" ref="eventsTable">
      <tbody>
        <tr class="sfc-date">
          <td v-for="day in eventsWeek" :class="{'not-current-month': !day.moment.isSame(monthMoment, 'month')}"  v-bind:class="[ day.moment.format('YYYY-MM-DD') === currentDate ? 'current-date': 'not-current-date' ]"   ><span :class="{'not-current-month': !day.moment.isSame(monthMoment, 'month')}">{{ day.date }}</span></td>
        </tr>
        <tr class="sfc-events" v-for="i in maxCount">
          <template v-for="day in eventsWeek">
            <td v-if="day.events[0]"  v-bind:class="[ day.events[0].isOffday === 'Y' ? 'isOffday': 'noOffday' ]">
              <div v-if="day.events[0].target === 'Y'">
                <i  class="el-icon-check"></i>
              </div>
              <div v-else></div>
            </td>
            <td v-else  class="noOffday">
            </td>
          </template>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import { dateFormat } from '@/utils/dateFormat.js'
const WAIT_TIME = 100
export default {
  props: {
    monthMoment: {
      type: Object
    },
    week: {
      type: Array,
      required: true
    },
    events: {
      type: Array,
      default: []
    },
    highlightTimeRange: {
      type: Array,
      default: []
    }
  },
  data () {
    return {
      wrapperHeight: 0,
      currentDate: ''
    }
  },
  computed: {
    eventsWeek () {
      let week = this.week.map((day) => {
        day.events = []
        day.dateText = day.moment.format('YYYY-MM-DD')
        this.events.forEach(function (eventItem, eventIndex) {
          if (eventItem.calDate === day.dateText) {
            day.events[0] = eventItem
          }
        })
        return day
      })
      return week
    },
    maxCount () {
      return Math.max.apply(null, this.eventsWeek.map(day => day.events.length))
    }
  },
  watch: {
    eventsWeek () {
      this.updateHeight()
    }
  },
  mounted () {
    this.updateHeight()
    this.currentDate = this.getNowTime()
  },
  methods: {
    getNowTime () {
      return dateFormat(new Date().getTime(), 'YYYY-MM-DD')
    },
    recordDate (point, e) {
      console.log('monthMoment', this.monthMoment)
      if (this._recordTimer) {
        clearTimeout(this._recordTimer)
      }
      this._recordTimer = setTimeout(() => {
        this.$emit('select', point, e)
      }, WAIT_TIME)
    },
    updateHeight () {
      this.$nextTick(() => {
        let height = this.$refs.eventsTable.clientHeight
        this.wrapperHeight = height
      })
    }
  }
}
</script>

<style scoped rel="stylesheet/scss" lang="scss">
  .el-icon-check {
    font-size: 20px;
    color: #ff971f;
  }
  .isOffday {
    background-color: #fff1d0;
    border: 1px solid #CCC;
    height: 80px;
    color: #000;
    text-align: center;
  }
  .noOffday {
    background-color: #ffffff;
    border: 1px solid #CCC;
    height: 80px;
    color: #000;
    text-align: center;
  }
  .sfc-button {
    display: inline-block;
    height: 24px;
    padding: 0 5px;
    border: 1px solid #666;
    border-color: #3b91ad;
    color: #3b91ad;
    border-radius: 4px;
    cursor: pointer;
    &:hover {
      color: darken(#3b91ad, 50%);
      border-color: #3b91ad;
    }
  }
  .sfc-month-hint{
    margin-bottom: 10px;
    text-align: center;
    zoom: 1;
    height: auto;
    &:before,
    &:after {
      content: " ";
      display: table;
    }
    &:after {
      clear: both;
      visibility: hidden;
      font-size: 0;
      height: 0;
    }
    .month-info{
      float: left;
    }
    .operations{
      float: right;
    }
  }
  .sfc-wrapper{
    width: 800px;
    margin: auto;
    .sfc-table-wrapper {
      position: relative;
      margin-top: -1px;
      .sfc-events-table {
        position: absolute;
        top: 0;
        left: 0;
        pointer-events: none;
      }
    }
    .sfc-table{
      width: 100%;
      table-layout: fixed;
      border-spacing: 0;
      border-collapse: collapse;
      user-select: none;
      .sfc-table-bg{
        td {
          border: 1px solid #CCC;
          height: 80px;
          background-color: white;
          color: #000;
          &.highlight{
            background-color: rgba(59, 143, 173, .1)
          }
        }
      }
    }
    .sfc-date{
      text-align: center;
      font-size: 14px;
      .not-current-month {
        color: #919191;
      }
      .not-current-date {
      }
      .current-date {
        background-color: #42d885;
      }
      td {
        padding-top: 2px;
        padding-right: 5px;
        background-color: #cfcfcf;
        color: #101010;
        align-items: center;
        border: 1px solid #b6b6b6;
      }
    }
    .sfc-events {
      .sfc-event-item {
        margin: -1px 0 2px;
        padding: 2px;
        border: 1px solid #666;
        border-color: #3b91ad;
        background-color: #3b91ad;
        color: #fff;
        font-size: 12px;
        line-height: 1.2;
        overflow: hidden;
        text-overflow: ellipsis;
        pointer-events: auto;
        &.is-start {
          margin-left: 2px;
          border-top-left-radius: 2px;
          border-bottom-left-radius: 2px;
        }
        &.is-end {
          margin-right: 2px;
          border-top-right-radius: 2px;
          border-bottom-right-radius: 2px;
        }
      }
    }
  }
</style>
