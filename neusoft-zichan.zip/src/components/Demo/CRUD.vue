<style scoped>
  .row {
    padding: 5px 0;
  }
</style>
<template>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-6 col-sm-12">
        <div class="btn-group" role="group" aria-label="btn group">
          <button type="button" class="btn btn-info" @click="addClk">
            <i class="fa fa-plus"></i>
            新增
          </button>
          <button type="button" class="btn btn-danger" @click="batchDelClk">
            <i class="fa fa-remove"></i>
            批量删除
          </button>
        </div>
      </div>
      <div class="col-md-6 col-sm-12" style="text-align: right;">
        <_INPUT @on-change="onendChange"
                :filmode="filmode" :filType="filType" :fileName="fileName"
                :datasource.sysc="tableData" :keyup="keyupend"/>
      </div>
    </div>
    <div>
      <el-row class="el-row">
        <el-col :span="24">
          <_TABLE :columns="columnHeader" :tableData="dataSource" :tableHeight="400"
                  :sortChange="sortChange" :rowClick="rowClick" :btnMode=true :btns="btns"
                  :pageSizes="pageSizes" :currentPage=currentPage :pageSize=pageSize
                  :totalCount=totalCount :queryData=this.queryData
                  :checkBox=true :columnType=columnType
                  :tableType="tableType"
                  :select="select" :selectAll="selectAll"></_TABLE>
        </el-col>
      </el-row>
    </div>
    <_POPUP :dialogObj='dialogObj1' @confirmBack="confirmBack1"/>
    <_POPUP :dialogObj='dialogObj5' @confirmBack="confirmBack5" />
    <ul>
      <template v-for="item in userInfo">
        <li>{{item.value}}</li>
      </template>
    </ul>
  </div>
</template>
<script>
import _TABLE from '../Template/TabPagin/Table.vue'
import _INPUT from '../Template/filter/InputTemp.vue'
import _POPUP from '../Template/Popup/Popup.vue'
import { mapState } from 'vuex'
import axios from 'axios'
import api from '@/api'
export default {
  mounted () {
    this.queryData(this.currentPage, this.pageSize)

    /**
     * 多请求
     * callback first：第一个回调返回值
     * callback scend：第二个回调返回值
     * callback third：第三个回调返回值
     */
    axios.all([
      this.$store.dispatch('getCompany'),
      this.$store.dispatch('getDeparment'),
      api.requestJava('POST', 'user/selectList.do', {})
    ])
    .then(axios.spread(function (first, scend, third) {
      console.log('first', first)
      console.log('scend', scend)
      console.log('third', third)
    }))

    // 请求 公司
    this.$store.dispatch('getCompany')
      .then((data) => {
        if (data === 'success') {
          console.log('company', this.company)
//          this.dialogObj5.dialogVisible = true
        } else if (data === '401') {
          this.$message('登录失效')
          this.dialogObj5.dialogVisible = true
        }
      })
    // 请求部门
    this.$store.dispatch('getDeparment')
      .then((data) => {
        if (data === 'success') {
          console.log('deparment', this.deparment)
        } else if (data === '401') {
          this.$message('登录失效')
        }
      })
  },
  data () {
    return {
      /** table **/
      columnType: 'selection',
      tableType: '4',
      currentPage: 1, // 默认当前第一页
      pageSize: 10,  // 默认每页20条数据
      pageSizes: [2, 5, 10, 20, 40, 50], // 分页数选择项
      totalCount: 0, // 表格总记录数
      columnHeader: [
        {
          value: 'user', // 列的值
          label: '登录账号', // 列的显示字段
          align: 'center' // 列的对齐方式，[left, center, right]，选填，默认是left
        }, {
          value: 'value',
          className: 'header', // 列的css样式（选填）
          label: '姓名'
        }, {
          value: 'userID',
          label: '工号',
          align: 'left'
        }, {
          value: 'email',
          label: '邮箱',
          align: 'left'
        }, {
          value: 'company',
          label: '公司',
          align: 'left'
        }
      ],
//      tableData: JSON.parse(localStorage.getItem('tableData')),
      fileName: ['user'],
      tableData: [
        {
          id: 'BS20170001',
          user: 'LiuXiaoJing',
          value: '刘晓静',
          userID: 'T15401101',
          email: 'bcm@163.com',
          company: '连云港市公司'
        },
        {
          id: 'BS20170002',
          user: 'LuHang',
          value: '陆杭',
          userID: 'T15401102',
          email: 'bcm@163.com',
          company: '连云港市公司'
        },
        {
          id: 'BS20170003',
          user: 'WuXiaoLong',
          value: '吴晓龙',
          userID: 'T15401103',
          email: 'bcm@163.com',
          company: '连云港市公司'
        },
        {
          id: 'BS20170004',
          user: 'YuLei',
          value: '於磊',
          userID: 'T15401104',
          email: 'bcm@163.com',
          company: '连云港市公司'
        },
        {
          id: 'BS20170005',
          user: 'HuangJiJian',
          value: '黄继建',
          userID: 'T15401104',
          email: 'bcm@163.com',
          company: '连云港市公司'
        },
        {
          id: 'BS20170006',
          user: 'lums',
          value: '陆明生',
          userID: 'T15401104',
          email: 'bcm@163.com',
          company: '连云港市公司'
        }
      ],
      btns: {
        btnArr: [
          {
            label: '修改', // 按钮的名称
            value: 'modify', // 按钮的值
            functionName: this.modify // 按钮的方法
          },
          {
            label: '删除',
            value: 'del',
            functionName: this.del
          }
        ],
        value: 'operation',
        label: '操作'
      },
      dataSource: [], // 当前页的数据
      /** filter **/
      filmode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
      filType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
      keyupend: false,   // 输入筛选；true：之前展示；false：之后展示
      templTableData: [], // 临时记录tableDate的值
      /** 弹出层 **/
      dialogObj1: {
        title: '新增用户',
        type: 'addUser',
        dialogVisible: false,
        data: {
          form: {
            name: '',
            Id: '',
            password: '',
            confirmPass: '',
            company: { url: 'static/json/company.json', value: '' },
            department: { url: 'static/json/department.json', value: '' },
            email: '',
            number: '',
            status: '',
            isLogIn: '',
            tel: '',
            phone: '',
            date: '',
            mark: '',
            upload: {type: '', url: 'https://jsonplaceholder.typicode.com/posts/'}
          }
        }
      },
      dialogObj5: {
        title: '会话失效',
        type: 'sessionFailured',
        dialogVisible: false,
        size: 'tiny',
        data: {
          form: {
            userCode: '',
            password: ''
          }
        }
      },
      tmp: {
        title: '新增用户',
        type: 'addUser',
        dialogVisible: false,
        data: {
          form: {
            name: '',
            Id: '',
            password: '',
            confirmPass: '',
            company: { url: 'static/json/company.json', value: '' },
            department: { url: 'static/json/department.json', value: '' },
            email: '',
            number: '',
            status: '',
            isLogIn: '',
            tel: '',
            phone: '',
            date: '',
            mark: '',
            upload: {type: '', url: 'https://jsonplaceholder.typicode.com/posts/'}
          }
        }
      },
      /** 实际操作 **/
      sel_id: '', // 当前选中的值id
      sel_all: []
    }
  },
  computed: {
    ...mapState([
      'userInfo',
      'company',
      'deparment'
    ])
  },
  methods: {
    queryData (page, size) {
      // 前段分页
      this.totalCount = this.tableData.length
      this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
    }, // 分页请求
    select (selection, index) {
      console.log('select', selection)
      if (selection[0] !== undefined) {
//        this.sel_id = index.id
        this.sel_all = []
        for (var i in selection) {
          this.sel_all.push(selection[i].id)
        }
        console.log(this.sel_all)
      } else {
//        this.sel_id = ''
      }
    }, // 选中某1条
    selectAll (data) {
      this.sel_all = []
      for (var i in data) {
        this.sel_all.push(data[i].id)
      }
    }, // 全选
    addClk () {
      this.dialogObj1.dialogVisible = true
    }, // 新增
    modify (index, row) {
      console.log('row', row)
      this.dialogObj1.data.form.number = row.id
      this.dialogObj1.data.form.Id = row.user
      this.dialogObj1.data.form.name = row.value
      this.dialogObj1.data.form.email = row.email
      this.dialogObj1.data.form.company.value = row.company
      this.dialogObj1.data.form.department.value = row.department
      console.log('form', this.dialogObj1.data.form)
      this.dialogObj1.dialogVisible = true
    }, // 修改
    del (index, row) {
      this.$confirm('确定删除此条信息吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$message({ type: 'success', message: '删除成功!' })
        this.$delete(this.dataSource, index)
      }).catch(() => {
        this.$message({ type: 'info', message: '已取消删除!' })
      })
    },  // 删除
    batchDelClk () {
      if (this.sel_all.length > 0) {
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$message({ type: 'success', message: '根据id删除一下数据' + this.sel_all })
        }).catch(() => {
          this.$message({ type: 'info', message: '已取消删除!' })
        })
      }
    },  // 批量删除
    onendChange (val) {
      var tmp = JSON.parse(val)
      if (Object.prototype.toString.call(tmp) === '[object Array]') {
        this.dataSource = tmp
      } else {
        this.dataSource = []
        this.dataSource.push(tmp)
      }
    }, // 过滤器修改事件
    confirmBack1 (msg) {
      let data = msg.data.form
      let params = {}
      params.id = data.Id
      params.user = data.name
      params.value = data.name
      params.userID = data.number
      params.email = data.email
      params.company = data.company.value
      params.department = data.department.value
      this.tableData.push(params)
      localStorage.setItem('tableData', JSON.stringify(this.tableData))
      this.$set(this.dialogObj1, 'data', this.tmp.data)
//      this.$router.go(0)
    },
    confirmBack5 (msg) {
      let headers = {}
      headers.userCode = msg.data.form.username
      headers.password = msg.data.form.password
      let array = [headers, this]
      this.$store.dispatch('login', array)
        .then((msg) => {
          if (msg === 'success') {
            this.dialogObj5.dialogVisible = false
          }
        })
        .catch((err) => { console.log(err) })
    },
    sortChange (msg) {},
    rowClick (msg) {}
  },
  components: {
    _TABLE,
    _INPUT,
    _POPUP
  },
  watch: {
    userInfo (newv, old) {
      console.log('newv', newv)
    }
  }
}
</script>
