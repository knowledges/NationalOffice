<!--qiu.bl-->
<style rel="stylesheet/scss" lang="scss" scoped>
  .el-col-24 {
    height: 36px;
  }
</style>
<template>
  <div class="container-fluid" style="height: 99%">
    <el-row class="filter_style">
      <el-form ref="searchForm" label-width="100px">
        <el-col :gutter="24" v-if="level == 1">
          <el-form-item label="查询周期">
            <el-date-picker
              v-model="timer"
              type="daterange"
              @change="dateChange"
              placeholder="选择日期范围">
            </el-date-picker>
            <el-button type="primary" @click="findDataClk">查询</el-button>
          </el-form-item>
        </el-col>
        <el-col :gutter="24" v-else>
          <el-col :span='6'>
            <el-form-item prop="countyId" label="数据范围">
              <_cascader @on-change="getChangeValue" @on-loading="getArrays"/>
            </el-form-item>
          </el-col>
          <el-col :span='9'>
            <el-form-item prop="actived" label="活动选择">
              <el-select v-model="planId" :clearable="true" placeholder="请选择活动">
                <template v-for="(item, key) in activedArr">
                  <el-option :label="item.title" :value="item.planId" :key="item.planId"></el-option>
                </template>
              </el-select>
              <el-button type="primary" @click="findClk">查询</el-button>
            </el-form-item>
          </el-col>
        </el-col>
      </el-form>
    </el-row>
    <div style="height: calc(100% - 94px)">
      <iframe id="myIframe" :src="htl" frameborder="0" allowtransparency="true" width="100%" height="100%" scrolling="yes"></iframe>
    </div>
  </div>
</template>
<script>
  import api from '@/api'
  import config from '@/config'
  import {getUser} from '@/config/info'
  import {dateFormat} from '@/utils/dateFormat'
  import BasePath from '@/config/BasePath'
  import _cascader from '@/components/Template/Cascader/Cascader.vue'
  export default {
    name: 'Find',
    mounted () {
      if (Number(getUser().unitLevel) === 1) {
        var date = new Date()
        if ((date.getMonth() + 1) > 6) {
          date = [new Date(date.getFullYear(), 6, 1, 0, 1), new Date(date.getFullYear(), 11, 31, 23, 59)]
        } else {
          date = [new Date(date.getFullYear(), 0, 1, 0, 1), new Date(date.getFullYear(), 5, 30, 23, 59)]
        }
        this.timer = date

        this.begin_date = dateFormat(Date.parse(this.timer[0]), 'YYYY-MM-DD')
        this.end_date = dateFormat(Date.parse(this.timer[1]), 'YYYY-MM-DD')
        this.findDataClk()
      } else {
        this.getAvtived(this.$route.params.fromId, this.$route.params.companyId)
      }
    },
    data () {
      return {
        begin_date: '',
        end_date: '',
        timer: [],
        level: getUser().unitLevel,
        tmp: [],
        planId: '', // 活动id
        companyId: '', // 公司 id
        whereStr: '', // in 语句
        reportId: '18ea96ed-e053-4b26-be22-4631f8dc21e1', // key
        formId: this.$route.params.fromId, // 表ID
        custArr: '', // 接口 选中市场经理下的所有客户经理的ID，
        activedArr: [],
        staffTree: [], // 人员树
        htl: ''
      }
    },
    methods: {
      findClk () {
        if (this.planId === '') {
          this.$notify({
            title: '警告',
            message: '活动不能为空不能为空',
            type: 'warning'
          })
          return
        }
        var sqlStr = ''
        if (Number(getUser().unitLevel) === 1) { // 展示所有
          sqlStr = 'select row_id from adb.md_employees'
          this.tmp.forEach((val, key) => {
            switch (key) {
              case 0:
                sqlStr = 'select row_id from adb.md_employees where company_id=' + val
                break
              case 1:
                sqlStr = 'select row_id from adb.md_employees where county_dept=' + val
                break
              case 2:
                sqlStr = 'select row_id from adb.md_employees where manager=' + val
                break
              case 3:
                sqlStr = val
                break
            }
          })
        } else if (Number(getUser().unitLevel) === 2) { // 展示该市下的所有分公司
          if (getUser().countyId === 'null') {
            sqlStr = 'select row_id from adb.md_employees where company_id=' + getUser().companyId
            this.tmp.forEach((val, key) => {
              switch (key) {
                case 0:
                  sqlStr = 'select row_id from adb.md_employees where county_dept=' + val
                  break
                case 1:
                  sqlStr = 'select row_id from adb.md_employees where manager=' + val
                  break
                case 2:
                  sqlStr = val
                  break
              }
            })
          } else if (getUser().countyId !== 'null' && Number(getUser().place) === 9999) {
            sqlStr = 'select row_id from adb.md_employees where county_dept=' + getUser().countyId
            this.tmp.forEach((val, key) => {
              switch (key) {
                case 0:
                  sqlStr = 'select row_id from adb.md_employees where manager=' + val
                  break
                case 1:
                  sqlStr = val
                  break
              }
            })
          } else if (getUser().countyId !== 'null' && getUser().deptId !== 'null' && Number(getUser().place) === 24) {
            if (this.tmp.length > 0) {
              sqlStr = this.tmp[0]
            } else {
              sqlStr = 'select row_id from adb.md_employees where manager=' + getUser().personId
            }
          } else if (Number(getUser().place) === 135) {
            sqlStr = getUser().personId
          }
        }
        this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + this.reportId + '&formId=' + this.formId + '&planId=' + this.planId + '&whereStr=b.visitor in (' + sqlStr + ')'
      },
      findDataClk () {
        this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=aa1a93bf-37ef-42f4-9576-54ccf5a96c29&form_id=' + this.formId + '&begin_date=' + this.begin_date + '&end_date=' + this.end_date
      },
      getCustMgrs (arr, id) { // 根据市场经理id 与数据里的treeId 对比；找到 市场经理下所有的客户经理
        arr.forEach((val, key) => {
          if (val.children && val.children.length > 0) {
            this.getCustMgrs(val.children, id)
          }
          if (val.treeId === id) {
            this.custArr += val.id + ','
          }
        })
      },
      getAvtived (fromId, companyId) {
        let params = {}
        params.formsId = fromId
        params.companyId = companyId
        api.requestJava('POST', BasePath.FW_COMMON_SELECTPLANSBYFORMID, params)
          .then((request) => {
            this.activedArr = request.data.data
          })
          .catch((err) => {
            this.$notify.error({title: '人员列表反回失败', message: err})
            console.error(err)
          })
      },
      getChangeValue (val) {
        this.tmp = val
      },
      getArrays (arr) {
        this.staffTree = arr
        console.log('测试：', arr)
      },
      dateChange (val) {
        var tmp = val.split(' - ')
        this.begin_date = tmp[0]
        this.end_date = tmp[1]
      }
    },
    components: {
      _cascader
    }
  }
</script>
