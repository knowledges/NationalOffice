<!-- 徐晓菁 -->
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='12'>
          <div v-if="isSelect">
            <el-form ref="searchForm" :model="searchForm" label-width="120px">
              <el-col :gutter="24">
                <el-col :span='12'>
                  <el-form-item label="活动事项">
                    <el-select v-model="searchForm.matterId"  multiple  :clearable="true" placeholder="请选择活动事项">
                      <template v-for="item in matterIdGroup">
                        <el-option :key="item.rowId"  :label="item.matterName" :value="item.rowId"></el-option>
                      </template>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='12'>
                  <div class="block">
                    <el-form-item label="活动周期">
                      <el-date-picker
                        v-model="datetime"
                        format="yyyy-MM-dd"
                        type="daterange"
                        :editable=false
                        :clearable=false
                        @change="datePickerChange"
                        placeholder="选择日期范围"
                        :picker-options="pickerOptions">
                      </el-date-picker>
                    </el-form-item>
                  </div>
                </el-col>
              </el-col>
            </el-form>
          </div>
        </el-col>
        <el-col :span="12">
          <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" :tableData="tableData" @on-click="exportEve" :isMore="isMore"></_BTN_FILTER>
        </el-col>
      </el-col>
    </el-row>
    <div>
       <_TABLE
         ref="table"
         stripe
         maxHeight="500"
         :data="dataSource"
         @update:data="tabChange" :reqParams="reqParams"
         :columns="columnHeader"
         :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
         :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
         @selection-change="selectionChange"></_TABLE>
    </div>
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve" />
    <!--<VIEW_POPUP_CONFIG :dialogObj='viewPop' @confirmBack="viewEditEve" />-->
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import { changeListValueByCode, dateFormat } from '@/utils/common'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import MY_POPUP_CONFIG from './Popup.vue'
//  import VIEW_POPUP_CONFIG from './viewPopup.vue'
  import log from '@/log'
  import api from '@/api'
  import axios from 'axios'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  export default {
    mounted () {
      // this.queryData(this.currentPage, this.pageSize)
//      getCodeList('YC_BUSINESS_TYPE', (data) => {
//        this.viewPop.data.form.businessTypeGroup = data
//      }) // 零售业态
//      getCodeList('YC_GEO_TYPE', (data) => {
//        this.viewPop.data.form.geoTypeGroup = data
//      }) // 市场类型
//      getCodeList('YC_OPERATION_SCALE', (data) => {
//        this.viewPop.data.form.operationScaleGroup = data
//      }) // 经营规模
//      getCodeList('CUSTOMER_GRADE', (data) => {
//        this.viewPop.data.form.customerGradeGroup = data
//      }) // 客户档级
      axios.all([
        api.requestJava('POST', BasePath.SELECT_MATTERIDGROUP, {status: '1'})
      ])
      .then(axios.spread((first) => {
        this.matterIdGroup = JSON.parse(JSON.stringify(first.data.data))
      }))
      this.initDate()
    },
    data () {
      return {
        isSelect: true,
        isMore: true, // 查询更多条件
        datetime: [new Date().setDate(1), new Date()],
        pickerOptions: {
          shortcuts: [{
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '当前月',
            onClick (picker) {
              const end = new Date()
              const start = new Date(new Date().setDate(1))
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }]
        },
        matterIdGroup: [], // 拜访情况
        customerGradeGroup: [],
        operationScaleGroup: [],
        geoTypeGroup: [],
        businessTypeGroup: [],
        /** 过滤的字段 **/
        fileName: ['matterName', 'makerNm', 'title'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '新增',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.addClk
          },
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 10,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'matterName', // 列的值
            label: '活动事项', // 列的显示字段
            columnsProps: {width: 150, align: 'left'}
          },
          {
            prop: 'title',
            label: '活动标题',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          },
          {
            prop: 'beginDate',
            label: '开始日期',
            columnsProps: {width: 120, align: 'left'}
          },
          {
            prop: 'endDate',
            label: '结束日期',
            columnsProps: {width: 120, align: 'left'}
          },
          {
            prop: 'status',
            label: '记录状态',
            columnsProps: {width: 120, align: 'center', formatter: this.changeValue}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 360, type: 'button'},
            cptProperties: [
              {
                label: '查看',
                value: 'view',
                icon: 'view',
                size: 'small',
                type: 'info',
                eventClick: this.view
              },
              {
                label: '修改',
                value: 'modify',
                icon: 'edit',
                size: 'small',
                type: 'warning',
                eventClick: this.modify
              },
              {
                label: '删除',
                value: 'del',
                icon: 'delete',
                size: 'small',
                type: 'danger',
                eventClick: this.del
              },
              {
                label: '分析查看',
                value: 'query',
                icon: 'search',
                size: 'small',
                type: 'primary',
                eventClick: this.fxck
              }
            ]
          }
        ],
        hasPagination: true,
        changeValueDate: {
          status: {
            type: 'text',
            group: [
              {value: '0', label: '未提交'},
              {value: '1', label: '提交'},
              {value: '2', label: '终止'},
              {value: '9', label: '作废'}
            ],
            key: 'value',
            value: 'label'
          }
        },
        tableData: [],
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        /** searchForm **/
        searchForm: {
          unitId: '',
          matterId: '',
          beginDate: '',
          endDate: '',
          status: ''
        },
        edit: {
          title: '活动发起',
          type: '3',
          num: 1,
          disable: false,
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              matterId: '',
              stepIds: '',
              stepId: [],
              unitId: '',
              deptId: '',
              maker: '',
              makerNm: '',
              parentId: '',
              beginDate: '',
              endDate: '',
              fpConds: '',
              title: '',
              notes: '',
              status: '',
              createdBy: '',
              ref: '',
              oldMatterId: '',
              haveAttach: '',
              files: []
            }
          }
        },
//        viewPop: {
//          title: '活动发起',
//          type: '3',
//          num: 1,
//          disable: false,
//          dialogVisible: false,
//          data: {
//            form: {
//              rowId: '',
//              matterId: '',
//              stepIds: '',
//              stepId: [],
//              unitId: '',
//              deptId: '',
//              maker: '',
//              makerNm: '',
//              parentId: '',
//              beginDate: '',
//              endDate: '',
//              fpConds: '',
//              title: '',
//              notes: '',
//              status: '',
//              createdBy: '',
//              ref: '',
//              oldMatterId: '',
//              haveAttach: '',
//              files: [],
//              customerGrade: '',
//              geoType: '',
//              businessType: '',
//              operationScale: '',
//              dataArea: {
//                type: '',
//                value: ''
//              }
//            }
//          }
//        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        sel_all_row: []
      }
    },
    methods: {
      fxck (index, row) {
        this.$router.push({name: 'ActivityInvestigation', params: {fromId: row.stepIds, activityId: row.rowId}})
      }, // 调研数据统计分析
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      datePickerChange () {
        this.searchForm.beginDate = this.getTime(Date.parse(this.datetime[0]))
        this.searchForm.endDate = this.getTime(Date.parse(this.datetime[1]))
        console.log('searchForm', this.searchForm)
      },
      query () {
        let params = {}
        let matterIds = this.listToString(this.searchForm.matterId, 'int')
        params.unitId = this.searchForm.unitId
        params.beginDate = this.searchForm.beginDate
        params.endDate = this.searchForm.endDate
        params.status = this.searchForm.status
        if (matterIds !== '') {
          params.whereClause = ' matter_Id in  (' + matterIds + ') '
        } else {
//          params.whereClause = '1=1 order by begin_date desc'
        }
        console.log('params', JSON.stringify(params))
        this.queryUpper(params)
      }, // 查询方法
      queryUpper (params) {
        this.reqParams.url = BasePath.ACTIVITY_SELECTCRMMATTERSLIST
        this.reqParams.params = params
        api.requestJava('POST', BasePath.ACTIVITY_SELECTCRMMATTERSLIST, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      initDate () {
        var myDate = new Date()
        this.searchForm.unitId = getUser().companyId
        this.searchForm.maker = getUser().personId
        this.searchForm.endDate = this.getTime(myDate.getTime())
        this.searchForm.beginDate = this.getTime(myDate.setDate(1))
        console.log('searchForm', this.searchForm)
        this.query()
      }, // 初始化时间并查询
      modify (index, row) {
        if (Number(row.status) === 1 || Number(row.status) === 2) {
          this.$message({type: 'info', message: '该记录已生效或终止，不可修改!'})
          return
        }
        this.findByIdUpper(row)
        this.edit.dialogVisible = true
      }, // 修改
      view (index, row) {
        this.findByIdUpper(row)
        this.edit.type = 1
        this.edit.dialogVisible = true
      },
      findByIdUpper (row) {
        let param = {}
        param.rowId = row.rowId
        param.haveAttach = '1'
        api.requestJava('POST', BasePath.ACTIVITY_SELECTONE, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              console.log('返回数据：' + JSON.stringify(request.data.data))
              Object.assign(this.edit.data.form, row)
              this.edit.data.form.files = request.data.data.files
              this.edit.data.form.oldMatterId = request.data.data.matterId
              this.edit.data.form.ref = request.data.data.ref
              this.edit.data.form.matterIdGroup = this.matterIdGroup
              if (row.stepIds !== '') {
                let steps = row.stepIds
                this.edit.data.form.stepId = steps.split(',')
              }
              Object.assign(this.edit.data.form, row)
//              this.viewPop.data.form.files = request.data.data.files
//              this.viewPop.data.form.oldMatterId = request.data.data.matterId
//              this.viewPop.data.form.ref = request.data.data.ref
//              this.viewPop.data.form.matterIdGroup = this.matterIdGroup
//              if (row.stepIds !== '') {
//                let steps = row.stepIds
//                this.viewPop.data.form.stepId = steps.split(',')
//              }
//              Object.assign(this.viewPop.data.form, row)
//              let param = JSON.parse(request.data.data.fpConds)
//              if ('DATA_AREAS' in param) {
//                if ('TYPE' in param.DATA_AREAS) {
//                  this.viewPop.data.form.dataArea.type = param.DATA_AREAS.TYPE
//                }
//                if ('VALUE' in param.DATA_AREAS) {
//                  this.viewPop.data.form.dataArea.value = param.DATA_AREAS.VALUE
//                }
//              }
//              if ('CUSTOMER_GRADE' in param) {
//                this.viewPop.data.form.customerGrade = param.CUSTOMER_GRADE
//              }
//              if ('GEO_TYPE' in param) {
//                this.viewPop.data.form.geoType = param.GEO_TYPE
//              }
//              if ('BUSINESS_TYPE' in param) {
//                this.viewPop.data.form.businessType = param.BUSINESS_TYPE
//              }
//              if ('ROUTE_ID' in param) {
//                this.viewPop.data.form.routeId = param.ROUTE_ID
//              }
//              if ('OPERATION_SCALE' in param) {
//                this.viewPop.data.form.operationScale = param.OPERATION_SCALE
//              }
//              if ('STATUS' in param) {
//                this.viewPop.data.form.status = '1'
//              }
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      editEve (msg) {
        if (msg === 'update') {
          this.saveUpper()
        }
        this.edit.dialogVisible = false
        let tmp = {
          title: '活动发起',
          type: '3',
          num: 1,
          disable: false,
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              matterId: '',
              stepIds: '',
              stepId: [],
              unitId: '',
              deptId: '',
              maker: '',
              makerNm: '',
              parentId: '',
              beginDate: '',
              endDate: '',
              fpConds: '',
              title: '',
              notes: '',
              status: '',
              createdBy: '',
              haveAttach: '',
              ref: '',
              oldMatterId: '',
              files: []
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
//      viewEditEve (msg) {
//        this.viewPop.dialogVisible = false
//      }, // 修改事件
      saveUpper () {
        let params = {}
        params.stepIds = this.listToString(this.edit.data.form.stepId, 'int')
        params.unitId = getUser().companyId
        params.deptId = getUser().deptId
        params.maker = getUser().personId
        params.makerNm = getUser().userName
        params.parentId = 1
        params.haveAttach = 1
        params.rowId = this.edit.data.form.rowId
        params.matterId = this.edit.data.form.matterId
        params.beginDate = dateFormat(Date.parse(this.edit.data.form.beginDate), 'YYYY-MM-DD')
        params.endDate = dateFormat(Date.parse(this.edit.data.form.endDate), 'YYYY-MM-DD')
        params.title = this.edit.data.form.title
        params.notes = this.edit.data.form.notes
        params.status = this.edit.data.form.status
        params.createdBy = getUser().personId
        params.ref = this.edit.data.form.ref
        let files = []
        console.log('files', this.edit.data.form.files)
        for (let i = 0; i < this.edit.data.form.files.length; i++) {
          if (this.edit.data.form.files[i].fileName === '') {
            return
          }
          console.log('files', this.edit.data.form.files[i])
          let rowS = {}
          rowS.fileName = this.edit.data.form.files[i].fileName
          rowS.fileType = 'visit_attach_photo'
          rowS.fileData = this.edit.data.form.files[i].fileData
          files.push(rowS)
        }
        params.fpConds = this.edit.data.form.fpConds
        params.files = files
        params.countDept = getUser().countyId
        if (this.edit.data.form.fpConds === '') {
          params.fpConds = JSON.stringify({DATA_AREAS: {}})
        }
        console.log('params', JSON.stringify(params))
        var url = BasePath.ACTIVITY_UPDATE
        if (this.edit.data.form.rowId === '') {
          url = BasePath.ACTIVITY_INSERT
        }
        api.requestJava('POST', url, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              this.query()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 保存
      listToString (values, type) {
        let result = ''
        for (let i = 0; i < values.length; i++) {
          if (type === 'int') {
            result = result + values[i] + ','
          } else if (type === 'string') {
            result = result + "'" + values[i] + "'" + ','
          }
        }
        if (result.length > 0) {
          result = result.substr(0, result.length - 1)
        }
        return result
      },
      del (index, row) {
        if (Number(row.status) === 1 || Number(row.status) === 2) {
          this.$message({type: 'info', message: '该记录已生效或终止，不可删除!'})
          return
        }
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.deleteUpper(row.rowId)
        }).catch(() => {
          this.$message({type: 'info', message: '已取消删除!'})
        })
      },  // 删除
      deleteUpper (val) {
        let params = {}
        params.rowId = val
        api.requestJava('POST', BasePath.ACTIVITY_DELETE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              this.query()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.result.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 删除接口
      batchDelClk () {},  // 批量删除
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.table.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      onendChange (val) {}, // 过滤器修改事件
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      dateFormatter (row, column) {
        var unixDate = row[column.property]
        return dateFormat(unixDate, 'YYYY-MM-DD')
      },  // 时间格式化
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      headerClick (column, event) {},
      isMoreClk () {
        this.isSelect = !this.isSelect
      },
      addClk () {
        var myDate = new Date()
        this.edit.data.form.beginDate = this.getTime(myDate.getTime())
        this.edit.data.form.endDate = this.getTime(myDate.getTime())
        this.edit.data.form.matterIdGroup = this.matterIdGroup
        this.edit.dialogVisible = true
      },
      sortChange (msg) {},
      rowClick (msg) {},
      selectionChange (rows) {}
    },
    components: {
      _TABLE,
      _POPUP,
      MY_POPUP_CONFIG,
//      VIEW_POPUP_CONFIG,
      _BTN_FILTER
    }
  }
</script>

<style scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-24 {
    height: 36px;
  }

</style>
