<template lang="html">
  <div class="sfc-table-wrapper">
    <table class="sfc-table" :style="{'height': `${wrapperHeight}px`}">
      <tbody class="sfc-table-bg">
        <tr>
          <td v-for="day in eventsWeek" :class="{'highlight': day.moment.isBetween(...highlightTimeRange, 'day', '[]')}"  style="cursor:pointer;" :data-date="day.dateText" @click="recordDate('start', $event, day)">
          </td>
        </tr>
      </tbody>
    </table>
    <table class="sfc-table sfc-events-table" ref="eventsTable">
      <tbody>
        <tr class="sfc-date">
          <!-- date -->
          <td v-for="day in eventsWeek"   v-bind:class="[ day.moment.format('YYYY-MM-DD') === currentDate ? 'current-date': '' ]"  ><span :class="{'not-current-month': !day.moment.isSame(monthMoment, 'month')}">{{ day.date }}</span></td>
        </tr>
        <tr class="sfc-events" v-for="i in maxCount">
          <!-- events wrapper -->
          <template v-for="day in eventsWeek">
            <td v-if="day.events[0]">
              <div style="margin-left:10px;">
                <span>计划覆盖率：{{day.events[0].planRage}}</span><br/>
                <span>计划拜访数：{{day.events[0].planCusts}}</span><br/>
                <span>实际拜访数：{{day.events[0].visitCusts}}</span>
              </div>
            </td>
            <td v-else>
            </td>
            <!-- <td v-if="!day.events[i - 1]"></td>
            <template v-else-if="day.events[i - 1].placehold"></template>
            <td v-else-if="day.events[i - 1]" :colspan="day.events[i - 1].colspan">
              <div class="sfc-event-item " :class="{'is-start': day.events[i - 1].isStart, 'is-end': day.events[i - 1].isEnd}" :title="day.events[i - 1].content">
                <span>{{ day.events[i - 1].time }}</span><br/><span>{{ day.events[i - 1].content }}</span>
              </div>
            </td> -->
          </template>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
// import { getDurationsDays } from '../util.js'
import { dateFormat } from '@/utils/dateFormat.js'
const WAIT_TIME = 100
export default {
  props: {
    monthMoment: {
      type: Object
    },
    week: {
      type: Array,
      required: true
    },
    events: {
      type: Array,
      default: []
    },
    highlightTimeRange: {
      type: Array,
      default: []
    }
  },
  data () {
    return {
      wrapperHeight: 0,
      currentDate: ''
    }
  },
  computed: {
    eventsWeek () {
      let week = this.week.map((day) => {
        day.events = []
        day.dateText = day.moment.format('YYYY-MM-DD')
        this.events.forEach(function (eventItem, eventIndex) {
          if (eventItem.expectedTime === day.dateText) {
            day.events[0] = eventItem
          }
        })
        return day
      })
      return week
    },
    maxCount () {
      return Math.max.apply(null, this.eventsWeek.map(day => day.events.length))
    }
  },
  watch: {
    eventsWeek () {
      this.updateHeight()
    }
  },
  mounted () {
    this.updateHeight()
    this.currentDate = this.getNowTime()
  },
  methods: {
    getNowTime () {
      return dateFormat(new Date().getTime(), 'YYYY-MM-DD')
    },
    recordDate (point, e, day) {
      if (day.events.length === 0) {
        return
      }
      if (this._recordTimer) {
        clearTimeout(this._recordTimer)
      }
      this._recordTimer = setTimeout(() => {
        this.$emit('select', point, e)
      }, WAIT_TIME)
    },
    updateHeight () {
      this.$nextTick(() => {
        let height = this.$refs.eventsTable.clientHeight
        this.wrapperHeight = height
      })
    }
  }
}
</script>

<style scoped rel="stylesheet/scss" lang="scss">
  .sfc-button {
    display: inline-block;
    height: 24px;
    padding: 0 5px;
    border: 1px solid #666;
    border-color: #3b91ad;
    color: #3b91ad;
    border-radius: 4px;
    cursor: pointer;
    &:hover {
      color: darken(#3b91ad, 50%);
      border-color: #3b91ad;
    }
  }
  .sfc-month-hint{
    margin-bottom: 10px;
    text-align: center;
    zoom: 1;
    height: auto;
    &:before,
    &:after {
      content: " ";
      display: table;
    }
    &:after {
      clear: both;
      visibility: hidden;
      font-size: 0;
      height: 0;
    }
    .month-info{
      float: left;
    }
    .operations{
      float: right;
    }
  }
  .sfc-wrapper{
    width: 800px;
    margin: auto;
    .sfc-table-wrapper {
      position: relative;
      margin-top: -1px;
      .sfc-events-table {
        position: absolute;
        top: 0;
        left: 0;
        pointer-events: none;
      }
    }
    .sfc-table{
      width: 100%;
      table-layout: fixed;
      border-spacing: 0;
      border-collapse: collapse;
      user-select: none;
      .sfc-table-bg{
        td {
          border: 1px solid #CCC;
          height: 80px;
          background-color: white;
          color: #000;
          &.highlight{
            background-color: rgba(59, 143, 173, .1)
          }
        }
      }
    }
    .sfc-date{
      text-align: center;
      font-size: 14px;
      .not-current-month {
        color: #919191;
      }
      .not-current-date {
      }
      .current-date {
        background-color: #13ce66;
      }
      td {
        padding-top: 2px;
        padding-right: 5px;
        background-color: #cfcfcf;
        color: #101010;
        align-items: center;
        border: 1px solid #b6b6b6;
      }
    }
    .sfc-events {
      .sfc-event-item {
        margin: -1px 0 2px;
        padding: 2px;
        border: 1px solid #666;
        border-color: #3b91ad;
        background-color: #3b91ad;
        color: #fff;
        font-size: 12px;
        line-height: 1.2;
        overflow: hidden;
        text-overflow: ellipsis;
        pointer-events: auto;
        &.is-start {
          margin-left: 2px;
          border-top-left-radius: 2px;
          border-bottom-left-radius: 2px;
        }
        &.is-end {
          margin-right: 2px;
          border-top-right-radius: 2px;
          border-bottom-right-radius: 2px;
        }
      }
    }
  }
</style>
