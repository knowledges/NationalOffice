<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :size='dialogObj.size'>
    <el-form :model="dialogObj.data.form"  label-width="180px" ref="query">
      <el-row>
        <el-col :gutter="24">
          <el-col :span='12'>
            <el-form-item prop="sno" label="序号" >
              <el-input v-model="dialogObj.data.form.sno" :disabled="codeDisabled" placeholder="系统自动生成"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='12'>
            <el-form-item prop="customerNbr" label="区域内零售客户总数" >
              <el-input v-model="dialogObj.data.form.customerNbr" :disabled="dialogObj.data.form.disabled"></el-input>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='12'>
            <el-form-item prop="events" label="区域变化事件" >
              <el-input v-model="dialogObj.data.form.events" :disabled="dialogObj.data.form.disabled"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='12'>
            <el-form-item prop="infoSrc" label="信息来源" >
              <el-input v-model="dialogObj.data.form.infoSrc" :disabled="dialogObj.data.form.disabled"></el-input>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='12'>
            <el-form-item prop="clDate" label="时间" >
                <el-date-picker
                  v-model="dialogObj.data.form.clDate"
                  type="date"
                  format="yyyy-MM-dd"
                  placeholder="选择月份"
                  :disabled="dialogObj.data.form.disabled"
                >
                </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span='12'>
            <el-form-item prop="areaAddr" label="区域地址" >
              <el-input v-model="dialogObj.data.form.areaAddr"  :disabled="dialogObj.data.form.disabled"></el-input>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='12'>
            <el-form-item prop="populationChg" label="卷烟消费人口变化" >
              <el-input v-model="dialogObj.data.form.populationChg" :disabled="dialogObj.data.form.disabled"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='12'>
            <el-form-item prop="flowrateChg" label="整体人流量变化" >
              <el-input v-model="dialogObj.data.form.flowrateChg" :disabled="dialogObj.data.form.disabled"></el-input>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='12'>
            <el-form-item prop="priceSegment" label="影响消费价位段" >
              <el-select v-model="dialogObj.data.form.priceSegmentl" multiple placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_regularPrice"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='12'>
            <el-form-item prop="advise" label="影响消费品牌" >
              <el-select v-model="dialogObj.data.form.brandsl"  filterable  multiple  placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <template v-for="item in refGroup">
                  <el-option  :key="item.rowId"  :label="item.goodsDesc" :value="item.rowId"></el-option>
                </template>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='24'>
            <el-form-item prop="advise" label="相关建议" >
              <el-input v-model="dialogObj.data.form.advise" type="textarea" autosize :disabled="dialogObj.data.form.disabled"></el-input>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
      <el-row>
        <el-col :gutter="24">
          <el-col :span='24'>
            <el-form-item style="float: right">
              <el-button @click="resetForm('addForm')">取 消</el-button>
              <el-button type="success" @click="submitForm('query')">确 定</el-button>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
    </el-form>
  </el-dialog>
</template>
<script>
  import axios from 'axios'
  import api from '@/api'
  import {getCodeList} from '@/config/info'
  import BasePath from '@/config/BasePath'
  export default {
    props: ['dialogObj'],
    mounted () {
      axios.all([
        api.requestJava('POST', BasePath.COMMODITY_SELECT, {'status': 'Y', 'isConfiscated': 'N'})
      ])
      .then(axios.spread((first) => {
        this.refGroup = JSON.parse(JSON.stringify(first.data.data))
      }))
      getCodeList('FW_CONSUMER_REGULAR_PRICE', (data) => {
        this.options_regularPrice = data
      }) // 性别
    },
    data () {
      return {
        value: '',
        codeDisabled: true,
        form: {},
        refGroup: [],
        options_regularPrice: []
      }
    },
    methods: {
      clearMethod () {
        this.dialogObj.data.form.rowId = ''
        this.dialogObj.data.form.sno = ''
        this.dialogObj.data.form.areaAddr = ''
        this.dialogObj.data.form.customerNbr = ''
        this.dialogObj.data.form.events = ''
        this.dialogObj.data.form.infoSrc = ''
        this.dialogObj.data.form.clDate = ''
        this.dialogObj.data.form.flowrateChg = ''
        this.dialogObj.data.form.populationChg = ''
        this.dialogObj.data.form.priceSegment = ''
        this.dialogObj.data.form.brands = ''
        this.dialogObj.data.form.advise = ''
      },
      resetForm (formName) {
        this.dialogObj.dialogVisible = false
        this.clearMethod()
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dialogObj.dialogVisible = false
            this.$emit('confirmBack', this.dialogObj)
          } else {
            return false
          }
        })
      }
    }
  }
</script>

<style scoped>
  .item__label_popup {
    text-align: right;
    vertical-align: middle;
    float: right;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 8px 11px 0;
    box-sizing: border-box;
    /* display: inline-block; */
  }
  .el-select {
    display: inline-block;
    position: relative;
    width: 100%;
  }
  .el-input, .el-input__inner {
    /*width: '';*/
    display: inline-block;
  }
</style>
