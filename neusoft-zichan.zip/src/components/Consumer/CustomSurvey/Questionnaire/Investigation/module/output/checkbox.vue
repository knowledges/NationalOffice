<template>
  <li class="li_surveyQuItemBody">
    <div class="surveyQuItemBody">
      <div class="initLine"></div>
      <div class="quInputCase" style="display: none;">
        <input type="hidden" name="rowId" :value="SubCheckBox.rowId"/>
        <input type="hidden" name="quType" value="multiselect" />
        <input type="hidden" name="itemCode" :value="SubCheckBox.itemCode" />
        <input type="hidden" name="sortNbr" :value="SubCheckBox.sortNbr" />
        <input type="hidden" name="saveTag" value="0" />
        <input type="hidden" name="hv" value="2" />
        <!--<input type="hidden" name="hoverTag" value="0" />-->
        <input type="hidden" name="isRequired" :value="SubCheckBox.mustFlag">
        <!--<input type="hidden" name="randOrder" value="0" />-->
        <!--<input type="hidden" name="cellCount" value="0" />-->
        <!--<input type="hidden" name="contactsAttr" value="0" />-->
        <!--<input type="hidden" name="contactsField" value="0" />-->
        <!--<div class="quLogicInputCase">-->
          <!--<input type="hidden" name="quLogicItemNum" value="0" />-->
        <!--</div>-->
      </div>
      <div class="surveyQuItem">
        <div class="surveyQuItemLeftTools" v-if="SubCheckBox.itemCode == SubCheckBox.rowId" >
          <ul class="surveyQuItemLeftToolsUl">
            <li title="移动排序" class="dwQuMove ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
            <li title="设置" class="dwQuSet ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
            <!--<li title="逻辑" class="dwQuLogic ui-draggable ui-draggable-handle">-->
              <!--<div class="dwQuIcon">-->
                <!--<div class="quLogicInfo"></div>-->
              <!--</div>-->
            <!--</li>-->
            <li title="删除" class="dwQuDelete ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
          </ul>
        </div>
        <div class="surveyQuItemRightTools">
          <ul class="surveyQuItemRightToolsUl">
            <li class="questionUp ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
            <li class="questionDown ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
          </ul>
        </div>
        <div class="surveyQuItemContent">
          <div class="quCoTitle">
            <div class="quCoNum">{{SubCheckBox.sortNbr}}、</div>
            <div class="editAble quCoTitleEdit">{{SubCheckBox.title}}</div>
            <input type="hidden" name="quTitleSaveTag" value="1">
          </div>
          <div class="quCoItem">
            <ul>
              <template v-for="item in SubCheckBox.enumList">
                <!--:class="'quOption_' + key"-->
                <li class="quCoItemUlLi ui-draggable ui-draggable-handle" >
                  <!--<input type="checkbox">-->
                  <!--<label class="editAble quCoOptionEdit">{{item.listTitle}}</label>-->
                  <template>
                    <!-- `checked` 为 true 或 false -->
                    <el-checkbox>
                      <label class="editAble quCoOptionEdit">{{item.listTitle}}</label>
                    </el-checkbox>
                  </template>
                  <div class="quItemInputCase">
                    <input type="hidden" name="rowId" :value="SubCheckBox.rowId">
                    <input type="hidden" name="rcFlag" :value="0">
                    <!--<input type="hidden" name="quItemId" :value="SubCheckBox.itemCode">-->
                    <!--<input type="hidden" name="quItemSaveTag" value="0">-->
                    <!--<input type="hidden" name="isNote" value="0">-->
                    <!--<input type="hidden" name="checkType" value="NO">-->
                    <!--<input type="hidden" name="isRequiredFill" :value="item.isRequiredFill">-->
                  </div>
                </li>
              </template>
            </ul>
          </div>
          <div class="quCoBottomTools">
            <ul class="quCoBottomToolsUl"  v-if="SubCheckBox.itemCode == SubCheckBox.rowId">
              <li title="添加" class="addOption ui-draggable ui-draggable-handle">
                <div class="dwQuIcon"></div>
              </li>
              <!--<li title="批量添加" class="addMoreOption ui-draggable ui-draggable-handle">-->
                <!--<div class="dwQuIcon"></div>-->
              <!--</li>-->
            </ul>
          </div>
        </div>
      </div>
    </div>
  </li>
</template>
<script>
  export default {
    props: ['SubCheckBox']
  }
</script>

