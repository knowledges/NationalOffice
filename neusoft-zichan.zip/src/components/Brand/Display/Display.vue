<!-- 黄龙 -->
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='12'>
          <div>
            <el-form ref="searchForm" :model="searchForm" label-width="120px">
              <el-col :gutter="24">
                <el-col :span='15'>
                  <el-form-item label="状态" >
                    <el-select v-model="searchForm.status" multiple :clearable="true"  placeholder="请选择审核状态">
                      <el-option
                        v-for="item in optionsStatus"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span='9'>
                  <div class="block">
                    <el-form-item label="提报日期">
                      <el-date-picker
                        v-model="datetime"
                        format="yyyy-MM-dd"
                        type="daterange"
                        :editable=false
                        :clearable=false
                        @change="datePickerChange"
                        placeholder="选择日期范围"
                        :picker-options="pickerOptions">
                      </el-date-picker>
                    </el-form-item>
                  </div>
                </el-col>
              </el-col>
            </el-form>
          </div>
        </el-col>
        <el-col :span="12">
          <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups"  :fileName="fileName" :tableData="tableData" @on-click="exportEve"></_BTN_FILTER>
        </el-col>
      </el-col>
    </el-row>
    <div>
      <_TABLE
        ref="tableGrid"
        stripe
        maxHeight="500"
        @update:data="tabChange" :reqParams="reqParams"
        :data="dataSource"
        :columns="columnHeader"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData></_TABLE>
    </div>
    <MY_POPUP_CONFIG :dialogObj='updateDialogObj' @confirmBack="addOrUpdateBack"/>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import MY_POPUP_CONFIG from './DisplayProp.vue'
  import log from '@/log'
  import api from '@/api'
  import { changeListValueByCode, dateFormat } from '@/utils/common'
  import { getUser, getCodeList } from '@/config/info'
  import BasePath from '@/config/BasePath'
  export default {
    name: 'Dispaly',
    props: {},
    mounted () {
      getCodeList('FW_DISPLAY_TMP_STATUS', (data) => {
        this.optionsStatus = data
      })
      this.initDate()
      this.init()
    },
    data () {
      return {
        optionsStatus: [], // 数据字典-状态
        datetime: [new Date().setDate(1), new Date()],
        pickerOptions: {
          shortcuts: [{
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '当前月',
            onClick (picker) {
              const end = new Date()
              const start = new Date().setDate(1)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }]
        },
        /** 过滤的字段 **/
        fileName: ['cat', 'licenseNo', 'customerName'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        hasPagination: true, // 是否有分页

        columnHeader: [
          {
            prop: 'customerCode', // 列的值
            label: '客户代码', // 列的显示字段
            columnsProps: {width: 150, align: 'left'}
          },
          {
            prop: 'customerDesc',
            label: '客户名称',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          },
          {
            prop: 'putterNm',
            label: '提报人',
            columnsProps: {width: 100, align: 'left'}
          },
          {
            prop: 'uploadDate',
            label: '提报日期',
            columnsProps: {width: 120, align: 'left'}
          },
          {
            prop: 'checkDate',
            label: '审核日期',
            columnsProps: {width: 120, align: 'left'}
          },
          {
            prop: 'status',
            label: '记录状态',
            columnsProps: {width: 150, align: 'center', formatter: this.changeValue}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 100, type: 'button'},
            cptProperties: [
              {
                label: '审核',
                value: 'modify',
                icon: 'edit',
                size: 'small',
                type: 'warning',
                eventClick: this.modify
              }
            ]
          }
        ],
        moreS: [
          {
            colunm: 'status',
            type: 'string'
          }
        ],
        changeValueDate: {
          status: {
            type: 'text',
            group: [
              {value: '0', label: '保存'},
              {value: '1', label: '已提交'},
              {value: '2', label: '审核通过'},
              {value: '3', label: '审核不通过'},
              {value: '9', label: '作废'}
            ],
            key: 'value',
            value: 'label'
          }
        },
        tableData: [],
        cat: [],
        tableType: '3',
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        /** searchForm **/
        searchForm: {
          receiveTime: '',
          companyId: '',
          beginDate: '',
          endDate: '',
          status: ''
        },
        updateDialogObj: {
          title: '生动化陈列审核',
          type: 'editUser',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              customerCode: '',
              customerDesc: '',
              putterNm: '',
              uploadDate: '',
              checkDate: '',
              status: '',
              desc_text: '',
              PHOTO_ID: '',
              radio2: '',
              files: []
            }
          }
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        sel_all_row: []
      }
    },
    methods: {
      init () {
        let params = {}
        params.uploadDateL = this.searchForm.beginDate
        params.uploadDateR = this.searchForm.endDate
        params.personId = getUser().personId
        params.countyId = getUser().countyId
        params.companyId = getUser().companyId
        params.haveAttach = '1'
        params.status = '1'
        console.log('====', params)
        this.reqParams.url = BasePath.DISPLAYTOM_SELECTAPPDISPLAYTMP
        this.reqParams.params = params
        api.requestJava('POST', BasePath.DISPLAYTOM_SELECTAPPDISPLAYTMP, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      datePickerChange () {
        this.searchForm.beginDate = this.getTime(Date.parse(this.datetime[0]))
        this.searchForm.endDate = this.getTime(Date.parse(this.datetime[1]))
        console.log('searchForm', this.searchForm)
      },
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },
      query () {
        let params = {}
        let param1 = {}
        for (let i = 0; i < this.moreS.length; i++) {
          param1.in = 'status:' + this.toMoreChange(this.searchForm[this.moreS[i].colunm], this.moreS[i].type)
          params.fluzzy = param1
        }
        params.uploadDateL = this.searchForm.beginDate
        params.uploadDateR = this.searchForm.endDate
        params.personId = getUser().personId
        params.countyId = getUser().countyId
        params.companyId = getUser().companyId
        params.haveAttach = '1'
        console.log('====', params)
        this.queryUpper(params)
      }, // 查询方法
      queryUpper (params) {
        this.reqParams.url = BasePath.DISPLAYTOM_SELECTAPPDISPLAYTMP
        this.reqParams.params = params
        api.requestJava('POST', BasePath.DISPLAYTOM_SELECTAPPDISPLAYTMP, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      initDate () {
        var myDate = new Date()
        this.searchForm.endDate = this.getTime(myDate.getTime())
        this.searchForm.beginDate = this.getTime(myDate.setDate(1))
        console.log('searchForm', this.searchForm)
        //  this.query()
      }, // 初始化时间并查询
      modify (index, row) {
        /* TODO 公司和部门替换为字典 */
        if (row.status === '1') {
          this.updateDialogObj.title = '生动化陈列审核'
          var myDate = new Date()
          this.updateDialogObj.data.form.beginDate = this.getTime(myDate.getTime())
          this.updateDialogObj.data.form.endDate = this.getTime(myDate.getTime())
          this.updateDialogObj.type = 'editUser'
          Object.assign(this.updateDialogObj.data.form, row)
          this.updateDialogObj.dialogVisible = true
        } else {
          console.log('====', row.status)
          this.updateDialogObj.title = '生动化陈列审核'
          this.updateDialogObj.type = 'updateUser'
          console.log('====', row.files)
          Object.assign(this.updateDialogObj.data.form, row)
          this.updateDialogObj.dialogVisible = true
        }
      }, // 修改d
      addOrUpdateBack (msg) {
        let data = msg.data.form
        let paraminfo = data
        api.requestJava('POST', BasePath.DISPLAYTOM_UPDATE, paraminfo)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.initDate()
              this.init()
              this.$message({type: 'success', message: '审核成功!', duration: 1000})
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      clearObject () {
        let temp = {
          title: '生动化陈列审核',
          type: 'editUser',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              customerCode: '',
              customerDesc: '',
              putterNm: '',
              uploadDate: '',
              checkDate: '',
              status: '',
              desc_text: '',
              PHOTO_ID: '',
              radio2: '',
              files: []
            }
          }
        }
        Object.assign(this.updateDialogObj, temp)
      },
      toMoreChange (values, type) {
        let result = ''
        for (let i = 0; i < values.length; i++) {
          if (type === 'int') {
            result = result + values[i] + ','
          } else if (type === 'string') {
            //       result = result + "'" + values[i] + "'" + ','
            result = result + "'" + values[i] + "'" + ','
          }
        }
        if (result.length > 0) {
          result = result.substr(0, result.length - 1)
        }
        // alert(result)
        return result
      },
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      onendChange (val) {}, // 过滤器修改事件
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      dateFormatter (row, column) {
        var unixDate = row[column.property]
        return dateFormat(unixDate, 'YYYY-MM-DD')
      },  // 时间格式化
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      headerClick (column, event) {},
      sortChange (msg) {},
      rowClick (msg) {}
    },
    components: {
      _TABLE,
      _POPUP,
      MY_POPUP_CONFIG,
      _BTN_FILTER
    }
  }
</script>

<style scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label{
    margin: 0px!important;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }

  .filter_style .el-col-24 {
    height: 36px;
  }
  .el-form-item {
    margin-bottom: 12px;
  }
</style>
