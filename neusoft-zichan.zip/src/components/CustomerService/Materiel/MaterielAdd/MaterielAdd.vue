<!--李晶-->
<style rel="stylesheet/scss" lang="scss" scoped></style>
<template>
  <div  class="container-fluid">
    <el-form :model="searchForm"  label-width="160px" ref="query">
      <el-row>
        <el-col :gutter="24">
        <el-col :span="6" :offset="20">
          <el-button type="success" @click="save(1)">保存</el-button>
          <!--<el-button type="success" @click="save(1)">提交</el-button>-->
          <el-button type="success" @click="back()">返回</el-button>
        </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="billType" label="单据类别" >
              <el-select v-model="searchForm.billType" visible-change="false" :clearable="true" placeholder="请选择" :disabled="billTypeDisabled">
                <el-option
                  v-for="item in options_billType"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="billNo" label="单据编号" >
              <el-input v-model="searchForm.billNo" :disabled="billNoDisabled"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="bizDate" label="业务日期" >
              <el-date-picker
                v-model="searchForm.bizDate"
                type="date"
                placeholder="选择日期">
              </el-date-picker>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='8'>
            <div v-if="$route.params.uId == '21'">
              <el-form-item prop="handlerId" label="领用人" >
                <el-select v-model="searchForm.customerId" filterable :clearable="true" placeholder="请选择" :disabled="customerIdDisabled">
                  <el-option
                    v-for="item in options_customerId"
                    :key="item.rowId"
                    :label="item.customerDesc"
                    :value="item.rowId">
                  </el-option>
                </el-select>
              </el-form-item>
            </div>
            <div v-else>
              <el-form-item prop="handlerId" label="领用人" >
                <el-select v-model="searchForm.handlerId" filterable :clearable="true" placeholder="请选择" :disabled="handlerIdDisabled">
                  <el-option
                    v-for="item in options_handlerId"
                    :key="item.rowId"
                    :label="item.employeeName"
                    :value="item.rowId">
                  </el-option>
                </el-select>
              </el-form-item>
            </div>
          </el-col>
          <el-col :span='8'>
            <div v-if="$route.params.uId == '11'">
            <el-form-item prop="customerDesc" label="供货商" >
              <el-input v-model="searchForm.customerDesc"></el-input>
            </el-form-item>
            </div>
            <div v-else-if="this.$route.params.uId == '21'">
              <el-form-item prop="customerId" label="发放人" >
                <el-select v-model="searchForm.handlerId" filterable :clearable="true" placeholder="请选择" :disabled="handlerIdDisabled" @change="onChange">
                <el-option
                v-for="item in options_handlerId"
                :key="item.rowId"
                :label="item.employeeName"
                :value="item.rowId">
                </el-option>
                </el-select>
              </el-form-item>
            </div>
            <div v-else>
              <el-form-item prop="customerId" label="发放人" >
                <el-select v-model="searchForm.customerId" filterable :clearable="true" placeholder="请选择" :disabled="customerIdDisabled" @change="onChange">
                  <el-option
                    v-for="item in options_customerId"
                    :key="item.rowId"
                    :label="item.employeeName"
                    :value="item.rowId">
                  </el-option>
                </el-select>
              </el-form-item>
            </div>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="total" label="总数量" >
              <el-input v-model="searchForm.total" ></el-input>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="remark" label="备注" >
              <el-input v-model="searchForm.resons" type="textarea"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='14'>
            <el-form-item prop="remark" label="物料" >
              <el-select v-model="searchForm.mtrlinventory" filterable :clearable="true" placeholder="请选择">
                <el-option
                  v-for="item in options_mtrlinventory"
                  :key="item.materialCd"
                  :label="item.materialNm"
                  :value="item.materialCd">
                  <span style="float: left">{{ item.materialNm }}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px">{{ item.materialCd }}</span>
                </el-option>
              </el-select>
              <el-input-number v-model="searchForm.num" @change="handleChange" label="描述文字"></el-input-number>
              <el-button type="success" @click="add()">添加</el-button>
            </el-form-item>
          </el-col>
          <!--<el-col :span='6'>-->
            <!--<el-input-number v-model="searchForm.num" @change="handleChange" label="描述文字"></el-input-number>-->
            <!--<el-button type="success" @click="add()">添加</el-button>-->
          <!--</el-col>-->
        </el-col>
      </el-row>
    </el-form>
    <div>
      <tableVue
        ref="tableGrid"
        stripe
        maxHeight="500"
        @update:data="tabChange" :reqParams="reqParams"
        :data="dataSource"
        :columns="columns"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
        @cell-dblclick="celldbClick"></tableVue>
    </div>
  </div>
</template>
<script>
import tableVue from '@/components/Template/table/Table.vue'
import { getUser, getCodeList } from '@/config/info'
import BasePath from '@/config/BasePath'
import { dateFormat } from '@/utils/dateFormat.js'
import api from '@/api'
import axios from 'axios'
import log from '@/log'
export default {
  name: 'MaterielAdd',
  props: {},
  mounted () {
    this.all()
  },
  data () {
    return {
      searchForm: {
        billType: '',
        billNo: '',
        bizDate: new Date(),
        customerId: '',
        handlerId: '',
        mtrlinventory: '',
        total: 0,
        remark: '',
        num: 1
      },
      options_customerId: [],
      options_handlerId: [],
      options_billType: [],
      options_market: [],
      options_custMgr: [],
      options_cust: [],
      options_materielEmp: [],
      options_mtrlinventory: [],
      billNoDisabled: false,
      billTypeDisabled: false,
      customerIdDisabled: false,
      handlerIdDisabled: false,
      /** table **/
      currentPage: 1, // 默认当前第一页
      pageSize: 100,  // 默认每页20条数据
      pageSizes: [100, 200, 500], // 分页数选择项
      reqParams: {
        url: '',
        params: {}
      },
      selectSells: [],
      totalCount: 0, // 表格总记录数
      hasPagination: true, // 是否有分页
      columns: [],
      columnsA: [ // 表格列
      { label: '物料代码', prop: 'materialCd', columnsProps: {width: 250} },
      { label: '物料名称', prop: 'materialNm', columnsProps: {width: 350} },
      { label: '单位', prop: 'unit', columnsProps: {width: 150} },
      { label: '数量', prop: 'quantity', columnsProps: {type: 'input'}, eventChange: this.selectChange, eventKey: this.eventKey },
      { label: '操作', prop: 'operation', columnsProps: {type: 'button'}, cptProperties: [{ label: '删除', value: 'del', type: 'text', eventClick: this.del }] }
      ],
      columnsB: [ // 表格列
        { label: '物料代码', prop: 'materialCd', columnsProps: {width: 250} },
        { label: '物料名称', prop: 'materialNm', columnsProps: {width: 350} },
        { label: '单位', prop: 'unit', columnsProps: {width: 150} },
        { label: '库存', prop: 'inventoryQty', columnsProps: {width: 150} },
        { label: '数量', prop: 'quantity', columnsProps: {type: 'input'}, eventChange: this.selectChange, eventKey: this.eventKey },
        { label: '操作', prop: 'operation', columnsProps: {type: 'button'}, cptProperties: [{ label: '删除', value: 'del', type: 'text', eventClick: this.del }] }
      ],
      tableData: [],
      tableType: '4',
      planTime: '',
      dataSource: [], // 当前页的数据
      /** filter **/
      templTableData: [], // 临时记录tableDate的值
      headerClick () {},
      sortChange (msg) {},
      rowClick (msg) {}
    }
  },
  methods: {
    getTime (data) {
      return dateFormat(data, 'YYYY-MM-DD')
    },  // 时间格式化
    all () {
      let typeId = this.$route.params.uId
      getCodeList('RM_MTRL_BILL_TYPE', (data) => {
        this.options_billType = data
      }) // 单据类别
      let custMgrParam = {} // 客户经理
      custMgrParam.place = 135
      custMgrParam.countyDept = getUser().countyId
      custMgrParam.fields = {include: 'employeeName,rowId'}
      custMgrParam.status = 1
      let marketParam = {} // 市场经理
      marketParam.place = 24
      marketParam.countyDept = getUser().countyId
      marketParam.fields = {include: 'employeeName,rowId'}
      marketParam.status = 1
      let allParam = {} // 所有人员
      allParam.companyId = getUser().companyId
      allParam.fields = {include: 'employeeName,rowId'}
      allParam.status = 1
      let cusParam = {} // 客户经理下的客户
      cusParam.custmgrId = getUser().personId
      cusParam.fields = {include: 'customerDesc,rowId'}
      let mtrlinventoryParam = {} // 物料下拉
      mtrlinventoryParam.billType = typeId
      mtrlinventoryParam.handlerId = getUser().personId
      mtrlinventoryParam.companyId = getUser().companyId
      mtrlinventoryParam.deptId = getUser().deptId
      let invyGParam = {} // 采购物资
      invyGParam.companyId = getUser().companyId
      let materielParam = {}
      materielParam.companyId = getUser().companyId
      axios.all([
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, marketParam), // 市场经理
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, custMgrParam), // 客户经理
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, allParam), // 所有人员
        api.requestJava('POST', BasePath.CUSTOMER_SELECT, cusParam), // 客户经理下的客户
        api.requestJava('POST', BasePath.MTRLINVENTORY_SELECT, mtrlinventoryParam), // 物料下拉
        api.requestJava('POST', BasePath.INVY_G_SELECT, invyGParam), // 物料下拉
        api.requestJava('POST', BasePath.HANDLERBY_COMID, materielParam) // 有库存的人员
      ])
        .then(axios.spread((_marketId, _custmgrId, _allId, _cusId, _mtrlinventoryId, _invyG, _materielEmployee) => {
          if (Number(_marketId.data.code) === 200 &&
            Number(_custmgrId.data.code) === 200 &&
            Number(_allId.data.code) === 200 &&
            Number(_cusId.data.code) === 200 &&
            Number(_mtrlinventoryId.data.code) === 200 &&
            Number(_cusId.data.code) === 200) {
            this.options_market = _marketId.data.data
            this.options_custMgr = _custmgrId.data.data
            this.options_all = _allId.data.data
            this.options_cust = _cusId.data.data
            this.options_materielEmp = _materielEmployee.data.data
            if (Number(getUser().place) === 24) {
              this.options_customerId = this.options_materielEmp // 发放人上级 自选
              this.options_handlerId = this.options_market // 领用人自己
              if (Number(typeId) === 11) {
                this.options_mtrlinventory = _invyG.data.data
              } else if (Number(typeId) === 21) {
                this.options_mtrlinventory = _mtrlinventoryId.data.data
              } else {
                this.options_mtrlinventory = _invyG.data.data
              }
            } else if (Number(getUser().place) === 135) {
              if (Number(typeId) === 11) {
                this.options_mtrlinventory = _invyG.data.data
              } else if (Number(typeId) === 21) {
                this.options_mtrlinventory = _mtrlinventoryId.data.data
                this.options_customerId = this.options_cust // 领用人客户
                this.options_handlerId = this.options_custMgr // 发放人自己
                console.log('领用人客户', this.options_customerId)
              } else {
                this.options_mtrlinventory = _invyG.data.data
              }
              if (Number(typeId) !== 21) {
                this.options_customerId = this.options_materielEmp // 发放人上级 默认是自己的市场经理
                this.options_handlerId = this.options_custMgr // 领用人自己
              }
            } else if (Number(getUser().place) === 9999) {
              this.options_customerId = this.options_materielEmp // 发放人上级 自选
              this.options_handlerId = this.options_all // 领用人自己
              if (Number(typeId) === 11) {
                this.options_mtrlinventory = _invyG.data.data
              } else if (Number(typeId) === 21) {
                this.options_mtrlinventory = _mtrlinventoryId.data.data
              } else {
                this.options_mtrlinventory = _invyG.data.data
              }
            } else {
              this.options_customerId = this.options_materielEmp // 领用人自己
              this.options_handlerId = this.options_market // 发放人上级 自选
            }
            this.init()
          } else {
            console.error('众多请求失败了！')
          }
        }))
    },
    init () {
      this.$nextTick(() => {
        this.$set(this.searchForm, 'billType', this.$route.params.uId + '')
        this.billTypeDisabled = true
        this.getBillNo() // 初始化单据编号
        this.searchForm.handlerId = getUser().personId
        this.handlerIdDisabled = true
        if (Number(this.searchForm.billType) === 11) {
          this.columns = this.columnsA
        } else {
          this.columns = this.columnsB
        }
      })
    },
    getBillNo () {
      api.requestJava('POST', BasePath.GET_BILLNO, {})
        .then(request => {
          if (Number(request.data.code) === 200) {
            console.log(request.data.data)
            this.searchForm.billNo = request.data.data
            this.billNoDisabled = true
          } else {
            this.$notify.error({ title: '提示', message: '获取单据号接口调用失败！' })
            throw new Error(JSON.stringify(request))
          }
        })
        .catch(err => {
          let culprit = this.$route.name
          log.work(err, culprit)
        })
    },
    handleChange (value) {
      console.log(value)
    },
    onChange (value) {
      let mtrlinventoryParam = {} // 物料下拉
      mtrlinventoryParam.billType = this.$route.params.uId
      mtrlinventoryParam.handlerId = getUser().personId
      mtrlinventoryParam.customerId = value
      mtrlinventoryParam.companyId = getUser().companyId
      mtrlinventoryParam.deptId = getUser().deptId
      console.log('查询库存' + JSON.stringify(mtrlinventoryParam))
      api.requestJava('POST', BasePath.MTRLINVENTORY_SELECT, mtrlinventoryParam)
        .then((request) => {
          if (Number(request.data.code) === 200) {
            this.options_mtrlinventory = request.data.data
          } else if (Number(request.data.code) === 401) {
            console.log('session 回话失效')
          } else {
            throw new Error(JSON.stringify(request))
          }
        })
    },
    save (status) {
      this.$confirm('确定保存此记录吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        let typeId = this.$route.params.uId
        if (this.dataSource.length === 0) {
          this.$notify.error({ title: '提示', message: '保存失败，请录入物料！' })
        } else if (Number(this.isExceed()) === 1) {
          this.$notify.error({ title: '提示', message: '物料数量录入有误，超过库存量！请重新录入！' })
        } else {
          let param = {}
          param.billType = this.searchForm.billType
          param.billNo = this.searchForm.billNo
          param.bizDate = this.getTime(Date.parse(this.searchForm.bizDate))
          param.companyId = getUser().companyId
          param.deptId = getUser().deptId
          param.handlerId = this.searchForm.handlerId
          var i = 0
          this.options_handlerId.forEach((e) => {
            if (this.options_handlerId[i].rowId === this.searchForm.handlerId) {
              param.handlerNm = this.options_handlerId[i].employeeName
            }
            i++
          })
          param.resons = this.searchForm.resons
          param.customerId = this.searchForm.customerId === '' ? '0' : this.searchForm.customerId
          var j = 0
          if (param.customerId !== '0') {
            this.options_customerId.forEach((e) => {
              if (Number(this.options_customerId[j].rowId) === Number(this.searchForm.customerId)) {
                if (Number(this.searchForm.billType) === 21) {
                  param.customerDesc = this.options_customerId[j].customerDesc
                } else {
                  param.customerDesc = this.options_customerId[j].employeeName
                }
              }
              j++
            })
          } else {
            param.customerDesc = this.searchForm.customerDesc
          }
          param.status = status + ''
          param.createdBy = getUser().personId
          param.detailEntities = this.dataSource
          console.log(JSON.stringify(param))
          api.requestJava('POST', BasePath.MTRLINVENTORY_INSERT, param)
            .then(request => {
              if (Number(request.data.code) === 200) {
                console.log(request.data.data)
                this.$notify.info({ title: '提示', message: '保存成功！' })
                this.tableData = []
                this.dataSource = []
                this.searchForm.total = 0
                if (Number(typeId) === 21) {
                  this.customerIdDisabled = false
                }
              } else {
                this.$notify.error({ title: '提示', message: '保存失败！' + request.data.message })
                throw new Error(JSON.stringify(request))
              }
            })
            .catch(err => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        }
      }).catch(() => {
        this.$message({type: 'info', message: '已取消!'})
      })
    },
    isExceed () {
      var i = 0
      this.dataSource.forEach((e) => {
        let inventoryQty = this.dataSource[i].inventoryQty // 库存
        let quantity = this.dataSource[i].quantity // 数量
        if (typeof this.dataSource[i].inventoryQty !== 'undefined') {
          if (quantity > inventoryQty) {
            return 1
          }
        }
        i++
      })
      return 0
    },
    queryData (page, size) {
      // 前段分页
//      this.totalCount = this.tableData.length
      this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
    }, // 分页请求
    tabChange (msg) {
      let tmp = JSON.parse(msg)
      this.currentPage = tmp.currentPage
      this.dataSource = this.tableData = tmp.arr
    }, // 表格数据便跟后
    add () {
      let mtrlinventoryCd = this.searchForm.mtrlinventory
      let mtrlinventoryNm = ''
      let mtrlinventoryId = ''
      let inventoryQty = ''
      let num = this.searchForm.num
      let unit = ''
      var i = 0
      if (mtrlinventoryCd === '') {
        this.$message({ type: 'error', message: '请选择需要添加的物料！' })
      } else {
        this.options_mtrlinventory.forEach((e) => {
          if (this.options_mtrlinventory[i].materialCd === mtrlinventoryCd) {
            mtrlinventoryNm = this.options_mtrlinventory[i].materialNm
            mtrlinventoryId = this.options_mtrlinventory[i].materialId
            inventoryQty = this.options_mtrlinventory[i].inventoryQty
            unit = this.options_mtrlinventory[i].unit
          }
          i++
        })
        let mtrlinventoryData = {}
        mtrlinventoryData.companyId = getUser().companyId
        mtrlinventoryData.deptId = getUser().deptId
        mtrlinventoryData.materialId = mtrlinventoryId
        mtrlinventoryData.materialCd = mtrlinventoryCd
        mtrlinventoryData.materialNm = mtrlinventoryNm
        mtrlinventoryData.unit = unit
        mtrlinventoryData.quantity = num + ''
        mtrlinventoryData.price = '0'
        mtrlinventoryData.chkQty = '0'
        mtrlinventoryData.amount = '0'
        mtrlinventoryData.tax = '0'
        mtrlinventoryData.inventoryQty = inventoryQty
        mtrlinventoryData.createdBy = getUser().personId
        if (this.tableData.length > 0) {
          var k = 0
          var flag = false
          this.tableData.forEach((e) => {
            if (Number(mtrlinventoryId) === Number(this.tableData[k].materialId)) {
              this.tableData[k].quantity = Number(this.tableData[k].quantity) + Number(num) + ''
              flag = true
            }
            k++
          })
          if (!flag) {
            this.tableData.push(mtrlinventoryData)
            this.dataSource.push(mtrlinventoryData)
          }
        } else {
          this.tableData.push(mtrlinventoryData)
          this.dataSource.push(mtrlinventoryData)
        }
      }
      this.countNumber()
      this.customerIdDisabled = true
    },
    del (row, column) {
      this.tableData.splice(row, 1)
      this.dataSource.splice(row, 1)
      this.countNumber()
      if (this.dataSource.length === 0) {
        this.customerIdDisabled = false
      }
    },
    back () {
      this.$router.push({name: 'MaterielQuery'})
    },
    celldbClick (row, column, cell, event) {
      this.$set(row, '_edit', !row._edit)
      if (!row._edit) {
        if (!this.numberChange(row)) {
          row._edit = true
        } else {
          this.$set(row, '_edit', !row._edit)
        }
      }
    },
    eventKey (key, row) {
      if (key.code === 'Enter' || key.code === 'NumpadEnter') {
        if (!this.numberChange(row)) {
          return true
        } else {
          return false
        }
      }
    },
    show () {
      this.$message('双击事件')
    },
    selectChange (index, row) {
      if (!row._edit) {
        this.$message('双击事件')
      }
    },
    numberChange (row) {
      let _this = this
      this.$nextTick(() => {
        var t
        clearTimeout(t)
        t = setTimeout(function () {
          let num = row.quantity
          if (num <= 0) {
            _this.$message({ type: 'error', message: '录入数量必须大于0！' })
            return false
          } else if (typeof row.inventoryQty !== 'undefined') {
            let inventoryQty = row.inventoryQty
            if (Number(num) > Number(inventoryQty)) {
              _this.$message({ type: 'error', message: '录入数量必须小于库存(' + inventoryQty + ')！' })
              return false
            }
          } else {
            return true
          }
        }, 1000)
      })
      this.countNumber()
    },
    countNumber () {
      var i = 0
      var count = 0
      this.dataSource.forEach((e) => {
        count = count + Number(this.dataSource[i].quantity)
        i++
      })
      this.searchForm.total = count
    }
  },
  components: {
    tableVue
  },
  watch: {
    '$route' (val, old) {
      if (val.params.uId !== old.params.uId) {
        this.all()
      }
    }
  }
}
</script>
