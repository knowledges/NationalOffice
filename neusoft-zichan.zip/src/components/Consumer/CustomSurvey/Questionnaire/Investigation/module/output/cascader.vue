<!--三级联动-->
<template>
  <li class="li_surveyQuItemBody">
    <div class="surveyQuItemBody">
      <div class="initLine"></div>
      <div class="quInputCase" style="display: none;">
        <input type="hidden" name="rowId" :value="SUBCASCADER.rowId"/>
        <input type="hidden" name="quType" :value="SUBCASCADER.inputType"/>
        <input type="hidden" name="itemCode" :value="SUBCASCADER.itemCode"/>
        <input type="hidden" name="sortNbr" :value="SUBCASCADER.sortNbr"/>
        <input type="hidden" name="saveTag" value="1" />
        <!--<input type="hidden" name="hoverTag" value="0" />-->
        <input type="hidden" name="isRequired" :value="SUBCASCADER.mustFlag">
        <input type="hidden" name="hv" value="2" />
        <!--<input type="hidden" name="randOrder" value="0" />-->
        <!--<input type="hidden" name="cellCount" value="0" />-->
        <!--<input type="hidden" name="checkType" value="NO" />-->
        <!--<input type="hidden" name="answerInputWidth" value="300" />-->
        <!--<input type="hidden" name="answerInputRow" value="1" />-->
        <!--<input type="hidden" name="contactsAttr" value="1" />-->
        <!--<input type="hidden" name="contactsField" value="8" />-->
        <!--<div class="quLogicInputCase">-->
          <!--<input type="hidden" name="quLogicItemNum" value="0" />-->
        <!--</div>-->
      </div>
      <div class="surveyQuItem">
        <div class="surveyQuItemLeftTools" v-if="SUBCASCADER.itemCode == SUBCASCADER.rowId">
          <ul class="surveyQuItemLeftToolsUl">
            <li title="移动排序" class="dwQuMove ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
            <li title="设置" class="dwQuSet ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div></li>
            <!--<li title="逻辑" class="dwQuLogic ui-draggable ui-draggable-handle">-->
              <!--<div class="dwQuIcon">-->
                <!--<div class="quLogicInfo"></div>-->
              <!--</div></li>-->
            <li title="删除" class="dwQuDelete ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
          </ul>
        </div>
        <div class="surveyQuItemRightTools">
          <ul class="surveyQuItemRightToolsUl">
            <li class="questionUp ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div></li>
            <li class="questionDown ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div></li>
          </ul>
        </div>
        <div class="surveyQuItemContent">
          <div class="quCoTitle">
            <div class="quCoNum">
              {{SUBCASCADER.sortNbr}}、
            </div>
            <div class="editAble quCoTitleEdit">
              {{SUBCASCADER.title}}
            </div>
            <input type="hidden" name="quTitleSaveTag" value="1" />
          </div>
          <div class="quCoItem">
            <ul data-v-73ab92a0="">
              <li class="quCoItemUlLi ui-draggable ui-draggable-handle"><span class="el-cascader">
          <div class="el-input">
           <!---->
           <i class="el-input__icon el-icon-caret-bottom"></i>
           <input autocomplete="off" placeholder="  请选择  " readonly="readonly" type="text" rows="2" class="el-input__inner" />
            <!---->
            <!---->
          </div><span class="el-cascader__label"></span></span></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </li>
</template>
<script>
  export default {
    props: ['SUBCASCADER']
  }
</script>
