<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :size='dialogObj.size'>
    <el-form :model="dialogObj.data.form"  label-width="160px" ref="query">
      <el-row>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="code" label="消费者编号" >
              <el-input v-model="dialogObj.data.form.code" :disabled="codeDisabled"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="name" label="姓名" >
              <el-input v-model="dialogObj.data.form.name" :disabled="dialogObj.data.form.disabled"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="sex" label="性别" >
              <el-select v-model="dialogObj.data.form.sex" :clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_sex"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="mobile" label="联系电话" >
              <el-input v-model="dialogObj.data.form.mobile" :disabled="dialogObj.data.form.disabled"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="custMgr" label="客户经理" >
              <el-select v-model="dialogObj.data.form.custMgr" :clearable="true" placeholder="请选择" :disabled="custmgrDisable">
                <el-option
                  v-for="item in options_custMgr"
                  :key="item.rowId"
                  :label="item.employeeName"
                  :value="item.rowId">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="customerCode" label="关系零售户" >
              <el-input v-model="dialogObj.data.form.customerCode" :disabled="dialogObj.data.form.disabled"></el-input>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="nativePlace" label="籍贯" >
              <el-cascader clearable="true"
                :options='options'
                v-model="dialogObj.data.form.nativePlace"
                @active-item-change='handleItemChange'
                :show-all-levels='true'
                filterable
                :props='props'
              ></el-cascader>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="birthday" label="出生年月" >
                <el-date-picker
                  v-model="dialogObj.data.form.birthday"
                  type="date"
                  placeholder="选择出生日期"
                  :disabled="dialogObj.data.form.disabled"
                >
                </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="degree" label="学历" >
              <el-select v-model="dialogObj.data.form.degree" clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_degree"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="beginyear" label="烟龄" >
              <el-input v-model="dialogObj.data.form.beginyear" :disabled="dialogObj.data.form.disabled"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="work" label="职业" >
              <el-select v-model="dialogObj.data.form.work" clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_work"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="income" label="收入" >
              <el-select v-model="dialogObj.data.form.income" clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_income"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="avgComsumption" label="卷烟月均消费（元）" >
              <el-select v-model="dialogObj.data.form.avgComsumption" clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_avgComsumption"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="regularPrice" label="常抽卷烟价位（元/包）" >
              <el-select v-model="dialogObj.data.form.regularPrice" clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_regularPrice"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="quant" label="每天的吸烟量（包）" >
              <el-select v-model="dialogObj.data.form.quant" clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_quant"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="trend" label="趋势" >
              <el-select v-model="dialogObj.data.form.trend" clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_trend"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="lastNewCig" label="最近尝试的新品卷烟" >
              <el-input v-model="dialogObj.data.form.lastNewCig" filterable :disabled="dialogObj.data.form.disabled"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="likebestNewCig" label="最喜欢哪种类型的新品" >
              <el-select v-model="dialogObj.data.form.likebestNewCig" filterable  clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_likebestNewCig"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='8'>
            <el-form-item prop="recentlySpecCig" label="最近尝试的异型卷烟" >
              <el-input v-model="dialogObj.data.form.recentlySpecCig" filterable :disabled="dialogObj.data.form.disabled"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item prop="likebestSpecPack" label="最喜欢的异型包装" >
              <el-select v-model="dialogObj.data.form.likebestSpecPack" filterable clearable="true" placeholder="请选择" :disabled="dialogObj.data.form.disabled">
                <el-option
                  v-for="item in options_likebestSpecPack"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8'>
            <el-form-item style="float: right">
              <el-button @click="resetForm('addForm')">取 消</el-button>
              <el-button type="success" @click="submitForm('query')">确 定</el-button>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
    </el-form>
  </el-dialog>
</template>
      <script>
        import {getUser, getCodeList} from '@/config/info'
        import BasePath from '@/config/BasePath'
        import api from '@/api'
        import axios from 'axios'
        import log from '@/log'
        export default {
          props: ['dialogObj'],
          mounted () {
            getCodeList('YC_SEX', (data) => {
              this.options_sex = data
            }) // 性别
            getCodeList('FW_CONSUMER_REGULAR_PRICE', (data) => {
              this.options_regularPrice = data
            }) // 性别
            getCodeList('FW_CONSUMER_WORK', (data) => {
              this.options_work = data
            }) // 职业
            getCodeList('FW_CONSUMER_DEGREE', (data) => {
              this.options_degree = data
            }) // 学历
            getCodeList('FW_CONSUMER_INCOME', (data) => {
              this.options_income = data
            }) // 收入
            getCodeList('FW_CONSUMER_AVG_COMSUMPTION', (data) => {
              this.options_avgComsumption = data
            }) // 月均花费
            getCodeList('FW_CONSUMER_QUANT', (data) => {
              this.options_quant = data
            }) // 每天的吸烟量
            getCodeList('FW_CONSUMER_TREND', (data) => {
              this.options_trend = data
            }) // 趋势
            getCodeList('FW_CONSUMER_LIKEBEST_NEW_CIG', (data) => {
              this.options_likebestNewCig = data
            }) // 最喜欢哪种类型的新品
            getCodeList('FW_CONSUMER_LIKEBEST_SPEC_PACK', (data) => {
              this.options_likebestSpecPack = data
            }) // 最喜欢的异型包装
            let _this = this
            let custMgrParam = {} // 客户经理
            custMgrParam.place = 135
            custMgrParam.status = 1
            custMgrParam.county_dept = getUser().companyId
            custMgrParam.fields = {include: 'employeeName,rowId'}
            axios.all([
              api.requestJava('POST', BasePath.EMPLOYEE_SELECT, custMgrParam) // 市场经理
            ])
              .then(axios.spread(function (_custmgrId) {
                _this.options_custMgr = JSON.parse(JSON.stringify(_custmgrId.data.data))
              }))
            this.init()
          },
          data () {
            return {
              value: '',
              options_sex: [],
              options_work: [],
              options_degree: [],
              options_regularPrice: [],
              options_income: [],
              options_avgComsumption: [],
              options_quant: [],
              options_trend: [],
              options_likebestNewCig: [],
              options_likebestSpecPack: [],
              options_custMgr: [],
              form: {},
              options: this.dialogObj.data.form.nativePlace,
              props: {
                value: 'label',
                children: 'cities'
              },
              custmgrDisable: false,
              codeDisabled: false
            }
          },
          methods: {
            init () {
//              alert(this.dialogObj.data.form.nativePlace)
              let param = {}
              param.level = 1
              this.getProvince(param) // 籍贯
              if (getUser().place === '135') {
                this.custmgrDisable = true
              }
              this.codeDisabled = true
              if (this.dialogObj.data.form.nativePlace === '') {
              } else {
//                let nativePlaceArry = []
//                nativePlaceArry.push(this.dialogObj.data.form.nativePlace.split(',')[0])
//                nativePlaceArry.push(this.dialogObj.data.form.nativePlace.split(',')[1])
//                this.dialogObj.data.form.nativePlace = nativePlaceArry
                console.log(this.dialogObj.data.form.nativePlace)
              }
            },
            getProvince (param) {
              api.requestJava('POST', BasePath.SELECT_PROVINCEIDGROUP, param)
                .then(request => {
                  if (Number(request.data.code) === 200) {
                    var i = 0
                    request.data.data.forEach((e) => {
                      let option = {}
                      option.id = request.data.data[i].regionCode
                      option.label = request.data.data[i].regionName
                      option.cities = []
                      this.options.push(option)
                      i++
                    })
                  } else {
                    this.$notify.error({ title: '提示', message: '籍贯接口调用失败！' })
                    throw new Error(JSON.stringify(request))
                  }
                })
                .catch(err => {
                  let culprit = this.$route.name
                  log.work(err, culprit)
                })
            },
            clearMethod () {
              this.dialogObj.data.form.rowId = ''
              this.dialogObj.data.form.code = ''
              this.dialogObj.data.form.name = ''
              this.dialogObj.data.form.mobile = ''
              this.dialogObj.data.form.nativePlace = []
              this.dialogObj.data.form.sex = ''
              this.dialogObj.data.form.birthday = ''
              this.dialogObj.data.form.degree = ''
              this.dialogObj.data.form.custMgr = ''
              this.dialogObj.data.form.beginyear = ''
              this.dialogObj.data.form.income = ''
              this.dialogObj.data.form.avgComsumption = ''
              this.dialogObj.data.form.regularPrice = ''
              this.dialogObj.data.form.quant = ''
              this.dialogObj.data.form.trend = ''
              this.dialogObj.data.form.lastNewCig = ''
              this.dialogObj.data.form.likebestNewCig = ''
              this.dialogObj.data.form.recentlySpecCig = ''
              this.dialogObj.data.form.likebestSpecPack = ''
            },
            resetForm (formName) {
              this.dialogObj.dialogVisible = false
              this.clearMethod()
            },
            submitForm (formName) {
              this.$refs[formName].validate((valid) => {
                if (valid) {
                  this.dialogObj.dialogVisible = false
                  this.$emit('confirmBack', this.dialogObj)
                } else {
                  return false
                }
              })
//              this.clearMethod()
            },
            handleItemChange (val) {
              console.log('active item:', val)
              setTimeout(_ => {
                var k = 0
                this.options.forEach((e) => {
                  if (val.indexOf(this.options[k].label) > -1 && !this.options[k].cities.length) {
                    let param = {}
                    param.level = 2
                    param.parentRegion = this.options[k].id
                    let obj = this.options[k]
                    api.requestJava('POST', BasePath.SELECT_PROVINCEIDGROUP, param)
                      .then(request => {
                        if (Number(request.data.code) === 200) {
                          var j = 0
                          request.data.data.forEach((e) => {
                            let cityoption = {}
                            cityoption.label = request.data.data[j].regionName
                            console.log(JSON.stringify(cityoption))
                            obj.cities.push(cityoption)
                            j++
                          })
                        } else {
                          this.$notify.error({ title: '提示', message: '籍贯接口调用失败！' })
                          throw new Error(JSON.stringify(request))
                        }
                      })
                      .catch(err => {
                        let culprit = this.$route.name
                        log.work(err, culprit)
                      })
                  }
                  k++
                })
              }, 300)
            }
          }
        }
      </script>

      <style scoped>
        .item__label_popup {
          text-align: right;
          vertical-align: middle;
          float: right;
          font-size: 14px;
          color: #48576a;
          line-height: 1;
          padding: 11px 8px 11px 0;
          box-sizing: border-box;
          /* display: inline-block; */
        }
        .el-input, .el-input__inner {
          /*width: '';*/
          display: inline-block;
        }
      </style>
