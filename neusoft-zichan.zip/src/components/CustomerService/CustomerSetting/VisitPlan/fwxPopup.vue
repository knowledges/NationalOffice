<!-- 徐晓菁 -->
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :size='dialogObj.size'  :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-tabs type="border-card" v-model="activeName2"   >
        <el-tab-pane name="first">
            <span slot="label"><i v-if="Number(this.dialogObj.data.form.date7) !== 0" class="el-icon-check"></i>
              &nbsp;&nbsp;{{this.dialogObj.data.form.data0}}</span>
            <_TREECOMPONENT :search=searchable :data='this.dialogObj.data.form.steps0'  :nodeKey="nodeKey"
                          :showCheckBox=showCheckBox :expandAll=expandAll ref='tree' :highlight='true'
                          :defaultCheckedKeys="defaultCheckedKeys"></_TREECOMPONENT>
        </el-tab-pane>
        <el-tab-pane  name="second">
          <span slot="label"><i v-if="Number(this.dialogObj.data.form.date1) !== 0" class="el-icon-check"></i>
            &nbsp;&nbsp;{{this.dialogObj.data.form.data1}}</span>
          <_TREECOMPONENT :search=searchable :data='this.dialogObj.data.form.steps1'  :nodeKey="nodeKey"
                          :showCheckBox=showCheckBox :expandAll=expandAll ref='tree' :highlight='true'
                          :defaultCheckedKeys="defaultCheckedKeys"></_TREECOMPONENT>
        </el-tab-pane>
        <el-tab-pane  name="third">
          <span slot="label"><i v-if="Number(this.dialogObj.data.form.date2) !== 0" class="el-icon-check"></i>
            &nbsp;&nbsp;{{this.dialogObj.data.form.data2}}</span>
          <_TREECOMPONENT :search=searchable :data='this.dialogObj.data.form.steps2'  :nodeKey="nodeKey"
                          :showCheckBox=showCheckBox :expandAll=expandAll ref='tree' :highlight='true'
                          :defaultCheckedKeys="defaultCheckedKeys"></_TREECOMPONENT>
        </el-tab-pane>
        <el-tab-pane  name="fourth">
          <span slot="label"><i v-if="Number(this.dialogObj.data.form.date3) !== 0" class="el-icon-check"></i>
            &nbsp;&nbsp;{{this.dialogObj.data.form.data3}}</span>
          <_TREECOMPONENT :search=searchable :data='this.dialogObj.data.form.steps3'  :nodeKey="nodeKey"
                          :showCheckBox=showCheckBox :expandAll=expandAll ref='tree' :highlight='true'
                          :defaultCheckedKeys="defaultCheckedKeys"></_TREECOMPONENT>
        </el-tab-pane>
        <el-tab-pane  name="five">
          <span slot="label"><i v-if="Number(this.dialogObj.data.form.date4) !== 0" class="el-icon-check"></i>
            &nbsp;&nbsp;{{this.dialogObj.data.form.data4}}</span>
          <_TREECOMPONENT :search=searchable :data='this.dialogObj.data.form.steps4'  :nodeKey="nodeKey"
                          :showCheckBox=showCheckBox :expandAll=expandAll ref='tree' :highlight='true'
                          :defaultCheckedKeys="defaultCheckedKeys"></_TREECOMPONENT>
        </el-tab-pane>
        <el-tab-pane  name="six">
          <span slot="label"><i v-if="Number(this.dialogObj.data.form.date5) !== 0" class="el-icon-check"></i>
            &nbsp;&nbsp;{{this.dialogObj.data.form.data5}}</span>
          <_TREECOMPONENT :search=searchable :data='this.dialogObj.data.form.steps5'  :nodeKey="nodeKey"
                          :showCheckBox=showCheckBox :expandAll=expandAll ref='tree' :highlight='true'
                          :defaultCheckedKeys="defaultCheckedKeys"></_TREECOMPONENT>
        </el-tab-pane>
        <el-tab-pane  name="seven">
          <span slot="label"><i v-if="Number(this.dialogObj.data.form.date6) !== 0" class="el-icon-check"></i>
            &nbsp;&nbsp;{{this.dialogObj.data.form.data6}}</span>
          <_TREECOMPONENT :search=searchable :data='this.dialogObj.data.form.steps6'  :nodeKey="nodeKey"
                          :showCheckBox=showCheckBox :expandAll=expandAll ref='tree' :highlight='true'
                          :defaultCheckedKeys="defaultCheckedKeys"></_TREECOMPONENT>
        </el-tab-pane>
      </el-tabs>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import _TREECOMPONENT from '@/components/Template/Tree/Tree.vue'
  export default {
    props: ['dialogObj'],
    mounted () {

    },
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        if (Number(this.dialogObj.data.form.date7) !== 0) {
          this.activeName2 = 'first'
        } else if (Number(this.dialogObj.data.form.date1) !== 0) {
          this.activeName2 = 'second'
        } else if (Number(this.dialogObj.data.form.date2) !== 0) {
          this.activeName2 = 'third'
        } else if (Number(this.dialogObj.data.form.date3) !== 0) {
          this.activeName2 = 'fourth'
        } else if (Number(this.dialogObj.data.form.date4) !== 0) {
          this.activeName2 = 'five'
        } else if (Number(this.dialogObj.data.form.date5) !== 0) {
          this.activeName2 = 'six'
        } else if (Number(this.dialogObj.data.form.date6) !== 0) {
          this.activeName2 = 'seven'
        }
      }
    },
    data () {
      return {
        addrules: {},
        nodeKey: 'id',
        activeName2: 'first',
        defaultCheckedKeys: [],
        searchable: false, // 是否带搜索框
        showCheckBox: false, // 是否带复选框
        expandAll: true, // 是否展开所有节点
        isLoading: true
      }
    },
    methods: {
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      },
      handleClick (row) {}
    },
    components: {
      _TREECOMPONENT
    }
  }
</script>
<style scoped>
  .notice{
    color: #0e0808 !important;
    font-size: 15px;
  }
  .el-col-3 {
    width: 14.2%;
    height: 100%;
  }
</style>
