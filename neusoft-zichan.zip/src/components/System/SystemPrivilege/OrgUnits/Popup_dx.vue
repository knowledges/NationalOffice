<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-form-item label="机构类型">
        <el-select v-model="dialogObj.data.form.orgType" placeholder="请选择机构类型">
          <template v-for="item in groupCode1">
            <el-option :label="item.label" :value="item.id"></el-option>
          </template>
        </el-select>
      </el-form-item>
      <el-form-item label="机构代码">
        <el-input  v-model="dialogObj.data.form.unitCode"></el-input>
      </el-form-item>
      <el-form-item label="机构名称">
        <el-input  v-model="dialogObj.data.form.unitName"></el-input>
      </el-form-item>
      <el-form-item label="简称">
        <el-input  v-model="dialogObj.data.form.shortName"></el-input>
      </el-form-item>
      <el-form-item label="角色类型">
        <tbody>
          <tr  v-for="(value,key) in dialogObj.data.form.roles" :id="key">
            <td style="cursor: pointer;width:40%">
              <el-select v-model="value.roleTypeId" style="width:100%;"  placeholder="请选择角色类型">
                <template v-for="item in groupCode2">
                  <el-option :label="item.label" :value="item.id"></el-option>
                </template>
              </el-select>
            </td>
            <td align="center" style="cursor: pointer;width:5%" @click="plus"><div class="fa fa-plus"></div></td>
            <td align="center" style="cursor: pointer;width:5%" @click="deletes(key)"><div class="fa fa-minus"></div></td>
          </tr>
        </tbody>
      </el-form-item>
      <el-form-item    label="上级机构">
       <compositeInput :filterVal.sync="filterVal" @on-change="inputChange"></compositeInput>
      </el-form-item>
      </el-form-item>
      <el-form-item label="地址">
        <el-input  v-model="dialogObj.data.form.address"></el-input>
      </el-form-item>
      <el-form-item label="状态">
        <el-switch on-text="" off-text="" v-model="dialogObj.data.form.status"></el-switch>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="resetForm('addForm')">取 消</el-button>
      <el-button type="primary" @click="submitForm('addForm')">确 定</el-button>
    </div>
  </el-dialog>
  <POPUP :dialogObj='dialogObj5' @confirmBack="confirmBack5" />
  </div>
</template>

<script>
  import POPUP from '@/components/Template/Popup/Popup.vue'
  import compositeInput from './compositeInput.vue'
  import api from '@/api'
  import log from '@/log'
//  import { getUser } from '@/config/info'
  import { mapState } from 'vuex'
  import axios from 'axios'
  export default {
    props: ['dialogObj'],
    mounted () {
      let params1 = {}
      params1.typeCode = 'MD_ORG_TYPES'
      let params2 = {}
      params2.typeCode = 'MD_ORG_ROLE_TYPES'
      axios.all([
        api.requestJava('POST', 'common/codelist/searchCodeDetail.do', params1),
        api.requestJava('POST', 'common/codelist/searchCodeDetail.do', params2)
      ])
      .then(axios.spread((first, scend) => {
        this.groupCode1 = first.data.data
        this.groupCode2 = scend.data.data
        this.filterVal = this.dialogObj.data.form.parentName
      }))
    },
    updated () {
      this.filterVal = this.dialogObj.data.form.parentName
    },
    data () {
      return {
        groupCode1: [],
        groupCode2: [],
        groupCode3: [],
        parentTree: [],
        addrules: {
          unitName: [
            {required: true, message: '请输入机构名称', trigger: 'blur'}
          ],
          orgType: [
            {required: true, message: '请选择机构类型', trigger: 'blur'}
          ],
          roleId: [
            {required: true, message: '请选择角色类型', trigger: 'blur'}
          ],
          parentId: [
            {required: true, message: '请选择上级机构', trigger: 'blur'}
          ]
        },
        dialogObj5: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        filterVal: ''
      }
    },
    computed: {
      ...mapState([
        'userInfo',
        'company',
        'deparment'
      ])
    },
    methods: {
      clearMethod () {
        this.filterVal = this.dialogObj.data.form.parentName
        this.dialogObj.data.form.thesystem = ''
        this.dialogObj.data.form.companyId = ''
        this.dialogObj.data.form.entCulture = ''
        this.dialogObj.data.form.codeP1 = ''
        this.dialogObj.data.form.permitNo = ''
        this.dialogObj.data.form.unitLevel = ''
        this.dialogObj.data.form.beginDate = ''
        this.dialogObj.data.form.legalPerson = ''
        this.dialogObj.data.form.corpCode = ''
        this.dialogObj.data.form.url = ''
        this.dialogObj.data.form.address = ''
        this.dialogObj.data.form.shortName = ''
        this.dialogObj.data.form.sortCode = ''
        this.dialogObj.data.form.shortCode = ''
        this.dialogObj.data.form.unitName = ''
        this.dialogObj.data.form.unitCode = ''
        this.dialogObj.data.form.orgType = ''
        this.dialogObj.data.form.rowId = ''
        this.dialogObj.data.form.roleName = ''
        this.dialogObj.data.form.roleId = ''
        this.dialogObj.data.form.parentId = ''
        this.dialogObj.data.form.parentName = ''
        this.dialogObj.data.form.virtualFlag = ''
        this.dialogObj.data.form.stopId = ''
        this.dialogObj.data.form.regionalism = ''
        this.dialogObj.data.form.remarks = ''
        this.dialogObj.data.form.status = ''
        this.dialogObj.data.form.originFlag = ''
        this.dialogObj.data.form.originApp = ''
        this.dialogObj.data.form.supplierCode = ''
      },
      plus () {
        let temp = {roleTypeId: ''}
        this.dialogObj.data.form.roles.push(temp)
      },
      deletes (key) {
        if (key !== 0) {
          this.dialogObj.data.form.roles.splice(key, 1)
        }
      },
      resetForm (formName) {
        this.dialogObj.dialogVisible = false
        this.clearMethod()
      },
      changeValue (value) {
        let obj = {}
        obj = this.groupCode.find((item) => {
          if (item.id === value) {
            return item
          }
        })
        return obj.label
      },
      saveUpper () {
        let params = {}
        let units = {}
        units.orgType = this.dialogObj.data.form.orgType
        units.unitCode = this.dialogObj.data.form.unitCode
        units.unitName = this.dialogObj.data.form.unitName
        units.shortCode = this.dialogObj.data.form.shortCode
        units.sortCode = this.dialogObj.data.form.sortCode
        units.shortName = this.dialogObj.data.form.shortName
        units.address = this.dialogObj.data.form.address
        units.url = this.dialogObj.data.form.url
        units.corpCode = this.dialogObj.data.form.corpCode
        units.legalPerson = this.dialogObj.data.form.legalPerson
        units.beginDate = this.dialogObj.data.form.beginDate
        units.unitLevel = this.dialogObj.data.form.unitLevel
        units.permitNo = this.dialogObj.data.form.permitNo
        units.codeP1 = this.dialogObj.data.form.codeP1
        units.entCulture = this.dialogObj.data.form.entCulture
        units.thesystem = this.dialogObj.data.form.thesystem
        units.virtualFlag = this.dialogObj.data.form.virtualFlag
        // units.stopId = this.dialogObj.data.form.stopId
        units.regionalism = this.dialogObj.data.form.regionalism
        units.remarks = this.dialogObj.data.form.remarks
        units.remark = this.dialogObj.data.form.remark
        units.status = this.dialogObj.data.form.status
        units.modificationNum = this.dialogObj.data.form.modificationNum
        units.deletedFlag = this.dialogObj.data.form.deletedFlag
        units.originFlag = this.dialogObj.data.form.originFlag
        units.originApp = this.dialogObj.data.form.originApp
        units.supplierCode = this.dialogObj.data.form.supplierCode
        let roles = {}
        roles.orgRoleTypId = this.dialogObj.data.form.roleTypeId
        roles.status = 1
        let relations = {}
        relations.orgrelTypeId = 2
        relations.orgRoleTypId = this.dialogObj.data.form.roleTypeId
        if (Object.prototype.toString.call(this.parentTree) !== '[object Array]') {
          relations.relOrgRoleTypId = this.parentTree.roleTypeId
          relations.relOrgUnitId = this.parentTree.unitId
        } else {
          relations.relOrgRoleTypId = this.dialogObj.data.form.parentRoleTypeId
          relations.relOrgUnitId = this.dialogObj.data.form.parentId
        }
        relations.status = 1
        params.units = units
        params.roles = roles
        params.relations = relations
        api.requestJava('POST', 'common/appparam/save.do', params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.dialogObj5.dialogVisible = true
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            // this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.saveUpper()
            // this.dialogObj.dialogVisible = false
            // this.clearMethod()
            // this.$router.go(0)  //  刷新父页面
          } else {
            return false
          }
        })
      },
      inputChange (msg) {
        this.parentTree = JSON.parse(msg)
      }
    },
    components: {
      POPUP,
      compositeInput
    }
  }
</script>

<style scoped>
  .item__label_popup {
    text-align: right;
    vertical-align: middle;
    float: right;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 8px 11px 0;
    box-sizing: border-box;
    /* display: inline-block; */
  }
  .el-input, .el-input__inner {
    /*width: '';*/
    display: inline-block;
  }
</style>
