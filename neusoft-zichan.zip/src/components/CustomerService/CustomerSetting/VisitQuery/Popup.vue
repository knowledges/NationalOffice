<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-table :data="this.dialogObj.data.form.steps"  >
        <el-table-column prop="title" label="服务" ></el-table-column>
        <el-table-column prop="startTime" label="时间" ></el-table-column>
        <el-table-column label="操作" width="100">
          <template scope="scope">
            <el-button @click="handleClick(scope.row)" type="text" size="small">查看</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
    </div>
  </el-dialog>
  <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve"/>
  <MY_POPUP_SALES :dialogObj='sales' @confirmBack="salesEve"/>
  <MY_POPUP_SUMMARY :dialogObj='summary' @confirmBack="summaryEve"/>
  <MY_POPUP_VISITING :dialogObj='visiting' @confirmBack="visitingEve"/>
  <MY_POPUP_COMPLAINT :dialogObj='complaint' @confirmBack="complaintEve"/>
  <!--<MY_POPUP_FORM :dialogObj='forms' @confirmBack="formEve"/>-->
  <MY_POPUP_MATERIEL :dialogObj='materiel' @confirmBack="materielEve"/>
  <el-dialog title="调查问卷浏览" :visible.sync="dialogTableVisible">
    <iframe :src="iurl"  style="width: 100%;height: 521px;"></iframe>
  </el-dialog>
  </div>
</template>

<script>
//  import MY_POPUP_FORM from './formsListPopup.vue'
  import MY_POPUP_VISITING from './visitingPopup.vue'
  import MY_POPUP_COMPLAINT from './complaintListPopup.vue'
  import MY_POPUP_CONFIG from './stepPopup.vue'
  import MY_POPUP_SALES from './stepListPopup.vue'
  import MY_POPUP_SUMMARY from './summaryPopup.vue'
  import MY_POPUP_MATERIEL from './MaterielDetialPopup.vue'
  import log from '@/log'
  import api from '@/api'
  import { convertVal, dateFormat } from '@/utils/common'
  import BasePath from '@/config/BasePath'
  import config from '@/config'
  import {getCodeList, getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      getCodeList('YC_BUSINESS_TYPE', (data) => {
        this.options_businessType = data
      }) // 零售业态
      getCodeList('YC_TRADE_CIRCLE_TYPE', (data) => {
        this.options_tradeCircleType = data
      }) // 商圈
      getCodeList('CUSTOMER_GRADE', (data) => {
        this.options_grade = data
      }) // 客户档级
    },
    data () {
      return {
        dialogTableVisible: false,
        addrules: {},
        options_businessType: [],
        options_tradeCircleType: [],
        options_grade: [],
        edit: {
          title: '查看',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              files: [],
              rowId: '',
              companyId: '',
              stepId: '',
              formId: '',
              formCode: '',
              title: '',
              visitingRecId: '',
              planId: '',
              visitor: '',
              visitorName: '',
              customerId: '',
              cusotmerName: '',
              startTime: '',
              endTime: '',
              positionX: '',
              positionY: '',
              serialNo: '',
              onSchedule: '',
              clCode: '',
              clDesc: '',
              notes: '',
              status: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: '',
              endDate: '',
              beginDate: ''
            }
          }
        },
        materiel: {
          title: '查看物料发放',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              files: [],
              materialCd: '',
              materialNm: '',
              unit: '',
              quantity: ''
            }
          }
        },
        sales: {
          title: '驻店销售记录',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              products: []
            }
          }
        },
        complaint: {
          title: '客户意见征集及反馈',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              products: []
            }
          }
        },
        summary: {
          title: '驻店营销活动记录',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              files1: [],
              files2: [],
              rowId: '',
              visitingRecId: '',
              visitorId: '',
              visitorNm: '',
              visitorPlace: '',
              customerId: '',
              customerCode: '',
              customerDesc: '',
              businessType: '',
              tradeCircleType: '',
              customerGrade: '',
              addr: '',
              tel: '',
              instoreDate: '',
              val01: '',
              val02: '',
              val03: '',
              val04: '',
              val05: '',
              val06: '',
              val07: '',
              val08: '',
              val09: '',
              summaries: '',
              cEval: '',
              cOpinions: '',
              hPhotoId: '',
              sPhotoId: ''
            }
          }
        },
        visiting: {
          title: '拜访异常',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              files: [],
              rowId: '',
              companyId: '',
              flowId: '',
              visitor: '',
              visitorName: '',
              checkerId: '',
              checkerNm: '',
              opinions: '',
              auditDate: '',
              customerId: '',
              customerName: '',
              partyName: '',
              startTime: '',
              endTime: '',
              positionX: '',
              positionY: '',
              positionX2: '',
              positionY2: '',
              serialNo: '',
              summery: '',
              onSchedule: '',
              expectedTime: '',
              status: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: '',
              visitMode: ''
            }
          }
        },
        forms: {
          title: '调查',
          type: '3',
          dialogVisible: false,
          size: 'small',
          data: {
            form: {
              files: [],
              rowId: '',
              companyId: '',
              flowId: '',
              visitor: '',
              visitorName: '',
              checkerId: '',
              checkerNm: '',
              opinions: '',
              auditDate: '',
              customerId: '',
              customerName: '',
              partyName: '',
              startTime: '',
              endTime: '',
              positionX: '',
              positionY: '',
              positionX2: '',
              positionY2: '',
              serialNo: '',
              summery: '',
              onSchedule: '',
              expectedTime: '',
              status: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: '',
              visitMode: ''
            }
          }
        },
        iurl: ''
      }
    },
    methods: {
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      },
      handleClick (row) {
        this.Open(row)
      },
      editEve (msg) {
        this.edit.dialogVisible = false
        let tmp = {
          title: '查看',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              files: [],
              rowId: '',
              companyId: '',
              stepId: '',
              formId: '',
              formCode: '',
              title: '',
              visitingRecId: '',
              planId: '',
              visitor: '',
              visitorName: '',
              customerId: '',
              cusotmerName: '',
              startTime: '',
              endTime: '',
              positionX: '',
              positionY: '',
              serialNo: '',
              onSchedule: '',
              clCode: '',
              clDesc: '',
              notes: '',
              status: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: '',
              endDate: '',
              beginDate: ''
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      salesEve (msg) {
        this.sales.dialogVisible = false
        let tmp = {
          title: '驻店销售记录',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              products: []
            }
          }
        }
        Object.assign(this.sales, tmp)
      }, // 修改事件
      complaintEve (msg) {
        this.complaint.dialogVisible = false
        let tmp = {
          title: '客户意见征集及反馈',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              products: []
            }
          }
        }
        Object.assign(this.complaint, tmp)
      }, // 修改事件
      summaryEve (msg) {
        this.summary.dialogVisible = false
        let tmp = {
          title: '驻店营销活动记录',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              files: [],
              rowId: '',
              visitingRecId: '',
              visitorId: '',
              visitorNm: '',
              visitorPlace: '',
              customerId: '',
              customerCode: '',
              customerDesc: '',
              businessType: '',
              tradeCircleType: '',
              addr: '',
              tel: '',
              instoreDate: '',
              val01: '',
              val02: '',
              val03: '',
              val04: '',
              val05: '',
              val06: '',
              val07: '',
              val08: '',
              val09: '',
              summaries: '',
              cEval: '',
              cOpinions: '',
              hPhotoId: '',
              sPhotoId: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: ''
            }
          }
        }
        Object.assign(this.summary, tmp)
      }, // 修改事件
      visitingEve (msg) {
        this.visiting.dialogVisible = false
        let tmp = {
          title: '拜访异常',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              files: [],
              rowId: '',
              companyId: '',
              flowId: '',
              visitor: '',
              visitorName: '',
              checkerId: '',
              checkerNm: '',
              opinions: '',
              auditDate: '',
              customerId: '',
              customerName: '',
              partyName: '',
              startTime: '',
              endTime: '',
              positionX: '',
              positionY: '',
              positionX2: '',
              positionY2: '',
              serialNo: '',
              summery: '',
              onSchedule: '',
              expectedTime: '',
              status: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: '',
              visitMode: ''
            }
          }
        }
        Object.assign(this.visiting, tmp)
      }, // 修改事件
      formEve (msg) {
        this.forms.dialogVisible = false
        let tmp = {
          title: '调查',
          type: '3',
          dialogVisible: false,
          size: 'small',
          data: {
            form: {
              files: [],
              rowId: '',
              companyId: '',
              flowId: '',
              visitor: '',
              visitorName: '',
              checkerId: '',
              checkerNm: '',
              opinions: '',
              auditDate: '',
              customerId: '',
              customerName: '',
              partyName: '',
              startTime: '',
              endTime: '',
              positionX: '',
              positionY: '',
              positionX2: '',
              positionY2: '',
              serialNo: '',
              summery: '',
              onSchedule: '',
              expectedTime: '',
              status: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: '',
              visitMode: ''
            }
          }
        }
        Object.assign(this.forms, tmp)
      }, // 修改事件
      materielEve (msg) {
        this.materiel.dialogVisible = false
        let tmp = {
          title: '查看物料发放',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              files: [],
              materialCd: '',
              materialNm: '',
              unit: '',
              quantity: ''
            }
          }
        }
        Object.assign(this.visiting, tmp)
      },
      Open (stepDate) {
        if (stepDate.formCode === 'HJTS') {
          this.edit.title = '环境提升'
          Object.assign(this.edit.data.form, stepDate)
          this.edit.dialogVisible = true
        } else if (stepDate.formCode === 'MMBJ') {
          this.edit.title = '明码标价'
          Object.assign(this.edit.data.form, stepDate)
          this.edit.dialogVisible = true
        } else if (stepDate.formCode === 'CLZD') {
          this.edit.title = '陈列指导'
          Object.assign(this.edit.data.form, stepDate)
          this.edit.dialogVisible = true
        } else if (stepDate.formCode === 'XFZDC') {
          this.forms.title = '消费者调查'
          this.findByIdUpper5(stepDate)
        } else if (stepDate.formCode === '-1') {
          this.visiting.title = '拜访异常'
          this.findByIdUpper4(stepDate)
        } else if (stepDate.formCode === 'ZDYX-XSJL') {
          this.sales.title = '驻店销售记录'
          this.findByIdUpper2(stepDate)
        } else if (stepDate.formCode === 'ZDYX-HDJL') {
          this.summary.title = '驻店营销活动记录'
          this.findByIdUpper3(stepDate)
        } else if (stepDate.formCode === 'PDC') {
          this.complaint.title = '客户意见征集及反馈'
          this.findByIdUpper1(stepDate)
        } else if (stepDate.formCode === 'XPCS-CONSUMER') {
          this.forms.title = '新品测试调查（消费者）'
          this.findByIdUpper5(stepDate)
        } else if (stepDate.formCode === 'JYDHZD') {
          this.forms.title = '卷烟订货指导'
          Object.assign(this.edit.data.form, stepDate)
          this.edit.dialogVisible = true
        } else if (stepDate.formCode === 'WLFF') {
          this.forms.title = '终端物料发放'
          this.findByIdUpperWLFF(stepDate)
        } else if (stepDate.formCode === '新建工作表单') {
          this.forms.title = '问卷调查'
          this.findByIdUpper6(stepDate)
        }
      },
      findByIdUpper1 (row) { //  客户意见征集及反馈
        let param = {}
        let time = this.getTime(Date.parse(row.startTime))
        let start = time + ' 00:00:00'
        let end = time + ' 23:59:59'
        param.whereClause = ` and CREATED_TIME between  '` + start + `'   and  '` + end + ` ' `
        param.customerId = row.customerId
        console.log('param', param)
        api.requestJava('POST', BasePath.COMPLAINTREC_SELECT, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.complaint.data.form.products = request.data.data
              this.complaint.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 问题需求采集
      findByIdUpper2 (row) { // 驻店销售记录
        let param = {}
        param.visitingRecId = row.visitingRecId
//        param.haveAttach = '1'
        api.requestJava('POST', BasePath.INSTORESALES_SELECTLIST, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.sales.data.form.products = request.data.data
              this.sales.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 驻店销售记录
      findByIdUpper3 (row) { // 驻店营销活动记录
        let param = {}
        param.visitingRecId = row.visitingRecId
        param.haveAttach = '1'
        api.requestJava('POST', BasePath.INSTORESUMMARY_SELECTONE, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              Object.assign(this.summary.data.form, request.data.data)
              let tempfiles = request.data.data.files
              var i = 0
              tempfiles.forEach((e) => {
                if (tempfiles[i].fileType === 'legal_attach_photo') {
                  this.summary.data.form.file1.push(tempfiles[i])
                } else {
                  this.summary.data.form.file2.push(tempfiles[i])
                }
                i++
              })
              this.findCusByIdUpper3(row)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 驻店营销活动记录
      findCusByIdUpper3 (row) { // 驻店营销活动记录
        let param = {}
        param.rowId = row.customerId
        api.requestJava('POST', BasePath.CUSTOMER_SELECTONE, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.summary.data.form.customerGrade = convertVal(this.options_grade, request.data.data.customerGrade, 'value', 'label')
              this.summary.data.form.businessType = convertVal(this.options_businessType, request.data.data.businessType, 'value', 'label')
              this.summary.data.form.tradeCircleType = convertVal(this.options_tradeCircleType, request.data.data.tradeCircleType, 'value', 'label')
              this.summary.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 驻店营销活动记录
      findByIdUpper4 (row) { // 异常
        let param = {}
        param.rowId = row.visitingRecId
        param.haveAttach = '1'
        api.requestJava('POST', BasePath.VISITQUERY_SELECTONE, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              Object.assign(this.visiting.data.form, request.data.data)
              this.visiting.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 异常
//      findByIdUpper5 (row) { // 消费者调查  新品测试调查（消费者）
//        let param = {}
//        param.visitingRecId = row.visitingRecId
//        param.formCode = row.formCode
//        api.requestJava('POST', BasePath.VISITQUERY_STEPSSELECT, param)
//          .then((request) => {
//            if (Number(request.data.code) === 200) {
//              this.forms.data.form.products = request.data.data
//              this.forms.dialogVisible = true
//            } else if (Number(request.data.code) === 401) {
//              this.$message('登录失效')
//              this.logInvalid.dialogVisible = true
//            } else {
//              this.$notify.error({title: '提示', message: request.data.message})
//              throw new Error(JSON.stringify(request))
//            }
//          })
//          .catch((err) => {
//            let culprit = this.$route.name
//            log.work(err, culprit)
//          })
//      }, // 消费者调查
      findByIdUpper6 (row) { //  客户意见征集及反馈
        console.log('row数据' + JSON.stringify(row))
        let temp = {}
        temp.formId = row.formId
        temp.stepId = row.stepId
        temp.userId = getUser().id
        temp.customerId = row.customerId
        temp.brandId = 0
        temp.companyId = row.companyId
        temp.personId = getUser().personId
        temp.disabled = 0
        temp.visitingRecId = row.rowId
        temp.planId = row.planId
        temp.visitor = row.visitor
        temp.visitorName = row.visitorName
        temp.customerName = row.cusotmerName
        let str = JSON.stringify(temp)
        console.log('str' + str)
        let enCode = encodeURI(str)
        this.iurl = config.root + '/survey/' + enCode
        console.log('this.iurl' + this.iurl)
        this.dialogTableVisible = true
      },
      findByIdUpperWLFF (row) { // 终端物料发放
        let param = {}
        param.rowId = row.serialNo
        param.haveAttach = '1'
        api.requestJava('POST', BasePath.MTRLINVENTORY_SELECTLIST, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              Object.assign(this.materiel.data.form, request.data.data[0])
              let billparam = {}
              billparam.billId = request.data.data[0].rowId
              api.requestJava('POST', BasePath.MTRLINVENTORY_SELECTLIST_DETAIL, billparam)
                .then(request => {
                  if (Number(request.data.code) === 200) {
                    this.materiel.data.form.materialCd = request.data.data[0].materialCd
                    this.materiel.data.form.materialNm = request.data.data[0].materialNm
                    this.materiel.data.form.unit = request.data.data[0].unit
                    this.materiel.data.form.quantity = request.data.data[0].quantity
                    this.materiel.dialogVisible = true
                  } else {
                    this.$notify.error({ title: '提示', message: '查询接口调用失败！' })
                    throw new Error(JSON.stringify(request))
                  }
                })
                .catch(err => {
                  let culprit = this.$route.name
                  log.work(err, culprit)
                })
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 终端物料发放
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      }  // 时间格式化
    },
    components: {
      MY_POPUP_CONFIG,
      MY_POPUP_SALES,
      MY_POPUP_SUMMARY,
      MY_POPUP_VISITING,
      MY_POPUP_COMPLAINT,
//      MY_POPUP_FORM,
      MY_POPUP_MATERIEL
    }
  }
</script>
