<template>
<div>
  <el-checkbox-group v-show="row._edit" v-model="row[col.prop]">
    <el-checkbox v-for="(item, index) in col.options" :key="item" :label="item"></el-checkbox>
  </el-checkbox-group>
  <span v-show="!row._edit">{{ text }}</span>
</div>
</template>

<script>
  export default {
    props: {
      row: Object,
      col: Object,
      data: Array
    // KeyDownEvent: {
    //   type: Function,
    //   default: function (ev) {
    //   }
    // }
    },
    methods: {
    },
    computed: {
      text () {
        return String(this.row[this.col.prop])
      }
    }
  }
</script>