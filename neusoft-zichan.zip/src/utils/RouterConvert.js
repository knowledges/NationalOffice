/**
 * 设置去掉缓存的路由
 */
const setFalse = ['WarningInfoDeal', 'MaterielAdd', 'MaterielReceive', 'MaterielGrant', 'MaterielQuery', 'CustomSurvey', 'SurveyCount', 'Record', 'recordDetail', 'ReportVisitStatistics', 'ReportStatistics', 'Customer']
/**
 * 设置带参的路由
 */
const setParams = ['MaterielAdd', 'MaterielReceive', 'MaterielGrant', 'MaterielQuery', 'CustomSurvey', 'SurveyCount', 'QuarterCustSalesAnalysisEdit']
/**
 * DataViz 直接跳转
 * @type {[string]}
 */
const setDataViz = ['DatavizCustom', 'VizDataAnalysis']
export function getRouterObj (route, data) {
  data.children.forEach((item) => {
    let isTrue = true
    if (item.children.length > 0) {
      getRouterObj(route, item)
    } else {
      let tmp = {}
      /**
       * ~取反所有存在的为 -1
       */
      if (~setParams.indexOf(item.resCode)) {
        tmp.path = '/' + item.resCode + '/:uId'
      } else {
        tmp.path = '/' + item.resCode
      }
      tmp.name = item.resCode
      tmp.meta = {
        keepAlive: ~setFalse.indexOf(item.resCode) ? isTrue = false : isTrue, // keepAlive 【true：缓存模块，false：不缓存】
        dataViz: ~setDataViz.indexOf(item.resCode) ? isTrue = false : isTrue, // dataViz 【true：dataviz模块，false：;】
        parent: Number(item.id.slice(0, 1)) - 1 // 归属于哪一个2级模块
      }
      if (item.resUrl !== '') {
        tmp.component = resolve => require([`../components/${item.resUrl}.vue`], resolve)
      } else {
        tmp.component = resolve => require(['../components/Dash.vue'], resolve)
      }
      route.push(tmp)
    }
  })
}
export function getDynamicRoute (route, data, place) {
  data.forEach((item) => {
    let tmp = {}
    if (item.resCode === 'Home') {
      /* 根据登录者分配不同的首页 */
      if (place === 135) {
        tmp.component = resolve => require([`../components/Home/ClientManager/Home.vue`], resolve)
      } else if (place === 24) {
        tmp.component = resolve => require([`../components/Home/MarketingManager/Home.vue`], resolve)
      } else {
        // tmp.component = resolve => require([`../components/Home/MarketingManager/Home.vue`], resolve)
        tmp.component = resolve => require([`../components/Home/Leader/Home.vue`], resolve)
      }
    } else {
      tmp.component = resolve => require([`../components/${item.resUrl}.vue`], resolve)
    }
    tmp.path = '/' + item.path
    tmp.name = item.resCode
    tmp.meta = {
      keepAlive: false, // keepAlive 【true：缓存模块，false：不缓存】
      parent: item.parent // 归属于哪一个2级模块
    }
    route.push(tmp)
  })
}

