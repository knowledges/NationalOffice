<!--李晶-->
<style rel="stylesheet/scss" lang="scss" scoped></style>
<template>
  <div class="container-fluid" style="height: 99%">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <div class="text-right">
          <el-date-picker
            v-model="timer"
            type="daterange"
            align="right"
            @change="rangeTime"
            placeholder="选择日期范围"
            :picker-options="pickerOptions">
          </el-date-picker>
          <el-button type="primary" @click="findClk">查询</el-button>
        </div>
      </el-col>
    </el-row>
    <div style="height: calc(100% - 94px)">
      <iframe id="myIframe" :src="htl" frameborder="0" allowtransparency="true" width="100%" height="100%" scrolling="yes"></iframe>
    </div>
  </div>
</template>
<script>
  import config from '@/config'
  import {dateFormat} from '@/utils/dateFormat'
  import {getUser} from '@/config/info'
  import DatePickerTemp from '@/components/Template/DatePicker/DatePickerTemp.vue'
  export default {
    name: 'MarketingActived',
    props: {},
    mounted () {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
      this.timer = [start, end]
      this.begin_date = dateFormat(Date.parse(this.timer[0]), 'YYYY-MM-DD')
      this.end_date = dateFormat(Date.parse(this.timer[1]), 'YYYY-MM-DD')
      this.findClk()
    },
    data () {
      return {
        timer: [],
        begin_date: '',
        end_date: '',
        daterange: 'daterange',
        quick: true,
        company_id: '',
        county_dept: '',
        htl: '',
        pickerOptions: {
          shortcuts: [{
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }]
        }
      }
    },
    methods: {
      rangeTime (val) {
        var tmp = val.split(' - ')
        this.begin_date = tmp[0]
        this.end_date = tmp[1]
      },
      findClk () {
        var reportId = ''
        if (this.begin_date === '' && this.end_date === '') {
          this.$notify({
            title: '警告',
            message: '时间范围不能为空',
            type: 'warning'
          })
        } else {
          if (Number(getUser().unitLevel) === 1) {
            reportId = '211ed65d-1374-4ba1-930e-d6d8122618b3'
            this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&begin_date=' + this.begin_date + '&end_date=' + this.end_date
          } else {
            reportId = '4fcd4d03-968a-42bd-9967-4fd47a7570b5'
            this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&begin_date=' + this.begin_date + '&end_date=' + this.end_date + '&company_id=' + getUser().companyId
          }
          console.log('this.htlthis.htl:' + this.htl)
        }
      }
    },
    components: {
      DatePickerTemp
    },
    watch: {}
  }
</script>
