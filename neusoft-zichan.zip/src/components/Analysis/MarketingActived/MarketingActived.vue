<!--李晶-->
<style rel="stylesheet/scss" lang="scss" scoped></style>
<template>
  <div class="container-fluid" style="height: 99%">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <div class="text-right">
          <el-date-picker
            v-model="timer"
            type="daterange"
            align="right"
            @change="rangeTime"
            placeholder="选择日期范围"
            :picker-options="pickerOptions">
          </el-date-picker>
          <el-button type="primary" @click="findClk">查询</el-button>
        </div>
      </el-col>
    </el-row>
    <div style="height: calc(100% - 94px)">
      <iframe id="myIframe" :src="htl" frameborder="0" allowtransparency="true" width="100%" height="100%" scrolling="yes"></iframe>
    </div>
  </div>
</template>
<script>
  import config from '@/config'
  import {dateFormat} from '@/utils/dateFormat'
  import {getUser} from '@/config/info'
  import DatePickerTemp from '@/components/Template/DatePicker/DatePickerTemp.vue'
  export default {
    name: 'MarketingActived',
    props: {},
    mounted () {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
      this.timer = [start, end]
      this.BEGIN_DATE = dateFormat(Date.parse(this.timer[0]), 'YYYY-MM-DD')
      this.END_DATE = dateFormat(Date.parse(this.timer[1]), 'YYYY-MM-DD')
      this.findClk()
    },
    data () {
      return {
        timer: [],
        BEGIN_DATE: '',
        END_DATE: '',
        daterange: 'daterange',
        quick: true,
        company_id: '',
        county_dept: '',
        htl: '',
        pickerOptions: {
          shortcuts: [{
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }]
        }
      }
    },
    methods: {
      rangeTime (val) {
        var tmp = val.split(' - ')
        this.BEGIN_DATE = tmp[0]
        this.END_DATE = tmp[1]
      },
      findClk () {
        var reportId = ''
        if (this.BEGIN_DATE === '' && this.END_DATE === '') {
          this.$notify({
            title: '警告',
            message: '时间范围不能为空',
            type: 'warning'
          })
        } else {
//          if (Number(getUser().unitLevel) === 1) {
//            reportId = '6a28e47d-99b1-4585-9ce2-4466b8a9e3b2'
//            this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&BEGIN_DATE=' + this.BEGIN_DATE + '&END_DATE=' + this.END_DATE
//          } else {
//            reportId = 'aa8837ba-6b2f-465a-934e-c4194dd65b30'
//            this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&BEGIN_DATE=' + this.BEGIN_DATE + '&END_DATE=' + this.END_DATE + '&unit_id=' + getUser().companyId
//          }
//          console.log('this.htlthis.htl:' + this.htl)

          // 省公司
          if (Number(getUser().unitLevel) === 1) {
            reportId = '6a28e47d-99b1-4585-9ce2-4466b8a9e3b2'
            this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&BEGIN_DATE=' + this.BEGIN_DATE + '&END_DATE=' + this.END_DATE
          } else if (Number(getUser().unitLevel) === 2) {
            // 市公司
            if (getUser().countyId === null || getUser().countyId === 'null') {
              reportId = 'aa8837ba-6b2f-465a-934e-c4194dd65b30'
              this.company_id = getUser().companyId
              this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&BEGIN_DATE=' + this.BEGIN_DATE + '&END_DATE=' + this.END_DATE + '&unit_id=' + this.company_id
              // 分公司
            } else if (getUser().countyId !== null) {
              reportId = 'aa8837ba-6b2f-465a-934e-c4194dd65b30'
              this.company_id = getUser().companyId
              this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&BEGIN_DATE=' + this.BEGIN_DATE + '&END_DATE=' + this.END_DATE + '&unit_id=' + this.company_id
              console.log(this.htl)
            }
          }
        }
      }
    },
    components: {
      DatePickerTemp
    },
    watch: {}
  }
</script>
