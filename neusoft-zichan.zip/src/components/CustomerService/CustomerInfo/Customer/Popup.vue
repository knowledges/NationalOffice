<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false">
    <el-form :model="dialogObj.data.form" label-width="80px" ref="query" :rules="addrules">
      <el-row>
        <el-col :gutter="18">
          <el-col :span='8'>
            <el-form-item  prop="geoType" label="市场类型" >
              <el-select v-model="dialogObj.data.form.geoType" :clearable="true"  placeholder="请选择">
                <el-option
                  v-for="item in options_geoType"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8' >
            <el-form-item prop="businessType" label="零售业态">
              <el-select v-model="dialogObj.data.form.businessType" :clearable="true" placeholder="请选择">
                <el-option
                  v-for="item in options_businessType"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8' >
            <el-form-item prop="operationScale" label="经营规模">
              <el-select v-model="dialogObj.data.form.operationScale" :clearable="true" placeholder="请选择">
                <el-option
                  v-for="item in options_operationScale"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
      <el-row>
        <el-col :gutter="18">
          <el-col :span='8'>
            <el-form-item  prop="orderMethod" label="订货类型" >
              <el-select v-model="dialogObj.data.form.orderMethod" :clearable="true" placeholder="请选择">
                <el-option
                  v-for="item in options_orderMethod"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8' >
            <el-form-item prop="customerGrade" label="客户级别">
              <el-select v-model="dialogObj.data.form.customerGrade" :clearable="true" placeholder="请选择">
                <el-option
                  v-for="item in options_customerGrade"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='8' >
            <el-form-item prop="batchNo" label="批次">
              <el-select v-model="dialogObj.data.form.batchNo" :clearable="true" placeholder="请选择">
                <el-option
                  v-for="item in options_batchNo"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
      <el-row>
        <el-col :gutter="18">
          <el-col :span='8'>
            <el-form-item  prop="status" label="状态" >
              <el-select v-model="dialogObj.data.form.status" :clearable="true" placeholder="请选择">
                <el-option
                  v-for="item in options_status"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='6'>
            <el-form-item  prop="starGrade" label="客户星级" >
              <el-select v-model="dialogObj.data.form.starGrade" :clearable="true" placeholder="请选择">
                <el-option
                  v-for="item in options_starGrade"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
      <el-row>
        <el-col :gutter="24">
          <el-col :span='24'>
            <el-form-item style="float: right">
              <el-button @click="resetForm('addForm')">取 消</el-button>
              <el-button type="success" @click="submitForm('query')">确 定</el-button>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
    </el-form>
  </el-dialog>
</template>
      <script>
        import {getCodeList, getUser} from '@/config/info'
        import api from '@/api'
        import axios from 'axios'
        import BasePath from '@/config/BasePath'
        export default {
          props: ['dialogObj'],
          mounted () {
            getCodeList('YC_GEO_TYPE', (data) => {
              this.options_geoType = data
            }) // 市场类型
            getCodeList('YC_BUSINESS_TYPE', (data) => {
              this.options_businessType = data
            }) // 零售业态
            getCodeList('YC_OPERATION_SCALE', (data) => {
              this.options_operationScale = data
            }) // 经营规模
            getCodeList('CUSTOMER_GRADE', (data) => {
              this.options_customerGrade = data
            }) // 客户级别
            getCodeList('YC_CUST_STATUS', (data) => {
              this.options_status = data
            }) // 客户状态
            let _this = this
            let params = {}
            params.companyId = getUser().companyId
            let starGradeParam = {} // 客户星级
            starGradeParam.companyId = getUser().companyId
            starGradeParam.typeCode = 'STAR_GRADE'
            axios.all([
              api.requestJava('POST', BasePath.CUSTOMER_BANTCHNO, params), // 公司批次
              api.requestJava('POST', BasePath.CUSTOMER_STARGRADE, starGradeParam) // 客户星级
            ])
              .then(axios.spread(function (_companyId, _starGrade) {
                _this.options_batchNo = _companyId.data.data
                _this.options_starGrade = _starGrade.data.data
                console.log('客户星级：' + JSON.stringify(_this.options_starGrade))
              }))
          },
          data () {
            return {
              options_geoType: [],
              options_businessType: [],
              options_operationScale: [],
              options_starGrade: [],
              options_orderMethod: [{
                value: '1',
                label: '电话呼入'
              }, {
                value: '2',
                label: '网上订货'
              }, {
                value: '3',
                label: '手机订货'
              }],
              options_customerGrade: [],
              options_batchNo: [
//                {
//                value: '1',
//                label: '11'
//              }, {
//                value: '2',
//                label: '21'
//              }, {
//                value: '3',
//                label: '51'
//              }
              ],
              options_status: [{
                value: '1',
                label: '启用'
              }, {
                value: '2',
                label: '停用'
              }, {
                value: '3',
                label: '新入网'
              }],
              addrules: {
                roleCode: [
                  {required: true, message: '请输入角色代码', trigger: 'blur'}
                ],
                roleName: [
                  {required: true, message: '请输入角色名称', trigger: 'blur'}
                ]
              },
              value: '',
              form: {}
            }
          },
          methods: {
            clearMethod () {
              this.dialogObj.data.form.roleCode = ''
              this.dialogObj.data.form.roleName = ''
              this.dialogObj.data.form.remark = ''
              this.dialogObj.data.form.attrFlag = ''
            },
            resetForm (formName) {
//              this.$refs[formName].resetFields()
              this.dialogObj.dialogVisible = false
              this.clearMethod()
            },
            submitForm (formName) {
              this.$refs[formName].validate((valid) => {
                if (valid) {
                  this.dialogObj.dialogVisible = false
                  this.$emit('confirmBack', this.dialogObj)
                } else {
                  return false
                }
              })
            }
          }
        }
      </script>

      <style scoped>
        .item__label_popup {
          text-align: right;
          vertical-align: middle;
          float: right;
          font-size: 14px;
          color: #48576a;
          line-height: 1;
          padding: 11px 8px 11px 0;
          box-sizing: border-box;
          /* display: inline-block; */
        }
        .el-input, .el-input__inner {
          /*width: '';*/
          display: inline-block;
        }
      </style>
