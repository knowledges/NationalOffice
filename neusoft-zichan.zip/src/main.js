// Import System requirements
import 'babel-polyfill'
import Vue from 'vue'
import VCharts from 'v-charts'
// import Raven from 'raven-js'
// import RavenVue from 'raven-js/plugins/vue'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-default/index.css'
import iView from 'iview'
import 'iview/dist/styles/iview.css'
import VueRouter from 'vue-router'
import { sync } from 'vuex-router-sync'
import VeeValidate, { Validator } from 'vee-validate'
import zhCN from 'vee-validate/dist/locale/zh_CN'
import store from './store'
import routes from './routes'
import { getRouterObj, getDynamicRoute } from '@/utils/RouterConvert.js'
import htmlToPdf from '@/utils/htmlToPdf'
// Import Helpers for filters
import { domain, count, prettyDate, pluralize } from './filters'

// Import Views - Top level
import AppView from './components/App.vue'

Validator.addLocale(zhCN)
// Import Install and register helper items
Vue.filter('count', count)
Vue.filter('domain', domain)
Vue.filter('prettyDate', prettyDate)
Vue.filter('pluralize', pluralize)
Vue.use(VCharts)
Vue.use(ElementUI)
Vue.use(VueRouter)
Vue.use(htmlToPdf)
// 解决 [Vue warn]: The computed property "fields" is already defined in data.
const config = {
  errorBagName: 'errors', // change if property conflicts.
  fieldsBagName: 'fileds ', // Default is fields
  delay: 0,
  locale: 'zh_CN', // vee-validate 中英文转换
  dictionary: null,
  strict: true,
  enableAutoClasses: false,
  classNames: {
    touched: 'touched', // the control has been blurred
    untouched: 'untouched', // the control hasn't been blurred
    valid: 'valid', // model is valid
    invalid: 'invalid', // model is invalid
    pristine: 'pristine', // control has not been interacted with
    dirty: 'dirty' // control has been interacted with
  },
  events: 'input|blur',
  inject: true
}

Vue.use(VeeValidate, config)

// Vue.use(Raven)
Vue.use(iView)
// global
Vue.config.productionTip = false
Vue.config.devtools = false
Vue.config.errorHandler = (err, vm, info) => {
  console.log(err)
  console.log(info)
}

Vue.directive('popupdraDirective', {
  bind: function (el, binding, vnode) {
    // el.style.backgroundColor = binding.arg
    var oDiv = el.childNodes[0]
    var eventDiv = oDiv.childNodes[0]
    // console.log(binding.value.show)
    eventDiv.addEventListener('mousedown', function (ev) {
      var disX = ev.clientX - oDiv.offsetLeft
      var disY = ev.clientY - oDiv.offsetTop
      // console.log(oDiv)
      document.onmousemove = function (ev) {
        // alert(1111)
        var l = ev.clientX - disX
        var t = ev.clientY - disY
        oDiv.style.left = l + 'px'
        oDiv.style.top = t + 'px'
      }
      document.onmouseup = function () {
        document.onmousemove = null
        document.onmouseup = null
      }
    })
  },
  componentUpdated: function (el, binding) {
    var oDiv = el.childNodes[0]
    // console.log(binding.value.show)
    if (!binding.value.show) {
      setTimeout(function () {
        oDiv.style.left = 50 + '%'
        oDiv.style.transform = 'translateX(-50%)'
        oDiv.style.top = '15%'
      }, 1000)
    }
  }
})

// Routing logic
var router = new VueRouter({
  base: '/crm/',  // 外网
  routes: routes,
  mode: 'history',
  scrollBehavior: function (to, from, savedPosition) {
    return savedPosition || { x: 0, y: 0 }
  }
})

let powerMenu = JSON.parse(sessionStorage.getItem('powerMenu'))
let localPowerMenu = JSON.parse(sessionStorage.getItem('localPowerMenu'))
let user = JSON.parse(localStorage.getItem('information'))
if (user !== null && powerMenu !== null && powerMenu !== '' && powerMenu !== undefined && localPowerMenu !== null && localPowerMenu !== '' && localPowerMenu !== undefined) {
  const route = []
  /* 自定义路由 */
  getDynamicRoute(route, localPowerMenu, Number(user.place))
  // 动态获取路由
  getRouterObj(route, powerMenu)
  let rout = [{
    path: '/',
    component: resolve => require(['./components/Dash.vue'], resolve),
    children: route
  }]
  router.addRoutes(rout.concat(
    {
      path: '*',
      component: resolve => require(['./components/404.vue'], resolve),
      name: '404'
    }
  ))
}

// Some middleware to help us ensure the user is authenticated.
router.beforeEach((to, from, next) => {
  if (to.path === '/login') {
    localStorage.removeItem('information')
    sessionStorage.removeItem('sessionMenus')
    sessionStorage.removeItem('powerMenu')
    sessionStorage.removeItem('localPowerMenu')
    next()
  } else {
    let powerMenu = JSON.parse(sessionStorage.getItem('powerMenu'))
    let localPowerMenu = JSON.parse(sessionStorage.getItem('localPowerMenu'))
    let user = JSON.parse(localStorage.getItem('information'))
    if (to.name === 'Survey' || to.name === 'Ceshi' || user !== null && powerMenu !== null && powerMenu !== '' && powerMenu !== undefined && localPowerMenu !== null && localPowerMenu !== '' && localPowerMenu !== undefined) {
      next()
    } else {
      next({ path: '/login' })
    }
  }
})

sync(store, router)

// Start out app!
// eslint-disable-next-line no-new
new Vue({
  el: '#root',
  router: router,
  store: store,
  render: h => h(AppView),
  renderError: (h, err) => {
    console.err(JSON.stringify(err))
    return h('pre', {style: {color: 'red'}}, err.stack)
  }
})

// Raven
//   .config('https://2f52daf655694fa79a6cdd98e61dd01d@sentry.io/223829')
//   .addPlugin(RavenVue, Vue)
//   .install()
