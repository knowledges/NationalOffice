<!--qiu.bl-->
<style rel="stylesheet/scss" lang="scss" scoped></style>
<template>
  <li id="fillblankQuModel">
    <!--填空题模板-->
    <div class="dwToolbar_icon"></div>
    <div class="dwQuTypeModel">
      <div class="surveyQuItemBody quDragBody">
        <div class="initLine"></div>
        <div class="quInputCase" style="display: none;">
          <input type="hidden" name="quType" value="label" >
          <input type="hidden" name="itemCode" value="">
          <input type="hidden" name="sortNbr" value="0"/>
          <input type="hidden" name="saveTag" value="0">
          <input type="hidden" name="hv" value="2">
        </div>
        <div class="surveyQuItem">
          <div class="surveyQuItemLeftTools">
            <ul class="surveyQuItemLeftToolsUl">
              <li title="移动排序" class="dwQuMove"><div class="dwQuIcon"></div></li>
              <!--<li title="设置" class="dwQuSet"><div class=dwQuIcon></div></li>-->
              <!--<li title="逻辑" class="dwQuLogic"><div class="dwQuIcon"><div class="quLogicInfo"></div></div></li>-->
              <li title="删除" class="dwQuDelete"><div class="dwQuIcon"></div></li>
            </ul>
          </div>
          <div class="surveyQuItemRightTools">
            <ul class="surveyQuItemRightToolsUl">
              <li class="questionUp"><div class="dwQuIcon"></div></li>
              <li class="questionDown"><div class="dwQuIcon"></div></li>
            </ul>
          </div>
          <div class="surveyQuItemContent">
            <div class="quCoTitle">
              <!--<div class="quCoNum">1、</div>-->
              <!--<div class="editAble quCoTitleEdit">题标题？</div>-->
              <!--<input type="hidden" name="quTitleSaveTag" value="0">-->
              <div class="quCoNum">1、</div>
              <div>
                <el-select v-model="value" :clearable="true" placeholder="请选择" style="width:100px;">
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"></el-option>
                </el-select>
                <el-input class="quFillblankAnswerInput" style="width:200px;" placeholder="请输入内容"></el-input>
              </div>
            </div>
            <!--<div class="quCoItem">-->
              <!--<ul>-->
                <!--<li class="quCoItemUlLi">-->
                  <!--<div class="quFillblankItem">-->
                    <!--<el-input class="quFillblankAnswerInput"  style="width:200px;padding:5px;" placeholder="请输入内容"></el-input>-->
                  <!--</div>-->
                <!--</li>-->
              <!--</ul>-->
            <!--</div>-->
          </div>
        </div>
      </div>
    </div>
  </li>
</template>

<script>
  export default {
    name: 'info',
    props: {},
    mounted () {
    },
    data () {
      return {
        options: [{
          value: '选项1',
          label: '黄金糕'
        }, {
          value: '选项2',
          label: '双皮奶'
        }, {
          value: '选项3',
          label: '蚵仔煎'
        }, {
          value: '选项4',
          label: '龙须面'
        }, {
          value: '选项5',
          label: '北京烤鸭'
        }],
        value: ''
      }
    },
    methods: {},
    components: {},
    watch: {}
  }
</script>
