<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog title="当日订单" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false"  :size='dialogObj.size' :before-close="cancleClk" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <div class="container-fluid_new">
      <el-row class="filter_style">
        <el-col :gutter="24">
          <el-col :span='12'>
            <label class="el-form-item__label" style="width: 120px;">订单日期</label>
            <el-date-picker
              v-model="orderDate1"
              type="date"
              format="yyyy-MM-dd"
              :editable=false
              :clearable=false
              @change="orderFind"
              placeholder="选择查询日期">
            </el-date-picker>
          </el-col>
        </el-col>
      </el-row>
      <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-table :data="this.dialogObj.data.form.products"  >
        <el-table-column prop="custName" label="客户名称" ></el-table-column>
        <el-table-column prop="coNum" label="订单号" ></el-table-column>
        <el-table-column prop="qtySum" label="订单量（条）" ></el-table-column>
        <el-table-column prop="amtSum" label="订单金额（元）" ></el-table-column>
        <el-table-column prop="status" label="订单状态" ></el-table-column>
        <el-table-column label="操作" >
          <template scope="scope">
            <el-button @click="handleClick(scope.row)" type="text" size="small">查看</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-form>
  </div>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
    </div>
  </el-dialog>
    <MY_POPUP_SALES :dialogObj='sales' @confirmBack="salesEve"/>
  </div>
</template>

<script>
  import MY_POPUP_SALES from './salesPopup.vue'
  import api from '@/api'
  import log from '@/log'
  import BasePath from '@/config/BasePath'
  import { dateFormat } from '@/utils/dateFormat.js'
  import {getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      this.orderDate1 = new Date()
      this.orderFind()
    },
    data () {
      return {
        orderDate1: '',
        addrules: {},
        sales: {
          title: '订单商品明细',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              custId: '',
              custName: '',
              itemId: '',
              itemName: '',
              qtyNeed: '',
              qtyOrd: '',
              price: '',
              amt: ''
            }
          }
        }
      }
    },
    methods: {
      orderFind () { // 消费者调查  新品测试调查（消费者）
        let param = {}
//        var myDate = new Date()
        param.employeecode = getUser().userCode
        param.bornDate = this.getTime(Date.parse(this.orderDate1))
        console.log('orderFind', param)
        api.requestJava('POST', BasePath.CLIENTMANAGER_ORDERCUSTS, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.dialogObj.data.form.products = request.data.data
//              this.order.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 当日订单量请求
      findByIdUpper (row) {
        let param = {}
        param.coNum = row.coNum
        console.log('param', param)
        api.requestJava('POST', BasePath.CLIENTMANAGER_ORDERMX, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              Object.assign(this.sales.data.form, row)
              this.sales.data.form.products = request.data.data
              this.sales.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      },
      handleClick (row) {
        this.findByIdUpper(row)
      },
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },
      salesEve (msg) {
        this.sales.dialogVisible = false
        let tmp = {
          title: '订单商品明细',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              custId: '',
              custName: '',
              itemId: '',
              itemName: '',
              qtyNeed: '',
              qtyOrd: '',
              price: '',
              amt: ''
            }
          }
        }
        Object.assign(this.sales, tmp)
      } // 修改事件
    },
    components: {
      MY_POPUP_SALES
    }
  }
</script>
<style scoped>
  .container-fluid_new {
    background: #FFF;
    margin: 0 5px 5px 5px;
  }
</style>
