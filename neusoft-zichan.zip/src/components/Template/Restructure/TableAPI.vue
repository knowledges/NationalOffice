<!--qiu.bl-->
<style rel="stylesheet/scss" lang="scss" scoped></style>
<template>
    <div class="container-fluid" style="margin-top: 30px!important">
      <tabModule
      :coloumHeader="coloumHeader"
      :coloumDate="array"
      ></tabModule>
    </div>
</template>
<script>
  import tabModule from './Table.vue'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  export default {
    name: '',
    props: {},
    mounted () {
      this.init()
    },
    data () {
      return {
        coloumHeader: [
          {
            prop: 'customerName',
            label: '客户名称',
            coloumProp: {}
          },
          {
            prop: 'addr',
            label: '经营地址',
            coloumProp: {}
          },
          {
            prop: 'permitNo',
            label: '许可证号',
            coloumProp: {}
          },
          {
            prop: 'legalPerson',
            label: '法人',
            coloumProp: {}
          },
          {
            prop: 'customerGrade',
            label: '档级',
            coloumProp: {}
          },
          {
            prop: 'expectedTime',
            label: '拜访时间',
            coloumProp: {}
          },
          {
            prop: 'visitMode',
            label: '拜访方式',
            coloumProp: {}
          },
          {
            prop: 'detailList',
            label: '服务内容',
            coloumProp: { type: 'array' }
          },
          {
            prop: 'files',
            label: '照片展示',
            coloumProp: { type: 'img' }
          }
        ],
        array: []
      }
    },
    methods: {
      init () {
        var params = {}
        params.visitor = '72782'
        params.companyId = '3820008'
        params.beginDate = '2018-06-21'
        params.endDate = '2018-06-21'
        api.requestJava('POST', BasePath.COMMON_SELSECTVISIT, params)
          .then((reponse) => {
            if (Number(reponse.data.code) === 200) {
              this.array = reponse.data.data
            }
          })
      }
    },
    components: { tabModule },
    watch: {}
  }
</script>
