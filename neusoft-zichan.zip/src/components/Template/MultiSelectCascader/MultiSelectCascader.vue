/**
*                    _ooOoo_
*                   o8888888o
*                   88" . "88
*                   (| -_- |)
*                    O\ = /O
*                ____/`---'\____
*              .   ' \\| |// `.
*               / \\||| : |||// \
*             / _||||| -:- |||||- \
*               | | \\\ - /// | |
*             | \_| ''\---/'' | |
*              \ .-\__ `-` ___/-. /
*           ___`. .' /--.--\ `. . __
*        ."" '< `.___\_<|>_/___.' >'"".
*       | | : `- \`.;`\ _ /`;.`/ - ` : | |
*         \ \ `-. \_ __\ /__ _/ .-` / /
* ======`-.____`-.___\_____/___.-`____.-'======
*                    `=---='
*
* .............................................
*          佛祖保佑             永无BUG
*  佛曰:
*          写字楼里写字间，写字间里程序员；
*          程序人员写程序，又拿程序换酒钱。
*          酒醒只在网上坐，酒醉还来网下眠；
*          酒醉酒醒日复日，网上网下年复年。
*          但愿老死电脑间，不愿鞠躬老板前；
*          奔驰宝马贵者趣，公交自行程序员。
*          别人笑我忒疯癫，我笑自己命太贱；
*          不见满街漂亮妹，哪个归得程序员？
*/
<!--qiu.bl-->
<style rel="stylesheet/scss" lang="scss" scoped>
  .mult {
    position: relative;
    z-index: 110;
    &:hover{
       .mult-tree {
         display: block;
       }
    }
  }
  .mult-view {
    display: flex;
    width: 100%;
    height: 40px;
    border: 1px solid #ccc;
    background: #FFF;
    border-radius: 5px;
    padding: 5px 10px;
    &:hover{
       border: 1px solid #999;
      .mult-view-clear {
        display: inline-block;
      }
     }
  }
  .mult-view-clear {
    display: none;
    width: 20px;
    height: 100%;
    text-align: center;
    line-height: 27px;
    color: #999;
    cursor: pointer;
  }
  .mult-view-ul {
    flex: 1;
    li {
      float: left;
      margin-right: 5px;
      padding: 7px 10px;
      display: inline-block;
      background: #20a0ff;
      color: #FFF;
      text-align: center;
      cursor: pointer;
      border-radius: 2px;
    }
  }
  .mult-tree {
    display: none;
    padding-top: 5px;
    padding-left: 10px;
    height: 320px;
    border: 1px solid #8c8c8c;
    overflow-y: scroll;
    background: #FFF;
    min-width: 270px;
  }
</style>
<template>
  <div class="mult">
    <div class="mult-view">
      <ul class="mult-view-ul">
        <p style="line-height: 26px;color: #97a8be;">请选择范围（支持多选）</p>
        <!--<li>-->
        <!--zhang.wy-->
        <!--<i class="fa fa-close"></i>-->
        <!--</li>-->
      </ul>
      <div class="mult-view-clear">
        <i class="fa fa-close"></i>
      </div>
    </div>
    <div class="mult-tree">
      <MultiTree v-for="(item, key) in options" :key="key" :model="item" :getTransmit="getTransmit" :selectCondition="selectCondition"></MultiTree>
    </div>
  </div>
</template>
<script>
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  import MultiTree from '@/components/Template/MultiSelectCascader/MultiTree'
  export default {
    name: 'MultiSelectCascader',
    props: {
      selectCondition: Object,
      selectOption: Array,
      getTransmit: Function
    },
    mounted () {
      this.init()
    },
    data () {
      return {
        first: false,
        options: [],
        tempOpt: []
      }
    },
    methods: {
      init () {
        let params = {}
        api.requestJava('POST', BasePath.EMPLOYEE_COMPANY_TREE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              var array = request.data.data.children
              /*
               * 1. 等级（getUser().unitLevel） == 1 展示所有
               * 2. 等级 == 2 && countyId == '' || null  展示该市下的所有分公司
               * 3. 等级 == 2 && countyId != '' && deptId == '' || null && place == 9999 展示该市下的具体分公司的所有市场经理
               * 4. 等级 == 2 && countyId != '' && deptId != '' && place == 24 展示该市场经理下的所有客户经理
               * 5. place == 135 展示自己
               * */
              if (Number(getUser().unitLevel) === 1) { // 展示所有
                this.options = array
              } else if (Number(getUser().unitLevel) === 2) { // 展示该市下的所有分公司
                if (getUser().countyId === 'null') {
                  this.recursionMth(array, getUser().companyId)
                } else if (getUser().countyId !== 'null' && Number(getUser().place) === 9999) {
                  this.recursionMth(array, getUser().countyId)
                } else if (getUser().countyId !== 'null' && getUser().deptId !== 'null' && Number(getUser().place) === 24) {
                  this.recursionMth(array, getUser().personId)
                } else if (Number(getUser().place) === 135) {
                  this.recursionMth(array, getUser().personId)
                }
              }
              Object.assign(this.tempOpt, this.options)
//              console.log('this.tempOpt:', this.tempOpt)
              if (this.selectOption && this.selectOption.length > 0) {
                this.recursionAss(this.options)
              }
            }
          })
      },
      recursionMth (data, condition) {
        data.forEach((val, key) => {
          if (val.children && val.children.length > 0) {
            this.recursionMth(val.children, condition)
          }
          /* 字符串比较 */
          if (val.id === condition) {
            if (val.children) {
              this.options = val.children
            } else {
              var tmp = []
              tmp.push(val)
              this.options = tmp
            }
          }
        })
      },
      recursionAss (data) {
        data.forEach((val, key) => {
          if (val.children && val.children.length > 0) {
            this.recursionAss(val.children)
          }
          for (var i = 0; i < this.selectOption.length; i++) {
            if (this.selectOption[i].indexOf(val.id) >= 0) {
              console.log('我选中的id')
              this.$set(val, 'select', true)
            }
          }
        })
      },
      resetAssignment (num) { // 重置参数
        this.init()
      }
    },
    components: {MultiTree},
    watch: { }
  }
</script>
