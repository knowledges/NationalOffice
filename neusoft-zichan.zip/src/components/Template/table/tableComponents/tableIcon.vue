<template>
  <div  @click="col.eventClick(row, col.prop)">
    <i v-if="col.options" :class="col.options[row[col.prop]]"></i>
    <i v-else :class="row[col.prop]"></i>
  </div>
</template>

<script>
export default {
  data () {
    return {
      icon: ''
    }
  },
  props: {
    row: Object,
    col: Object,
    data: Array
    // KeyDownEvent: {
    //   type: Function,
    //   default: function (ev) {
    //   }
    // }
  },
  mounted () {
    if (this.col.options) {
      this.icon = this.col.options[this.row[this.col.prop]]
    } else {
      this.icon = this.row[this.col.prop]
    }
  },
  computed: {
    eventClick () {
      return this.col.cptProperties.eventClick ? this.col.cptProperties.eventClick : function () {}
    }
  }
}
</script>