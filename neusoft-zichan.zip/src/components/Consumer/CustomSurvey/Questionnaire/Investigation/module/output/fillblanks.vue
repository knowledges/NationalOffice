<template>
  <li class="li_surveyQuItemBody">
    <div class="surveyQuItemBody">
      <div class="initLine"></div>
      <div class="quInputCase" style="display: none;">
        <input type="hidden" name="rowId" :value="SubFillBlanks.rowId"/>
        <input type="hidden" name="quType" value="MULTIFILLBLANK" />
        <input type="hidden" name="quId" :value="SubFillBlanks.itemCode">
        <!--<input type="hidden" name="orderById" :value="SubFillBlanks.rowId + 1">-->
        <input type="hidden" name="saveTag" value="1" />
        <input type="hidden" name="hoverTag" value="0" />
        <input type="hidden" name="isRequired" :value="SubFillBlanks.mustFlag">
        <input type="hidden" name="hv" value="2" />
        <!--<input type="hidden" name="randOrder" value="0" />-->
        <!--<input type="hidden" name="cellCount" value="0" />-->
        <!--<input type="hidden" name="paramInt01" value="1" />-->
        <!--<input type="hidden" name="paramInt02" value="5" />-->
        <!--<div class="quLogicInputCase">-->
          <!--<input type="hidden" name="quLogicItemNum" value="0" />-->
        <!--</div>-->
      </div>
      <div class="surveyQuItem">
        <div class="surveyQuItemLeftTools"  v-if="SubFillBlanks.itemCode == SubFillBlanks.rowId">
          <ul class="surveyQuItemLeftToolsUl">
            <li title="移动排序" class="dwQuMove ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div></li>
            <li title="设置" class="dwQuSet ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div></li>
            <!--<li title="逻辑" class="dwQuLogic ui-draggable ui-draggable-handle">-->
              <!--<div class="dwQuIcon">-->
                <!--<div class="quLogicInfo"></div>-->
              <!--</div></li>-->
            <li title="删除" class="dwQuDelete ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div></li>
          </ul>
        </div>
        <div class="surveyQuItemRightTools">
          <ul class="surveyQuItemRightToolsUl">
            <li class="questionUp ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div></li>
            <li class="questionDown ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div></li>
          </ul>
        </div>
        <div class="surveyQuItemContent">
          <div class="quCoTitle">
            <div class="quCoNum">
              {{SubFillBlanks.rowId + 1}}、
            </div>
            <div class="editAble quCoTitleEdit">
              {{SubFillBlanks.title}}
            </div>
            <input type="hidden" name="quTitleSaveTag" value="1" />
          </div>
          <div class="quCoItem">
            <table class="mFillblankTable">
              <tbody>
              <template v-for="item in SubFillBlanks.quItems">
                <tr class="mFillblankTableTr">
                  <td align="right" class="mFillblankTableEditTd quOption_0">
                    <label class="editAble quCoOptionEdit">{{item.listTitle}}</label>
                    <div class="quItemInputCase">
                      <input type="hidden" name="quItemId" value="" />
                      <input type="hidden" name="quItemSaveTag" value="0" />
                    </div></td>
                  <td><input type="text" style="width: 200px; padding: 5px;" /></td>
                </tr>
              </template>
              </tbody>
            </table>
          </div>
          <div class="quCoBottomTools">
            <ul class="quCoBottomToolsUl">
              <li title="添加" class="addOption ui-draggable ui-draggable-handle">
                <div class="dwQuIcon"></div></li>
              <!--<li title="批量添加" class="addMoreOption ui-draggable ui-draggable-handle">-->
                <!--<div class="dwQuIcon"></div></li>-->
            </ul>
          </div>
        </div>
      </div>
    </div>
  </li>
</template>
<script>
  export default {
    props: ['SubFillBlanks']
  }
</script>
