<style scoped>
  .cust_el_col{
    display: inline-block;
    height:calc(100vh - 185px);
  }
  .cust_row_r{
    display: flex;
    flex: 1;
  }
  .cust_btn_box {
    position: absolute;
    top: 40px;
    width: 340px;
    height: calc(100vh - 120px);
    right:0px;
    box-shadow: -2px 3px 6px #666;
    padding: 0!important;
  }
  .cust_btn_r{
    background: #00b234;
    -webkit-box-shadow: 2px 2px 5px #008627;
    box-shadow: 2px 2px 5px #008627;
    position: absolute;
    top: 50%;
    right: 5%;
    margin-top: -18px;
  }
  .cust_btn_r i {
    font-size: 18px;
    color: #FFF;
  }
  .grid-content {
    background: #e6e6e6!important;
    height: 100%;
  }
  .moveR-enter-active {
    animation: moveR-in .5s;
  }
  .moveR-leave-active {
    animation: moveR-in .5s reverse;
  }
  @keyframes moveR-in {
    0% {
      transform: translate(340px, 0px);
    }
    80% {
      transform: translate(-20px, 0px);
    }
    100% {
      transform: translate(0px, 0px);
    }
  }
</style>
<template>
  <div style="height: 100%;">
    <el-row :gutter="22" class="cust_el_row" style="margin: 0 0; height: 100%;">
      <el-col :span="22" class="cust_el_min" id="el-col-map" style="padding: 0 0; height: 100%;">
          <_Map :coors="coors" :zoom="zoom" :place="place" :coorGroup="coorGroup" ref="childs" @mapBack="mapBack" @backCalcDis="backCalcDis"></_Map>
      </el-col>
      <el-row :gutter="24" class="cust_row_r">
        <transition name="moveR">
          <el-col :span="20" class="cust_btn_box" v-show="isTree">
            <div class="grid-content">
              <_VisitingLog @confirmBack="localBack" ref="visitingLog"></_VisitingLog>
            </div>
          </el-col>
        </transition>
        <el-col :span="4"  class="cust_el_col">
          <button class="btn cust_btn_r" @click="showTreeClk">
            <i class="fa fa-angle-double-left" v-if="!isTree"></i>
            <i class="fa fa-angle-double-right" v-if="isTree"></i>
          </button>
        </el-col>
      </el-row>
    </el-row>
  </div>
</template>
<script>
import _VisitingLog from './MgrVisitingLog.vue'
import _Map from '@/components/Template/Map/Map.vue'
import BasePath from '@/config/BasePath'
import api from '@/api'
export default {
  name: 'Home',
  mounted () {
    document.getElementById('el-col-map').style.height = document.documentElement.clientHeight - 80 + 'px'
    this.init()
  },
  data: () => ({
    showVisitingLog: true,
    zoom: 18, // 根据百度地图变焦值（3-18）默认 12
    coors: [],
    coorGroup: [],
    place: 135,
    isTree: true,
    calcDis: []
  }),
  methods: {
    showTreeClk () {
      this.isTree = !this.isTree
    },
    init () {
      let custmgrParam = {}
      custmgrParam.custmgrId = this.$route.params.uId
      custmgrParam.queryDate = this.$route.params.visitDate
      api.requestJava('POST', BasePath.CUSTMGR_STATUS, custmgrParam, {})
        .then((request) => {
          if (Number(request.data.code) === 200) {
            let reqArray = request.data.data
            if (reqArray.length > 0) {
              reqArray.forEach((data, key) => {
                if (Number(data.status) === 1 || Number(data.status) === 2 || Number(data.status) === 3) {
                  let mgrcoor = {}
                  this.$set(mgrcoor, 'lng', data.positionX)
                  this.$set(mgrcoor, 'lat', data.positionY)
                  this.coors.push(mgrcoor) // 客户经理坐标线路
                  let custcoor = {}
                  if (data.x !== '' && data.y !== '') {
                    this.$set(custcoor, 'lng', data.x)
                    this.$set(custcoor, 'lat', data.y)
                    this.$set(custcoor, 'customerId', data.customerId)
                    this.$set(custcoor, 'customerName', data.customerName)
                    this.coorGroup.push(custcoor) // 客户坐标
                  }
                }
              })
            } else {
              let mgrcoor = {}
              this.$set(mgrcoor, 'lng', '')
              this.$set(mgrcoor, 'lat', '')
              this.coors.push(mgrcoor)
            }
          } else if (Number(request.data.code) === 401) {
            this.sessionFailedDialogObj.dialogVisible = true
          } else {
            throw new Error(JSON.stringify(request))
          }
        }).catch((err) => {
          this.$message({ type: 'info', message: '操作异常!' })
          this.$refs.childs.init()
          console.error(err)
        }
      )
    },
    localBack (info) {
      if (info.type === 'refreshMap') {
        let custmgrParam = {}
        custmgrParam.custmgrId = info.custmgrId
        custmgrParam.queryDate = info.queryDate
        api.requestJava('POST', BasePath.CUSTMGR_STATUS, custmgrParam, {})
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.clearData()
              if (request.data.data.length > 0) {
                request.data.data.forEach((data, key) => {
                  let mgrcoor = {}
                  if ((data.positionX !== '' && data.positionY !== '') || (data.positionX !== '0' && data.positionY !== '0')) {
                    this.$set(mgrcoor, 'lng', data.positionX)
                    this.$set(mgrcoor, 'lat', data.positionY)
                  }
                  if (data.status === '1' || data.status === '2' || data.status === '3') {
                    this.coors.push(mgrcoor) // 客户经理坐标线路
                  }
                  let custcoor = {}
                  if (data.x !== '' && data.y !== '') {
                    this.$set(custcoor, 'lng', data.x)
                    this.$set(custcoor, 'lat', data.y)
                    this.$set(custcoor, 'customerId', data.customerId)
                    this.$set(custcoor, 'customerName', data.customerName)
                  }
                  if (data.status === '1' || data.status === '2' || data.status === '3') {
                    this.coorGroup.push(custcoor) // 客户坐标
                  }
                })
              } else {
                let mgrcoor = {}
                this.$set(mgrcoor, 'lng', '')
                this.$set(mgrcoor, 'lat', '')
                this.coors.push(mgrcoor)
              }
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          }).catch((err) => {
            this.$message({ type: 'info', message: '操作异常!' })
            console.error(err)
          }
        )
      } else if (info.type === 'zoom') {
        this.$refs.childs.zoomIn(info.X, info.Y, info.customerId, info.customerName)
      } else if (info.type === 'calcDis') {
        this.$refs.childs.calculateMileage(info.positionAX, info.positionAY, info.positionBX, info.positionBY)
      }
    },
    mapBack (info) {
      this.$refs.visitingLog.detailRow(info)
    },
    backCalcDis (info) {
      this.$refs.visitingLog.calcDis(info)
    },
    clearData () {
      this.coors = []
      this.coorGroup = []
    }
  },
  components: {
    _VisitingLog, _Map
  }
}
</script>
