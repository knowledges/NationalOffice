<template>
  <li data-v-73ab92a0="" class="li_surveyQuItemBody">
    <div class="surveyQuItemBody">
      <div class="initLine"></div>
      <div class="quInputCase" style="display: none;">
        <input type="hidden" name="rowId" :value="SUBPARAGRAPH.rowId"/>
        <input type="hidden" name="quType" value="PARAGRAPH" />
        <input type="hidden" name="itemCode" :value="SUBPARAGRAPH.itemCode" />
        <input type="hidden" name="sortNbr" :value="SUBPARAGRAPH.sortNbr" />
        <input type="hidden" name="saveTag" value="1" />
        <!--<input type="hidden" name="hoverTag" value="0" />-->
        <input type="hidden" name="isRequired" :value="SUBPARAGRAPH.mustFlag" />
        <input type="hidden" name="hv" value="2" />
        <!--<input type="hidden" name="randOrder" value="0" />-->
        <!--<input type="hidden" name="cellCount" value="0" />-->
        <!--<div class="quLogicInputCase">-->
          <!--<input type="hidden" name="quLogicItemNum" value="0" />-->
        <!--</div>-->
      </div>
      <div class="surveyQuItem">
        <div class="surveyQuItemLeftTools" v-if="SUBPARAGRAPH.itemCode == SUBPARAGRAPH.rowId">
          <ul class="surveyQuItemLeftToolsUl">
            <li title="删除" class="dwQuDelete ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div></li>
          </ul>
        </div>
        <div class="surveyQuItemRightTools">
          <ul class="surveyQuItemRightToolsUl">
            <li class="questionUp ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div></li>
            <li class="questionDown ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div></li>
          </ul>
        </div>
        <div class="surveyQuItemContent" style="min-height: 45px;">
          <div class="quCoTitle">
            <div class="quCoNum" style="display: none;"> {{SUBPARAGRAPH.sortNbr}}、 </div>
            <div class="editAble quCoTitleEdit">
              <div v-html="SUBPARAGRAPH.title"></div>
            </div>
            <input type="hidden" name="quTitleSaveTag" value="1" />
          </div>
        </div>
      </div>
    </div>
  </li>
</template>
<script>
  export default {
    props: ['SUBPARAGRAPH']
  }
</script>
