<!-- 徐晓菁 -->
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :size='dialogObj.size'  :close-on-press-escape="false" :before-close="cancleClk" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-col :gutter="24">
        <el-col :span='8'>
          <el-form-item label="驻店人员姓名" >
            <el-input v-model="dialogObj.data.form.visitorNm"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='8'>
          <el-form-item label="驻店人员职位">
            <el-input v-model="dialogObj.data.form.visitorPlace"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='8'>
          <el-form-item label="驻店时间" >
            <el-input v-model="dialogObj.data.form.instoreDate"></el-input>
          </el-form-item>
        </el-col>
      </el-col>
      <el-col :gutter="24">
        <el-col :span='8'>
          <el-form-item label="客户代码">
            <el-input v-model="dialogObj.data.form.customerCode"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='8'>
          <el-form-item label="客户名称" >
            <el-input v-model="dialogObj.data.form.customerDesc"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='8'>
          <el-form-item label="档级">
            <el-input v-model="dialogObj.data.form.customerGrade"></el-input>
          </el-form-item>
        </el-col>
      </el-col>
      <el-col :gutter="24">
        <el-col :span='8'>
          <el-form-item label="业态" >
            <el-input v-model="dialogObj.data.form.businessType"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='8'>
          <el-form-item label="商圈">
            <el-input v-model="dialogObj.data.form.tradeCircleType"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='8'>
          <el-form-item label="客户电话" >
            <el-input v-model="dialogObj.data.form.tel"></el-input>
          </el-form-item>
        </el-col>
      </el-col>
      <el-col :gutter="24">
        <el-col :span='8'>
          <el-form-item label="客户地址">
            <el-input v-model="dialogObj.data.form.addr"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='8'>
          <el-form-item label="当日店铺总营业额" >
            <el-input v-model="dialogObj.data.form.val01"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='8'>
          <el-form-item label="当日条/包销售比例（%）">
            <el-input v-model="dialogObj.data.form.val02"></el-input>
          </el-form-item>
        </el-col>
      </el-col>
      <el-col :gutter="24">
        <el-col :span='8'>
          <el-form-item label="当日卷烟销售量" >
            <el-input v-model="dialogObj.data.form.val07"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='8'>
          <el-form-item label="当日卷烟销售金额">
            <el-input v-model="dialogObj.data.form.val04"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='8'>
          <el-form-item label="当日卷烟销售规格数" >
            <el-input v-model="dialogObj.data.form.val05"></el-input>
          </el-form-item>
        </el-col>
      </el-col>
      <el-col :gutter="24">
        <el-col :span='8'>
          <el-form-item label="当日断货规格数">
            <el-input v-model="dialogObj.data.form.val08"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='8'>
          <el-form-item label="条价格到位率" >
            <el-input v-model="dialogObj.data.form.val03"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='8'>
          <el-form-item label="包价格到位率">
            <el-input v-model="dialogObj.data.form.val06"></el-input>
          </el-form-item>
        </el-col>
      </el-col>
      <el-col :gutter="24">
        <el-col :span='8'>
          <el-form-item label="购买率最高的卷烟价位段" >
            <el-input v-model="dialogObj.data.form.val09"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='16'>
          <el-form-item label="驻店营销活动小结">
            <el-input  type="textarea" resize="none" v-model="dialogObj.data.form.summaries"></el-input>
          </el-form-item>
        </el-col>
      </el-col>
      <el-col :gutter="24">
        <el-col :span='8'>
          <el-form-item label="零售户评价" >
            <el-input v-model="dialogObj.data.form.cEval"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='16'>
          <el-form-item label="零售户意见建议">
            <el-input type="textarea" resize="none" v-model="dialogObj.data.form.cOpinions"></el-input>
          </el-form-item>
        </el-col>
      </el-col>
      <el-col :gutter="24">
        <el-col :span='12'>
          <el-form-item label="客户门头">
            <uploadTemp style="margin:7px;" :files="dialogObj.data.form.files1" ref="uploadPic" :operation="false" ></uploadTemp>
          </el-form-item>
        </el-col>
        <el-col :span='12'>
          <el-form-item label="驻店现场">
            <uploadTemp style="margin:7px;" :files="dialogObj.data.form.files2" ref="uploadPic" :operation="false" ></uploadTemp>
          </el-form-item>
        </el-col>
      </el-col>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
    </div>
  </el-dialog>

</template>

<script>
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
  export default {
    props: ['dialogObj'],
    mounted () {
    },
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        this.query(1, this.pageSize)
      }
    },
    data () {
      return {
        isLoading: true,
        addrules: {}
      }
    },
    methods: {
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      }
    },
    components: {
      uploadTemp
    }
  }
</script>
<style scoped>
  .el-col-8 {
    width: 33.33333%;
    height: 45px;
  }
  .el-col-16 {
    width: 66.66667%;
    height: 58px;
  }
</style>
