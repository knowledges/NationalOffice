<style scoped>
  .treepop .el-transfer-panel{
    width: 45%!important; overflow: hidden;
  }
  .transfer-footer {
    margin-left: 20px;
    padding: 6px 5px;
  }
</style>
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="closeModalEve" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <el-transfer
      v-model="targetValue"
      filterable
      :titles="[dialogObj.Source, dialogObj.Target]"
      :format="{
        noChecked: '${total}',
        hasChecked: '${checked}/${total}'
      }"
      class="treepop scoped"
      @change="handleChange"
      :data="allData">
      <!--<el-button class="transfer-footer" slot="right-footer" size="small" @click="save">保存</el-button>-->
    </el-transfer>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="resetForm('query')">取 消</el-button>
      <el-button type="primary" @click="save">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import api from '@/api'
  import log from '@/log'
  import BasePath from '@/config/BasePath'
  import { getUser } from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      this.source_goal()
    },
    data () {
      return {
        sourceData: [], // sourceData(),
        targetValue: [], // goalData()
        allData: [],
        tempTargetValue: []
      }
    },
    methods: {
      handleChange (targetValue, direction, movedKeys) {
        console.log(targetValue)
      },
      closeModalEve () {
        this.sourceData = []
        this.targetValue = []
        this.allData = []
        this.dialogObj.dialogVisible = false
      },
      source_goal () {
        this.sourceData = []
        this.targetValue = []
        this.allData = []
        let sourceParam = {}
        sourceParam.flag = false
        sourceParam.roleId = this.dialogObj.data.form.rowId
        sourceParam.companyId = getUser().companyId
//        console.log('1sourceParam' + JSON.stringify(sourceParam))
        api.requestJava('POST', BasePath.ROLE_USER_JURISDICTION, sourceParam)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              for (let i = 0; i <= request.data.data.length; i++) {
//                console.log('1返回' + JSON.stringify(request.data.data))
                this.sourceData.push({
                  key: request.data.data[i].userId + '',
                  label: request.data.data[i].division + '-' + request.data.data[i].userName
                })
                this.allData.push({
                  key: request.data.data[i].userId + '',
                  label: request.data.data[i].division + '-' + request.data.data[i].userName
                })
              }
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
        let goalParam = {}
        goalParam.flag = true
        goalParam.roleId = this.dialogObj.data.form.rowId
        goalParam.companyId = getUser().companyId
//        console.log('2goalParam' + JSON.stringify(goalParam))
        api.requestJava('POST', BasePath.ROLE_USER_JURISDICTION, goalParam)
          .then(request => {
            if (Number(request.data.code) === 200) {
//              console.log('2返回' + JSON.stringify(request.data.data))
              this.tableData = request.data.data
              this.tempTargetValue = request.data.data
              for (let i = 0; i <= request.data.data.length; i++) {
                this.targetValue.push(
                   request.data.data[i].userId + ''
                )
                this.allData.push({
                  key: request.data.data[i].userId + '',
                  label: request.data.data[i].division + '-' + request.data.data[i].userName
                })
              }
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      save () {
        let temp = '' + this.targetValue
        let params = {}
        let deletes = []
        let inserts = []
        this.targetValue.forEach((val, key) => {
          let param = {}
          param.roleId = this.dialogObj.data.form.rowId
          param.userId = temp.split(',')[key]
          param.authorizer = getUser().personId
          param.admin = 'N'
          inserts.push(param)
        })
        this.tempTargetValue.forEach((val, key) => {
          let param = {}
          param.roleId = this.dialogObj.data.form.rowId
          param.userId = val.userId
          deletes.push(param)
        })
        params.insert = inserts
        params.delete = deletes
        this.$emit('confirmBack', params)
      },
      resetForm (formName) {
        this.dialogObj.dialogVisible = false
      }
    }
  }
</script>
