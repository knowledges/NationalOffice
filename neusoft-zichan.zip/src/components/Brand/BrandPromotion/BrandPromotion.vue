<!--author qiu.bl-->
<style scoped>
  .row {
    padding: 5px 0;
  }
  .block{
    text-align: center;
    font-size: 16px;
  }
</style>
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='12'>
          <div class="block">
            <span class="demonstration">拟引入日期</span>
            <span label="活动周期">
        <el-date-picker
          v-model="beginDate"
          type="date"
          format="yyyy-MM-dd"
          :editable=false
          :clearable=false
          placeholder="选择开始时间">
        </el-date-picker>
        <span>至</span>
        <el-date-picker
          v-model="endDate"
          type="date"
          format="yyyy-MM-dd"
          :editable=false
          :clearable=false
          placeholder="选择结束时间">
        </el-date-picker>
      </span>
          </div>
        </el-col>
        <el-col :span="12">
          <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" :tableData="tableData" @on-click="exportEve" :isMore="isMore"></_BTN_FILTER>
        </el-col>
      </el-col>
    </el-row>
    <div>
      <_TABLE :columns="columnHeader" :tableData="dataSource" :tableHeight="400"
              :btnMode=true :btns="btns"
              :pageSizes="pageSizes" :currentPage=currentPage :pageSize=pageSize
              :totalCount=totalCount :queryData=this.queryData
              @update:data="tabChange" :reqParams="reqParams"
              :checkBox=true
              :hasPagination="true"
              ref="tableGrid" :tableType=tableType ></_TABLE>
    </div>
    <_POPUP :dialogObj='edit' @confirmBack="confirmBack_base" />
  </div>
</template>
<script>
  import { dateFormat } from '@/utils/common'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import _TABLE from '@/components/Template/TabPagin/Table.vue'
  import _POPUP from './Popup.vue'
  import api from '@/api'
  import log from '@/log'
  import {getUser, getCodeList} from '@/config/info'
  import BasePath from '@/config/BasePath'
  export default {
    mounted () {
      // this.getDesc()
      let params = {}
      params.unitId = getUser().companyId
      params.impDateL = this.getTime(Date.parse(this.beginDate))
      params.impDateR = this.getTime(Date.parse(this.endDate))
      this.init(params)
      getCodeList('YC_OPERATION_SCALE', (data) => {
        this.operationScaleGroup = data
      }) // 经营规模
      getCodeList('VISITING_STATUS', (data) => {
        this.visitStatusGroup = data
      }) // 拜访情况
    },
    data () {
      return {
        fileName: ['goodsDesc', 'impDate'],
        filemode: 0,
        fileType: 1,
        isSelect: false,
        desc: '',
        isMore: true,
        btnGroups: [
          {
            name: '新增',
            className: 'btn-info',
            iconName: 'fa-add',
            event: this.add
          },
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        pickerOptions: {
          shortcuts: [{
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }]
        },
        beginDate: new Date(),
        endDate: new Date(),
        datetime: [new Date().setDate(1), new Date()],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            value: 'goodsDesc', // 列的值
            label: '规格', // 列的显示字段
            align: 'left' // 列的对齐方式，[left, center, right]，选填，默认是left
          }, {
            value: 'impDate',
            align: 'left',
            label: '拟引入日期'
          }, {
            value: 'goodsPrice',
            label: '零售指导价格',
            align: 'left'
          }, {
            value: 'taste',
            label: '口味特点',
            align: 'left'
          }, {
            value: 'marketPosition',
            label: '市场定位',
            align: 'left'
          }, {
            value: 'propaganda',
            label: '宣传口号',
            align: 'left'
          }
        ],
        btns: {
          btnArr: [
            {
              label: '修改', // 按钮的名称
              value: 'modify', // 按钮的值
              type: 'warning',
              icon: 'edit',
              functionName: this.modify// 按钮的方法
            },
            {
              label: '删除',
              value: 'del',
              type: 'danger',
              icon: 'delete',
              functionName: this.delete
            }
          ],
          value: 'operation',
          label: '操作',
          width: '180px'
        },
        tableType: '3',
        planTime: '',
        totalNum: '',
        dataSource: [], // 当前页的数据
        tableData: [],
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** 查询日期**/
        unitId: '',
        searchData: { unitId: '',
          beginDate: '',
          endDate: ''},
        /** 弹出层**/
        formLabelWidth: '120px',
        edit: {
          title: '新品修改',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              goodsDesc: '',
              impDate: '',
              goodsPrice: '',
              propaganda: '',
              marketPosition: '',
              taste: '',
              status: '1',
              haveAttach: 1,
              files: []
            }
          }
        }
      }
    },
    methods: {
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      init (param) {
        this.reqParams.url = BasePath.ACTIVITY_CIGARETTES_NEW
        this.reqParams.params = param
        api.requestJava('POST', BasePath.ACTIVITY_CIGARETTES_NEW, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
//              this.tableData.forEach((data, index, arr) => {
//                this.searchForm.isGather = (Number(data.isGather) === 1)
//              })
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      /* add () {
        this.$router.push({path: 'BrandPromotionEdit'})
      }, 跳转到增加页面 */
//       getDesc () {
//         api.requestJava('POST', '/baseinfo/cigarettes/selectList.do', {'isCadrebrand': 'N', 'fields': {'include': 'rowId,goodsDesc'}})
//           .then((request) => {
//             if (Number(request.data.code) === 200) {
//               debugger
//               this.desc = request.data.data
// //              this.tableData.forEach((data, index, arr) => {
// //                this.searchForm.isGather = (Number(data.isGather) === 1)
// //              })
//             } else if (Number(request.data.code) === 401) {
//               this.sessionFailedDialogObj.dialogVisible = true
//             } else {
//               throw new Error(JSON.stringify(request))
//             }
//           })
//           .catch((err) => {
//             this.$store.commit('TOGGLE_LOADING')
//             let culprit = this.$route.name
//             log.work(err, culprit)
//           })
//       },
      add () {
        var myDate = new Date()
        this.edit.data.form.beginDate = this.getTime(myDate.getTime())
        this.edit.data.form.endDate = this.getTime(myDate.getTime())
        this.edit.data.form.goodsDesc = this.desc
//        if (this.edit.data.form.fpConds === '{DATA_AREAS:{}}')
        this.edit.dialogVisible = true
      },
      delete (index, row) {
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let param = {}
          param.rowId = row.rowId
          api.requestJava('POST', BasePath.CIGNEW_DELETE, param)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.$notify({title: '删除成功', message: request.data.message, type: 'success'})
                let params = {}
                params.unitId = getUser().companyId
                params.impDateL = this.getTime(Date.parse(this.beginDate))
                params.impDateR = this.getTime(Date.parse(this.endDate))
                this.init(params)
              } else if (Number(request.data.code) === 401) {
                this.$message('登录失效')
                this.logInvalid.dialogVisible = true
              } else {
                this.$notify.error({ title: '提示', message: request.data.message })
                throw new Error(JSON.stringify(request))
              }
            })
            .catch((err) => {
              this.$store.commit('TOGGLE_LOADING')
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        })
      }, //  删除//
      modify (index, row) {
/*        if (Number(row.status) === 1 || Number(row.status) === 2) {
          this.$message({type: 'info', message: '该记录已生效或终止，不可修改!'})
          return
        } */
        this.findByIdUpper(row)
      }, // 修改// 修改
      findByIdUpper (row) {
        let param = {}
        param.rowId = row.rowId
        param.haveAttach = 1
        api.requestJava('POST', BasePath.ACTIVITY_CIGARETTES_NEW, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              Object.assign(this.edit.data.form, row)
              this.edit.data.form.files = request.data.data[0].files
              console.log('修改2', request.data.data[0].files)
              this.edit.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      },
      confirmBack_base (msg) {
        if (msg) {
          if (msg.data.form.rowId === '') {
            this.queryExit()
          } else {
            this._upload_submit()
          }
        }
        this.clearObject()
      }, // 修改事件
      clearObject () {
        let temp = {
          title: '新品维护',
          type: 'addConfigure',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              goodsDesc: '',
              impDate: '',
              goodsPrice: '',
              propaganda: '',
              marketPosition: '',
              taste: '',
              status: '1',
              haveAttach: '1',
              files: []
            }
          }
        }
        Object.assign(this.edit, temp)
      }, // 清空数据
      queryExit () {
        this.edit.data.form.impDate.setTime(this.edit.data.form.impDate.getTime() + 3600 * 1000 * 24)
        let params = this.edit.data.form
        let files = []
        for (let i = 0; i < this.edit.data.form.files.length; i++) {
          if (this.edit.data.form.files[i].fileName === '') {
            return
          }
          console.log('files', this.edit.data.form.files[i])
          let rowS = {}
          rowS.fileName = this.edit.data.form.files[i].fileName
          rowS.fileType = 'visit_attach_photo'
          if ('src' in this.edit.data.form.files[i]) {
            let src = this.edit.data.form.files[i].src
            if (src.split(',').length > 0) {
              rowS.fileData = src.split(',')[1]
            }
          } else {
            rowS.fileData = this.edit.data.form.files[i].fileData
          }
          files.push(rowS)
        }
        params.files = files
        params.unitId = getUser().companyId
        console.log(JSON.stringify(params))
        api.requestJava('POST', BasePath.CIG_INSERT, params)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '新增成功', message: request.data.message, type: 'success'})
              let param = {}
              param.unitId = getUser().companyId
              param.impDateL = this.getTime(Date.parse(this.beginDate))
              param.impDateR = this.getTime(Date.parse(this.endDate))
              this.init(param)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
      },
      _upload_submit () {
//        this.edit.data.form.impDate.setTime(this.edit.data.form.impDate.getTime() + 3600 * 1000 * 24)
        let params = this.edit.data.form
        let files = []
        for (let i = 0; i < this.edit.data.form.files.length; i++) {
          if (this.edit.data.form.files[i].fileName === '') {
            return
          }
          console.log('files', this.edit.data.form.files[i])
          let rowS = {}
          rowS.fileName = this.edit.data.form.files[i].fileName
          rowS.fileType = 'visit_attach_photo'
          rowS.fileData = this.edit.data.form.files[i].fileData
          files.push(rowS)
        }
        params.files = files
        params.haveAttach = 1
        params.unitId = getUser().companyId
        console.log(JSON.stringify(params))
        api.requestJava('POST', BasePath.CIGNEW_UPDATE, params)
            .then(request => {
              if (Number(request.data.code) === 200) {
                this.$notify({title: '更新成功', message: request.data.message, type: 'success'})
                let param = {}
                param.unitId = getUser().companyId
                param.impDateL = this.getTime(Date.parse(this.beginDate))
                param.impDateR = this.getTime(Date.parse(this.endDate))
                this.init(param)
              } else if (Number(request.data.code) === 401) {
                this.$message('登录失效')
                this.logInvalid.dialogVisible = true
              } else {
                this.$notify.error({ title: '提示', message: request.data.message })
                throw new Error(JSON.stringify(request))
              }
            })
            .catch(err => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        this.clearObject()
      }, // 提交
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      datePickerChange () {
        this.searchData.beginDate = this.getTime(Date.parse(this.datetime[0]))
        this.searchData.endDate = this.getTime(Date.parse(this.datetime[1]))
        console.log('searchData', this.searchData)
      },
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
        this.setFiexHeigth()
      },
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      query () {
        let params = {}
//        params.unitId = this.unitId
//        const start = this.beginDate
//        const end = this.endDate
//        start.setTime(start.getTime() + 3600 * 1000 * 24)
//        end.setTime(end.getTime() + 3600 * 1000 * 24)
//        params.impDateL = start
//        params.impDateR = end
        // params.visitStatus = '0'
        params.unitId = getUser().companyId
        params.impDateL = this.getTime(Date.parse(this.beginDate))
        params.impDateR = this.getTime(Date.parse(this.endDate))
        this.queryUpper(params)
      }, // 按时间段查询
      queryUpper (params) {
        this.reqParams.url = BasePath.ACTIVITY_CIGARETTES_NEW
        this.reqParams.params = params
        api.requestJava('POST', BasePath.ACTIVITY_CIGARETTES_NEW, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      },
      setFiexHeigth () {
        let form1 = document.getElementById('form1')
        let fixed = document.getElementsByClassName('el-table__fixed')
        if (Number(fixed.length) === 1) {
          setTimeout(() => {
            fixed[0].style.height = (parseInt(form1.style.height) - parseInt('1px')) + 'px'
          })
        } else {
          console.log('存在多个固定列，注意检查')
        }
      }, // 给flex 列 修改 高度
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      }, // 时间格式化
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      }
    },
    components: {
      _BTN_FILTER,
      _TABLE,
      _POPUP
    }
  }
</script>

