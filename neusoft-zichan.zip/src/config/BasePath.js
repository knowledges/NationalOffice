export default {
  /* 首页 */
  H_: '',
  /* 公共 */
  /* 树 */
  ORGTREE_SELECTORGTREE: 'system/orgtree/selectOrgTree.do', // 组织机构树
  COMMODITYTREE_FACTORYBRAND: 'baseinfo/productbrand/selectTreeList.do', // 供应商品牌树。。。
  BASE_BRANDTREE: 'baseinfo/common/selectCigarettesBrandTree.do', // 工业公司拥有品牌的卷烟牌号树形
  /* 下拉框 */
  SELECT_CODELIST_MAPLIST: 'system/codelist/mapList.do', // 参数分组。。
  SELECT_PARAMGRPCODEGROUP: 'system/orgrelationshiptypes/selectList.do', // 参数分组。。。
  SELECT_BRANDIDGROUP: 'baseinfo/productbrand/selectList.do', // 品牌。。。
  SELECT_PCKTMPIDGROUP: 'baseinfo/packagetemplate/selectList.do', // 包装模板
  SELECT_GOODSGRADEGROUP: 'baseinfo/productgrade/selectList.do', // 卷烟级别。。。
  SELECT_FACTORYIDGROUP: 'system/orgroles/selectList.do', // 厂家。。。
  SELECT_PROVINCEIDGROUP: 'system/regionalisms/selectList.do', // 省份。。。
  SELECT_TREELIST: 'system/regionalisms/selectTreeList.do', // 省份级联
  SELECT_ORGROLETYPIDGROUP: 'system/orgroletypes/selectList.do', // 组织角色。。。
  SELECT_ORGTYPEGROUP: 'system/orgtypes/selectList.do', // 组织机构类型。。。
  SELECT_DEPTIDGROUP: 'system/orgunits/selectList.do', // 所属部门。。。
  SELECT_RTLCATIDGROUP: 'system/customergroup/selectList.do', // 客户集ID。。。
  /* 基础信息 */
  /* 客户信息 */
  CUSTOMER_SELECT: 'system/customer/selectList.do', // 客户信息查询
  CUSTOMER_DELETE: 'system/customer/delete.do', // 客户删除
  CUSTOMER_SELECTONE: 'system/customer/selectOne.do', // 客户明细查询
  CUSTOMER_UPDATE: 'system/customer/update.do', // 客户信息更新
  CUSTOMER_BANTCHNO: 'system/common/getBatchNoByCom.do', // 批次
  CUSTOMER_STARGRADE: '/system/common/getCodeFromCustgroup.do', // 客户星级
  CUSTOMER_NEXTDEPT: '/system/common/getNextDept.do',
  /* 雇员信息 */
  EMPLOYEE_SELECT: 'system/employees/selectList.do', // 雇员信息查询
  EMPLOYEE_SELECTONE: 'system/employees/selectOne.do',
  EMPLOYEE_INSERT: 'system/employees/insert.do',
  EMPLOYEE_UPDATE: 'system/employees/update.do',
  EMPLOYEE_DELETE: 'system/employees/delete.do',
  EMPLOYEE_DELETEBATCH: 'system/employees/deleteBatch.do',
  /* 行政区 */
  REGIONALISMS_SELECT: 'system/regionalisms/selectList.do', // 行政区查询
  /* 银行 */
  BANK_SELECT: 'system/bank/selectList.do', // 银行查询
  /* 商品信息 */
  COMMODITY_SELECT: 'baseinfo/cigarettes/selectList.do', // ...
  COMMODITY_PACKAGEMX: 'baseinfo/goodspackage/selectList.do', // ...
  COMMODITY_ALL: 'baseinfo/common/selectBrandGoodsTree.do',
  COMMODITY_SELECTLIST: 'baseinfo/common/selectCigarettes.do',
  COMMODITY_UPDATE: 'baseinfo/common/updateGoodsOrg.do',
  /* 客户集 */
  CUSTOMERGROUP_SELECTLIST: 'system/customergroup/selectList.do',
  CUSTOMERGROUP_INSERT: 'system/customergroup/insert.do',
  CUSTOMERGROUP_UPDATE: 'system/customergroup/update.do',
  CUSTOMERLISTBYCUSTOMERGROUP: 'system/common/getCustomerGroupMembers.do', // 根据客户集id查客户
  CUSTOMERGROUP_DELETE: 'system/customergroup/delete.do',
  CUSTOMERGROUP_INSERTCUSTOMERS: 'system/customerclassified/insertBatch.do',
  CUSTOMERGROUPDETAIL_DELETE: 'system/customerclassified/delete.do',
  CUSTOMERGROUP_UPDATEBATCH: 'system/customerclassified/updateBatch.do',
  /* 商品集 */
  CIGCATEGORYS_SELECTLIST: 'baseinfo/cigcategorys/selectList.do',
  CIGCATEGORYS_INSERT: 'baseinfo/cigcategorys/insert.do',
  CIGCATEGORYS_DELETE: 'baseinfo/cigcategorys/delete.do',
  CIGCATEGORYS_DELETE_DETAIL: 'baseinfo/cigclassfied/delete.do',
  CIGCATEGORYS_SELECTLIST_DETAIL: 'baseinfo/common/selectCigclassfied.do',
  CIGCATEGORYS_DELETE_BATCH: 'baseinfo/cigclassfied/deleteBatch.do',
  CIGCATEGORYS_INSERT_BATCH: 'baseinfo/cigclassfied/insertBatch.do',
  CIGCATEGORYS_COMMODITY_SELECTLIST: 'baseinfo/common/selectCigNotClassfied.do',
  /* 岗位 */
  DEPTPLACES_DELETE: 'system/deptplaces/delete.do',
  DEPTPLACES_SELECT: 'system/deptplaces/selectList.do',
  DEPTPLACES_UPDATE: 'system/deptplaces/update.do',
  DEPTPLACES_INSERT: 'system/deptplaces/insert.do',
  DEPTPLACES_DELETEBATCH: 'system/deptplaces/deleteBatch.do',
  /* 服务 */
  DEPTPLACESTYPE_DELETE: 'system/deptplacestype/delete.do',
  DEPTPLACESTYPE_SELECT: 'system/deptplacestype/selectList.do',
  DEPTPLACESTYPE_UPDATE: 'system/deptplacestype/update.do',
  DEPTPLACESTYPE_INSERT: 'system/deptplacestype/insert.do',
  DEPTPLACESTYPE_DELETEBATCH: 'system/deptplacestype/deleteBatch.do',
  /* 系统管理 */
  ROLE_SELECT: 'system/role/selectListPages.do', // 角色查询
  ROLE_INSERT: 'system/role/insert.do', // 角色新增
  ROLE_UPDATE: 'system/role/update.do', // 角色更新
  ROLE_DELETE: 'system/role/delete.do', // 角色删除
  ROLE_PERMISSIONS_QUERY: 'system/rolepermissions/selectList.do', // 角色赋权查询
  ROLE_PERMISSIONS_DELETE: 'system/rolepermissions/delete.do', // 角色赋权删除
  ROLE_USER_QUERY: 'system/userrole/selectList.do', // 角色用户授权查询
  ROLE_USER_DELETE: 'system/userrole/delete.do', // 角色用户授权删除
  ROLE_USER_JURISDICTION: 'system/common/selectUserByComAndRole.do', // 角色人员权限
  ROLE_USER_DISTRIBUTION: 'system/common/selectRolebyResources.do', // 角色模块分配
  ROLE_USER_INSERT_BATCH: 'system/userrole/insertBatch.do', // 角色人员权限批量插入
  ROLE_USER_DELETE_BATCH: 'system/userrole/deleteBatch.do', // 角色人员权限批量删除
  ROLE_PERMISSIONS_SELECT: 'system/common/selectRolebyResources.do', // 角色菜单赋权查询
  ROLE_PERMISSIONS_INSERT_BATCH: 'system/rolepermissions/insertBatch.do', // 角色菜单赋权批量插入
  ROLE_PERMISSIONS_DELETE_BATCH: 'system/rolepermissions/deleteBatch.do', // 角色菜单赋权批量插入
  PERMISSIONBYROLE_SELECT: 'system/common/selectPermissionByrole.do', // roleId为条件查询 是否有记录
  PERMISSIONBYROLE_DELETE: 'system/common/deleteByRoleId.do', // 强制删除
  PERMISSIONBYROLE_MERGE: 'system/rolepermissions/merge.do', // 菜单赋权先删除后插入
  ROLE_USER_PERMISSIONS_TREE_LIST: 'system/resources/selectTreeListByRole.do', // 菜单树展现
  ROLE_USER_PERMISSIONS_TREE_MERGE: 'system/common/merge.do', // 菜单下发
  /* 参数设置 */
  APPPARAM_DELETE: 'system/appparam/delete.do',
  APPPARAM_SELECT: 'system/appparam/selectList.do',
  APPPARAM_UPDATE: 'system/appparam/update.do',
  APPPARAM_INSERT: 'system/appparam/insert.do',
  APPPARAM_DELETEBATCH: 'system/appparam/deleteBatch.do',
  APPPARAMVALUE_SELECT: 'system/appparamvalue/selectList.do',
  APPPARAMVALUE_UPDATE: 'system/appparamvalue/update.do',
  APPPARAMVALUE_INSERT: 'system/appparamvalue/insert.do',
  APPPARAMVALUE_DELETE: 'system/appparamvalue/delete.do',
  /* 组织机构 */
  ORGUNITS_DELETE: 'system/orgunits/delete.do',
  ORGUNITS_INSERT: 'system/orgunits/insert.do',
  ORGUNITS_UPDATE: 'system/orgunits/update.do',
  ORGUNITS_SELECT: 'system/orgunits/selectList.do',
  ORGUNITS_SELECTONE: 'system/orgunits/selectOne.do',
  /* 用户管理 */
  USER_INSERT: 'system/user/insert.do',
  USER_SELECTLISTPAGES: 'system/user/selectListPages.do',
  USER_SELECTLIST: 'system/user/selectList.do',
  USER_UPDATE: 'system/user/update.do',
  USER_DELETE: 'system/user/delete.do',
  /* 人员管理 */
  NEXTORGUNIT_SELECT: 'system/common/selectNextOrgUnit.do',
  /* 模块管理 */
  MODULE_SELECTLIST: 'system/resources/selectList.do',
  MODULE_INSERTIDTREE: 'system/resources/insertIdTree.do',
  MODULE_SELECTTREELIST: 'system/resources/selectTreeList.do',
  MODULE_DELETE: 'system/resources/delete.do',
  MDOULE_UPDARE: 'system/resources/update.do',
  /* 数据字典 */
  CODETYPE_SELECTLIST: 'system/codetype/selectList.do', // 查询主表列表
  CODETYPE_INSERT: 'system/codetype/insert.do', // 新增单条主表
  CODELIST_INSERT: 'system/codelist/insertBatch.do', // 批量新增、保存、删除从表对象
  CODETYPE_DELETE: 'system/codetype/delete.do', // 删除单条主表
  CODELIST_SELECT: 'system/codelist/selectList.do', // 根据主表id查询从表数据
  CODETYPE_UPDATE: 'system/codetype/update.do', // 更新单条主表
  /* 客戶拜訪 */
  /* 客户经理日历首页 */
  CLIENTMANAGER_ORDER_TOTAL: 'ordercdc/common/queryOrdersDayTot.do', // 未订单，未扣款，当日订单统计
  CLIENTMANAGER_CALENDAR: 'visit/common/selectCustmgrStatistics.do', // 客户经理日历接口
  CLIENTMANAGER_QUERYPAYFAIL: 'ordercdc/common/querypayFail.do', // 未扣款零售户
  CLIENTMANAGER_NOORDERCUSTS: 'ordercdc/common/noOrdercusts.do', // 客户经理计划订货客户查询,未订货
  CLIENTMANAGER_ORDERCUSTS: 'ordercdc/common/queryOrdersDayDtl.do', // 当日订单量
  CLIENTMANAGER_ORDERMX: 'ordercdc/common/queryOrdersDayPrdDtl.do', // 当日订单量
  CUSTOMER_SALESVOLUME: 'orderquery/common/querycustmgrTot.do', // 经营分析总体
  CUSTOMER_SPECIFICATIONS: 'orderquery/common/querycustmgrCustPrd.do', // 经营分析规格
  CUSTOMER_CUSTOMER: 'orderquery/common/querycustmgrCust.do', // 经营分析客户
  CUSTOMER_DAYORDER: 'ordercdc/common/ordselectCust.do', // 当日订单
  CUSTOMER_GOODRESOURCELIST: 'ordercdc/common/supplylimitCust.do', // 货源信息
/* 拜访计划制定 */
  VISITPLAN_SAVE: 'visit/common/insertBatchRec.do', // ...
  VISITPLAN_PLANDATE: 'visit/visitingrec/selectVisitPeriod.do', // ...
  VISITPLAN_SELECT: 'visit/common/selectMapListPages.do', // ...
  VISITPLAN_TOTAL: 'visit/visitingrec/selectVisitedCustomerSum.do', // ...
  VISITPLAN_DELETE: 'visit/visitingrec/delete.do', // ...
  VISITPLAN_DELETEBATCH: 'visit/visitingrec/deleteBatch.do', // ...
  VISITPLAN_EMP_PASS: 'visit/visitingrec/checkVisitPlan.do',
  VISITPLAN_EMP_SELECT: 'visit/visitingrec/selectVisitPlanCount.do',
  VISITPLAN_PASS: 'visit/visitingrec/updateBatch.do',
  VISITPLAN_PASS_STEPSSELECT: 'visit/common/selectVisitOptions.do',
  VISITPLAN_TODATE_SELECTLIST: 'visit/visitingrec/selectListMobilePages.do',
  VISITPLAN_STATISTICS: 'visit/common/visitStatistics.do', // 拜访统计
  VISITPLAN_FREQUENCY: 'visit/common/visitFrequency.do', // 拜访频率
/* 拜访计划制定 */
  VISITQUERY_SELECT: 'visit/visitingrec/selectVistingResult.do', // ...
  VISITQUERY_STEPSSELECT: 'visit/clsteps/selectList.do', // ...
  CLSTEPS_SELECTONE: 'visit/clsteps/selectOne.do',
  VISITQUERY_SELECTONE: 'visit/visitingrec/selectOne.do',
  INSTORESUMMARY_SELECTONE: 'visit/instoresummary/selectOne.do',
  INSTORESALES_SELECTLIST: 'visit/instoresales/selectList.do',
  INSTORESALES_SELECTONE: 'visit/instoresales/selectOne.do',
/* 采集计划制定 */
  JOBSET_SELECT: 'system/businesscalendar/selectGatherScheduleCustom.do', // ...
  JOBSET_UPDATE: 'system/businesscalendar/updateGatherScheduleCustom.do', // ...
  /* 监控地图 */
  MARKETMGR_STATISTICS: 'visit/common/selectMarketmgrStatistics.do', // 市场经理查看客户经理拜访情况
  CUSMGR_STATISTICS: 'visit/common/selectCustmgrStatistics.do', // 周期内拜访情况统计
  CUSTMGR_STATUS: 'visit/common/selectCustmgrStatus.do', // 周期内拜访情况统计
  /* 问卷调查 */
  FW_FROMS_INSERT: 'visit/forms/insert.do', // 插入表单
  // FW_FROMS_SELECTLIST: 'visit/forms/selectList.do', // 查询所有问卷
  FW_FROMS_SELECTLIST: 'visit/forms/getList.do', // 查询所有问卷
  FW_ITEMS_SELECTELIST: 'visit/items/selectList.do',
  FW_FROMS_UPDATE: 'visit/forms/update.do', // 逻辑删除某问卷
  FW_ITEMS_GETFULLFORM: 'visit/forms/getFullForm.do', // 查詢问卷
  FW_ITEMS_SAVEFULLFORM: 'visit/forms/saveFullForm.do', // 保存问卷
  FW_FROMS_COPYFULLFROM: 'visit/forms/copyFullForm.do', // 复制整张表单
  CL_STEPS: 'visit/clsteps/insertMuti.do', // 问卷录入
  FW_STEPS_SELECTFLOWANDSTEPS: 'visit/flows/selectFlowAndSteps.do', // 岗位流程 多步骤的
  FW_FLOWS_SELECTLIST: 'visit/flows/selectList.do', // 岗位流程 只有一个步骤的
  FW_STEPS_UPDATE: 'visit/steps/update.do', // 修改岗位的流程
  FW_STEPS_INSERT: 'visit/steps/insert.do', // 插入岗位的流程
  FW_COMMON_SELECTPLANSBYFORMID: 'visit/common/selectPlansByFormId.do', // 活动选择
  FW_COMMON_SELECTFORMDATABYPLANID: 'visit/common/selectFormDataByPlanId.do', // 活动查询
  FW_COMMON_FORMANALYSIS: 'visit/common/formAnalysis.do', // 表单分析
  /* 消费营销-活动管理 */
  ACTIVITY_CIGARETTES_NEW: '/visit/cigarettesnew/selectList.do', // ...
  ACTIVITY_SELECTCRMMATTERSLIST: 'visit/common/selectCrmMattersList.do', // 3.5.2消费营销-活动管理-活动管理列表
  ACTIVITY_INSERT: 'visit/plans/insert.do', // 3.5.3消费营销-活动管理-活动管理列表-新增（初始化及保存）
  ACTIVITY_UPDATE: 'visit/plans/update.do', // 3.5.4消费营销-活动管理-活动管理列表-修改（初始化）
  ACTIVITY_DELETE: 'visit/plans/delete.do', // 3.5.5消费营销-活动管理-活动管理列表-删除
  ACTIVITY_SELECTONE: 'visit/plans/selectOne.do',
  SELECT_MATTERIDGROUP: 'visit/crmmatters/selectList.do', // 3.5.7消费营销-活动管理-活动管理列表-活动事项下拉框
  ACTIVITY_SELECTACTIVITYCOLLECTION: 'visit/common/selectActivityCollection.do', // 3.5.8消费营销-活动管理-活动管理列表-新增-收集内容列表
  ACTIVITY_CUSTOMER_SELECT: 'system/common/custSelect.do', // 3.5.7消费营销-活动管理-活动管理列表-活动事项下拉框
  ACTIVITY_SELECTLIST: 'visit/plans/selectList.do',
  /* 历史拜访 */
  VISI_HISTORY: 'visit/visitingrec/selectList.do',
  /* 历史订单 */
  ORDER_HISTORY: 'orderquery/common/ordhisselect.do',
  ORDER_HISTORY_DETAIL: 'orderquery/common/ordhisselectLine.do',
  /* 组织机构树 */
  ORGUNIT_TREE: 'system/orgunits/selectTreeList.do',
  EMPLOYEE_TREE: 'system/employees/selectTreeList.do',
  EMPLOYEE_COMPANY_TREE: 'system/employees/selectCompanyTreeList.do',
  /* 价格采集录入 */
  GATHER_PRICE_SELECT: 'visit/gatherproductprice/selectList.do',
  GATHER_PRICE_DETAIL: 'visit/gatherproductpricedetail/selectList.do', // 价格采集录入细表查询
  GATHER_PRICE_ADD: 'visit/gatherproductpricedetail/selectGatherPriceCigarettes.do', // 价格采集录入新建/修改
  GATHER_PRICE_UPDATE: 'visit/gatherproductpricedetail/saveGatherPrice.do',
  GATHER_PRICE_SUBMIT: 'visit/gatherproductprice/update.do',
  GATHER_PRICE_DELETE: 'visit/gatherproductprice/deleteGatherPriceAndDetail.do',
  /* 采集品规设置 */
  GATHER_SELECT: 'visit/gatherproduct/selectList.do', // 查询多条信息
  GATHER_SELECTONE: 'visit/gatherproduct/selectOne.do', // 查询单条信息
  GATHER_SELECTGATCH: 'visit/gatherproduct/selectGatherSettingCigarettes.do', // 价格采集商品设置
  GATHER_UPDATE: 'visit/gatherproduct/update.do', // 更新单条
  GATHER_UPDATEBATCH: 'visit/gatherproduct/updateBatch.do', // 更新多条
  GATHER_INSERT: 'visit/gatherproduct/insert.do', // 插入单条
  GATHER_INSERTBATCH: 'visit/gatherproduct/insertBatch.do', // 插入多条
  GATHER_DELETE: 'visit/gatherproduct/delete.do', // 删除单条记录
  GATHER_DELETEBATCH: 'visit/gatherproduct/deleteBatch.do', // 删除多条记录
  /* 3.6.1周订单分析报告 */
  WEEKORDERREPORT_SELECT: 'visit/reports/selectList.do', // 3.6.1.1接口一（订单报告查询）
  WEEKORDERREPORT_SELECTONE: 'visit/reports/selectOne.do', // 3.6.1.1接口一（订单报告查询）
  WEEKORDERREPORT_UPDATE: 'visit/reports/update.do', // 3.6.1.2接口二（保存）
  WEEKORDERREPORT_INSERT: 'visit/reports/insert.do', // 3.6.1.2接口二（保存）
  WEEKORDERREPORT_DELETE: 'visit/reports/delete.do', // 3.6.1.2接口二（删除）
  WEEKORDERREPORT_CONSUMPTION: 'baseinfo/common/selectKeyBrandMarketPriceByIds.do', // 3.6.1.3接口三（订单报告参考数据1:重点品牌市场价格）
  WEEKORDERREPORT_BRANDS: 'baseinfo/common/selectKeyBrandRatesByIds.do', // 3.6.1.4接口四（订单报告参考数据2:各种率分析）
  WEEKORDERREPORT_CUSTOMER: 'baseinfo/common/selectKeyBrandIndex.do', // 3.6.1.5接口五（订单报告参考数据3:辖区指标分析）
  WEEKORDERREPORT_SELECTLIST: 'visit/common/selectWeekReportByObjId.do',
  WEEK_SELECTLIST: 'orderquery/dtweek/selectList.do',
// WEEKORDERREPORT_BRANDQUERY: '', // 3.6.1.6接口六（选择分析品牌）
  // WEEKORDERREPORT_BRANDSAVE: '', // 3.6.1.7接口七（选择分析品牌保存）
  /* 客户销售分析报告 */
  CUSTSALESANALYSIS_SELECT: 'visit/common/reportQuery.do', // 客户销售分析查询
  CUSTSALESANALYSIS_ANAYSIS: 'visit/common/reportQuery.do', // 月度总体卷烟经营情况
  CUSTSALESANALYSIS_UPDATE: 'visit/reports/update.do', // 3.6.1.2接口二（保存）
  CUSTSALESANALYSIS_INSERT: 'visit/reports/insert.do', // 3.6.1.2接口二（保存）
  CUSTSALESANALYSIS_SELECTONE: 'visit/reports/selectOne.do', // 3.6.1.2接口二（保存）
  CUSTSALESANALYSIS_ANAYSIS4: 'orderquery/common/reportQueryRefer4.do', // 3.6.2.3 分析报告-客户销售分析报告-客户分析报告参考数据4:总体指标分析
  CUSTSALESANALYSIS_ANAYSIS5: 'orderquery/common/reportQueryRefer5.do', // 3.6.2.4 分析报告-客户销售分析报告-客户分析报告参考数据5:客户经理总体指标分析
  CUSTSALESANALYSIS_ANAYSIS6: 'orderquery/common/reportQueryRefer6.do', // 3.6.2.5 分析报告-客户销售分析报告-客户分析报告参考数据6规格前5销量
  CUSTSALESANALYSIS_ANAYSIS7: 'orderquery/common/reportQueryRefer7.do', // 3.6.2.6 分析报告-客户销售分析报告-客户分析报告参考数据7分价位订购情况
  WEEKORDERREPORT_WEEK: 'orderquery/common/selectReportPeriod.do', // 3.6.1.7接口七（选择分析品牌保存）
  /* 季度分析报告-客户销售分析报告 */
  CUSTSALESANALYSIS_ANAYSISQ4: 'orderquery/common/reportQueryReferQ4.do', // 季度分析报告-客户销售分析报告-客户分析报告参考数据4:总体指标分析
  CUSTSALESANALYSIS_ANAYSISQ5: 'orderquery/common/reportQueryReferQ5.do', // 季度分析报告-客户销售分析报告-客户分析报告参考数据4:总体指标分析
  CUSTSALESANALYSIS_ANAYSISQ6: 'orderquery/common/reportQueryReferQ6.do', // 季度分析报告-规格前5销量
  CUSTSALESANALYSIS_ANAYSISQ7: 'orderquery/common/reportQueryReferQ7.do', // 季度分析报告-分价位订购情况
  /* 3.6.1周订单分析报告 */
  REGIONALSALES_ANALYTICALDATA1_KEY: 'orderquery/common/areaReportQueryRefer8.do', // 3.6.3.3接口三（区域销售分析参考数据8: 关键指标）
  REGIONALSALES_ANALYTICALDATA2_CATEGORY: 'orderquery/common/areaReportQueryRefer9.do', // 3.6.3.4接口四（区域销售分析参考数据9: 五类烟指标）
  REGIONALSALES_ANALYTICALDATA3_PRICE: 'orderquery/common/areaReportQueryRefer10.do', // 3.6.3.5接口五（区域销售分析参考数据10: 分价类）
  REGIONALSALES_ANALYTICALDATA4_NEWPRODUCTS: 'orderquery/common/areaReportQueryRefer11.do', // 3.6.3.6***接口六（区域销售分析参考数据11: 新品分析）
  REGIONALSALES_ANALYTICALDATA5_SALES: 'orderquery/common/areaReportQueryRefer12.do', // 3.6.3.7接口七（区域销售分析参考数据12: 客户档次变化情况及销售分析）
  REGIONALSALES_QUARTER: 'visit/bizperiods/selectList.do', // 区域销售分析参考数据--季度
  REGIONALSALES_QUARTER_SELECTLIST: 'orderquery/dtquarter/selectOne.do', // 区域销售分析参考数据--季度
  WEEKORDERREPORT_QUARTER_SELECTLIST: 'orderquery/dtweeklaunch/selectList.do', //
  WEEKORDERREPORT_QUARTER_SELECTONE: 'orderquery/dtweeklaunch/selectOne.do', //

/* 投诉记录 */
  COMPLAINTREC_SELECTNAME: 'visit/complaintrec/selectComplaintRecDepName.do', // 查询带部门名称的投诉记录
  COMPLAINTREC_SELECT: 'visit/complaintrec/selectList.do', // 查询多条
  COMPLAINTREC_SELECTONE: 'visit/complaintrec/selectOne.do', // 查询单条
  COMPLAINTREC_UPDATE: 'visit/complaintrec/update.do', // 更新单条记录
  COMPLAINTREC_UPDATEBATCH: 'visit/complaintrec/updateBatch.do', // 更新多条记录
  COMPLAINTREC_INSERT: 'visit/complaintrec/insert.do', // 插入单条记录
  COMPLAINTREC_INSERTBATCH: 'visit/complaintrec/insertBatch.do', // 插入多条记录
  COMPLAINTREC_DELETE: 'visit/complaintrec/delete.do', // 删除单条记录
  COMPLAINTREC_DELETEBATCH: 'visit/complaintrec/deleteBatch.do', // 删除多条记录
  /* 区域消费数据收集 */
  AREARTINFO_DELETE: 'visit/areartinfo/delete.do',
  AREARTINFO_INSERT: 'visit/areartinfo/insert.do',
  AREARTINFO_SELECT: 'visit/areartinfo/selectList.do',
  AREARTINFO_SELECTONE: 'visit/areartinfo/selectOne.do',
  AREARTINFO_UPDATE: 'visit/areartinfo/update.do',
  /* 消费者信息 */
  CONSUMER_DELETE: 'visit/consumer/delete.do',
  CONSUMER_DELETEBATCH: 'visit/consumer/deleteBatch.do',
  CONSUMER_INSERT: 'visit/consumer/insert.do',
  CONSUMER_INSERTBATCH: 'visit/consumer/insertBatch.do',
  CONSUMER_SELECTLIST: 'visit/consumer/selectList.do',
  CONSUMER_GETLIST: 'visit/consumer/getList.do',
  CONSUMER_SELECTONE: 'visit/consumer/selectOne.do',
  CONSUMER_UPDATE: 'visit/consumer/update.do',
  CONSUMER_UPDATEBATCH: 'visit/consumer/updateBatch.do',
  /* 获取单据号 */
  GET_BILLNO: 'system/common/getBillNo.do',
  /* 品牌跟踪 */
  BRANDTRACK_DELETE: 'visit/brandtrack/delete.do',
  BRANDTRACK_INSERT: 'visit/brandtrack/insert.do',
  BRANDTRACK_SELECT: 'visit/brandtrack/selectList.do',
  BRANDTRACK_GETLIST: 'visit/brandtrack/getList.do',
  BRANDTRACK_SELECTONE: 'visit/brandtrack/selectOne.do',
  BRANDTRACK_UPDATE: 'visit/brandtrack/update.do',
  /* 陈列模板 */
  DISPLAYTOM_SELECTAPPDISPLAYTMP: 'visit/displaytmp/selectApplyDisplayTmp.do',  // 4.19.3 接口二（陈列模板审核）-查询
  DISPLAYTOM_SELECT: 'visit/displaytmp/selectList.do',
  DISPLAYTOM_SELECTONE: 'visit/displaytmp/selectOne.do',
  DISPLAYTOM_INSERT: 'visit/displaytmp/insert.do',
  DISPLAYTOM_UPDATE: 'visit/displaytmp/update.do',
  /* 物料领取录入 */
  MTRLINVENTORY_SELECT: 'visit/common/selectMtrlDataById.do', // 物料查询
  INVY_G_SELECT: 'visit/invyg/selectList.do', // 物料查询
  MTRLINVENTORY_INSERT: 'visit/common/insertMtrlOptions.do', // 物料保存
  MTRLINVENTORY_COMMIT: 'visit/common/commitMtrlOptions.do', // 物料提交
  MTRLINVENTORY_SELECTLIST: 'visit/mtrlbill/selectList.do', // 物料录入查询
  MTRLINVENTORY_SELECTLIST_DETAIL: 'visit/mtrlbilldtl/selectList.do', // 物料录入查询
  HANDLERBY_COMID: 'visit/common/selectHandlerByComID.do', // 查询有库存的发放人
  /* 物料维护 */
  VISIT_INVYG_SELECT: 'visit/invyg/selectList.do', // 物料维护查询
  VISIT_INVYG_INSERT: 'visit/invyg/insert.do', // 物料维护插入
  VISIT_INVYG_UPDATE: 'visit/invyg/update.do', // 物料维护更新
  VISIT_INVYG_DELETE: 'visit/invyg/delete.do', // 物料维护删除
  /* 预警信息 */
  WARNINGINFO_RULE: 'report/common/getRulesList.do', // 预警项
  WARNINGINFO_OBJECT: 'report/common/viewAlertData.do', // 预警明细
  WARNINGINFO_RULECOUNT: 'report/common/getRulesCount.do', // 预警监控
  /* app版本号 */
  VERIONUP_SELECTLIST: 'system/appversion/selectList.do', // app版本号列表查询
  VERIONUP_UPDATE: 'system/appversion/update.do', // app版本号列表修改
  VERIONUP_LOG_SELECTLIST: 'system/apprelease/selectList.do', // app版本号日志查询
  VERIONUP_LOG_SELECTONE: 'system/apprelease/selectOne.do', // app版本号单条日志查询
  VERIONUP_LOG_INSERT: 'system/apprelease/insert.do', // app版本号单条日志查询
  INVENTORY_INVENTORYREMAINDER: 'visit/mtrlinventory/selectList.do',
  VISTSTATISTICS_SELECTLIST: 'visit/common/selectVisitingCount.do',
  REPORT_SELECTVISTINGCOUNT: 'report/common/selectVisitingCount.do',
  /* 分析报告 */
  PRICOLLECTION_SELECTLIST: 'visit/common/selectGatherPriceStatistics.do', // 价格采集查询
  /* 变更信息审批 */
  EXCHANGEINFO_SELECTLIST: '/visit/custchgapp/selectCustchgAppCheck.do', // 变更信息审批查询
  EXCHANGEINFO_UPDATE: '/visit/custchgapp/update.do', // 变更信息审批修改
  /* 培训记录 */
  TRAININGRECORD_SELECTLIST: '/visit/trainingrec/selectList.do', // 培训记录录入查询
  TRAININGRECORD_DELETE: '/visit/trainingrec/delete.do', // 培训记录录入删除
  TRAININGRECORD_UPDATE: '/visit/trainingrec/update.do', // 培训记录录入修改
  TRAININGRECORD_INSERT: '/visit/trainingrec/insert.do', // 培训记录录入插入
  /* 消息 */
  COMMON_TOPICQUERY: 'system/common/topicQuery.do', // 查看全消息,查询小结接口,查询消息接口,查询@我接口,查询我的接口
  COMMON_TOPICQUERY_COUNT: 'system/common/topicQueryCount.do', // 查看全消息,查询小结接口,查询消息接口,查询@我接口,查询我的接口
  TOPIC_SAVETOPIC: 'system/topic/saveTopic.do', // 小结提交
  REPLAY_REPLAYSAVE: 'system/replay/replaySave.do', // 评论,点赞
  /* 新品 */
  CIGNEW_UPDATE: 'visit/cigarettesnew/update.do', // 修改新品信息
  CIGNEW_DELETE: 'visit/cigarettesnew/delete.do', //  删除新品信息
  CIG_INSERT: 'visit/cigarettesnew/insert.do', // 插入新品信息
  /* 样本户申请 */
  MICUSSTAP_SELECT: 'visit/micustap/selectList.do',
  MICUSSTAP_INSERT: 'visit/micustap/insert.do',
  MICUSSTAP_UPDATE: 'visit/micustap/update.do',
  MICUSSTAP_DELETE: 'visit/micustap/delete.do',
  /* 样本户审批 */
  MICUSST_SELECT: 'visit/micust/selectList.do',
  MICUSST_INSERT: 'visit/micust/insert.do',
  MICUSST_UPDATE: 'visit/micust/update.do',
  MICUSST_DELETE: 'visit/micust/delete.do',
  MICUSST_CHECK: 'visit/micustap/checkMiCustAp.do',
  /* 人员岗位 */
  EMPPLACES_SELECT: 'system/empplaces/selectList.do',
  EMPPLACES_INSERT: 'system/empplaces/insert.do',
  EMPPLACES_UPDATE: 'system/empplaces/update.do',
  EMPPLACES_DELETE: 'system/empplaces/delete.do',
  COMMON_SELSECTVISIT: 'visit/common/selectVisitingCusts.do',
  COMMON_MARKETING: 'report/common/consumerMarketing.do',
  COMMON_SERVICE: 'report/common/customerService.do',
  COMMON_SERVICE_RATE: 'report/common/customerServiceRate.do',
  COMMON_TREND: 'report/common/priceTrend.do',
  MKCUMM_FIVE: 'ordersale/mkcumm/priceTrendFive.do',
  OPLOG_INSERT: 'system/oplog/insert.do',
  // 客户经理行驶里程
  VISIT_DISTANCE: 'visit/visitingrec/getVisitRecDistance.do'
}
