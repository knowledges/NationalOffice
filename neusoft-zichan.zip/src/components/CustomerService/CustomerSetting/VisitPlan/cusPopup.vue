<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk"  :size='dialogObj.size' v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <div class="container-fluid_new">
      <el-collapse-transition>
        <div v-if="isSelect" class="filter_more">
          <el-form ref="searchForm" :model="dialogObj.data.form" label-width="120px">
            <el-col :gutter="24">
              <el-col :span='12'>
                <el-form-item label="客户档级">
                  <el-select v-model="dialogObj.data.form.customerGrade" multiple disabled  placeholder="请选择客户档级">
                    <template v-for="item in customerGradeGroup">
                      <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item label="市场类型">
                  <el-select v-model="dialogObj.data.form.geoType" multiple disabled  placeholder="请选择市场类型">
                    <template v-for="item in geoTypeGroup">
                      <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              </el-col>
              <el-col :gutter="24">
              <el-col :span='12'>
                <el-form-item label="业态">
                  <el-select v-model="dialogObj.data.form.businessType" multiple  disabled  placeholder="请选择业态">
                    <template v-for="item in businessTypeGroup">
                      <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item label="规模">
                  <el-select v-model="dialogObj.data.form.operationScale" multiple disabled  placeholder="请选择规模">
                    <template v-for="item in operationScaleGroup">
                      <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
          </el-form>
        </div>
      </el-collapse-transition>
      <el-row class="filter_style">
        <el-col :span="24" style="padding: 0 0">
           <_BTN_FILTER  @on-change="inputChange" :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData" :isMore="isMore"/></_BTN_FILTER>
      </el-col>
        </el-row>
      <div>
        <_TABLE
          ref="table"
          stripe
          maxHeight="500"
          :data="dataSource"
          :columns="columnHeader"
          :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
          :totalCount="totalCount" :hasPagination="hasPagination"
          @selection-change="selectionChange" :setPage=this.getPage ></_TABLE>
      </div>
    </div>
  </el-dialog>
  </div>
</template>

<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import api from '@/api'
  import log from '@/log'
  import BasePath from '@/config/BasePath'
  import {getCodeList, getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      getCodeList('YC_BUSINESS_TYPE', (data) => {
        this.businessTypeGroup = data
      }) // 零售业态
      getCodeList('YC_GEO_TYPE', (data) => {
        this.geoTypeGroup = data
      }) // 市场类型
      getCodeList('YC_OPERATION_SCALE', (data) => {
        this.operationScaleGroup = data
      }) // 经营规模
      getCodeList('CUSTOMER_GRADE', (data) => {
        this.customerGradeGroup = data
      }) // 客户档级
    },
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        this.query(1, this.pageSize)
      }
    },
    data () {
      return {
        /** table **/
        columnType: 'selection',
        hasPagination: true,
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [10, 20, 40, 50, 100], // 分页数选择项
        totalCount: 0, // 表格总记录数
        customerGradeGroup: [],
        operationScaleGroup: [],
        geoTypeGroup: [],
        businessTypeGroup: [],
        Group: [],
        moreS: [
          {
            colunm: 'customerGrade',
            type: 'string'
          },
          {
            colunm: 'geoType',
            type: 'string'
          },
          {
            colunm: 'businessType',
            type: 'string'
          },
          {
            colunm: 'routeId',
            type: 'string'
          },
          {
            colunm: 'operationScale',
            type: 'string'
          }
        ],
        columnHeader: [
          {
            prop: 'customerCode', // 列的值
            label: '客户代码', // 列的显示字段
            columnsProps: {width: 140, align: 'center'}
          },
          {
            prop: 'customerDesc', // 列的值
            label: '客户名称', // 列的显示字段
            columnsProps: {width: 200, align: 'left'}
          },
          {
            prop: 'addr',
            label: '经验地址',
            columnsProps: {align: 'left'}
          },
          {
            prop: 'tel',
            label: '联系电话',
            columnsProps: {width: 140, align: 'center'}
          },
          {
            prop: 'marketmgrNm',
            label: '市场经理',
            columnsProps: {width: 120, align: 'center'}
          },
          {
            prop: 'custmgrNm',
            label: '客户经理',
            columnsProps: {width: 120, align: 'center'}
          }
        ],
        tableData: [],
        dataSource: [], // 当前页的数据
        /** filter **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['customerCode', 'customerDesc'],
        isMore: true,
        isSelect: true,
        keyupend: false,   // 输入筛选；true：之前展示；false：之后展示
        templTableData: [], // 临时记录tableDate的值
        btnGroups: [],
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        treeData: [],
        nodeKey: 'id',
        defaultCheckedKeys: [],
        isLoading: true
        /** 弹出层 **/
      }
    },
    methods: {
      getPage (page, size) {
        this.currentPage = page
        this.pageSize = size
        this.query(this.currentPage, this.pageSize)
      },
      query_New () {
        this.currentPage = '1'
        this.query(this.currentPage, this.pageSize)
      },
      query (pageNum, pageSize) {
        let param = {}
        if (Number(getUser().place) === 135) {
          param.custmgrId = getUser().personId
        } else if (Number(getUser().place) === 24) {
          param.marketmgrId = getUser().personId
        }
        for (let i = 0; i < this.moreS.length; i++) {
          param[this.moreS[i].colunm] = this.toMoreChange(this.dialogObj.data.form[this.moreS[i].colunm], this.moreS[i].type)
        }
        param.status = '1'
        param.pageSize = pageSize
        param.pageNum = pageNum
        console.log('param', JSON.stringify(param))
        api.requestJava('POST', BasePath.ACTIVITY_CUSTOMER_SELECT, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.dataSource = request.data.data
              this.totalCount = Number(request.data.count)
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询方法
      toMoreChange (values, type) {
        let result = ''
        for (let i = 0; i < values.length; i++) {
          if (type === 'int') {
            result = result + values[i] + ','
          } else if (type === 'string') {
            result = result + "'" + values[i] + "'" + ','
          }
        }
        if (result.length > 0) {
          result = result.substr(0, result.length - 1)
        }
        return result
      },
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = this.currentPage
        let size = this.pageSize
        this.dataSource = JSON.parse(val).filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      onendChange (val) {}, // 过滤器修改事件
      select (selection, index) {}, // 选中某1条
      selectAll (data) {}, // 全选
      headerClick (column, event) {},
      sortChange (msg) {},
      rowClick (msg) {},
      selectionChange (rows) {},
      addClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'update')
      },
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      },
      isMoreClk () {
        this.isSelect = !this.isSelect
      }
    },
    components: {
      _TABLE,
      _BTN_FILTER
    }
  }
</script>
<style scoped>
  .container-fluid_new {
    background: #FFF;
    margin: 0 5px 5px 5px;
  }
  .el-select {
    display: inline-block;
    position: relative;
    width: 92%;
  }
  .el-dialog__body {
    color: #48576a;
    font-size: 14px;
  }
  .form-group{
    margin-top: 13px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 12px 11px 0;
    box-sizing: border-box;
  }
  .label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 700;
  }
  .notice {
    font-size: medium;
    color: red;
    padding-left: 14px;
    padding-top: 11px;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-8 {
    height: 46px;
  }
  .el-col-2 {
    height: 61px;
  }
  .el-col-7 {
    height: 16px;
  }
  .el-col-15 {
    height: 61px;
  }
</style>

