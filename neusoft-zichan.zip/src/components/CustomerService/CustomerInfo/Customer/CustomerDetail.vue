<template>
  <div class="container-fluid_new">
    <el-form  label-width="100px" :model="custForm" ref="form" :rules="queryrules">
      <el-collapse>
        <el-collapse-item title="基础信息" name="1">
          <div>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="customerCode" label="客户代码:" class="wahaha">
                    <span class="notic">{{custForm.customerCode}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6'>
                  <el-form-item  prop="permitNo" label="许可证号:" >
                    <span class="notic">{{custForm.permitNo}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item  prop="customerGrade" label="客户档级:" >
                    <span class="notic">{{custForm.customerGrade}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="customerDesc" label="客户名称:" >
                    <span class="notic">{{custForm.customerDesc}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6'>
                  <el-form-item  prop="addr" label="地址:" >
                    <span class="notic">{{custForm.addr}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6'>
                  <el-form-item  prop="businessType" label="零售业态:" >
                    <span class="notic">{{custForm.businessType}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="tel" label="订货电话:" >
                    <span class="notic">{{custForm.tel}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6'>
                  <el-form-item  prop="contactpersonZipcode" label="邮政编码:" >
                    <span class="notic">{{custForm.contactpersonZipcode}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item  prop="geoType" label="市场类型:" >
                    <span class="notic">{{custForm.geoType}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="tradeCircleType" label="商圈类型:" >
                    <span class="notic">{{custForm.tradeCircleType}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item  prop="taxpayerType" label="纳税性质:" >
                    <span class="notic">{{custForm.taxpayerType}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="status" label="状态:">
                    <span class="notic">{{custForm.status}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item prop="isNight" label="是否夜店:">
                    <span class="notic">{{custForm.isNight}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="isChain" label="是否连锁:">
                    <span class="notic">{{custForm.isChain}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                    <el-form-item prop="reserveTag2" label="是否采集点:">
                    <span class="notic">{{custForm.reserveTag2}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
          </div>
        </el-collapse-item>
        <el-collapse-item title="网络信息" name="2">
          <div>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="sampleForm" label="出样能力:" class="wahaha">
                    <span class="notic">{{custForm.sampleForm}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6'>
                  <el-form-item  prop="visitBatch" label="拜访批次:" >
                    <span class="notic">{{custForm.visitBatch}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item  prop="delivererId" label="送货员:" >
                    <span class="notic">{{custForm.delivererId}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="networkedDate" label="入网时间:" >
                    <span class="notic">{{custForm.networkedDate}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6'>
                  <el-form-item  prop="registeredCapital" label="注册资金:" >
                    <span class="notic">{{custForm.registeredCapital}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6'>
                  <el-form-item  prop="institution" label="财务制度:" >
                    <span class="notic">{{custForm.institution}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="engageArea" label="经营面积:" >
                    <span class="notic">{{custForm.engageArea}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6'>
                  <el-form-item  prop="status" label="网点规模:" >
                    <span class="notic">{{custForm.status}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item  prop="regionalism" label="行政区划:" >
                    <span class="notic">{{custForm.regionalism}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
          </div>
        </el-collapse-item>
        <el-collapse-item title="管理信息" name="3">
          <div>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="legalPerson" label="法人:" >
                    <span class="notic">{{custForm.legalPerson}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6'>
                  <el-form-item  prop="licenseNo" label="营业执照:" >
                    <span class="notic">{{custForm.licenseNo}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item  prop="customerDesc" label="发证日期:" >
                    <span class="notic">{{custForm.issueDate}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="issueDate" label="有效日期:" >
                    <span class="notic">{{custForm.validDate}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item  prop="validDate" label="年审日期:" >
                    <span class="notic">{{custForm.annulDate}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6' >
                  <el-form-item prop="issuingAuthority" label="发证局:">
                    <span class="notic">{{custForm.issuingAuthority}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item prop="isNight" label="市管员:">
                    <span class="notic">{{custForm.isNight}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
          </div>
        </el-collapse-item>
        <!--<el-collapse-item title="销售信息" name="4">-->
          <!--<div>-->
            <!--<el-row>-->
              <!--<el-col :gutter="20">-->
                <!--<el-col :span='6'>-->
                  <!--<el-form-item  prop="salesEnvironmental" label="销售结构:" class="wahaha">-->
                    <!--<span class="notic">{{custForm.salesEnvironmental}}</span>-->
                  <!--</el-form-item>-->
                <!--</el-col>-->
                <!--<el-col :span='6'>-->
                  <!--<el-form-item  prop="totalLimit" label="总销量:" >-->
                    <!--<span class="notic">{{custForm.totalLimit}}</span>-->
                  <!--</el-form-item>-->
                <!--</el-col>-->
                <!--<el-col :span='6' >-->
                  <!--<el-form-item  prop="detailLimit" label="单品销量:" >-->
                    <!--<span class="notic">{{custForm.detailLimit}}</span>-->
                  <!--</el-form-item>-->
                <!--</el-col>-->
              <!--</el-col>-->
            <!--</el-row>-->
          <!--</div>-->
        <!--</el-collapse-item>-->
        <el-collapse-item title="形象信息" name="5">
          <div>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="custmgrId" label="客户经理:" class="wahaha">
                    <span class="notic">{{custForm.custmgrId}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='8'>
                  <el-form-item  prop="companyId" label="法人" align="center" >
                  </el-form-item>
                  <div id="uploadPic1">
                    <uploadTemp style="margin:20px;" :files="custForm.filesLegal" ref="uploadPicLegal"></uploadTemp>
                  </div>
                </el-col>
                <el-col :span='8'>
                  <el-form-item  prop="companyId" label="成列展柜" align="center" >
                  </el-form-item>
                  <div id="uploadPic2">
                    <uploadTemp style="margin:20px;" :files="custForm.filesDisplay" ref="uploadPicDisplay"></uploadTemp>
                  </div>
                </el-col>
                <el-col :span='8'>
                  <el-form-item  prop="companyId" label="店面" align="center" >
                  </el-form-item>
                  <div id="uploadPic3">
                    <uploadTemp style="margin:20px;" :files="custForm.filesStorefront" ref="uploadPicStorefront"></uploadTemp>
                  </div>
                </el-col>
              </el-col>
            </el-row>
          </div>
        </el-collapse-item>
        <el-collapse-item title="个人信息" name="6">
          <div>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="contactperson" label="联系人:" class="wahaha">
                    <span class="notic">{{custForm.contactperson}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6'>
                  <el-form-item  prop="tel" label="联系电话:" class="wahaha">
                    <span class="notic">{{custForm.tel}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6'>
                  <el-form-item  prop="mail" label="电子邮件:" class="wahaha">
                    <span class="notic">{{custForm.mail}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="birthDate" label="出生日期:" class="wahaha">
                    <span class="notic">{{custForm.birthDate}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6'>
                  <el-form-item  prop="degree" label="学历:" class="wahaha">
                    <span class="notic">{{custForm.degree}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6'>
                  <el-form-item  prop="hobby" label="爱好特长:" class="wahaha">
                    <span class="notic">{{custForm.hobby}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
          </div>
        </el-collapse-item>
        <el-collapse-item title="坐标" name="7">
          <div>
            <el-row>
              <el-col :gutter="20">
                <el-col :span='6'>
                  <el-form-item  prop="customerCode" label="x坐标:" class="wahaha">
                    <span class="notic">{{custForm.x}}</span>
                  </el-form-item>
                </el-col>
                <el-col :span='6'>
                  <el-form-item  prop="permitNo" label="y坐标:" >
                    <span class="notic">{{custForm.y}}</span>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
          </div>
        </el-collapse-item>
      </el-collapse>

    </el-form>
  </div>
</template>
<style scoped>
  .container-fluid_new {
    background: #FFF;
  }
  .el-col-20 {
    width: 83.33333%;
    height: 30px;
  }
  .el-col-10{
    height: 150px;
  }
  .el-col-6 {
    width: 33.33%;
    height: 30px;
  }
  .notic {
    margin-left: 0px!important;
  }
</style>
<script>
  import InputTemp from '@/components/Template/filter/InputTemp.vue'
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
  import DatePickerTemp from '@/components/Template/DatePicker/DatePickerTemp.vue'
  import compositeInput from '@/components/Template/Popup/compositeInput.vue'
  import { convertVal } from '@/utils/common'
  import api from '@/api'
//  import log from '@/log'
  import axios from 'axios'
  import {getCodeList, getUser} from '@/config/info'
  import BasePath from '@/config/BasePath'
  let token = localStorage.getItem('token') // 要保证取到
  export default {
    props: {
      custId: {
        type: String,
        default: ''
      }
    },
    name: 'accident',
    mounted () {
      getCodeList('YC_GEO_TYPE', (data) => {
        this.options_geoType = data
      }) // 市场类型
      getCodeList('YC_BUSINESS_TYPE', (data) => {
        this.options_businessType = data
      }) // 零售业态
      getCodeList('YC_OPERATION_SCALE', (data) => {
        this.options_operationScale = data
      }) // 经营规模
      getCodeList('YC_TRADE_CIRCLE_TYPE', (data) => {
        this.options_tradeCircleType = data
      }) // 商圈
      getCodeList('YC_CUST_SENDER_METHOD', (data) => {
        this.options_senderMethod = data
      }) // 送货方式
      getCodeList('YC_SENDER_TIME', (data) => {
        this.options_senderTime = data
      }) // 送货响应时间
      getCodeList('YC_PAYMENT_MODE', (data) => {
        this.options_paymentMode = data
      }) // 结算方式
      getCodeList('CUSTOMER_GROUP_TYPE', (data) => {
        this.options_groupType = data
      }) // 群体类型
      getCodeList('MAIN_FORMAT', (data) => {
        this.options_mainFormat = data
      }) // 主营业态
      getCodeList('ORDER_RATE', (data) => {
        this.options_orderRate = data
      }) // 订货频次
      getCodeList('CUSTOMER_GRADE', (data) => {
        this.options_customerGrade = data
      }) // 客户级别
      getCodeList('TAXPAYER_TYPE', (data) => {
        this.options_taxpayerType = data
      }) // 纳税人分类
      this.init(JSON.parse(this.custId))
    },
    data () {
      return {
        cust: {},
        custMgrIdGroup: [],
        orderSche: [],
        myHeaders: {Authorization: token},
        imgNum: 4,
        activeName: '1',
        rowId: '',
        custForm: {
          customerCode: '',
          customerDesc: '',
          shortCode: '',
          shortName: '',
          contactperson: '',
          tel: '',
          alternatePhone: '',
          addr: '',
          legalPerson: '',
          legalTel: '',
          nationalCode: '',
          postalCode: '',
          licenseNo: '',
          issueDate: '',
          validDate: '',
          annulDate: '',
          networkedDate: '',
          permitType: '',
          permitNo: '',
          monopolyAdm: '',
          regionalism: '',
          geoType: '',
          businessType: '',
          groupType: '',
          coagent: '',
          isLawful: '',
          svericeTel: '',
          mail: '',
          degree: '',
          birthDate: '',
          familySituation: '',
          homeAddr: '',
          hobby: '',
          status: '',
          companyId: '',
          countyId: '',
          marketOrg: '',
          thesystem: '',
          tradeCircleType: '',
          isChain: '',
          isNight: '',
          confiscateCustFlg: '',
          hours: '',
          terms: '',
          logoType: '',
          reserveType1: '',
          customerGrade: '',
          operationScale: '',
          totalLimit: '',
          detailLimit: '',
          engageArea: '',
          mainFormat: '',
          sampleForm: '',
          salesEnvironmental: '',
          shopPlace: '',
          displayInstallation: '',
          advertisementArea: '',
          operationAgeLimit: '',
          displayCapability: '',
          softwareCapability: '',
          recommendCapability: '',
          communicationCapability: '',
          contactpersonZipcode: '',
          communicateAddr: '',
          reserveTag1: '',
          seflCustFlg: '',
          funcCustFlg: '',
          reserveTag2: '',
          custmgrId: '',
          visitsalesmanId: '',
          orderMethod: '',
          orderRate: '',
          batchNo: '',
          appointedTime: '',
          orderSche: [],
          senderMethod: '',
          senderTime: '',
          deliveryAddr: '',
          routeId: '',
          deliveredOrd: '',
          delivererId: '',
          x: '',
          y: '',
          paymentMode: '',
          bankId: '',
          depositaryBank: '',
          cardOwner: '',
          accountNo: '',
          taxpayerType: '',
          invoiceType: '',
          customerLabel: '',
          taxNo: '',
          isAllowInq: '',
          reserveType4: '',
          visitCycle: '',
          visitBatch: '',
          qty1Limit: '',
          files1: [],
          files2: [],
          filesLegal: [],
          filesDisplay: [],
          filesStorefront: []
        },
        options_geoType: [],
        options_businessType: [],
        options_tradeCircleType: [],
        options_custmgrId: [],
        options_visitsalesmanId: [],
        options_senderMethod: [],
        options_senderTime: [],
        options_paymentMode: [],
        options_customerGrade: [],
        options_isNight: [
          {'value': '0', 'label': '否'},
          {'value': '1', 'label': '是'}
        ],
        options_isChain: [
          {'value': 'N', 'label': '否'},
          {'value': 'Y', 'label': '是'}
        ],
        options_reserveTag2: [
          {'value': '0', 'label': '否'},
          {'value': '1', 'label': '是'}
        ],
        options_status: [
          {'value': '0', 'label': '停用'},
          {'value': '1', 'label': '正常'}
        ],
        status: true,
        isChain: false,
        isNight: true,
        reserveTag1: false,
        seflCustFlg: true,
        funcCustFlg: false,
        reserveTag2: false,
        confiscateCustFlg: true,
        queryrules: {
          roleCode: [
            {required: true, message: '请输入角色代码', trigger: 'blur'}
          ],
          roleName: [
            {required: true, message: '请输入角色名称', trigger: 'blur'}
          ]
        },
        imageUrl: '',
        date: 'date'
      }
    },
    methods: {
      init (val) {
        this.customerCode = ''
        this.customerDesc = ''
        this.shortCode = ''
        Object.assign(this.custForm, val)
        this.custForm.businessType = convertVal(this.options_businessType, val.businessType, 'value', 'label')
        this.custForm.tradeCircleType = convertVal(this.options_tradeCircleType, val.tradeCircleType, 'value', 'label')
        this.custForm.customerGrade = convertVal(this.options_customerGrade, val.customerGrade, 'value', 'label')
        this.custForm.geoType = convertVal(this.options_geoType, val.geoType, 'value', 'label')
        this.custForm.taxpayerType = convertVal(this.options_taxpayerType, val.taxpayerType, 'value', 'label')
        this.custForm.isNight = convertVal(this.options_isNight, val.isNight, 'value', 'label')
        this.custForm.isChain = convertVal(this.options_isChain, val.isChain, 'value', 'label')
        this.custForm.reserveTag2 = convertVal(this.options_reserveTag2, val.reserveTag2, 'value', 'label')
        this.custForm.status = convertVal(this.options_status, val.status, 'value', 'label')
        let tempfiles = val.files
        console.log('查看：' + JSON.stringify(val))
        var i = 0
        tempfiles.forEach((e) => {
          if (tempfiles[i].fileType === 'legal_attach_photo') {
            this.custForm.filesLegal.push(tempfiles[i])
          }
          if (tempfiles[i].fileType === 'display_attach_photo') {
            this.custForm.filesDisplay.push(tempfiles[i])
          }
          if (tempfiles[i].fileType === 'storeFront_attach_photo') {
            this.custForm.filesStorefront.push(tempfiles[i])
          }
          i++
        })
        this.changeCus(val.custmgrId)
      },
      changeCus (custmgrId) {
        let params1 = {}
        params1.companyId = getUser().companyId
        params1.place = '135'
        params1.status = 1
        axios.all([
          api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params1)
        ])
        .then(axios.spread((first) => {
          this.custMgrIdGroup = JSON.parse(JSON.stringify(first.data.data))
          this.custForm.custmgrId = convertVal(this.custMgrIdGroup, custmgrId, 'rowId', 'employeeName')
        }))
      },
      startTime () {}
    },
    queryrules: {
    },
    components: {
      InputTemp, DatePickerTemp, uploadTemp, compositeInput
    },
    watch: {
      custId (val, old) {
        this.init(JSON.parse(val))
      }
    }
  }
</script>
