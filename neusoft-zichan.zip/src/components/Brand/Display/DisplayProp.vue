<template>
  <div>
    <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="closeModalEve" :size='dialogObj.size' v-popupdra-directive="{'show': dialogObj.dialogVisible}">
      <div v-if="dialogObj.type == 'editUser'">
        <el-form :model="dialogObj.data.form" :rules="addrules" ref="editForm" label-width="100px">
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="uploadDate" label="提报日期">
                  <el-input v-model="dialogObj.data.form.uploadDate" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item  prop="putterNm" label="提报人" >
                  <el-input v-model="dialogObj.data.form.putterNm" :disabled="true"></el-input>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="customerCode" label="客户代码">
                  <el-input v-model="dialogObj.data.form.customerCode" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item prop="customerDesc" label="客户名称">
                  <el-input v-model="dialogObj.data.form.customerDesc" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='24'>
                <el-form-item label="陈列描述">
                  <el-input type="textarea" v-model="dialogObj.data.form.descText"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='24'>
                <template v-for="item in dialogObj.data.form.files">
                  <img v-bind:src="gatherer+item.fileData" height="160"  style="margin-left: 30px;"/>
                </template>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item  prop="endDate" label="审核日期">
                  <el-input v-model="dialogObj.data.form.endDate" auto-complete="off" :disabled="true" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <template>
                  <el-radio-group v-model="dialogObj.data.form.status" style="margin-left: 100px;">
                    <el-radio :label="2">同意</el-radio>
                    <el-radio :label="3">不同意</el-radio>
                  </el-radio-group>
                </template>
              </el-col>
            </el-col>
          </el-row>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='24'>
                <el-form-item label="审核意见">
                  <el-input type="textarea" v-model="dialogObj.data.form.opinions"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
        </el-form>
        <div slot="footer" class="dialog-footer" style="text-align: right">
          <el-button @click="resetForm('editForm')">取 消</el-button>
          <el-button type="success" @click="editSubmitForm('editForm')">确 定</el-button>
        </div>
      </div>
      <div v-if="dialogObj.type == 'updateUser'">
        <el-form :model="dialogObj.data.form" :rules="addrules" ref="editForm" label-width="100px">
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="uploadDate" label="提报日期">
                  <el-input v-model="dialogObj.data.form.uploadDate" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item  prop="putterNm" label="提报人" >
                  <el-input v-model="dialogObj.data.form.putterNm" :disabled="true"></el-input>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="customerCode" label="客户代码">
                  <el-input v-model="dialogObj.data.form.customerCode" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item prop="customerDesc" label="客户名称">
                  <el-input v-model="dialogObj.data.form.customerDesc" :disabled="true"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='24'>
                <el-form-item label="陈列描述">
                  <el-input type="textarea" v-model="dialogObj.data.form.descText"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='24'>
                <template v-for="item in dialogObj.data.form.files">
                  <img v-bind:src="gatherer+item.fileData" height="160" style="margin-left: 30px;"/>
                </template>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item  prop="checkDate" label="审核日期" >
                  <el-input v-model="dialogObj.data.form.checkDate" auto-complete="off" :disabled="true" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <template>
                  <el-radio-group v-model="radio2" style="margin-left: 100px;">
                    <el-radio :label="2">同意</el-radio>
                    <el-radio :label="3">不同意</el-radio>
                  </el-radio-group>
                </template>
              </el-col>
            </el-col>
          </el-row>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='24'>
                <el-form-item label="审核意见">
                  <el-input type="textarea" v-model="dialogObj.data.form.opinions"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
        </el-form>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import InputTemp from '@/components/Template/filter/InputTemp.vue'
  import DatePickerTemp from '@/components/Template/DatePicker/DatePickerTemp.vue'
  import config from '@/config'
  import {getUser} from '@/config/info'
  export default {
    mounted () {
//      this.gatherer = config.FILE_ADDR
//      console.log('下标：', Number(this.dialogObj.data.form.status))
//      console.log('我的radio2的值：', this.radio2)
    },
    props: ['dialogObj'],
    updated () {
      this.radio2 = Number(this.dialogObj.data.form.status)
//      console.log('下标：', Number(this.dialogObj.data.form.status))
//      console.log('我的radio2的值：', this.radio2)
    },
    data () {
      return {
        radio2: '',
        gatherer: config.FILE_ADDR,
        dialogVisible: false,
        formLabelWidth: '120px',
        filmode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤
        fileName: ['value'],
        filType: 0, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        keyup: true, // 输入筛选；true：之前展示；false：之后展示
        tableData: [],
        optionsManager: [],
        deptIdGroup: [],
        addrules: {
//          tel: [
//            {validator: checkeTel, trigger: 'blur'}
//          ]
        }
      }
    },
    methods: {
      editSubmitForm (formName) {
        if (this.dialogObj.data.form.status !== '1') {
          this.dialogObj.data.form.checkerId = getUser().personId
          this.dialogObj.data.form.checkerNm = getUser().userName
          this.dialogObj.data.form.opinions
          this.dialogObj.data.form.stauts
          this.dialogObj.data.form.checkDate = this.dialogObj.data.form.endDate
          this.$refs[formName].validate((valid) => {
            if (valid) {
              // this.$refs.uploadTemp.submitUpload()
              this.dialogObj.dialogVisible = false
              this.$emit('confirmBack', this.dialogObj)
              setTimeout(() => {
                this.$refs[formName].resetFields()
              }, 1000)
            } else {
              console.log('error submit!!')
              return false
            }
          })
        }
      },
      closeModalEve () {
        this.$emit('confirmBack', false)
        this.dialogObj.dialogVisible = false
        this.valcomp = this.valdevp = ''
      },
      resetForm (formName) {
        if (this.dialogObj.type === 'editUser') {
          this.$emit('confirmBack', false)
          this.dialogObj.dialogVisible = false
          this.valcomp = this.valdevp = ''
        } else {
          this.$refs[formName].resetFields()
          this.$emit('confirmBack', false)
          this.dialogObj.dialogVisible = false
          this.valcomp = this.valdevp = ''
        }
      },
      startTime (val) {
        this.dialogObj.data.form.date = val
      }
    },
    components: {
      InputTemp,
      DatePickerTemp
    }
  }
</script>
