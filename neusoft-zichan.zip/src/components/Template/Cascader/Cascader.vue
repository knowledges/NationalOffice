/**
*                    _ooOoo_
*                   o8888888o
*                   88" . "88
*                   (| -_- |)
*                    O\ = /O
*                ____/`---'\____
*              .   ' \\| |// `.
*               / \\||| : |||// \
*             / _||||| -:- |||||- \
*               | | \\\ - /// | |
*             | \_| ''\---/'' | |
*              \ .-\__ `-` ___/-. /
*           ___`. .' /--.--\ `. . __
*        ."" '< `.___\_<|>_/___.' >'"".
*       | | : `- \`.;`\ _ /`;.`/ - ` : | |
*         \ \ `-. \_ __\ /__ _/ .-` / /
* ======`-.____`-.___\_____/___.-`____.-'======
*                    `=---='
*
* .............................................
*          佛祖保佑             永无BUG
*  佛曰:
*          写字楼里写字间，写字间里程序员；
*          程序人员写程序，又拿程序换酒钱。
*          酒醒只在网上坐，酒醉还来网下眠；
*          酒醉酒醒日复日，网上网下年复年。
*          但愿老死电脑间，不愿鞠躬老板前；
*          奔驰宝马贵者趣，公交自行程序员。
*          别人笑我忒疯癫，我笑自己命太贱；
*          不见满街漂亮妹，哪个归得程序员？
*/
<!--qiu.bl-->
<style rel="stylesheet/scss" lang="scss" scoped>
  .container-fluid {
    margin-top: 5%!important;
  }
</style>
<template>
  <el-cascader
    v-model="selected"
    :options="options"
    change-on-select
    :clearable="true"
    :filterable=true
    @change="cascaderChange"
  ></el-cascader>
</template>
<script>
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  export default {
    name: '',
    props: ['selectOption'],
    mounted () {
      this.init()
      this.selected = this.selectOption
    },
    data () {
      return {
        selected: [],
        options: []
      }
    },
    methods: {
      init () {
        let params = {}
        api.requestJava('POST', BasePath.EMPLOYEE_COMPANY_TREE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              var array = request.data.data.children
              /*
               * 1. 等级（getUser().unitLevel） == 1 展示所有
               * 2. 等级 == 2 && countyId == '' || null  展示该市下的所有分公司
               * 3. 等级 == 2 && countyId != '' && deptId == '' || null && place == 9999 展示该市下的具体分公司的所有市场经理
               * 4. 等级 == 2 && countyId != '' && deptId != '' && place == 24 展示该市场经理下的所有客户经理
               * 5. place == 135 展示自己
               * */
              if (Number(getUser().unitLevel) === 1) { // 展示所有
                this.options = array
              } else if (Number(getUser().unitLevel) === 2) { // 展示该市下的所有分公司
                if (getUser().countyId === 'null') {
                  this.recursionMth(array, getUser().companyId)
                } else if (getUser().countyId !== 'null' && Number(getUser().place) === 9999) {
                  this.recursionMth(array, getUser().countyId)
                } else if (getUser().countyId !== 'null' && getUser().deptId !== 'null' && Number(getUser().place) === 24) {
                  this.recursionMth(array, getUser().personId)
                } else if (Number(getUser().place) === 135) {
                  this.recursionMth(array, getUser().personId)
                }
              }
              this.$emit('on-loading', this.options)
            }
          })
      },
      recursionMth (data, condition) {
        data.forEach((val, key) => {
          if (val.children && val.children.length > 0) {
            this.recursionMth(val.children, condition)
          }
          /* 字符串比较 */
          if (val.id === condition) {
            if (val.children) {
              this.options = val.children
            } else {
              var tmp = []
              tmp.push(val)
              this.options = tmp
            }
          }
        })
      },
      cascaderChange (val) {
        this.$emit('on-change', val)
      }
    },
    components: {},
    watch: {
      selectOption (val, old) {
        this.selected = val
      }
    }
  }
</script>
