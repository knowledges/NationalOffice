/**
 * 懒加载baidu api 库
 * @param ak 百度key
 * @returns {Promise} 百度实例
 * @constructor
 */
import config from '@/config'
export function MP (ak) {
  return new Promise(function (resolve, reject) {
    window.init = function () {
      var script0 = document.createElement('script')
      script0.type = 'text/javascript'
      script0.src = config.root + `/static/js/plugins/Map/TextIconOverlay.js`
      script0.onerror = reject
      document.head.appendChild(script0)

      var script1 = document.createElement('script')
      script1.type = 'text/javascript'
      script1.src = config.root + `/static/js/plugins/Map/MarkerClusterer.js`
      script1.onerror = reject
      document.head.appendChild(script1)
      resolve(BMap)
    }
    window.onload = function () {
      var script0 = document.createElement('script')
      script0.type = 'text/javascript'
      script0.src = config.root + `/static/js/plugins/Map/TextIconOverlay.js`
      script0.onerror = reject
      document.head.appendChild(script0)

      var script1 = document.createElement('script')
      script1.type = 'text/javascript'
      script1.src = config.root + `/static/js/plugins/Map/MarkerClusterer.js`
      script1.onerror = reject
      document.head.appendChild(script1)
      resolve(BMap)
    }
    var script = document.createElement('script')
    // script.async = true
    script.type = 'text/javascript'
    script.src = 'http://api.map.baidu.com/api?v=2.0&ak=' + ak + '&callback=init'
    script.onerror = reject
    document.head.appendChild(script)
  })
}

/**
 * 聚合加载JS
 * @returns {Promise}
 */
export function polymerization () {
  return new Promise(function (resolve, reject) {
    var script1 = document.createElement('script')
    script1.type = 'text/javascript'
    script1.src = 'http://api.map.baidu.com/library/MarkerClusterer/1.2/src/MarkerClusterer.js'
    script1.onerror = reject
    document.head.appendChild(script1)
    resolve(BMapLib)
  })
}

/**
 * 显示地图
 * @param map 当前地图实例
 * @param params 显示地图坐标
 * @constructor
 */
export function ShowMap (map, params, zoom) {
  try {
    map.centerAndZoom(new BMap.Point(params.lng, params.lat), zoom)
    map.enableScrollWheelZoom()
    map.addControl(new BMap.NavigationControl())
    map.addControl(new BMap.ScaleControl())
    map.addControl(new BMap.OverviewMapControl())
    // map.addEventListener('tilesloaded', () => { console.log('地图加载完毕！！！') })
  } catch (e) {
    console.log(e)
  }
}

/**
 * 根据 ip 获取 经纬度
 * @param callback
 */
export function getCityShowMap (callback) {
  let myCity = new BMap.LocalCity()
  myCity.get((result) => {
    if (typeof callback === 'function') {
      callback(result)
    }
  })
}

/**
 * 创建批注
 * @param map 地图实例
 * @param params 地图坐标
 * @param isUpdateIcon 是否修改默认 icon
 * @param iconCoor 图标坐标
 * @param labCoor label偏移位置
 * @param styleObj label样式
 */
export function createMarker (map, params, isUpdateIcon, iconCoor, imgUrl, labCoor, styleObj) {
  let points = new BMap.Point(params.lng, params.lat)
  let marker = null
  /* 替换图标 */
  if (isUpdateIcon) {
    let icon = new BMap.Icon(imgUrl, new BMap.Size(iconCoor[0].x, iconCoor[0].y), {
      anchor: new BMap.Size(iconCoor[1].x, iconCoor[1].y)
    })
    marker = new BMap.Marker(points, {icon: icon})
  } else {
    marker = new BMap.Marker(points)
  }
  let label = new BMap.Label(params.name, {offset: new BMap.Size(labCoor.x, labCoor.y)})
  label.setStyle(styleObj)
  map.addOverlay(marker)
  marker.setLabel(label)
}

/**
 * 画直线
 * @param start 起始坐标经纬度
 * @param end 终点坐标经纬度
 */
export function drawLine (map, start, end) {
  let startPoint = new BMap.Point(start.lng, start.lat)
  let endPoint = new BMap.Point(end.lng, end.lat)
  let polyline = new BMap.Polyline([startPoint, endPoint], {strokeColor: '#2e85fc', strokeWeight: 2, strokeOpacity: 1})  // 定义折线
  map.addOverlay(polyline)     // 添加折线到地图上
}
/**
 * 计算距离
 */
export function calcDis (map, positionAX, positionAY, positionBX, positionBY) {
  var pointA = new BMap.Point(positionAX, positionAY)
  var pointB = new BMap.Point(positionBX, positionBY)
  return (map.getDistance(pointA, pointB)).toFixed(2)
}
