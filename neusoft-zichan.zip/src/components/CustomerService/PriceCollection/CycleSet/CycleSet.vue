<template>
  <div class="container-fluid" id="app">
          <simple-fullcalendar :events="events" @timeRangeSelected="addEvent2Events"   @confirmBack="editEve" ></simple-fullcalendar>
  </div>
</template>

<script>
import moment from 'moment'
import { dateFormat } from '@/utils/dateFormat.js'
import api from '@/api'
import log from '@/log'
import BasePath from '@/config/BasePath'
import simpleFullcalendar from '@/components/CustomerService/PriceCollection/CycleSet/simple-fullcalendar'
import {getUser} from '@/config/info'
const FORMATTER = 'YYYY-MM-DD'
let TODAY = moment()
export default {
  name: 'app',
  components: {
    simpleFullcalendar
  },
  mounted () {
//    this.query(new Date().getFullYear(), (new Date().getMonth()) + 1)
  },
  data () {
    return {
      cache: {
        start: '',
        end: '',
        content: ''
      },
      events: [],
      weekDays: ['N', 'N', 'N', 'N', 'N', 'N', 'N'],
      today: TODAY.format(FORMATTER)
    }
  },
  methods: {
    editEve (msg) {
      if (msg === 'update') {
        this.saveUpper()
      } else {
        let year = msg.split('-')[0]
        let month = msg.split('-')[1]
        this.query(year, year + '' + month)
      }
    }, // 修改事件
    clearCache () {
      this.cache.start = ''
      this.cache.end = ''
      this.cache.content = ''
    },
    removeEvent (index) {
      this.events.splice(index, 1)
    },
    getNowTime () {
      return dateFormat(new Date().getTime(), 'YYYY-MM-DD')
    },
    addEvent2Events (event) {
      let start = event.start
      let end = Number(event.end)
      if (Number(end) === 1) {
        if (start < this.getNowTime()) {
          return
        }
        for (let i = 0; i < this.events.length; i++) {
          // alert(start)
          if (start === this.events[i].calDate) {
            if (this.events[i].target === 'Y') {
              this.events[i].target = 'N'
            } else {
              this.events[i].target = 'Y'
            }
          }
        }
      } else {
        if (this.weekDays[end] === 'Y') {
          this.weekDays[end] = 'N'
        } else {
          this.weekDays[end] = 'Y'
        }
        for (let i = 0; i < this.events.length; i++) {
          if (start === new Date(this.events[i].calDate).getDay()) {
            if (this.events[i].calDate >= this.getNowTime()) {
              this.events[i].target = this.weekDays[end]
            }
          }
        }
      }
    },
    query (year, month) {
      let params = {}
      params.companyId = getUser().companyId
      params.bizYear = year
      params.bizMonth = month
      this.queryUpper(params)
    },
    queryUpper (params) {
      params.fields = {include: 'bizDateId,bizYear,bizTendays,tagOther,festivals,bizWeek,bizQuarter,bizHalfyear,orgRoleId,bizMonth,rowId,target,companyId,isDelivery,isOffday,calDate,isOrder,remarks,status'}
      console.log('params:' + JSON.stringify(params))
      api.requestJava('POST', BasePath.JOBSET_SELECT, params)
        .then((request) => {
          if (Number(request.data.code) === 200) {
            this.events = request.data.data
          } else if (Number(request.data.code) === 401) {
            this.$message('登录失效')
            this.logInvalid.dialogVisible = true
          } else {
            this.$notify.error({title: '提示', message: request.data.message})
            throw new Error(JSON.stringify(request))
          }
        })
        .catch((err) => {
          let culprit = this.$route.name
          // this.toggleLoading()
          log.work(err, culprit)
        })
    }, // 查询接口
    saveUpper () {
      let params = this.events
      console.log('params_save', JSON.stringify(params))
      api.requestJava('POST', BasePath.JOBSET_UPDATE, params)
        .then((request) => {
          if (Number(request.data.code) === 200) {
            this.$notify({title: '成功', message: '保存成功', type: 'success'})
//            this.query()
          } else if (Number(request.data.code) === 401) {
            this.$message('登录失效')
            this.logInvalid.dialogVisible = true
          } else {
            this.$notify.error({ title: '提示', message: request.data.message })
            throw new Error(JSON.stringify(request))
          }
        })
        .catch((err) => {
          let culprit = this.$route.name
          log.work(err, culprit)
        })
    } // 保存
  }
}
</script>
<style scoped rel="stylesheet/scss" lang="scss">
  #app{
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #2c3e50;
  }
  .moveCust {
    height: 590px;
    background-color: white;
  }
  .grid-content {
    border-radius: 4px;
    min-height: 36px;
    box-shadow: 1px 1px 4px #ccc;
    height: 590px;
  }
  .header {
    text-align: center
  }
  .events-list {
    width: 100%;
    margin: 0 auto;
  }
  .cust_row_l{
    position: absolute;
    top:0;
    left: 10px;
    z-index:9;
    width: 315px;
    border: none;
  }
  .cust_btn_box {
    box-shadow: 2px 3px 6px #666;
    padding: 0!important;
  }
  .cust_btn_l{
    background: #fff;
    border-radius: 50%;
    box-shadow: 2px 2px 5px #999;
    position: absolute;
    top: 50%;
    left: 0;
    margin-top: -18px;
  }
  .moveL-enter-active {
    animation: moveL-in .5s;
  }
  .moveL-leave-active {
    animation: moveL-in .5s reverse;
  }
  @keyframes moveL-in {
    0% {
      transform: translate(-315px, 0px);
    }
    80% {
      transform: translate(25px, 0px);
    }
    100% {
      transform: translate(-5px, 0px);
    }
  }
</style>
