<style scoped>
  .cust_tboy {
    line-height: 45px;
  }
  .cust_tboy_lab {
    margin-right: 12px;
  }
</style>
<template>
  <li class="li_surveyQuItemBody surveyQu_1" style="">
    <div class="surveyQuItemBody">
      <div class="initLine"></div>
      <div class="quInputCase" style="display: none;">
        <input type="hidden" name="quType" value="SCORE" />
        <input type="hidden" name="quId" :value="BTable.itemCode" />
        <input type="hidden" name="orderById" :value="BTable.rowId + 1" />
        <input type="hidden" name="saveTag" value="1" />
        <input type="hidden" name="hoverTag" value="0" />
        <input type="hidden" name="isRequired" :value="BTable.mustFlag" />
        <input type="hidden" name="hv" value="2" />
        <input type="hidden" name="randOrder" value="0" />
        <input type="hidden" name="cellCount" value="0" />
        <div class="quLogicInputCase">
          <input type="hidden" name="quLogicItemNum" value="0" />
        </div>
      </div>
      <div class="surveyQuItem">
        <div class="surveyQuItemContent">
          <div class="quCoTitle">
            <div class="quCoNum">
              {{BTable.sortNbr}}、
            </div>
            <div class="editAble quCoTitleEdit">
              {{BTable.title}} <span v-if="Basics.mustFlag == 1">（此题必答）</span>
            </div>
            <input type="hidden" name="quTitleSaveTag" value="1" />
          </div>
          <div class="quCoItem">
            <template v-if="BTable.inputType == '多项填空题'">
              <table class="mFillblankTable" cellpadding="0" cellspacing="0">
                <template v-for="item in BTable.quItems">
                  <tbody class="cust_tboy">
                  <tr class="mFillblankTableTr">
                    <td align="right" class="mFillblankTableEditTd">
                      <label class="editAble quCoOptionEdit cust_tboy_lab">{{item.listTitle}}</label>
                    </td>
                    <td>
                      <el-input @change="handleChange(item.values, item, BTable.itemCode)"
                                v-model="item.values == '' ? item.values = null : item.values"
                                placeholder="请输入内容" style="width:300px;"></el-input>
                    </td>
                  </tr>
                  </tbody>
                </template>
              </table>
            </template>
            <template v-else="BTable.inputType == 'score'">
              <table class="quCoItemTable" cellpadding="0" cellspacing="0">
                <template v-for="(item, key) in BTable.enumList">
                  <tbody>
                  <tr class="quScoreOptionTr">
                    <td class="quCoItemTableTd quOptionEditTd">
                      <label class="editAble quCoOptionEdit">{{item.listTitle}}</label>
                    </td>
                    <td class="quCoItemTableTd">
                      <el-rate
                        @change="handleChange(item.val, item, BTable.itemCode)"
                        v-model="item.val == '' ? item.val = null : item.val"
                        :colors="['#99A9BF', '#F7BA2A', '#FF9900']">
                      </el-rate>
                    </td>
                    <td class="quCoItemTableTd">{{item.val}} 分</td>
                  </tr>
                  </tbody>
                </template>
              </table>
            </template>
          </div>
        </div>
      </div>
    </div>
  </li>
</template>
<script>
  export default {
    props: ['BTable'],
    name: 'Rate',
    mounted () {},
    data () {
      return {}
    },
    methods: {
      handleChange (val, obj, key) {
        for (let i in this.$parent.subParams) {
          let ele = this.$parent.subParams[i]
          if (ele.key === key) {
            let params = {}
            params.itemCode = key
            params.enumitemIdr = obj.rowId
            params.valus = val
            /* 判断数组是否存为空 */
            if (ele.val.length > 0) {
              for (let j in ele.val) {
                /* 判断数组是否存此数据 */
                if (ele.val[j].enumitemIdr === obj.rowId) {
                  /* 存在的值替换已经修改的值 */
                  ele.val.splice(Number(j), 1, params)
                } else {
                  ele.val.push(params)
                }
              }
            } else {
              ele.val.push(params)
            }
          }
        }
      }
    }
  }
</script>
