<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-col :gutter="24">
        <el-col :span='24'>
          <el-form-item label="应用名称">
            <el-input v-model="dialogObj.data.form.name"  :disabled="true"></el-input>
          </el-form-item>
        </el-col>
      </el-col>
      <el-col :gutter="24">
        <el-col :span='12'>
          <el-form-item label="版本号">
            <el-input v-model="dialogObj.data.form.ver"  @change="clear()"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span='12'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <i class="fa fa-cog fa-spin" @click="chuckCus()" ></i>&nbsp;&nbsp;<span class="notice" @click="chuckCus()">回退历史版本</span>
        </el-col>
      </el-col>
      <el-col :gutter="24">
        <el-col :span='24'>
          <el-form-item label="备注"  >
            <el-input type="textarea" resize="none" v-model="dialogObj.data.form.notes" ></el-input>
          </el-form-item>
        </el-col>
      </el-col>
        <el-col :gutter="24">
          <el-col :span='24'>
            <el-form-item label="文件上传">
              <uploadTemp style="margin:7px;" :files="dialogObj.data.form.files" ref="uploadPic"></uploadTemp>
            </el-form-item>
          </el-col>
        </el-col>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
      <el-button type="success" @click="updateClk('addForm')" >保存</el-button>
      <el-button type="success" @click="upClk('addForm')" >确认回滚</el-button>
    </div>
  </el-dialog>
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve" @backUrl="openImg" />
  </div>
</template>

<script>
//  import api from '@/api'
//  import axios from 'axios'
  import MY_POPUP_CONFIG from './LogPopup.vue'
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
//  import BasePath from '@/config/BasePath'
//  import {getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
    },
    data () {
      return {
        files: [],
        matterIdGroup: [],
        stepIdsGroup: [],
        refGroup: [],
        addrules: {},
        edit: {
          title: '应用发布',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              rowId: '',
              name: '',
              appName: '',
              ver: '',
              releaseTime: '',
              appPath: '',
              notes: '',
              status: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: '',
              files: []
            }
          }
        }
      }
    },
    methods: {
      clear () {
        this.dialogObj.data.form.files = []
      },
      chuckCus () {
        this.edit.data.form.appName = this.dialogObj.data.form.appName
        this.edit.dialogVisible = true
      },
      editEve (msg) {
        if (msg === 'update') {
          this.dialogObj.data.form.ver = this.edit.data.form.ver
          this.dialogObj.data.form.appPath = this.edit.data.form.appPath
          this.dialogObj.data.form.files = this.edit.data.form.files
        }
        this.edit.dialogVisible = false
        let tmp = {
          title: '应用发布',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              rowId: '',
              name: '',
              appName: '',
              ver: '',
              releaseTime: '',
              appPath: '',
              notes: '',
              status: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: '',
              files: []
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      openImg (msg) {
        alert('获取open 里参数', msg)
      },
      _upload_submit () {
        this.$refs.uploadTemp.submitUpload()
      },
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      },
      updateClk (formName) {
        if (this.dialogObj.data.form.ver === this.dialogObj.data.form.old) {
          this.$message({type: 'info', message: '请修改版本号!'})
          return
        }
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dialogObj.data.form.files = this.$refs.uploadPic.getFiles()
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      upClk (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$emit('confirmBack', 'roleback')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      }
    },
    components: {
      uploadTemp,
      MY_POPUP_CONFIG
    }
  }
</script>
<style scoped>
  .el-form-item {
    margin-bottom: 15px;
  }
  .el-dialog__body {
    padding: 12px 20px;
    color: #48576a;
    font-size: 14px;
    height: 490px;
  }
  .el-select {
    display: inline-block;
    position: relative;
    width: 60%;
  }
  .el-dialog__body {
    color: #48576a;
    font-size: 14px;
  }
  .fa-cog{
    color: #7f9eeb;
    font-size: 21px;
  }
  .notice{
    color: #7f9eeb;
    font-size: 16px;
  }
</style>
