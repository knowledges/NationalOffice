<!--qiu.bl-->
<style rel="stylesheet/scss" lang="scss" scoped>
  .containers {
    margin: 0 5px 5px 5px!important;
    padding-top: 50px;
  }
  .lab {
    display: inline-block;
    background: #FFF;
    width: 100%;
  }
  .lab-top {
    padding: 5px 28px;
    border-bottom: 1px solid #CCC;
    h4 {
      font-size: 14px;
      font-weight: 700;
      display: inline-block;
      width: 70%;
      float: left;
      height: 35px;
      line-height: 35px;
    }
    button {
      float: right;
      margin-right: -15px;
      height: 30px;
      line-height: 10px;
      margin-top: 3px;
    }
  }
  .lab-bottom {
    padding: 0 15px;
    ul {
      li {
        float: left;
        width: 23%;
        height: 90px;
        border: 1px solid #ebebeb;
        border-radius: 4px;
        box-shadow: 2px 2px 5px #ccc;
        margin-left: 10px;
        margin-top: 10px;
        margin-bottom: 10px;
        p {
          font-size: 16px;
          text-align: center;
          margin: 10px 0;
        }
        .lab-num {
          font-size: 18px;
          color: #60b478;
        }
      }
    }
    span{
      padding: 4px 0;
      font-size: 14px;
    }
    .lab-bottom-left {
      display: inline-block;
      width: 105px;
      text-align: right;
    }
    .lab-bottom-right {
      margin-left: 2px;
      color: #0eb63f;
    }
  }
  .lab-Occ {
    height: 175px;
    ul {
      display: inline-block;
      width: 100%;
      padding: 10px 0px;
      li {
        float: left;
        display: inline-block;
        width: calc(100% / 6);
        height: 30px;
        line-height: 30px;
        text-align: center;
        font-size: 15px;
      }
    }
    ul:nth-child(2), ul:nth-child(3) {
      padding: 5px 0;
    }
  }
  .lab-Con {
    height: 175px;
    overflow-y: scroll;
    ul {
      display: inline-block;
      width: 100%;
      padding: 10px 0px;
      li {
        float: left;
        display: inline-block;
        width: calc((100% - 180px) / 5);
        height: 30px;
        line-height: 30px;
        text-align: center;
        font-size:15px;
      }
      li:nth-child(1) {
        width: 180px;
        color: #60b478;
      }
    }
    .ul_li {
      padding: 0 0;
      margin-top: -5px
    }
  }
  .green{
    color: #60b478;
  }
  .lab-Con-title {
    background: #f7f7f7;
  }
  .lab-chars {
    display: inline-block;
    height: 250px;
    width: 100%;
    background: #FFF;
    overflow-x: scroll;
  }
  .lab-btn {
    padding: 5px;
    position: absolute;
    top: 40px;
    z-index: 9999;
    li {
      float: left;
      margin-right: 5px;
    }
  }
  .left {
    padding-right: 2px!important;
  }
  .right {
    padding-left: 2px!important;
  }
  .isEmply {
    text-align: center;
    margin-top: 50px;
  }
  .atvicd {
     color: rgb(29, 144, 230);
     border-color: rgb(29, 144, 230);
     outline: 0px;
  }
</style>
<template>
    <div class="containers">
      <el-row :gutter="24" style="margin-top: -6px;">
        <el-col :span="12" class="left">
          <div class="lab" style="height: 158px!important;">
            <div class="lab-top clearfix">
              <h4 class="">预警监控</h4>
              <el-button @click="$router.push('/WarningInfoDeal')">更多</el-button>
            </div>
            <div class="lab-bottom">
              <ul>
                <li v-for="(item, key) in warnDate">
                  <p>{{item.name}}</p>
                  <p class="lab-num">{{item.count}}个</p>
                </li>
              </ul>
              <p v-if="warnDate.length<=0" class="isEmply">数据搜索中...</p>
            </div>
          </div>
        </el-col>
        <el-col :span="12" class="right">
          <div class="lab" style="height: 158px!important;">
            <div class="lab-top clearfix">
              <h4 class="">拜访统计</h4>
              <el-button @click="$router.push('/ReportVisitStatistics')">更多</el-button>
            </div>
            <div class="lab-bottom" style="padding: 11px 15px;">
              <el-row :gutter="24">
                <el-col :span="8">
                  <span class="lab-bottom-left">总客户数量</span>
                  <span class="lab-bottom-right">{{visit.custSum != 'null' ? visit.custSum : '/'}}</span>
                </el-col>
                <el-col :span="8">
                  <span class="lab-bottom-left">未拜访</span>
                  <span class="lab-bottom-right">{{visit.unfinVisit != 'null' ? visit.unfinVisit : '/'}}</span>
                </el-col>
                <el-col :span="8">
                  <span class="lab-bottom-left">服务项目</span>
                  <span class="lab-bottom-right">{{visit.items != 'null' ? visit.items : '/'}}</span>
                </el-col>
              </el-row>
              <el-row :gutter="24">
                <el-col :span="8">
                  <span class="lab-bottom-left">应拜访</span>
                  <span class="lab-bottom-right">{{visit.planVisit != 'null' ? visit.planVisit : '/'}}</span>
                </el-col>
                <el-col :span="8">
                  <span class="lab-bottom-left">计划外</span>
                  <span class="lab-bottom-right">{{visit.unplanVisit != 'null' ? visit.unplanVisit : '/'}}</span>
                </el-col>
                <el-col :span="8">
                  <span class="lab-bottom-left">在店平均时长(m)</span>
                  <span class="lab-bottom-right">{{visit.avgCompTime != 'null' ? visit.avgCompTime : 0}}分钟</span>
                </el-col>
              </el-row>
              <el-row :gutter="24">
                <el-col :span="8">
                  <span class="lab-bottom-left">已拜访</span>
                  <span class="lab-bottom-right">{{visit.compVisit != 'null' ? visit.compVisit : '/'}}</span>
                </el-col>
                <el-col :span="8">
                  <span class="lab-bottom-left">已作废</span>
                  <span class="lab-bottom-right">{{visit.invalidVisit != 'null' ? visit.invalidVisit : '/'}}</span>
                </el-col>
                <el-col :span="8">
                  <span class="lab-bottom-left">完成率(%)</span>
                  <span class="lab-bottom-right">{{visit.compRate != 'null' ? visit.compRate : 0}}%</span>
                </el-col>
              </el-row>
            </div>
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="24" >
        <el-col :span="12" class="left">
          <div class="lab">
            <div class="lab-top clearfix">
              <h4 class="">拜访频率</h4>
              <el-button @click="$router.push('/ReportVisitFrequency')">更多</el-button>
            </div>
            <div class="lab-Occ">
              <ul class="lab-Con-title">
                <li></li>
                <li>总客户数</li>
                <li>本月一次</li>
                <li>本月二次</li>
                <li>本月三次</li>
                <li>本月四次</li>
              </ul>
              <ul>
                <li>客户数</li>
                <li>{{frequency.custSum != 'null' ? frequency.custSum : '/'}}</li>
                <li>{{frequency.cusOne != 'null' ? frequency.cusOne : '/'}}</li>
                <li>{{frequency.cusTwo != 'null' ? frequency.cusTwo : '/'}}</li>
                <li>{{frequency.cusThree != 'null' ? frequency.cusThree : '/'}}</li>
                <li>{{frequency.cusFour != 'null' ? frequency.cusFour : '/'}}</li>
              </ul>
              <ul>
                <li>占比</li>
                <li>100%</li>
                <li>{{frequency.rateOne != 'null' ? frequency.rateOne : 25}}%</li>
                <li>{{frequency.rateTwo != 'null' ? frequency.rateTwo : 25}}%</li>
                <li>{{frequency.rateThree != 'null' ? frequency.rateThree : 25}}%</li>
                <li>{{frequency.rateFour != 'null' ? frequency.rateFour : 25}}%</li>
              </ul>
            </div>
          </div>
        </el-col>
        <el-col :span="12" class="right">
          <div class="lab">
            <div class="lab-top clearfix">
              <h4 class="">消费营销</h4>
              <el-button @click="$router.push('/MarketingActived')">更多</el-button>
            </div>
            <div class="lab-Con">
              <ul class="lab-Con-title">
                <li></li>
                <li>消费调查</li>
                <li>驻店营销</li>
                <li>新品测试</li>
                <li>新品培育</li>
                <li>品牌跟踪</li>
              </ul>
              <ul v-for="(item, key) in customData" class="ul_li">
                <li>{{item.unitName}}</li>
                <li class="green">{{item.xfdc}}</li>
                <li class="green">{{item.zdyx}}</li>
                <li class="green">{{item.xpcs}}</li>
                <li class="green">{{item.xppy}}</li>
                <li class="green">{{item.ppgz}}</li>
              </ul>
              <p v-if="customData.length<=0" class="isEmply">数据搜索中...</p>
            </div>
          </div>
        </el-col>
      </el-row >
      <el-row :gutter="24">
        <el-col :span="12" class="left">
          <div class="lab">
            <div class="lab-top clearfix">
              <h4 class="">客户服务</h4>
              <el-button @click="$router.push('/ReportServiceItemsReport')">更多</el-button>
            </div>
            <div class="lab-chars" id="bar">
              <p v-if="barArr.length <= 0" class="isEmply">数据搜索中...</p>
            </div>
          </div>
        </el-col>
        <el-col :span="12" class="right">
          <div class="lab">
            <div class="lab-top clearfix">
              <h4 class="">当月销量前五位品牌价格走势图</h4>
              <el-button @click="$router.push('/ReportSurveyData')">更多</el-button>
            </div>
            <ul class="lab-btn" style="padding-left: 15px;">
              <li v-for="(item, key) in TrendFive">
                <!--<a href="javascript:;;" :class="{'atvicd': firstClk}" class="btn btn-default" style="height: 28px; line-height: 10px;margin-top: 3px;" @click="getLineInit(item)">{{firstClk+item.cigProductNm}}</a>-->
                <el-button :class="{'atvicd': firstClk && key == 0}" style="height: 28px; line-height: 7px;margin-top: 3px;" @click="getLineInit(item)">{{item.cigProductNm}}</el-button>
              </li>
            </ul>
            <div class="lab-chars" id="line">
              <p v-if="TrendFive.length <= 0" class="isEmply">数据搜索中....</p>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
</template>
<script>
  // 引入 ECharts 主模块
  var echarts = require('echarts/lib/echarts')
  // 引入柱状图
  require('echarts/lib/chart/bar')
  require('echarts/lib/chart/line')
  // 引入提示框和标题组件
  require('echarts/lib/component/tooltip')
  require('echarts/lib/component/title')
  require('echarts/lib/component/legend')
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  export default {
    name: 'Home',
    props: {},
    mounted () {
      this.visitInit()
      this.frequencyInit()
      this.curstomInit()
      this.warnInit({pageNum: 2})
      this.visiFrequencyInit()
      this.getTrendFive()
    },
    data () {
      return {
        warnDate: [],
        visit: {},
        frequency: {},
        customData: [],
        customernum: 0,
        marketnum: 0,
        barArr: [],
        lineArr: [],
        TrendFive: [],
        firstClk: true
      }
    },
    methods: {
      warnInit (params) {
        params.companyId = getUser().companyId
        params.empId = getUser().personId
        params.status = 1
        params.pageSize = 1
        api.requestJava('POST', BasePath.WARNINGINFO_RULECOUNT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              var tmp = this.warnDate
              this.warnDate = tmp.concat(request.data.data)
              var num = params.pageNum
              if (num < 5) {
                ++num
                this.warnInit({pageNum: num})
              }
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => { console.error(err) })
      },
      visitInit () {
        api.requestJava('POST', BasePath.VISITPLAN_STATISTICS, {})
          .then((request) => {
            if (Number(request.data.code) === 200) {
              var tmp = request.data.data
              this.$set(tmp, 'avgCompTime', Number(tmp.avgCompTime).toFixed(0))
              this.visit = tmp
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => { console.error(err) })
      },
      frequencyInit () {
        api.requestJava('POST', BasePath.VISITPLAN_FREQUENCY, {})
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.frequency = request.data.data
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => { console.error(err) })
      },
      curstomInit () {
        api.requestJava('POST', BasePath.COMMON_MARKETING, {})
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.customData = request.data.data
            }
          })
      },
      visiFrequencyInit () {
        api.requestJava('POST', BasePath.COMMON_SERVICE, {})
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.customernum = request.data.data.customernum
              this.marketnum = request.data.data.marketnum
              this.barInit()
            }
          })
      },
      barInit () {
        api.requestJava('POST', BasePath.COMMON_SERVICE_RATE, {})
          .then((request) => {
            if (Number(request.data.code) === 200 && request.data.data !== '') {
              this.barArr = [1]
              var tmp = request.data.data
              // 基于准备好的dom，初始化echarts实例
              var myChart = echarts.init(document.getElementById('bar'))
              var [option, dataAxis, data, yMax, dataShadow] = [{}, [], [], 3, []]
              tmp.map((item) => {
                dataAxis.push(item.companyName)
                var temp = Number(Number(item.itemCusRate) / 100).toFixed(2)
                data.push(temp)
              })
              for (var i = 0; i < data.length; i++) {
                dataShadow.push(yMax)
              }
              option = {
                title: {
                  text: '客户经理：' + this.customernum + '人；市场经理：' + this.marketnum + '人',
                  subtext: '户均服务数量'
                },
                color: ['#3398DB'],
                tooltip: {
                  trigger: 'axis',
                  axisPointer: { // 坐标轴指示器，坐标轴触发有效
                    type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
                  }
                },
                xAxis: [
                  {
                    type: 'category',
                    data: dataAxis,
                    axisTick: {
                      alignWithLabel: true
                    }
                  }
                ],
                yAxis: [
                  {
                    type: 'value'
                  }
                ],
                dataZoom: [
                  {
                    type: 'inside'
                  }
                ],
                series: [
                  {
                    name: '户均服务数量',
                    type: 'bar',
                    barWidth: '70%',
                    data: data
                  }
                ]
              }
              myChart.setOption(option)
            } else {
              this.barArr = []
            }
          })
      },
      getTrendFive () {
        api.requestJava('POST', BasePath.MKCUMM_FIVE, {})
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.TrendFive = request.data.data.splice(0, 5)
              this.getLineInit(this.TrendFive[0])
              setTimeout(() => {
                this.firstClk = true
              }, 500)
            }
          })
      },
      getLineInit (obj) {
        this.firstClk = false
        api.requestJava('POST', BasePath.COMMON_TREND, {productCD: obj.cigProductCd})
          .then((request) => {
            if (Number(request.data.code) === 200) {
              var [timer, series, params, max, min, params1, series1, legend] = [[], [], {}, 0, 0, {}, [], []]
              var data = request.data.data
              data.forEach((item, key) => {
                var y = Number(item.avgPrice).toFixed(2)
                var y1 = isNaN(Number(item.retAvgPrice)) ? 0 : Number(item.retAvgPrice).toFixed(2)
                if (key === 0) {
                  max = isNaN(Number(item.retAvgPrice)) ? y : Number(item.retAvgPrice)
                  min = isNaN(Number(item.retAvgPrice)) ? y : Number(item.retAvgPrice)
                  params.type = 'line'
                  params.smooth = true
                  params.stack = '市场价'
                  params.name = item.productName + '市场价(条)'
                  legend.push(params.name)
                  params.data = []
                  params1.type = 'line'
                  params1.smooth = false
                  params1.stack = '市场价'
                  params1.name = item.productName + '零售价(条)'
                  params1.data = []
//                  legend.push(params1.name)
                }
                timer.push(item.gatherDate)
                series.push(y)
                series1.push(y1)
//                console.log(max)
//                console.log(min)
                if (y1 > max) {
                  max = y1
                }
                if (y1 < min && y1 !== 0) {
                  min = y1
                }
              })
              params.data = series
              params1.data = series1
              var tmp = []
              tmp.push(params)
//              tmp.push(params1)
              console.log(tmp)
              var option = {
                tooltip: {
                  trigger: 'axis'
                },
                legend: {
                  padding: [40, 0, 0, 0],
                  data: legend
                },
                xAxis: {
                  boundaryGap: false, // 区分颜色
                  type: 'category',
                  data: timer
                },
                yAxis: {
                  min: min,
                  max: max,
                  type: 'value'
                },
                series: tmp
              }
              var myChart = echarts.init(document.getElementById('line'))
              myChart.setOption(option)
            }
          })
      }
    },
    components: {},
    watch: {}
  }
</script>
