<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-form-item label="活动事项">
        <el-select v-model="dialogObj.data.form.matterId"   @change="changeXp" disabled  :clearable="true" placeholder="请选择活动事项">
          <template v-for="item in matterIdGroup">
            <el-option  :key="item.rowId"  :label="item.matterName" :value="item.rowId"></el-option>
          </template>
        </el-select>&nbsp;&nbsp;&nbsp;&nbsp;
        <i class="fa fa-cog fa-spin" @click="chuckCus()" ></i>&nbsp;&nbsp;<span class="notice" @click="chuckCus()">选点条件设置</span>
      </el-form-item>
      <el-form-item label="活动周期">
        <el-date-picker
          v-model="dialogObj.data.form.beginDate"
          type="date"
          format="yyyy-MM-dd"
          :editable=false
          :clearable=false
          :disabled = true
          placeholder="选择开始时间">
        </el-date-picker>
        <span>至</span>
        <el-date-picker
          v-model="dialogObj.data.form.endDate"
          type="date"
          format="yyyy-MM-dd"
          :editable=false
          :disabled = true
          :clearable=false
          placeholder="选择结束时间">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="活动主题">
        <el-input v-model="dialogObj.data.form.title" :disabled = true></el-input>
      </el-form-item>
      <el-form-item label="活动描述"  >
        <el-input type="textarea" resize="none" v-model="dialogObj.data.form.notes" :disabled = true></el-input>
      </el-form-item>
      <el-form-item label="收集内容"  >
        <el-select v-model="dialogObj.data.form.stepId"  multiple disabled  :clearable="true"  placeholder="请选择收集内容">
          <template v-for="item in stepIdsGroup">
            <el-option  :key="item.rowId"  :label="item.title" :value="item.rowId"></el-option>
          </template>
        </el-select>
      </el-form-item>
      <el-form-item label="新品选择"  v-if="isXp">
        <el-select v-model="dialogObj.data.form.ref"  disabled  :clearable="true" placeholder="请选择新品选择">
          <template v-for="item in refGroup">
            <el-option  :key="item.rowId"  :label="item.goodsDesc" :value="item.rowId"></el-option>
          </template>
        </el-select>
      </el-form-item>
      <el-form-item label="文件上传">
        <uploadTemp style="margin:20px;" :files="dialogObj.data.form.files" ref="uploadPic" :operation="false" ></uploadTemp>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
    </div>
  </el-dialog>
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve" />
  </div>
</template>

<script>
  import api from '@/api'
  import axios from 'axios'
  import MY_POPUP_CONFIG from './cusPopup.vue'
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
    },
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        axios.all([
          api.requestJava('POST', BasePath.SELECT_MATTERIDGROUP, {status: '1'})
        ])
        .then(axios.spread((first) => {
          this.matterIdGroup = JSON.parse(JSON.stringify(first.data.data))
        }))
        axios.all([
          api.requestJava('POST', BasePath.ACTIVITY_CIGARETTES_NEW, {})
        ])
        .then(axios.spread((first) => {
          this.refGroup = JSON.parse(JSON.stringify(first.data.data))
        }))
        let params = {}
        params.prodUnitId = getUser().companyId
        params.onSchedule = 'Y'
        axios.all([
          api.requestJava('POST', BasePath.FW_FROMS_SELECTLIST, params)
        ])
        .then(axios.spread((first) => {
          this.stepIdsGroup = JSON.parse(JSON.stringify(first.data.data))
        }))
      }
    },
    data () {
      return {
        files: [
          {
            fileName: 'baidu.gif',
            fileData: 'https://www.baidu.com/img/baidu_jgylogo3.gif',
            src: 'https://www.baidu.com/img/baidu_jgylogo3.gif'
          }
        ],
        isLoading: true,
        isXp: false,
        matterIdGroup: [],
        stepIdsGroup: [],
        refGroup: [],
        addrules: {
//          paramName: [
//            {required: true, message: '请输入参数名称', trigger: 'blur'}
//          ],
//          paramCode: [
//            {required: true, message: '请输入参数编码', trigger: 'blur'}
//          ],
//          valueCode: [
//            {required: true, message: '请输入参数值', trigger: 'blur'}
//          ]
        },
        edit: {
          title: '零售户选择器',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              dataArea: {
                type: '',
                value: ''
              },
              customerGrade: [],
              geoType: [],
              businessType: [],
              routeId: [],
              operationScale: [],
              status: ''
            }
          }
        }
      }
    },
    methods: {
      changeXp () {
        if (this.dialogObj.data.form.matterId === '381012479574016011' || this.dialogObj.data.form.matterId === '381012479574016012') {
          this.isXp = true
        } else {
          this.isXp = false
          this.dialogObj.data.form.ref = ''
        }
      },
      chuckCus () {
        if (this.dialogObj.data.form.fpConds !== '') {
          let param = JSON.parse(this.dialogObj.data.form.fpConds)
          if ('DATA_AREAS' in param) {
            if ('TYPE' in param.DATA_AREAS) {
              this.edit.data.form.dataArea.type = param.DATA_AREAS.TYPE
            }
            if ('VALUE' in param.DATA_AREAS) {
              this.edit.data.form.dataArea.value = param.DATA_AREAS.VALUE
            }
          }
          if ('CUSTOMER_GRADE' in param) {
            this.edit.data.form.customerGrade = param.CUSTOMER_GRADE
          }
          if ('GEO_TYPE' in param) {
            this.edit.data.form.geoType = param.GEO_TYPE
          }
          if ('BUSINESS_TYPE' in param) {
            this.edit.data.form.businessType = param.BUSINESS_TYPE
          }
          if ('ROUTE_ID' in param) {
            this.edit.data.form.routeId = param.ROUTE_ID
          }
          if ('OPERATION_SCALE' in param) {
            this.edit.data.form.operationScale = param.OPERATION_SCALE
          }
          if ('STATUS' in param) {
            this.edit.data.form.status = '1'
          }
        }
        console.log('this.edit.data.form', this.edit.data.form)
        this.edit.dialogVisible = true
      },
      editEve (msg) {
        if (msg === 'update') {
          let param = {}
          let dataArea = {}
          if (Number(getUser().place) === 135) {
            dataArea.TYPE = 'cust'
          } else if (Number(getUser().place) === 24) {
            dataArea.TYPE = 'market'
          }
          dataArea.VALUE = getUser().personId
          param.DATA_AREAS = dataArea
          if (this.edit.data.form.customerGrade.length > 0) {
            param.CUSTOMER_GRADE = this.edit.data.form.customerGrade
          }
          if (this.edit.data.form.geoType.length > 0) {
            param.GEO_TYPE = this.edit.data.form.geoType
          }
          if (this.edit.data.form.businessType.length > 0) {
            param.BUSINESS_TYPE = this.edit.data.form.businessType
          }
          if (this.edit.data.form.routeId.length > 0) {
            param.ROUTE_ID = this.edit.data.form.routeId
          }
          if (this.edit.data.form.operationScale.length > 0) {
            param.OPERATION_SCALE = this.edit.data.form.operationScale
          }
          this.dialogObj.data.form.fpConds = JSON.stringify(param)
        }
        console.log('this.dialogObj.data.form.fpConds', this.dialogObj.data.form.fpConds)
        this.edit.dialogVisible = false
        let tmp = {
          title: '零售户选择器',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              dataArea: {
                type: '',
                value: ''
              },
              customerGrade: [],
              geoType: [],
              businessType: [],
              routeId: [],
              operationScale: [],
              status: ''
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      _upload_submit () {
        this.$refs.uploadTemp.submitUpload()
      },
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      },
      updateClk (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dialogObj.data.form.files = this.$refs.getUploadPic.getFiles()
            this.dialogObj.data.form.status = '0'
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      upClk (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dialogObj.data.form.status = '1'
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      }
    },
    components: {
      uploadTemp,
      MY_POPUP_CONFIG
    }
  }
</script>
<style scoped>
  .el-form-item {
    margin-bottom: 16px;
  }
  .el-select {
    display: inline-block;
    position: relative;
    width: 60%;
  }
  .el-dialog__body {
    color: #48576a;
    font-size: 14px;
  }
  .fa-cog{
    color: #7f9eeb;
    font-size: 21px;
  }
  .notice{
    color: #7f9eeb;
    font-size: 16px;
  }
</style>
