<!--author qiu.bl-->
<style scoped>
  .row {
    padding: 5px 0;
  }
</style>
<template>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-6 col-sm-12">
        <div class="btn-group" v-if="isOpen">
          <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            展开 <span class="caret"></span>
          </button>
          <ul class="dropdown-menu">
            <li>
              <a href="javascript:;;" @click="openClk(true)">
                <i class="fa fa-plus-square"></i>
                全部展开</a>
            </li>
            <li>
              <a href="javascript:;;" @click="openClk(false)">
                <i class="fa fa-minus-square"></i>
                全部收起
              </a>
            </li>
          </ul>
        </div>
        <div class="btn-group" role="group" aria-label="btn group">
          <template v-for="group in btnGroups">
            <button type="button" class="btn" :class="group.className" @click="group.event">
              <i class="fa" :class="group.iconName"></i>
              {{group.name}}
            </button>
          </template>
          <button type="button" class="btn btn-success" v-if="isExport" @click="exclClk">
            <i class="fa fa-file-text"></i>
            导出Excl
          </button>
        </div>
      </div>
      <div class="col-md-6 col-sm-12  clearfix">
        <div class="input-group clearfix"  style="float:right;">
          <el-autocomplete
            class="inline-input"
            v-model="filVal"
            :fetch-suggestions="querySearch"
            placeholder="请输入内容"
            :trigger-on-focus="false"
            @select="handleSelect"
            style="float:right"
          ></el-autocomplete>
          <span class="input-group-btn"  v-if="isMore">
            <button class="btn backgroundHeadtheme" type="button" @click="moreClk">
              <i class="fa fa-th"></i>
            </button>
          </span>
        </div>
      </div>
    </div>
    <div>
      <el-row class="el-row">
        <el-col :span="24">
          <tree-grid
            :dataSource.sync='dataSource'
            :columns='columns'
            :tree-structure="true"
            :tableType = 3
            :btns="btns"
            :selectAll="selectAll"
            :select="select"
            :defaultExpandAll="defaultExpandAll"
            ref="tableGrid"
          ></tree-grid>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
  import TreeGrid from '@/components/Template/TabPagin/TreeGrid'
  import api from '@/api'
  import log from '@/log'
  export default {
    mounted () {
//      this.init()
      this.tableData = [
        {
          'children': [
            {
              'children': [
                {
                  'children': [
                    {
                      'children': [],
                      'resCode': '2017110202',
                      'resName': '测试菜单名称2'
                    }
                  ],
                  'resCode': '201711012',
                  'resName': '测试菜单名称44'
                }
              ],
              'resCode': 'USER',
              'resName': '用户管理'
            },
            {
              'children': [],
              'resCode': 'MENU',
              'resName': '菜单管理'
            },
            {
              'children': [],
              'resCode': 'ROLE',
              'resName': '角色管理'
            }
          ],
          'resCode': 'SYSTEM',
          'resName': '系统管理'
        },
        {
          'children': [
            {
              'children': [],
              'resCode': 'COMMON_REPORT',
              'resName': '一般报表'
            },
            {
              'children': [],
              'resCode': 'BUSS_REPORT',
              'resName': '业务报表'
            }
          ],
          'resCode': 'REPORT',
          'resName': '报表合集'
        }
      ]
      this.currentPage = 1
      this.queryData(this.currentPage, this.pageSize)
    },
    data () {
      return {
        isOpen: true, // 是否显示展开更多按钮
        isExport: true, // 是否显示导出elcx
        isMore: true, // 是否显示更多按钮
        btnGroups: [
          {
            name: '新增',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.addClk
          }
        ], // 按钮组
        filVal: '', // 过滤变量
        fileName: ['resName'],
        defaultExpandAll: true,
        tableData: [],
        currentPage: 1, // 默认当前第一页
        pageSize: 10,  // 默认每页20条数据
        pageSizes: [2, 5, 10, 20, 40, 50], // 分页数选择项
        totalCount: 0, // 表格总记录数
        columns: [
          {
            value: 'resCode',
            label: '菜单代码',
            align: 'center'
          }, {
            value: 'resName', // 列的值
            label: '菜单名称', // 列的显示字段
            align: 'center' // 列的对齐方式，[left, center, right]，选填，默认是left
          }, {
            value: 'resSicon',
            align: 'center', // 列的css样式（选填）
            label: '图标'
          }, {
            value: 'resUrl',
            label: '链接',
            align: 'center'
          }, {
            value: 'status',
            label: '状态',
            align: 'center'
          }
        ],
        btns: {
          btnArr: [
            {
              label: '修改', // 按钮的名称
              value: 'modify', // 按钮的值
              functionName: this.modify, // 按钮的方法
              type: 'warning',
              icon: 'edit'
            },
            {
              label: '删除',
              value: 'del',
              type: 'danger',
              functionName: this.del,
              icon: 'delete'
            }
          ],
          value: 'operation',
          label: '操作',
          width: '180px'
        },
        dataSource: [], // 当前页的数据
        temp: []
      }
    },
    methods: {
      init () {
        let params = {}
        params.treeKey = 'parentId'
        params.treeRoot = '1'
        params.roleId = '0'
        api.requestJava('POST', 'menu/selectByCode.do', params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$notify.error({ title: '查询失败', message: request.data.message })
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      /* 展开-收起 */
      openClk (isTrue) {
        this.$refs.tableGrid.expand(isTrue)
      },
      /* 新增 */
      addClk () {
        this.$message('新增')
      },
      /* 导出excl */
      exclClk () {
        this.$refs.tableGrid.exportExcel()
      },
      moreClk () {
        this.$message('更多click')
      },
      modify () {
        this.$message('修改')
      },
      danger () {
        this.$message('删除')
      },
      handleSelect (item) {
        console.log(item)
      },
      querySearch (queryString, cb) {
        this.temp = []
        let restaurants = this.tableData
        let results = queryString ? this.dataFilter(restaurants, queryString) : restaurants
        // 调用 callback 返回建议列表的数据
        cb(results)
        this.temp.push(...results)
        if (this.temp.length > 0) {
          let page = this.currentPage
          let size = this.pageSize
          this.dataSource = this.temp.filter((u, index) => index < size * page && index >= size * (page - 1))
        } else {
          this.dataSource = []
        }
      },
      dataFilter (restaurants, queryString) {
        let result = []
        restaurants.forEach((restaurant, n) => {
          let isTrue = false
          for (let i in this.fileName) {
            if (restaurant[this.fileName[i]].indexOf(queryString) !== -1) {
              result.push(restaurant)
              isTrue = true
              break
            }
          }
          if (!isTrue && restaurant.children.length > 0) {
            let temp = this.findInChild(restaurant.children, queryString)
            if (temp.length !== 0) {
              result.push(...temp)
            }
          }
        })
        return result
      },
      findInChild (obj, str) {
        let result = []
        for (let i in obj) {
          let isTrue = false
          for (let j in this.fileName) {
            if (obj[i][this.fileName[j]].indexOf(str) !== -1) {
              result.push(obj[i])
              isTrue = true
              break
            }
          }
          if (!isTrue && obj[i].children.length > 0) {
            let temp = this.findInChild(obj[i].children, str)
            if (temp.length !== 0) {
              result.push(...temp)
            }
          }
        }
        return result
      },
      selectAll () {},
      select () {}
    },
    components: {
      TreeGrid
    },
    watch: {
      filVal (val, oval) {
        if (val === '') {
          this.currentPage = 1
          this.queryData(this.currentPage, this.pageSize)
        }
      }
    }
  }
</script>
