<template>
  <div>
    <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk">
        <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="cat" label="受理类型" >
                  <el-select v-model="dialogObj.data.form.cat" filterable :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_cat"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="receiveTime" label="受理日期">
                  <el-date-picker
                    :disabled="true"
                    v-model="dialogObj.data.form.receiveTime"
                    type="date"
                    format="yyyy-MM-dd"
                    :editable=false
                    :clearable=false
                    placeholder="请选择受理日期">
                  </el-date-picker>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="deptId" label="受理部门">
                  <el-select v-model="dialogObj.data.form.deptId" filterable :clearable="true" placeholder="请选择所属部门">
                    <template v-for="item in deptIdGroup">
                      <el-option  :key="item.rowId"  :label="item.unitName" :value="item.rowId"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item prop="licenseNo"  label="许可证号码">
                  <el-input v-model="dialogObj.data.form.licenseNo" @blur="datePickerChange" ></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="custmgrId" label="所属客户经理">
                  <el-select v-model="dialogObj.data.form.custmgrId" filterable :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in optionsManager"
                      :key="item.rowId"
                      :label="item.employeeName"
                      :value="item.rowId">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item  prop="customerName" label="客户名称" >
                  <el-input v-model="dialogObj.data.form.customerName" :disabled="true" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item  prop="tel" label="联系电话" >
                  <el-input v-model="dialogObj.data.form.tel" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item  prop="addr" label="经营地址" >
                  <el-input v-model="dialogObj.data.form.addr"   :disabled="true" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='24'>
                <el-form-item  prop="contents" label="详细内容"  >
                  <el-input type="textarea" v-model="dialogObj.data.form.contents"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row v-if="Number(this.dialogObj.type) === 2">
            <el-col :span='24'>
              <el-col :span='24'>
                <el-form-item  prop="contents" label="处理结果"  >
                  <el-input type="textarea" v-model="dialogObj.data.form.results"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row v-if="Number(this.dialogObj.type) === 2">
            <el-col :span='24'>
              <el-col :span='24'>
                <el-form-item  prop="uploadPicComplaint" label="照片上传">
                  <uploadTemp :files="dialogObj.data.form.files" ref="uploadPic"></uploadTemp>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
        </el-form>
        <div slot="footer" class="dialog-footer" style="text-align: right">
          <el-button @click="cancleClk('addForm')">取 消</el-button>
          <el-button type="success"  v-if="Number(this.dialogObj.type) !== 2"  @click="updateClk('addForm')" >保存</el-button>
        </div>
    </el-dialog>
  </div>
</template>
<script>
  import InputTemp from '@/components/Template/filter/InputTemp.vue'
  import DatePickerTemp from '@/components/Template/DatePicker/DatePickerTemp.vue'
  import { getUser, getCodeList } from '@/config/info'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import axios from 'axios'
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
  export default {
    mounted () {
      getCodeList('COMPLAINT_TYPE', (data) => {
        this.options_cat = data
      })
      let params1 = {}
      params1.companyId = getUser().companyId
      params1.whereClause = ` and ORG_TYPE like '2%' `
      let params = {}
      params.companyId = getUser().companyId
      params.status = 1
      axios.all([
        api.requestJava('POST', BasePath.SELECT_DEPTIDGROUP, params1),
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params)
      ])
      .then(axios.spread((first, second) => {
        this.deptIdGroup = first.data.data
        this.optionsManager = second.data.data
      }))
    },
    props: ['dialogObj'],
    data () {
      return {
        options_cat: [],
        isLoading: true,
        disable: true,
        dialogVisible: false,
        formLabelWidth: '120px',
        filmode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤
        fileName: ['value'],
        filType: 0, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        keyup: true, // 输入筛选；true：之前展示；false：之后展示
        tableData: [],
        optionsManager: [],
        deptIdGroup: [],
        files: [],
        addrules: {
          customerName: [
            {required: true, message: '请选择客户名称', trigger: 'blur'}
          ],
          deptId: [
            {required: true, message: '请受理部门', trigger: 'blur'}
          ]
        }
      }
    },
    methods: {
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      },
      updateClk (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.isLoading = true
            if (Number(this.dialogObj.type) === 2) {
              this.dialogObj.data.form.custmgrNm = this.changeValue(this.optionsManager, 'rowId', this.dialogObj.data.form.custmgrId, 'employeeName')
              this.dialogObj.data.form.files = this.$refs.uploadPic.getFiles()
            }
            this.dialogObj.dialogVisible = false
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      changeValue (group, key, value, key1) {
        let obj = {}
        obj = group.find((item) => {
          if (item[key] === value) {
            return item
          }
        })
        return obj.key1
      },
      datePickerChange () {
        let params = {}
        params.permitNo = this.dialogObj.data.form.licenseNo
        params.companyId = getUser().companyId
        if (params.permitNo !== '') {
          api.requestJava('POST', BasePath.CUSTOMER_SELECTONE, params)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                if (request.data.data.length === 0) {
                  this.$notify.error({title: '提示', message: '无该客户'})
                } else {
                  this.dialogObj.data.form.tel = request.data.data.tel
                  this.dialogObj.data.form.addr = request.data.data.addr
                  this.dialogObj.data.form.customerName = request.data.data.customerDesc
                  this.dialogObj.data.form.customerId = request.data.data.rowId
                  this.dialogObj.data.form.custmgrId = request.data.data.custmgrId
                }
              } else if (Number(request.data.code) === 401) {
//                this.$message('无该客户')
                this.logInvalid.dialogVisible = true
              } else {
                this.$notify.error({title: '提示', message: request.data.message})
                throw new Error(JSON.stringify(request))
              }
            })
        }
      }
    },
    components: {
      InputTemp,
      DatePickerTemp,
      uploadTemp
    }
  }
</script>
