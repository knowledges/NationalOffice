<!--代天辉-->
<style rel="stylesheet/scss" lang="scss" scoped></style>
<template>
    <div class="container-fluid" style="padding-top: 80px!important;">
      模拟内容
    </div>
</template>
<script>
  export default {
    name: 'UserDemo',
    props: {},
    mounted () {
    },
    data () {
      return {}
    },
    methods: {},
    components: {},
    watch: {}
  }
</script>
