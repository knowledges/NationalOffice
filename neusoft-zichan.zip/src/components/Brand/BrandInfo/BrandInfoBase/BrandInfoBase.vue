<!-- 徐晓菁 -->
<style scoped>
  .cust_row_l{
    position: absolute;
    top:0;
    left: 10px;
    z-index:9;
    width: 315px;
    border: none;
  }
  .cust_btn_box {
    box-shadow: 2px 3px 6px #666;
    padding: 0!important;
  }
  .cust_btn_l{
    background: #fff;
    border-radius: 50%;
    box-shadow: 2px 2px 5px #999;
    position: absolute;
    top: 50%;
    left: 0;
    margin-top: -18px;
  }
  .moveL-enter-active {
    animation: moveL-in .5s;
  }
  .moveL-leave-active {
    animation: moveL-in .5s reverse;
  }
  @keyframes moveL-in {
    0% {
      transform: translate(-315px, 0px);
    }
    80% {
      transform: translate(25px, 0px);
    }
    100% {
      transform: translate(-5px, 0px);
    }
  }
</style>
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :span="24" style="padding: 0 0">
        <_BTN_FILTER  :filterMethod="inputChange"  :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData" :isMore="isMore"/>
      </el-col>
    </el-row>
    <el-row :gutter="24" class="cust_el_row">
      <el-col :span="6" class="cust_el_col">
        <div class="bg-purple">
          <_TREECOMPONENT :search=searchable :data='treeData' :nodeClick='showTree' :nodeKey="nodeKey"
                          :showCheckBox=showCheckBox :expandAll=expandAll ref='tree' :highlight='true'
                          :defaultCheckedKeys="defaultCheckedKeys"></_TREECOMPONENT>
        </div>
      </el-col>
      <el-col :span="18">
        <div>
          <_TABLE
            ref="tableGrid"
            stripe
            maxHeight="500"
            @update:data="tabChange" :reqParams="reqParams"
            :data="dataSource"
            :columns="columnHeader"
            :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
            :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
            @selection-change="selectionChange"></_TABLE>
        </div>
      </el-col>
    </el-row>
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve" v-popupdra-directive="{'show': edit.dialogVisible}"/>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
    <MY_POPUP_SELECT :dialogObj='selectD' @confirmBack="selectEve"  v-popupdra-directive="{'show': selectD.dialogVisible}"/>
    <MY_POPUP_UPDATE :dialogObj='updateD' @confirmBack="updateEve"  v-popupdra-directive="{'show': updateD.dialogVisible}"/>

  </div>
</template>
<script>
  import _TREECOMPONENT from '@/components/Template/Tree/Tree.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import _TABLE from '@/components/Template/table/Table.vue'
  import MY_POPUP_CONFIG from './Popup.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import MY_POPUP_SELECT from './Popup1.vue'
  import MY_POPUP_UPDATE from './PopupUpdate.vue'
  import BasePath from '@/config/BasePath'
  import { changeListValueByCode } from '@/utils/common'
  import {getUser} from '@/config/info'
  import axios from 'axios'
  import api from '@/api'
  import log from '@/log'
  export default {
    mounted () {
      // this.queryData(this.currentPage, this.pageSize)
      this.init()
      this.queryUpper({})
      axios.all([
        api.requestJava('POST', BasePath.SELECT_BRANDIDGROUP, {}),
        api.requestJava('POST', BasePath.SELECT_GOODSGRADEGROUP, {'gradeType': '1'})
      ])
      .then(axios.spread((first, scend) => {
        this.changeValueDate.brandId.group = JSON.parse(JSON.stringify(first.data.data))
        this.changeValueDate.goodsGrade.group = JSON.parse(JSON.stringify(scend.data.data))
      }))
    },
    data () {
      return {
        isTree: false,
        /** table **/
        hasPagination: true,
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'goodsCode', // 列的值
            label: '卷烟代码', // 列的显示字段
            columnsProps: {width: 120, align: 'left'}
          },
          {
            prop: 'goodsDesc',
            className: 'header', // 列的css样式（选填）
            label: '卷烟名称',
            columnsProps: {align: 'left'}
          },
          {
            prop: 'shortCode',
            label: '简码',
            columnsProps: {
              width: 120,
              align: 'center'
            }
          },
          {
            prop: 'goodsGrade',
            label: '等级',
            columnsProps:
            {
              width: 80,
              align: 'center',
              formatter: this.changeValue
            }
          },
          {
            prop: 'brandId',
            label: '品牌',
            columnsProps:
            {
              width: 120,
              align: 'center',
              formatter: this.changeValue1
            }
          },
          {
            prop: 'status',
            label: '状态',
            columnsProps:
            {
              width: 80,
              align: 'center',
              formatter: this.changeValue
            }
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 200, type: 'button'},
            cptProperties: [
              {
                label: '修改',
                value: 'update',
                icon: 'edit',
                size: 'small',
                type: 'primary',
                eventClick: this.update
              },
              {
                label: '预览',
                value: 'modify',
                icon: 'search',
                size: 'small',
                type: 'primary',
                eventClick: this.modify
              }
            ]
          }
        ],
        changeValueDate: {
          status: {
            type: 'text',
            group: [{value: 'Y', label: '启用'}, {value: 'N', label: '停用'}],
            key: 'value',
            value: 'label'
          },
          goodsGrade: {
            type: 'text',
            group: [],
            key: 'rowId',
            value: 'gradeDesc'
          },
          brandId: {
            type: 'text',
            group: [],
            key: 'rowId',
            value: 'brandDesc'
          }
        },
        treeData: [
//          {
//            id: 5133017,
//            label: '南京卷烟厂',
//            type: 'factory',
//            children: [
//              {
//                id: 8006,
//                label: '双喜',
//                type: 'brand'
//              },
//              {
//                id: 8011,
//                label: '冬虫夏草',
//                type: 'brand'
//              },
//              {
//                id: 8014,
//                label: '群英会',
//                type: 'brand'
//              }
//            ]
//          },
//          {
//            id: 5133033,
//            label: '龙岩卷烟厂',
//            type: 'factory',
//            children: [
//              {
//                id: 8022,
//                label: '洛阳牡丹',
//                type: 'brand'
//              },
//              {
//                id: 8025,
//                label: '红金龙',
//                type: 'brand'
//              },
//              {
//                id: 8029,
//                label: '黄鹤楼',
//                type: 'brand'
//              },
//              {
//                id: 8032,
//                label: '襄阳',
//                type: 'brand'
//              },
//              {
//                id: 8043,
//                label: '家乐福',
//                type: 'brand'
//              },
//              {
//                id: 8045,
//                label: '义',
//                type: 'brand'
//              }
//            ]
//          }
        ],
        tableData: [
          {
            brandName: '',
            factoryName: '',
            provinceName: '',
            pcktmpName: '',
            rowId: '111',
            goodsCode: '111',
            goodsDesc: '中华',
            shortCode: '',
            shortName: '',
            goodsClass: '',
            goodsGrade: '',
            brandId: '',
            remarks: '',
            status: '',
            pcktmpId: '',
            goodsCatId: '',
            provinceId: '',
            barcodeBox: '',
            barcodeLoaf: '',
            barcodePack: '',
            stdName: '',
            gradeId: '',
            cigaretteType: '',
            color1: '',
            color2: '',
            packageSpec: '',
            statisticType: '',
            cigKind: '',
            totalLen: '',
            cigaretteLen: '',
            snipeLen: '',
            filterType: '',
            cigaretteGirth: '',
            tarScalar: '',
            nicotineScalar: '',
            monoxide: '',
            myjyCode: '',
            is100t: '',
            seq100t: '',
            isConfiscated: '',
            isOther: '',
            isInprovince: '',
            isLowTar: '',
            isCadrebrand: '',
            cigState: '',
            originType: '',
            reserveTag2: '',
            reserveTag3: '',
            marketDate: '',
            impDate: '',
            coreValue: '',
            taste: '',
            marketPosition: '',
            targetobject: '',
            nmprice: 0,
            cigLifecycle: '',
            synopsis: '',
            propaganda: '',
            loafSpclFlag: '',
            boxSpclFlag: '',
            maxOrderDate: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            lastUpdTime: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: '',
            packageMx: [
              {
                grade: '1',
                unit: '箱',
                quantity: '50000',
                barcode: '1111',
                isdefault: '否',
                status: '启用'
              },
              {
                grade: '2',
                unit: '件',
                quantity: '10000',
                barcode: '2222',
                isdefault: '否',
                status: '启用'
              },
              {
                grade: '3',
                unit: '条',
                quantity: '200',
                barcode: '3333',
                isdefault: '是',
                status: '启用'
              }
            ]
          },
          {
            brandName: '',
            factoryName: '',
            provinceName: '',
            pcktmpName: '',
            rowId: '222',
            goodsCode: '222',
            goodsDesc: '南京',
            shortCode: '',
            shortName: '',
            goodsClass: '',
            goodsGrade: '',
            brandId: '',
            remarks: '',
            status: '',
            pcktmpId: '',
            goodsCatId: '',
            provinceId: '',
            barcodeBox: '',
            barcodeLoaf: '',
            barcodePack: '',
            stdName: '',
            gradeId: '',
            cigaretteType: '',
            color1: '',
            color2: '',
            packageSpec: '',
            statisticType: '',
            cigKind: '',
            totalLen: '',
            cigaretteLen: '',
            snipeLen: '',
            filterType: '',
            cigaretteGirth: '',
            tarScalar: '',
            nicotineScalar: '',
            monoxide: '',
            myjyCode: '',
            is100t: '',
            seq100t: '',
            isConfiscated: '',
            isOther: '',
            isInprovince: '',
            isLowTar: '',
            isCadrebrand: '',
            cigState: '',
            originType: '',
            reserveTag2: '',
            reserveTag3: '',
            marketDate: '',
            impDate: '',
            coreValue: '',
            taste: '',
            marketPosition: '',
            targetobject: '',
            nmprice: 0,
            cigLifecycle: '',
            synopsis: '',
            propaganda: '',
            loafSpclFlag: '',
            boxSpclFlag: '',
            maxOrderDate: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            lastUpdTime: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: '',
            packageMx: [
              {
                grade: '1',
                unit: '箱',
                quantity: '50000',
                barcode: '1111',
                isdefault: '否',
                status: '启用'
              },
              {
                grade: '2',
                unit: '件',
                quantity: '10000',
                barcode: '2222',
                isdefault: '否',
                status: '启用'
              },
              {
                grade: '3',
                unit: '条',
                quantity: '200',
                barcode: '3333',
                isdefault: '是',
                status: '启用'
              }
            ]
          },
          {
            brandName: '',
            factoryName: '',
            provinceName: '',
            pcktmpName: '',
            rowId: '333',
            goodsCode: '333',
            goodsDesc: '苏烟',
            shortCode: '',
            shortName: '',
            goodsClass: '',
            goodsGrade: '',
            brandId: '',
            remarks: '',
            status: '',
            pcktmpId: '',
            goodsCatId: '',
            provinceId: '',
            barcodeBox: '',
            barcodeLoaf: '',
            barcodePack: '',
            stdName: '',
            gradeId: '',
            cigaretteType: '',
            color1: '',
            color2: '',
            packageSpec: '',
            statisticType: '',
            cigKind: '',
            totalLen: '',
            cigaretteLen: '',
            snipeLen: '',
            filterType: '',
            cigaretteGirth: '',
            tarScalar: '',
            nicotineScalar: '',
            monoxide: '',
            myjyCode: '',
            is100t: '',
            seq100t: '',
            isConfiscated: '',
            isOther: '',
            isInprovince: '',
            isLowTar: '',
            isCadrebrand: '',
            cigState: '',
            originType: '',
            reserveTag2: '',
            reserveTag3: '',
            marketDate: '',
            impDate: '',
            coreValue: '',
            taste: '',
            marketPosition: '',
            targetobject: '',
            nmprice: 0,
            cigLifecycle: '',
            synopsis: '',
            propaganda: '',
            loafSpclFlag: '',
            boxSpclFlag: '',
            maxOrderDate: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            lastUpdTime: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: '',
            packageMx: [
              {
                grade: '1',
                unit: '箱',
                quantity: '50000',
                barcode: '1111',
                isdefault: '否',
                status: '启用'
              },
              {
                grade: '2',
                unit: '件',
                quantity: '10000',
                barcode: '2222',
                isdefault: '否',
                status: '启用'
              },
              {
                grade: '3',
                unit: '条',
                quantity: '200',
                barcode: '3333',
                isdefault: '是',
                status: '启用'
              }
            ]
          },
          {
            brandName: '',
            factoryName: '',
            provinceName: '',
            pcktmpName: '',
            rowId: '444',
            goodsCode: '444',
            goodsDesc: '利群',
            shortCode: '',
            shortName: '',
            goodsClass: '',
            goodsGrade: '',
            brandId: '',
            remarks: '',
            status: '',
            pcktmpId: '',
            goodsCatId: '',
            provinceId: '',
            barcodeBox: '',
            barcodeLoaf: '',
            barcodePack: '',
            stdName: '',
            gradeId: '',
            cigaretteType: '',
            color1: '',
            color2: '',
            packageSpec: '',
            statisticType: '',
            cigKind: '',
            totalLen: '',
            cigaretteLen: '',
            snipeLen: '',
            filterType: '',
            cigaretteGirth: '',
            tarScalar: '',
            nicotineScalar: '',
            monoxide: '',
            myjyCode: '',
            is100t: '',
            seq100t: '',
            isConfiscated: '',
            isOther: '',
            isInprovince: '',
            isLowTar: '',
            isCadrebrand: '',
            cigState: '',
            originType: '',
            reserveTag2: '',
            reserveTag3: '',
            marketDate: '',
            impDate: '',
            coreValue: '',
            taste: '',
            marketPosition: '',
            targetobject: '',
            nmprice: 0,
            cigLifecycle: '',
            synopsis: '',
            propaganda: '',
            loafSpclFlag: '',
            boxSpclFlag: '',
            maxOrderDate: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            lastUpdTime: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: '',
            packageMx: [
              {
                grade: '1',
                unit: '箱',
                quantity: '50000',
                barcode: '1111',
                isdefault: '否',
                status: '启用'
              },
              {
                grade: '2',
                unit: '件',
                quantity: '10000',
                barcode: '2222',
                isdefault: '否',
                status: '启用'
              },
              {
                grade: '3',
                unit: '条',
                quantity: '200',
                barcode: '3333',
                isdefault: '是',
                status: '启用'
              }
            ]
          },
          {
            brandName: '',
            factoryName: '',
            provinceName: '',
            pcktmpName: '',
            rowId: '555',
            goodsCode: '555',
            goodsDesc: '大前门',
            shortCode: '',
            shortName: '',
            goodsClass: '',
            goodsGrade: '',
            brandId: '',
            remarks: '',
            status: '',
            pcktmpId: '',
            goodsCatId: '',
            provinceId: '',
            barcodeBox: '',
            barcodeLoaf: '',
            barcodePack: '',
            stdName: '',
            gradeId: '',
            cigaretteType: '',
            color1: '',
            color2: '',
            packageSpec: '',
            statisticType: '',
            cigKind: '',
            totalLen: '',
            cigaretteLen: '',
            snipeLen: '',
            filterType: '',
            cigaretteGirth: '',
            tarScalar: '',
            nicotineScalar: '',
            monoxide: '',
            myjyCode: '',
            is100t: '',
            seq100t: '',
            isConfiscated: '',
            isOther: '',
            isInprovince: '',
            isLowTar: '',
            isCadrebrand: '',
            cigState: '',
            originType: '',
            reserveTag2: '',
            reserveTag3: '',
            marketDate: '',
            impDate: '',
            coreValue: '',
            taste: '',
            marketPosition: '',
            targetobject: '',
            nmprice: 0,
            cigLifecycle: '',
            synopsis: '',
            propaganda: '',
            loafSpclFlag: '',
            boxSpclFlag: '',
            maxOrderDate: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            lastUpdTime: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: '',
            packageMx: [
              {
                grade: '1',
                unit: '箱',
                quantity: '50000',
                barcode: '1111',
                isdefault: '否',
                status: '启用'
              },
              {
                grade: '2',
                unit: '件',
                quantity: '10000',
                barcode: '2222',
                isdefault: '否',
                status: '启用'
              },
              {
                grade: '3',
                unit: '条',
                quantity: '200',
                barcode: '3333',
                isdefault: '是',
                status: '启用'
              }
            ]
          }
        ],
        unitDate: [],
        dataSource: [], // 当前页的数据
        /** filter **/
        filmode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        filType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['goodsCode', 'goodsDesc', 'shortCode', 'brandName', 'factoryId', 'brandCode'],
        isMore: true, // 查询更多条件
        keyupend: false,   // 输入筛选；true：之前展示；false：之后展示
        templTableData: [], // 临时记录tableDate的值
        btnGroups: [
          {
            name: '',
            className: 'btn-primary',
            iconName: 'fa-th',
            event: this.isMoreClk
          }
        ], // 定义按钮
        /** 弹出层 **/
        edit: {
          title: '商品信息预览',
          type: 'addCommodityManagement',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              brandName: '',
              factoryName: '',
              provinceName: '',
              pcktmpName: '',
              rowId: '',
              goodsCode: '',
              goodsDesc: '',
              shortCode: '',
              shortName: '',
              goodsClass: '',
              goodsGrade: '',
              brandId: '',
              remarks: '',
              status: '',
              pcktmpId: '',
              goodsCatId: '',
              provinceId: '',
              barcodeBox: '',
              barcodeLoaf: '',
              barcodePack: '',
              stdName: '',
              gradeId: '',
              cigaretteType: '',
              color1: '',
              color2: '',
              packageSpec: '',
              statisticType: '',
              cigKind: '',
              totalLen: '',
              cigaretteLen: '',
              snipeLen: '',
              filterType: '',
              cigaretteGirth: '',
              tarScalar: '',
              nicotineScalar: '',
              monoxide: '',
              myjyCode: '',
              is100t: '',
              seq100t: '',
              isConfiscated: '',
              isOther: '',
              isInprovince: '',
              isLowTar: '',
              isCadrebrand: '',
              cigState: '',
              originType: '',
              reserveTag2: '',
              reserveTag3: '',
              marketDate: '',
              impDate: '',
              coreValue: '',
              taste: '',
              marketPosition: '',
              targetobject: '',
              nmprice: 0,
              cigLifecycle: '',
              synopsis: '',
              propaganda: '',
              loafSpclFlag: '',
              boxSpclFlag: '',
              maxOrderDate: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: '',
              packageMx: []
            }
          }
        },
        selectD: {
          title: '查询条件选择',
          type: 'selectCommodityManagement',
          dialogVisible: false,
          size: 'small',
          data: {
            form: {
              goodsCode: '',
              goodsDesc: '',
              goodsGrade: '',
              status: '',
              isConfiscated: '',
              shortCode: ''
            }
          }
        },
        updateD: {
          title: '修改基础信息',
          type: 'updateCommodityManagement',
          dialogVisible: false,
          size: 'small',
          data: {
            form: {
              rowId: '',
              orgUnitId: '',
              goodsCode: '',
              goodsDesc: '',
              marketPosition: '',
              targetobject: '',
              nmprice: 0,
              cigLifecycle: '',
              synopsis: '',
              lifeCycle: []
            }
          }
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        factoryTree: [],
        /** 树形属性 **/
        nodeKey: 'id',
        defaultCheckedKeys: [],
        searchable: true, // 是否带搜索框
        showCheckBox: false, // 是否带复选框
        expandAll: true // 是否展开所有节点
      }
    },
    methods: {
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      changeValue1 (row, column) {
        var unixDate = row[column.property]
        let group = this.changeValueDate.brandId.group
        let key = 'rowId'
        let value = 'brandDesc'
        let result = ''
        for (let i = 0; i < group.length; i++) {
          let obj = group[i]
          if (obj[key] === unixDate) {
            result = obj[value]
            row.factoryId = obj.ownerId
            row.brandCode = obj.brandCode
            break
          }
        }
        return result
      },  // 转换list中的code
      showTreeClk () {
        this.isTree = !this.isTree
      },
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      isMoreClk () {
        // Object.assign(this.selectD, this.selectDTmp)
        if (Object.prototype.toString.call(this.factoryTree) !== '[object Array]') {
          this.selectD.title = this.factoryTree.label + '查询条件'
        }
        this.selectD.data.form.goodsGradeGroupCode = this.changeValueDate.goodsGrade.group
        this.selectD.dialogVisible = true
      },
      showTree (data) {  // 节点单击事件
        console.log('data', data)
        this.factoryTree = data
        console.log('factoryTree', this.factoryTree)
        let selectTmp = {
          title: '查询条件选择',
          type: 'selectCommodityManagement',
          dialogVisible: false,
          size: 'small',
          data: {
            form: {
              goodsCode: '',
              goodsDesc: '',
              goodsGrade: '',
              status: '',
              isConfiscated: '',
              shortCode: ''
            }
          }
        }
        Object.assign(this.selectD, selectTmp)
        let params = {}
        params.status = 1
        if ('children' in this.factoryTree) {
          let bra = ''
          let children = this.factoryTree.children
          for (let i = 0; i < children.length; i++) {
            bra = bra + children[i].id + ','
          }
          if (bra.length > 0) {
            bra = bra.substr(0, bra.length - 1)
          }
          params.fluzzy = {'in': 'brandId:' + bra}
        } else {
          params.brandId = this.factoryTree.id
        }
//        this.inputChange(this.factoryTree.id)
        this.queryUpper(params)
      },
      init () {
        let params = {}
        params.brandStatus = 'Y'
        this.reqParams.url = BasePath.COMMODITYTREE_FACTORYBRAND
        this.reqParams.params = params
        api.requestJava('POST', BasePath.COMMODITYTREE_FACTORYBRAND, params)
          .then((request) => {
            this.filTree = this.filterVal
            if (Number(request.data.code) === 200) {
              this.treeData = request.data.data
            } else if (Number(request.data.code) === 401) {
              this.$notify.error({ title: '查询失败', message: request.data.message })
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      queryData (page, size) {
      // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      addClk () {
        this.edit.dialogVisible = true
      }, // 新增
      modify (index, row) {
        Object.assign(this.edit.data.form, row)
        this.edit.data.form.brandIdGroup = this.changeValueDate.brandId.group
        this.edit.data.form.goodsGradeGroup = this.changeValueDate.goodsGrade.group
//        let factoryId = ''
//        for (let i = 0; i < this.changeValueDate.brandId.group.length; i++) {
//          let obj = this.changeValueDate.brandId.group[i]
//          if (obj.rowId === row.brandId) {
//            factoryId = obj.ownerId
//            break
//          }
//        }
//        this.edit.data.form.factoryId = factoryId
        this.findByIdUpper(row)
        this.edit.dialogVisible = true
      }, // 修改
      update (index, row) {
        Object.assign(this.updateD.data.form, row)
        this.updateD.dialogVisible = true
      }, // 修改
      del (index, row) {
        if (Number(row.modifyFlag) === 0) {
          this.$message({type: 'info', message: '该记录不可修改删除!'})
          return
        }
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
        // this.$message({type: 'success', message: '删除成功!'})
        // this.$delete(this.dataSource, index)
          this.deleteUpper(row.rowId)
        }).catch(() => {
          this.$message({type: 'info', message: '已取消删除!'})
        })
      },  // 删除
      batchDelClk () {
        let rowIds = ''
        console.log('sel_all_row', this.sel_all_row)
        for (let i = 0; i < this.sel_all.length; i++) {
          if (Number(this.sel_all_row[i].modifyFlag) === 0) {
            this.$message({type: 'info', message: '选择记录中有不可修改记录!'})
            return
          } else {
            rowIds = rowIds + this.sel_all_row[i].rowId + ','
          }
        }
        rowIds = rowIds.substr(0, rowIds.length - 1)
        if (this.sel_all.length > 0) {
          this.$confirm('确定删除此条信息吗？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
          // this.$message({type: 'success', message: '根据id删除一下数据' + this.sel_all})
            this.deleteUpper(rowIds)
          })
        .catch(() => {
          this.$message({type: 'info', message: '已取消删除!'})
        })
        }
      },  // 批量删除
      onendChange (val) {}, // 过滤器修改事件
      queryUpper (params) {
        params.status = 'Y'
        params.companyId = getUser().companyId
        console.log('params', JSON.stringify(params))
        this.reqParams.url = BasePath.COMMODITY_SELECTLIST
        this.reqParams.params = params
        api.requestJava('POST', BasePath.COMMODITY_SELECTLIST, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
//              alert(request.data.count)
              this.totalCount = Number(request.data.count) <= 0 ? 1 : Number(request.data.count)
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
              // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      findByIdUpper (row) {
        let param = {}
        param.productId = row.rowId
        console.log('row-params', JSON.stringify(param))
        api.requestJava('POST', BasePath.COMMODITY_PACKAGEMX, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              console.log('request.data.data', request.data.data)
              Object.assign(this.edit.data.form, row)
              let data = request.data.data
              let mx = []
              for (let i = 0; i < data.length; i++) {
                let rowS = {}
                rowS.grade = data[i].grade
                rowS.unit = data[i].unit
                rowS.quantity = data[i].quantity
                rowS.barcode = data[i].barcode
                if (data[i].isdefault === 'Y') {
                  rowS.isdefault = '是'
                } else {
                  rowS.isdefault = '否'
                }
                if (Number(data[i].status) === 1) {
                  rowS.status = '启用'
                } else {
                  rowS.status = '停用'
                }
                mx.push(rowS)
              }
              this.edit.data.form.packageMx = mx
              this.edit.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      editEve (msg) {
        this.edit.dialogVisible = false
        let tmp = {
          title: '商品信息预览',
          type: 'addCommodityManagement',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              brandName: '',
              factoryName: '',
              provinceName: '',
              pcktmpName: '',
              rowId: '',
              goodsCode: '',
              goodsDesc: '',
              shortCode: '',
              shortName: '',
              goodsClass: '',
              goodsGrade: '',
              brandId: '',
              remarks: '',
              status: '',
              pcktmpId: '',
              goodsCatId: '',
              provinceId: '',
              barcodeBox: '',
              barcodeLoaf: '',
              barcodePack: '',
              stdName: '',
              gradeId: '',
              cigaretteType: '',
              color1: '',
              color2: '',
              packageSpec: '',
              statisticType: '',
              cigKind: '',
              totalLen: '',
              cigaretteLen: '',
              snipeLen: '',
              filterType: '',
              cigaretteGirth: '',
              tarScalar: '',
              nicotineScalar: '',
              monoxide: '',
              myjyCode: '',
              is100t: '',
              seq100t: '',
              isConfiscated: '',
              isOther: '',
              isInprovince: '',
              isLowTar: '',
              isCadrebrand: '',
              cigState: '',
              originType: '',
              reserveTag2: '',
              reserveTag3: '',
              marketDate: '',
              impDate: '',
              coreValue: '',
              taste: '',
              marketPosition: '',
              targetobject: '',
              nmprice: 0,
              cigLifecycle: '',
              synopsis: '',
              propaganda: '',
              loafSpclFlag: '',
              boxSpclFlag: '',
              maxOrderDate: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: '',
              packageMx: []
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      selectEve (msg) {
        if (msg === 'query') {
          let params = {}
          if ('children' in this.factoryTree) {
            params.factoryId = this.factoryTree.id
          } else {
            params.brandId = this.factoryTree.id
          }
          let or = ''
          if (this.selectD.data.form.goodsCode !== '') {
            or = or + 'goodsCode:' + this.selectD.data.form.goodsCode + ','
          }
          if (this.selectD.data.form.goodsDesc !== '') {
            or = or + 'goodsDesc:' + this.selectD.data.form.goodsDesc + ','
          }
          if (this.selectD.data.form.goodsGrade !== '') {
            params.goodsGrade = this.selectD.data.form.goodsGrade
          }
          if (this.selectD.data.form.shortCode !== '') {
            or = or + 'shortCode:' + this.selectD.data.form.shortCode + ','
          }
          if (or.length > 0) {
            params.fluzzy = {'and': or}
          }
          this.queryUpper(params)
        }
        this.selectD.dialogVisible = false
      }, // 查询事件
      sortChange (msg) {},
      rowClick (msg) {},
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      selectionChange (rows) {},
      updateEve (msg) {
        if (msg !== 'cancle') {
          let params = msg.data.form
          api.requestJava('POST', BasePath.COMMODITY_UPDATE, params)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.$message({ type: 'success', message: '新增成功!' })
                this.init()
                this.queryUpper({})
              } else if (Number(request.data.code) === 401) {
                this.$notify.error({ title: '提示', message: '新增错误' })
              } else {
                this.$notify.error({ title: '提示', message: '新增错误' })
                throw new Error(JSON.stringify(request))
              }
            })
            .catch((err) => {
              this.$store.commit('TOGGLE_LOADING')
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        } else {
          this.updateD.dialogVisible = false
        }
      }
    },
    components: {
      _TREECOMPONENT,
      _TABLE,
      _POPUP,
      _BTN_FILTER,
      MY_POPUP_CONFIG,
      MY_POPUP_UPDATE,
      MY_POPUP_SELECT
    }
  }
</script>
