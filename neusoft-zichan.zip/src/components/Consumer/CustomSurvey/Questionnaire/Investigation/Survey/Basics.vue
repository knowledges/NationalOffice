<style scoped>
  .cust_box{
    display: block;
    margin-left: 0px;
  }
</style>
<template>
  <li class="li_surveyQuItemBody surveyQu_1" style="">
    <div class="surveyQuItemBody">
      <div class="initLine"></div>
      <div class="quInputCase" style="display: none;">
        <input type="hidden" name="quType" value="RADIO" />
        <input type="hidden" name="quId"  :value="Basics.itemCode" />
        <input type="hidden" name="orderById" :value="Basics.sortNbr">
        <input type="hidden" name="isRequired" :value="Basics.mustFlag">
      </div>
      <div class="surveyQuItem">
        <div class="surveyQuItemContent">
          <div class="quCoTitle">
            <div class="quCoNum">
              {{Basics.sortNbr}}、
            </div>
            <div class="editAble quCoTitleEdit">
              <ol class="custom_num list-paddingleft-1">
                <li class="list-num-1-1 list-num-paddingleft-1">
                  <p><span style="text-decoration: underline;">{{Basics.title}}</span><span v-if="Basics.mustFlag == 1">（此题必答）</span></p>
                </li>
              </ol>
            </div>
          </div>
          <div class="quCoItem">
            <template v-if="Basics.inputType == 'radio'">
              <el-radio-group v-model="Basics.val" @change="handleChange" @click.native="handleClick($event, Basics, _key)">
                <el-radio class="cust_box" :disabled="Disabled == 0"
                          v-for="(quItem, key) in Basics.enumList"
                          :key="key" :label="quItem.listTitle">{{quItem.listTitle}}
                </el-radio>
              </el-radio-group>
            </template>
            <template v-else-if="Basics.inputType == 'multiselect'">
              <el-checkbox-group
                v-model="Object.prototype.toString.call(Basics.val) !== '[object Array]' ? Basics.val = [] : Basics.val"
                @change='handleChange'>
                <el-checkbox class="cust_box" @click.native="handleClick($event, Basics)"
                             v-for="(quItem, key) in Basics.enumList"  :disabled="Disabled == 0"
                             :key="key" :label="quItem.listTitle">{{quItem.listTitle}}</el-checkbox>
              </el-checkbox-group>
            </template>
            <template v-else-if="Basics.inputType == 'input'">
              <el-input @change="inputChange(Basics.val, Basics)"
                        v-model="Basics.val"  :disabled="Disabled == 0"
                        placeholder="请输入内容" style="width:300px;"></el-input>
            </template>
          </div>
        </div>
      </div>
    </div>
  </li>
</template>
<script>
  export default {
    props: {
      Disabled: {
        type: Number,
        default: 1
      },
      Basics: {
        type: Object,
        default: {}
      },
      _key: {
        type: Number,
        default: 0
      }
    },
    data () {
      return {
        radios: [],
        temp: {},
        timer: null
      }
    },
    methods: {
      handleChange (val) {
        this.temp = val
      }, // 单选框、复选框改变时
      inputChange (val, obj) {
        this.fill(val, obj)
      }, // 文本框
      handleClick (e, obj, idx) {
        /* preventDefault() 阻止元素默认的行为；将会导致chang功能失效 */
        clearTimeout(this.temp)
        this.timer = setTimeout(() => {
          this.fill(this.temp, obj)
        }, 500)
      },
      fill (val, obj) {
        for (let i in this.$parent.subParams) {
          let ele = this.$parent.subParams[i]
          if (ele.key === obj.itemCode) {
            ele.val = val
          }
        }
      }
    }
  }
</script>
