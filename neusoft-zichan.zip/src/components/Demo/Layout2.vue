<style scoped>
</style>
<template>
  <div class="container-fluid">
    <_BTN_FILTER :isMore="isMore" :fileName="filName" :btnGroups="btnGroups"
                 :tableData="tableData"/>
    <el-row :gutter="22" class="cust_el_row">
      <el-row :gutter="24" class="cust_row_l">
        <el-col :span="4"  class="cust_el_col">
          <button class="btn cust_btn_l" @click="showTreeClk">
            <i class="fa fa-angle-double-left" v-if="isTree"></i>
            <i class="fa fa-angle-double-right" v-if="!isTree"></i>
          </button>
        </el-col>
        <transition name="moveL">
          <el-col :span="20" class="cust_el_col cust_btn_box"  v-if="isTree">
            <div class="grid-content bg-purple">
              <_TREECOMPONENT :search=searchable :data='treeData' :nodeClick='showTree' :nodeKey="nodeKey"
                              :showCheckBox=showCheckBox :expandAll=expandAll ref='tree' :highlight='true'
                              :defaultCheckedKeys="defaultCheckedKeys"></_TREECOMPONENT>
            </div>
          </el-col>
        </transition>
      </el-row>
      <el-col :span="22" class="cust_el_col" style="margin-left: 8%">
        <div class="grid-content bg-purple">
          <_TABLE :columns="columnHeader" :tableData="dataSource" :tableHeight="400"
                  :sortChange="sortChange" :rowClick="rowClick" :btnMode=true :btns="btns"
                  :pageSizes="pageSizes" :currentPage=currentPage :pageSize=pageSize
                  :totalCount=totalCount :queryData=this.queryData
                  :checkBox=true :columnType=columnType
                  :select="select" :selectAll="selectAll" :tableType="tableType"></_TABLE>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/TabPagin/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import api from '@/api'
  import log from '@/log'
  import _TREECOMPONENT from '@/components/Template/Tree/Tree.vue'
  import {getCodeList} from '@/config/info'
  import BasePath from '@/config/BasePath'
  export default {
    mounted () {
      this.init()
      this.treeInit()
      getCodeList('YC_GEO_TYPE', (data) => {
        this.geoType = data.label
      })
    },
    data () {
      return {
        isTree: false,
        /** table **/
        columnType: 'selection',
        currentPage: 1, // 默认当前第一页
        pageSize: 10,  // 默认每页20条数据
        pageSizes: [2, 5, 10, 20, 40, 50], // 分页数选择项
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            width: '150',
            value: 'nationalCode', // 列的值
            label: '国标码', // 列的显示字段
            align: 'left' // 列的对齐方式，[left, center, right]，选填，默认是left
          },
          {
            width: '150',
            value: 'customerCode', // 列的值
            label: '客户代码', // 列的显示字段
            align: 'center' // 列的对齐方式，[left, center, right]，选填，默认是left
          },
          {
            width: '280',
            value: 'customerDesc',
            className: 'header', // 列的css样式（选填）
            label: '客户名称'
          },
          {
            width: '100',
            value: 'contactperson',
            align: 'left',
            label: '联系人'
          },
          {
            width: '150',
            value: 'tel',
            align: 'left',
            label: '电话'
          },
          {
            width: '100',
            value: 'geoType',
            align: 'left',
            label: '市场类型'
          },
          {
            width: '100',
            value: 'businessType',
            align: 'left',
            label: '零售业态'
          },
          {
            width: '100',
            value: 'operationScale',
            align: 'left',
            label: '销售规模'
          }
        ],
        tableData: [
          {
            nationalCode: '',
            customerCode: '',
            customerDesc: '',
            contactperson: '',
            tel: '',
            geoType: [],
            businessType: '',
            operationScale: '',
            operationScalesdf: ''
          }
        ],
        btns: {
          btnArr: [
            {
              label: '修改', // 按钮的名称
              value: 'modify', // 按钮的值
              type: 'success',
              functionName: this.modify // 按钮的方法
            },
            {
              label: '删除',
              value: 'del',
              type: 'danger',
              functionName: this.del
            }
          ],
          value: 'operation',
          label: '操作',
          width: 150
        },
        tableType: '4',
        dataSource: [], // 当前页的数据
        /** filter **/
        filmode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        filType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        filName: ['customerCode', 'customerDesc'],
        isMore: true,
        keyupend: false,   // 输入筛选；true：之前展示；false：之后展示
        templTableData: [], // 临时记录tableDate的值
        btnGroups: [],
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        treeData: [],
        nodeKey: 'id',
        defaultCheckedKeys: [],
        searchable: true, // 是否带搜索框
        showCheckBox: true, // 是否带复选框
        expandAll: true, // 是否展开所有节点
        /** 弹出层 **/
        dialogObj: {
          title: '筛选条件',
          type: 'query',
          dialogVisible: false,
          data: {
            form: {
              geoType: [],
              businessType: '',
              operationScale: '',
              orderMethod: '',
              customerGrade: '',
              batchNo: '',
              stauts: '',
              treeId: '',
              treeType: ''
            }
          }
        }
      }
    },
    methods: {
      showTreeClk () {
        this.isTree = !this.isTree
      },
      treeInit () {
        this.treeData = [{
          id: 1,
          label: '江苏省烟草专卖局',
          type: 'company',
          children: [{
            id: 11,
            label: '直属分公司',
            type: 'company',
            children: [{
              id: 11,
              label: '直属客户服务科',
              type: 'dept',
              children: [
                {
                  id: 11,
                  label: '梁合群',
                  type: 'mgr'
                },
                {
                  id: 12,
                  label: '胡光伟',
                  type: 'mgr'
                }
              ]
            }]
          }]
        }]
      },
      init () {
        let param = {}
        param.pageSize = 100
        param.pageNum = 1
        api.requestJava('POST', BasePath.CUSTOMER_SELECT, param, {})
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.queryData(this.currentPage, this.pageSize)
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      showTree (data) {
        this.treeId = data.id
        this.treeName = data.label
        this.dialogObj.title = data.label + '筛选条件'
        this.dialogObj.data.form.treeId = data.id
        this.dialogObj.data.form.treeType = data.type
      },
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      select (selection, index) {
        if (selection[0] !== undefined) {
//        this.sel_id = index.id
          this.sel_all = []
          for (var i in selection) {
            this.sel_all.push(selection[i].rowId)
          }
        } else {
//        this.sel_id = ''
        }
      }, // 选中某1条
      selectAll (data) {
        this.sel_all = []
        for (var i in data) {
          this.sel_all.push(data[i].rowId)
        }
      }, // 全选
      addClk () {
        this.$router.push({name: 'CustomerDetail', params: {}})
      }, // 新增
      modify (index, row) {
        this.$router.push({name: 'CustomerDetail', params: {rowId: row.rowId}})
      }, // 修改
      del (index, row) {
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let params = {}
          params.rowId = row.rowId
          api.requestJava('POST', BasePath.CUSTOMER_DELETE, params, {})
            .then(request => {
              if (Number(request.data.code) === 200) {
                this.$message({ type: 'success', message: '删除成功!' })
                this.init()
              } else {
                this.$notify.error({ title: '提示', message: Number(request.data.code) })
                throw new Error(JSON.stringify(request))
              }
            }).catch(() => {
              this.$message({ type: 'info', message: '删除操作异常!' })
            }
          )
        }).catch(() => {
          this.$message({ type: 'info', message: '已取消删除!' })
        })
      },  // 删除
      onendChange (val) {
        var tmp = JSON.parse(val)
        if (Object.prototype.toString.call(tmp) === '[object Array]') {
          this.dataSource = tmp
        } else {
          this.dataSource = []
          this.dataSource.push(tmp)
        }
      }, // 过滤器修改事件
      confirmBack (msg) {
        let param = {}
        param.pageSize = 100
        param.pageNum = 1
        let data = msg.data.form
        param.geoType = data.geoType
        param.businessType = data.businessType
        param.operationScale = data.operationScale
        param.orderMethod = data.orderMethod
        param.customerGrade = data.customerGrade
        param.batchNo = data.batchNo
        param.stauts = data.stauts
        param.treeType = data.treeType
        param.treeId = data.treeId
        api.requestJava('POST', BasePath.CUSTOMER_SELECT, param, {})
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.queryData(this.currentPage, this.pageSize)
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      isMoreClk () {
        this.dialogObj.data.form.geoType = ''
        this.dialogObj.data.form.businessType = ''
        this.dialogObj.data.form.operationScale = ''
        this.dialogObj.data.form.orderMethod = ''
        this.dialogObj.data.form.customerGrade = ''
        this.dialogObj.data.form.batchNo = ''
        this.dialogObj.data.form.stauts = ''
        this.dialogObj.dialogVisible = true
      },
      inputChange (val) {
        this.tableData = JSON.parse(val)
        this.queryData(this.currentPage, this.pageSize)
      },
      sortChange (msg) {},
      rowClick (msg) {}
    },
    components: {
      _TABLE,
      _BTN_FILTER,
      _TREECOMPONENT
    }
  }
</script>
