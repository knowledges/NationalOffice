<template>
  <div class="container-fluid_new">
    <div>
      <_TABLE
        ref="table"
        stripe
        maxHeight="500"
        @update:data="tabChange" :reqParams="reqParams"
        :data="dataSource"
        :columns="columnHeader"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
        @selection-change="selectionChange"></_TABLE>
    </div>
  </div>
</template>
<style scoped>
  .container-fluid_new {
    background: #FFF;
  }
</style>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import BasePath from '@/config/BasePath'
  import { dateFormat, last3Month } from '@/utils/common'
  import api from '@/api'
  import log from '@/log'
  export default {
    props: {
      custId: {
        type: String,
        default: ''
      }
    },
    mounted () {
      console.log('获取客户信息4：', JSON.parse(this.custId))
      this.init(JSON.parse(this.custId))
    },
    data () {
      return {
        /** table **/
        cust: {},
        isSelect: false,
        isMore: true, // 查询更多条件
        currentPage: 1, // 默认当前第一页
        pageSize: 500,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        tableType: '3',
        columnHeader: [
          {
            prop: 'orderCd', // 列的值
            label: '订单号', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'dtOrderdayId',
            label: '订单日期',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          },
          {
            prop: 'orderQty',
            label: '总数量',
            columnsProps: {align: 'left'}
          },
          {
            prop: 'orderAmt',
            label: '总金额',
            columnsProps: {align: 'left'}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 120, type: 'button'},
            cptProperties: [
              {
                label: '查看',
                value: 'query',
                icon: 'search',
                size: 'small',
                type: 'primary',
                eventClick: this.modify
              }
            ]
          }
        ],
        dataSource: [],
        tableData: [],
        hasPagination: true
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      init (val) {
        let orderParam = {}
        orderParam.customerCode = val.customerCode
        orderParam.BDate = last3Month('YYYY-MM-DD')
        orderParam.EDate = dateFormat(Date.parse(new Date()), 'YYYY-MM-DD')
        console.log('orderParam', JSON.stringify(orderParam))
        this.reqParams.url = BasePath.ORDER_HISTORY
        this.reqParams.params = orderParam
        api.requestJava('POST', BasePath.ORDER_HISTORY, orderParam)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.currentPage = 1
              this.totalCount = this.tableData.length
              this.queryData(this.currentPage, this.pageSize)
            } else {
              this.$notify.error({ title: '提示', message: request.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      modify (index, row) {
        let param = {}
        param.customerCode = JSON.parse(this.custId).customerCode
        param.BDate = row.dtOrderdayId
        this.$emit('confirmBack', JSON.stringify(param))
      }, // 查询接口
      selectionChange (rows) {},
      isMoreClk () {
        this.isSelect = !this.isSelect
      },
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      headerClick () {},
      sortChange (msg) {},
      rowClick (msg) {}
    },
    components: {
      _TABLE
    },
    watch: {
      custId (val, old) {
        this.init(JSON.parse(val))
      }
    }
  }
</script>
