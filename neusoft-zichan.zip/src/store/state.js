export default {
  callingAPI: false,
  searching: '',
  serverURI: 'http://10.110.1.136:8080',
  user: null,
  token: null,
  userInfo: {
    userName: '',
    userCode: '',
    remarks: '',
    email: '',
    status: 0,
    authToke: ''
  },
  company: {},
  deparment: {},
  powerMenu: {},
  localPowerMenu: {},
  routeMenu: [],
  sessionMenus: [],
  // sessionMenus: !sessionStorage.getItem('sessionMenus') ? sessionMenus = [] : sessionStorage.getItem('sessionMenus'),
  isLoading: {
    status: true,
    msg: '内容正在渲染...'
  },
  routeIdx: 0,
  errorMessage: {}
}
