<template>
  <li data-v-73ab92a0="" class="li_surveyQuItemBody">
    <div class="surveyQuItemBody">
      <div class="initLine"></div>
      <div class="quInputCase" style="display: none;">
        <input type="hidden" name="rowId" :value="SubFillBlank.rowId"/>
        <input type="hidden" name="quType" value="input">
        <input type="hidden" name="itemCode" :value="SubFillBlank.itemCode">
        <input type="hidden" name="sortNbr" :value="SubFillBlank.sortNbr">
        <input type="hidden" name="saveTag" value="0">
        <input type="hidden" name="isRequired" :value="SubFillBlank.mustFlag">
        <input type="hidden" name="hv" value="2">
      </div>
      <div class="surveyQuItem">
        <div class="surveyQuItemLeftTools" v-if="SubFillBlank.itemCode == SubFillBlank.rowId">
          <ul class="surveyQuItemLeftToolsUl">
            <li title="移动排序" class="dwQuMove ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
            <li title="设置" class="dwQuSet ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
            <!--<li title="逻辑" class="dwQuLogic ui-draggable ui-draggable-handle">-->
              <!--<div class="dwQuIcon">-->
                <!--<div class="quLogicInfo"></div>-->
              <!--</div>-->
            <!--</li>-->
            <li title="删除" class="dwQuDelete ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
          </ul>
        </div>
        <div class="surveyQuItemRightTools">
          <ul class="surveyQuItemRightToolsUl">
            <li class="questionUp ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
            <li class="questionDown ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
          </ul>
        </div>
        <div class="surveyQuItemContent">
          <div class="quCoTitle">
            <div class="quCoNum">{{SubFillBlank.sortNbr}}、</div>
            <div class="editAble quCoTitleEdit">{{SubFillBlank.title}}</div>
            <input type="hidden" name="quTitleSaveTag" value="0">
          </div>
          <div class="quCoItem">
            <ul>
              <li class="quCoItemUlLi ui-draggable ui-draggable-handle">
                <div class="quFillblankItem">
                  <el-input class="quFillblankAnswerInput"  style="width:200px;padding:5px;" placeholder="请输入内容"></el-input>
                  <!--<input type="text" class="quFillblankAnswerInput" style="width: 200px; padding: 5px;">-->
                  <!--<textarea rows="5" class="quFillblankAnswerTextarea" style="width: 300px; display: none;"></textarea>-->
                  <!--<div class="dwFbMenuBtn"></div>-->
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </li>
</template>
<script>
  export default {
    props: ['SubFillBlank']
  }
</script>
