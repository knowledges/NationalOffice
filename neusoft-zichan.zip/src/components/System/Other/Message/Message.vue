﻿<!--黄龙-->
<template xmlns="http://www.w3.org/1999/html">
  <div class="container-fluid">
    <div>
      <el-collapse-transition>
        <el-tabs v-model="activeName" @tab-click="handleClick" >
          <el-tab-pane label="小结" name="first">
            <div class="second">
              <el-row style="margin-left: 7%;">
                <el-col :span="24"><el-button  type="success" class= "sure"  @click="updateClk()"><i class="fa fa-plus"></i>添加</el-button></el-col>
              </el-row>
              <template v-for="(item, key) in summaryOption">
                <el-row style="margin-left: 7%;">
                  <el-col :span="8">
                    <p class="p_left" style="color:#00e765;">{{item.deptname}}{{item.userName}}的{{Number(item.setionId) ===1?'小结':'消息'}}</p>
                  </el-col>
                  <el-col :span="8">
                    <p style="float:left;margin: 0em 3em;">{{item.createdTime.substr(0,10)}}</p>
                  </el-col>
                  <el-col :span="8">
                    <div style="margin-left:45%;display:inline-block;float:left;" :class="isOperation(item.userNames) ? 'fa fa-thumbs-o-up fa-2x' : 'fa fa-thumbs-up fa-2x'" @click="dianZan(item,$event)"></div>
                    <div class="fa fa-comment-o fa-2x" style="margin-left: 20px;display:inline-block;float:left;"  @click="show(item, key)"></div>
                  </el-col>
                </el-row>
                <br />
                <div style="display:inline-block;float:left;margin-left: 7%;margin-right:10%;margin-top: 10px">
                  <p class="p_right" style="font-size: 14px" v-html="item.contents"></p>
                  <br v-if="idx === key"/><input type="text" name="message" v-model="item.notes" v-if="idx === key">&nbsp; <a v-if="idx === key" @click="faSong(item, key)">发送</a>
                </div>
                <br />
                <div style="float:left;margin-left: 7%;width: 88%; background-color:#F0F0F0;">
                  <div class="fa fa-thumbs-o-up fa-2x" style="padding: 0.2cm 0.4cm"></div>
                  <p style="display:inline-block;color:#00acd6;">{{item.userNames}}</p>
                  <br/>
                  <div class="fa fa-comment-o fa-2x" style="padding: 0.2cm 0.4cm"></div>
                  <template v-for="item1 in item.detailEntities">
                    <p style="display:inline-block;color:#00acd6;">{{item1.username}}</p>&nbsp;&nbsp;:<p style="display:inline-block;">{{item1.comments}}</p><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </template>
                </div>
                <br />
              </template>
            </div>
            <div class="father" style="display:none;">
              <div class="childone" contentEditable="true">
              </div>
              <el-button  class= "cancle"   @click="cancleClk()" ><i  class="fa fa-remove"></i>&nbsp;取 消</el-button>
              <el-button  type="success"  class= "sure" @click="submit()"><i class="fa fa-cloud-upload"></i>&nbsp;提交</el-button>
              <div  class="childthread">
                <el-form ref="searchForm" :model="searchForm" label-width="120px">
                  <el-form-item label="可见范围">
                    <el-select v-model="searchForm.range" @change="changeValue" :clearable="true" placeholder="请选择可见范围">
                      <el-option
                        v-for="item in optionsRange"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-form>
              </div>
              <div class="childthfore">
                <el-form ref="searchForm" :model="searchForm" label-width="120px">
                  <el-form-item prop="dept" label="@范围" >
                    <el-select v-model="searchForm.dept" multiple filterable :clearable="true" placeholder="请选择@范围" :disabled="readonly">
                      <el-option
                        v-for="item in optionsEmployeeName"
                        :key="item.rowId"
                        :label="item.employeeName"
                        :value="item.rowId">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-form>
              </div>
            </div>
          </el-tab-pane>
          <el-tab-pane label="消息" name="second">
            <div class="third">
              <el-row style="margin-left: 7%;">
                <el-col :span="24"><el-button  type="success" class= "sure"  @click="updateClkthird()"><i class="fa fa-plus"></i>添加</el-button></el-col>
              </el-row>
              <template v-for="(item, key) in newsOption">
                  <el-row style="margin-left: 7%;">
                    <el-col :span="8">
                      <p class="p_left" style="color:#00e765;">{{item.deptname}}{{item.userName}}的{{Number(item.setionId) ===1?'小结':'消息'}}</p>
                    </el-col>
                    <el-col :span="8">
                      <p style="float:left;margin: 0em 3em;">{{item.createdTime.substr(0,10)}}</p>
                    </el-col>
                    <el-col :span="8">
                      <div style="margin-left:45%;display:inline-block;float:left;" :class="isOperation(item.userNames) ? 'fa fa-thumbs-o-up fa-2x' : 'fa fa-thumbs-up fa-2x'" @click="dianZan(item,$event)"></div>
                      <div class="fa fa-comment-o fa-2x" style="margin-left: 20px;display:inline-block;float:left;"  @click="show(item, key)"></div>
                    </el-col>
                  </el-row>
                <div style="display:inline-block;float:left;margin-left: 7%;margin-right:10%;margin-top: 10px">
                  <p class="p_right" style="font-size: 14px"  v-html="item.contents"></p>
                  <br v-if="idx === key"/><input type="text" name="message" v-model="item.notes" v-if="idx === key">&nbsp; <a v-if="idx === key" @click="faSong(item, key)">发送</a>
                </div>
                <br />
                <div style="float:left;margin-left: 7%;width: 88%; background-color:#F0F0F0;">
                  <div class="fa fa-thumbs-o-up fa-2x" style="padding: 0.2cm 0.4cm"></div>
                  <p style="display:inline-block;color:#00acd6;">{{item.userNames}}</p>
                  <br/>
                  <div class="fa fa-comment-o fa-2x" style="padding: 0.2cm 0.4cm"></div>
                  <template v-for="item1 in item.detailEntities">
                    <p style="display:inline-block;color:#00acd6;">{{item1.username}}</p>&nbsp;&nbsp;:<p style="display:inline-block;">{{item1.comments}}</p><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </template>
                </div>
                <br />
              </template>
            </div>
            <div class="father" style="display:none;">
              <div class="childone" contentEditable="true">
              </div>
              <el-button  class= "cancle"   @click="cancleClkthird()" ><i  class="fa fa-remove"></i>&nbsp;取 消</el-button>
              <el-button  type="success"  class= "sure" @click="submitthird()"><i class="fa fa-cloud-upload"></i>&nbsp;提交</el-button>
              <div  class="childthread">
                <el-form ref="searchForm" :model="searchForm" label-width="120px">
                  <el-form-item label="可见范围">
                    <el-select v-model="searchForm.range" @change="changeValue" :clearable="true" placeholder="请选择可见范围">
                      <el-option
                        v-for="item in optionsRange"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-form>
              </div>
              <div class="childthfore">
                <el-form ref="searchForm" :model="searchForm" label-width="120px">
                  <el-form-item prop="dept" label="@范围" >
                    <el-select v-model="searchForm.dept" multiple filterable :clearable="true" placeholder="请选择@范围" :disabled="readonly">
                      <el-option
                        v-for="item in optionsEmployeeName"
                        :key="item.rowId"
                        :label="item.employeeName"
                        :value="item.rowId">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-form>
              </div>
            </div>
          </el-tab-pane>
          <el-tab-pane label="@我" name="third">
            <div class="fore">
              <template v-for="(item, key) in meOption">
                <el-row style="margin-left: 7%;">
                  <el-col :span="8">
                    <p class="p_left" style="color:#00e765;">{{item.deptname}}{{item.userName}}的{{Number(item.setionId) ===1?'小结':'消息'}}</p>
                  </el-col>
                  <el-col :span="8">
                    <p style="float:left;margin: 0em 3em;">{{item.createdTime.substr(0,10)}}</p>
                  </el-col>
                  <el-col :span="8">
                    <div style="margin-left:65%;display:inline-block;float:left;" :class="isOperation(item.userNames) ? 'fa fa-thumbs-o-up fa-2x' : 'fa fa-thumbs-up fa-2x'" @click="dianZan(item,$event)"></div>
                    <div class="fa fa-comment-o fa-2x" style="margin-left: 20px;display:inline-block;float:left;"  @click="show(item, key)"></div>
                  </el-col>
                </el-row>
                <div style="display:inline-block;float:left;margin-left: 7%;margin-right:10%;margin-top: 10px">
                  <p class="p_right" style="font-size: 14px" v-html="item.contents"></p>
                  <br v-if="idx === key"/><input type="text" name="message" v-model="item.notes" v-if="idx === key">&nbsp; <a v-if="idx === key" @click="faSong(item, key)">发送</a>
                </div>
                <br />
                <div style="float:left;margin-left: 7%;width: 88%; background-color:#F0F0F0;">
                  <div class="fa fa-thumbs-o-up fa-2x" style="padding: 0.2cm 0.4cm"></div>
                  <p style="display:inline-block;color:#00acd6;">{{item.userNames}}</p>
                  <br/>
                  <div class="fa fa-comment-o fa-2x" style="padding: 0.2cm 0.4cm"></div>
                  <template v-for="item1 in item.detailEntities">
                    <p style="display:inline-block;color:#00acd6;">{{item1.username}}</p>&nbsp;&nbsp;:<p style="display:inline-block;">{{item1.comments}}</p><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </template>
                </div>
                <br />
              </template>
            </div>
          </el-tab-pane>
          <el-tab-pane label="我的" name="fourth">
            <div class="five">
              <template v-for="(item, key) in commentOption">
                <el-row style="margin-left: 7%;">
                  <el-col :span="8">
                    <p class="p_left" style="color:#00e765;">{{item.deptname}}{{item.userName}}的{{Number(item.setionId) ===1?'小结':'消息'}}</p>
                  </el-col>
                  <el-col :span="8">
                    <p style="float:left;margin: 0em 3em;">{{item.createdTime.substr(0,10)}}</p>
                  </el-col>
                  <el-col :span="8">
                    <div style="margin-left:65%;display:inline-block;float:left;" :class="isOperation(item.userNames) ? 'fa fa-thumbs-o-up fa-2x' : 'fa fa-thumbs-up fa-2x'" @click="dianZan(item,$event)"></div>
                    <div class="fa fa-comment-o fa-2x" style="margin-left: 20px;display:inline-block;float:left;"  @click="show(item, key)"></div>
                  </el-col>
                </el-row>
                <div style="display:inline-block;float:left;margin-left: 7%;margin-right:10%;margin-top: 10px">
                  <p class="p_right" style="font-size: 14px" v-html="item.contents"></p>
                  <br v-if="idx === key"/><input type="text" name="message" v-model="item.notes" v-if="idx === key">&nbsp; <a v-if="idx === key" @click="faSong(item, key)">发送</a>
                </div>
                <br />
                <div style="float:left;margin-left: 7%;width: 88%; background-color:#F0F0F0;">
                  <div class="fa fa-thumbs-o-up fa-2x" style="padding: 0.2cm 0.4cm"></div>
                  <p style="display:inline-block;color:#00acd6;">{{item.userNames}}</p>
                  <br/>
                  <div class="fa fa-comment-o fa-2x" style="padding: 0.2cm 0.4cm"></div>
                  <template v-for="item1 in item.detailEntities">
                    <p style="display:inline-block;color:#00acd6;">{{item1.username}}</p>&nbsp;&nbsp;:<p style="display:inline-block;">{{item1.comments}}</p><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </template>
                </div>
                <br />
              </template>
            </div>
          </el-tab-pane>
          <el-tab-pane label="全部消息" name="five">
            <div class="first">
              <template v-for="(item, key) in consumption">
                <el-row style="margin-left: 7%;">
                  <el-col :span="8">
                    <p class="p_left" style="color:#00e765;">{{item.deptname}}{{item.userName}}的{{Number(item.setionId) ===1?'小结':'消息'}}</p>
                  </el-col>
                  <el-col :span="8">
                    <p style="float:left;margin: 0em 3em;">{{item.createdTime.substr(0,10)}}</p>
                  </el-col>
                  <el-col :span="8">
                    <div style="margin-left:65%;display:inline-block;float:left;" :class="isOperation(item.userNames) ? 'fa fa-thumbs-o-up fa-2x' : 'fa fa-thumbs-up fa-2x'" @click="dianZan(item,$event)"></div>
                    <div class="fa fa-comment-o fa-2x" style="margin-left: 20px;display:inline-block;float:left;"  @click="show(item, key)"></div>
                  </el-col>
                </el-row>
                <div style="display:inline-block;float:left;margin-left: 7%;margin-right:10%;margin-top: 10px">
                  <p class="p_right" style="font-size: 14px" v-html="item.contents"></p>
                  <br v-if="idx === key"/><input type="text" name="message" v-model="item.notes" v-if="idx === key">&nbsp; <a v-if="idx === key" @click="faSong(item, key)">发送</a>
                </div>
                <br />
                <div style="float:left;margin-left: 7%;width: 88%; background-color:#F0F0F0;">
                  <div class="fa fa-thumbs-o-up fa-2x" style="padding: 0.2cm 0.4cm"></div>
                  <p style="display:inline-block;color:#00acd6;">{{item.userNames}}</p>
                  <br/>
                  <div class="fa fa-comment-o fa-2x" style="padding: 0.2cm 0.4cm"></div>
                  <template v-for="item1 in item.detailEntities">
                    <p style="display:inline-block;color:#00acd6;">{{item1.username}}</p>&nbsp;&nbsp;:<p style="display:inline-block;">{{item1.comments}}</p><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  </template>
                </div>
              </template>
            </div>
          </el-tab-pane>
        </el-tabs>
      </el-collapse-transition>
    </div>
  </div>

</template>
<script>
  import _TABLE from '@/components/Template/TabPagin/Table.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import { getUser } from '@/config/info'
  import log from '@/log'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import { dateFormat, getFirstMonth, getDecember } from '@/utils/dateFormat'
  export default {
    mounted () {
      /** 调用初始化数据 **/
      this.init()
    },
    data () {
      return {
        idx: -1,
        activeName: Number(this.$route.params.count) > 0 ? 'third' : 'first',
        Array: [],
        all: [],
        gatherer: '',
        readonly: true,
        optionsEmployeeName: [],
        newsOption: [],
        meOption: [],
        userName: getUser.userName,
        commentOption: [],
        summaryOption: [],
        consumption: [],
        optionsRange: [
          {'value': '4', 'label': '仅自己和领导可见'},
          {'value': '3', 'label': '所在部门和下级部门'},
          {'value': '2', 'label': '全市可见'},
          {'value': '1', 'label': '全省可见'},
          {'value': '5', 'label': '请选择@的人  '}],
        searchForm: {
          dept: [],
          range: ''
        },
        item: {
          notes: ''
        }
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      init () {
        this.gatherer = getUser().userName
        this.second() // 小节
        this.third() // 消息
        this.fore() // @ 我
        this.five() // 我的
        this.findAll() // 全部消息
        this.getDeptEmployeeName()
      },
      dianZan: function (item, e) {
        let params = {}
        params.topicId = item.topicId
        params.userId = getUser().id
        params.personId = getUser().personId
        params.userName = getUser().userName
        params.isClick = 'Y'
        api.requestJava('POST', BasePath.REPLAY_REPLAYSAVE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              e.target.className = 'fa fa-thumbs-up fa-2x'
              this.init()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 点赞接口
      show: function (item, index) {
        this.idx = index
      },
      faSong: function (item, index) {
        if (item.notes !== null && item.notes !== '') {
          let params = {}
          params.topicId = item.topicId
          params.userId = getUser().id
          params.personId = getUser().personId
          params.userName = getUser().userName
          params.comments = item.notes
          api.requestJava('POST', BasePath.REPLAY_REPLAYSAVE, params)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.init()
                this.idx = -1
                item.notes = ''
              } else if (Number(request.data.code) === 401) {
                this.$message('登录失效')
                this.logInvalid.dialogVisible = true
              } else {
                this.$notify.error({title: '提示', message: request.data.message})
                throw new Error(JSON.stringify(request))
              }
            })
            .catch((err) => {
              let culprit = this.$route.name
              // this.toggleLoading()
              log.work(err, culprit)
            })
        } else {
          this.idx = -1
        }
      }, // 发送消息接口
      handleClick (tab, event) {
        $('.second').show()
        $('.father').hide()
      },
      updateClk () {
        $('.second').hide()
        $('.father').show()
        // 设置模板，调用接口
        let params = {}
        params.custmgrId = getUser().personId
        params.visitBegin = this.getTime(Date.parse(new Date()))
        params.visitEnd = this.getTime(Date.parse(new Date()))
        api.requestJava('POST', BasePath.CUSMGR_STATISTICS, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (request.data.data.length > 0) {
                var template =
                  '今日计划户数' +
                  request.data.data[0].planCusts +
                  '，实际拜访户数' +
                  request.data.data[0].visitCusts +
                  '，临时添加户数' +
                  request.data.data[0].tempCusts +
                  ',第一户签到时间为：' +
                  dateFormat(request.data.data[0].visitTimeBegin, 'YYYY-MM-DD HH:mm:ss') +
                  '，最后一户离店时间为：' +
                  dateFormat(request.data.data[0].visitTimeEnd, 'YYYY-MM-DD HH:mm:ss') +
                  '，在店总时长为' +
                  request.data.data[0].visitCustTimes +
                  '分钟，拜访总时长为：' +
                  request.data.data[0].visitAllTimes
              }
              $('.childone').text(template)
            }
          })
        this.searchForm.range = this.optionsRange[0].value
      },
      updateClkthird () {
        $('.third').hide()
        $('.father').show()
      },
      cancleClk () {
        this.searchForm.dept = []
        this.searchForm.range = ''
        $('.second').show()
        $('.father').hide()
      },
      cancleClkthird () {
        this.searchForm.dept = []
        this.searchForm.range = ''
        $('.third').show()
        $('.father').hide()
      },
      changeValue () {
        if (Number(this.searchForm.range) === 5) {
          this.readonly = false
        } else {
          this.readonly = true
        }
        this.searchForm.dept = []
      },
      submit () {
        let params = []
        let param = {}
        let value = $('.childone').text().trim()
        let range = this.searchForm.range
        if (range === null || range === '') {
          this.searchForm.range = '4'
        }
        if (value !== null && value !== '') {
          if (Number(this.searchForm.range) === 5) {
            let steps = this.searchForm.dept
            if (steps.length === 0) {
              this.$message({type: 'info', message: '请选择要@的人', duration: 1000})
              return
            }
            for (let i = 0; i < steps.length; i++) {
              let rowS = {}
              rowS.authObjId = steps[i]
              rowS.authLvl = this.searchForm.range
              params.push(rowS)
            }
            param.userId = getUser().id
            param.personId = getUser().personId
            param.title = $('.childone').text().substr(0, 6)
            param.contents = $('.childone').text()
            param.setionId = '1'
            param.rangeList = params
          } else {
            let rowS = {}
            rowS.authLvl = this.searchForm.range
            params.push(rowS)
            param.userId = getUser().id
            param.personId = getUser().personId
            param.title = $('.childone').text().substr(0, 6)
            param.contents = $('.childone').text()
            param.setionId = '1'
            param.rangeList = params
          }
          console.log('===', param)
          this.$confirm('确定要提交吗？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            api.requestJava('POST', BasePath.TOPIC_SAVETOPIC, param)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.$notify({title: '成功', message: '发送成功', type: 'success', duration: 1500})
                this.cancleClk()
                this.second()
              } else if (Number(request.data.code) === 401) {
                this.$message('登录失效')
                this.logInvalid.dialogVisible = true
              } else {
                this.$notify.error({title: '提示', message: request.data.message})
                throw new Error(JSON.stringify(request))
              }
            })
            .catch((err) => {
              let culprit = this.$route.name
              // this.toggleLoading()
              log.work(err, culprit)
            })
          }).catch(() => {
            this.$message({type: 'info', message: '已取提交操作!'})
          })
        } else {
          this.$message({type: 'info', message: '请输入小结内容', duration: 1000})
          return
        }
      },
      submitthird () {
        let params = []
        let param = {}
        let value = $('.childone').text().trim()
        let range = this.searchForm.range
        if (range === null || range === '') {
          this.searchForm.range = '4'
        }
        if (value !== null && value !== '') {
          if (Number(this.searchForm.range) === 5) {
            let steps = this.searchForm.dept
            if (steps.length === 0) {
              this.$message({type: 'info', message: '请选择要@的人', duration: 1000})
              return
            }
            for (let i = 0; i < steps.length; i++) {
              let rowS = {}
              rowS.authObjId = steps[i]
              rowS.authLvl = this.searchForm.range
              params.push(rowS)
            }
            param.userId = getUser().id
            param.personId = getUser().personId
            param.title = $('.childone').text().substr(0, 6)
            param.contents = $('.childone').text()
            param.setionId = '2'
            param.rangeList = params
          } else {
            let rowS = {}
            rowS.authLvl = this.searchForm.range
            params.push(rowS)
            param.userId = getUser().id
            param.personId = getUser().personId
            param.title = $('.childone').text().substr(0, 6)
            param.contents = $('.childone').text()
            param.setionId = '2'
            param.rangeList = params
          }
          console.log('===', param)
          this.$confirm('确定要提交吗？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            api.requestJava('POST', BasePath.TOPIC_SAVETOPIC, param)
              .then((request) => {
                if (Number(request.data.code) === 200) {
                  this.$notify({title: '成功', message: '发送成功', type: 'success'})
                  this.cancleClkthird()
                  this.third()
                } else if (Number(request.data.code) === 401) {
                  this.$message('登录失效')
                  this.logInvalid.dialogVisible = true
                } else {
                  this.$notify.error({title: '提示', message: request.data.message})
                  throw new Error(JSON.stringify(request))
                }
              })
              .catch((err) => {
                let culprit = this.$route.name
                // this.toggleLoading()
                log.work(err, culprit)
              })
          }).catch(() => {
            this.$message({type: 'info', message: '已取提交操作!'})
          })
        } else {
          this.$message({type: 'info', message: '请输入小结内容', duration: 1000})
          return
        }
      },
      getDeptEmployeeName () {
        let params = {}
//        params.place = 135
        params.status = 1
        params.companyId = getUser().companyId
//        params.deptId = getUser().deptId
        params.fields = {include: 'employeeName,rowId'}
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.optionsEmployeeName = request.data.data
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      findAll () {
        let params = {}
        params.userId = getUser().id
        params.beginTime = getFirstMonth()
        params.endTime = getDecember()
        api.requestJava('POST', BasePath.COMMON_TOPICQUERY, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.consumption = request.data.data
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询全部消息接口
      second () {
        let params = {}
        params.sectionName = '1'
        params.my = ''
        params.reply = ''
        params.userId = getUser().id
        params.beginTime = getFirstMonth()
        params.endTime = getDecember()
        api.requestJava('POST', BasePath.COMMON_TOPICQUERY, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.summaryOption = request.data.data
              console.log('查询小结记录：：：' + JSON.stringify(this.summaryOption))
              console.log(JSON.stringify(request.data.data))
//              Object.assign(this.summaryOption, request.data.data)
//              this.summaryOption.$set('summaryOption', request.data.data)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询小结接口
      third () {
        let params = {}
        params.sectionName = '2'
        params.my = ''
        params.reply = ''
        params.userId = getUser().id
        params.beginTime = getFirstMonth()
        params.endTime = getDecember()
        api.requestJava('POST', BasePath.COMMON_TOPICQUERY, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.newsOption = request.data.data
              console.log('查询消息记录：：：' + JSON.stringify(this.newsOption))
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询消息接口
      fore () {
        let params = {}
        params.sectionName = ''
        params.my = '1'
        //    params.reply = ''
        params.userId = getUser().id
        params.beginTime = getFirstMonth()
        params.endTime = getDecember()
        api.requestJava('POST', BasePath.COMMON_TOPICQUERY, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.meOption = request.data.data
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询@我接口
      five () {
        let params = {}
        params.sectionName = ''
        //    params.my = '1'
        params.reply = '1'
        params.userId = getUser().id
        params.beginTime = getFirstMonth()
        params.endTime = getDecember()
        api.requestJava('POST', BasePath.COMMON_TOPICQUERY, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.commentOption = request.data.data
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询我的接口
      isOperation (key) {
        let tmp = key.split(',')
        console.log(tmp)
        return tmp.indexOf(getUser().userName)
      } // 是否点赞
    },
    components: {
      _TABLE,
      _POPUP,
      _BTN_FILTER
    }
  }
</script>
<style>
  .test_box {
    width: 500px;
    min-height: 100px;
    max-height: 400px;
    margin: 0 auto;
    padding: 3px;
    outline: 0;
    border: 1px solid;
    font-size: 11px;
    word-wrap: break-word;
    overflow: auto;
  }
  /*.second {*/
  /*width:800px;*/
  /*height:500px;*/
  /*border:2px solid #000;*/
  /*position:relative;*/
  /*}*/
  .father {
    height:auto!important;
    min-height:480px;
    height:auto;
    position:relative;
  }
  .childone {
    width: 400px;
    height: 300px;
    border:solid 1px;
    left: 38%;
    margin-top: 10px;
    position:absolute;
  }
  .childtwo {
    width: 80px;
    height: 80px;
    border:solid 1px;
    border-radius: 6px;
    left: 38%;
    margin-top: 200px;
    position:absolute;
  }
  .childthread {
    width: 300px;
    height: 35px;
    /*border:solid 1px;*/
    /*border-radius: 4px;*/
    left: 34%;
    margin-top: 300px;
    position:absolute;
  }
  .childthfore {
    width: 300px;
    height: 40px;
    /*border:solid 1px;*/
    /*border-radius: 6px;*/
    left: 34%;
    margin-top: 360px;
    position:absolute;
  }
  .sure {
    margin-left: 89.4%;
  }
  .cancle {
    margin-left: 75%;
  }
  .p_left{float:left;font-size:15px;}
  .p_right{
    float:left;
    word-break:normal;
    word-wrap: break-word;
    word-break: break-all;
    display:inline-block;
    overflow: hidden;}
</style>
