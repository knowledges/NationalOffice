<style scoped></style>
<template>
  <li data-v-73ab92a0="" class="li_surveyQuItemBody">
    <div class="surveyQuItemBody">
      <div class="initLine"></div>
      <div class="quInputCase" style="display: none;">
        <input type="hidden" name="quType" value="score" />
        <input type="hidden" name="rowId" :value="SubScore.rowId"/>
        <input type="hidden" name="itemCode" :value="SubScore.itemCode">
        <input type="hidden" name="sortNbr" :value="SubScore.sortNbr">
        <input type="hidden" name="saveTag" value="0" />
        <!--<input type="hidden" name="hoverTag" value="0" />-->
        <input type="hidden" name="isRequired" :value="SubScore.mustFlag">
        <input type="hidden" name="hv" value="2" />
        <!--<input type="hidden" name="randOrder" value="0" />-->
        <!--<input type="hidden" name="cellCount" value="0" />-->
        <!--<input type="hidden" name="paramInt01" value="1" />-->
        <!--<input type="hidden" name="paramInt02" value="5" />-->
        <!--<div class="quLogicInputCase">-->
          <!--<input type="hidden" name="quLogicItemNum" value="0" />-->
        <!--</div>-->
      </div>
      <div class="surveyQuItem">
        <div class="surveyQuItemLeftTools"  v-if="SubScore.itemCode == SubScore.rowId" >
          <ul class="surveyQuItemLeftToolsUl">
            <li title="移动排序" class="dwQuMove ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div></li>
            <li title="设置" class="dwQuSet ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div></li>
            <!--<li title="逻辑" class="dwQuLogic ui-draggable ui-draggable-handle">-->
              <!--<div class="dwQuIcon">-->
                <!--<div class="quLogicInfo"></div>-->
              <!--</div></li>-->
            <li title="删除" class="dwQuDelete ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div></li>
          </ul>
        </div>
        <div class="surveyQuItemRightTools">
          <ul class="surveyQuItemRightToolsUl">
            <li class="questionUp ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
            <li class="questionDown ui-draggable ui-draggable-handle">
              <div class="dwQuIcon"></div>
            </li>
          </ul>
        </div>
        <div class="surveyQuItemContent">
          <div class="quCoTitle">
            <div class="quCoNum">
              {{SubScore.sortNbr}}、
            </div>
            <div class="editAble quCoTitleEdit">
              {{SubScore.title}}
            </div>
            <input type="hidden" name="quTitleSaveTag" value="0" />
          </div>
          <div class="quCoItem">
            <table cellpadding="0" cellspacing="0" class="quCoItemTable">
              <tbody>
                <template v-for="item in SubScore.enumList">
                  <tr class="quScoreOptionTr">
                    <td class="quCoItemTableTd quOptionEditTd">
                      <label class="editAble quCoOptionEdit">{{item.listTitle}}</label>
                      <div class="quItemInputCase">
                        <input type="hidden" name="rowId" :value="item.rowId">
                        <input type="hidden" name="rcFlag" :value="0">
                      </div>
                    </td>
                    <td class="quCoItemTableTd">
                      <el-rate v-model="item.val"></el-rate>
                    </td>
                    <td class="quCoItemTableTd">分</td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
          <div class="quCoBottomTools">
            <ul class="quCoBottomToolsUl"  v-if="SubScore.itemCode == SubScore.rowId">
              <li title="添加" class="addOption ui-draggable ui-draggable-handle">
                <div class="dwQuIcon"></div></li>
              <!--<li title="批量添加" class="addMoreOption ui-draggable ui-draggable-handle">-->
                <!--<div class="dwQuIcon"></div></li>-->
            </ul>
          </div>
        </div>
      </div>
    </div>
  </li>
</template>
<script>
  export default {
    props: ['SubScore']
  }
</script>
