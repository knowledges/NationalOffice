<!--qiu.bl-->
<style rel="stylesheet/scss" lang="scss" scoped></style>
<template>
    <div class="table-responsive">
      <table class="table table-bordered scrolltable">
        <thead style="display:block;border-bottom:1px solid #eee;">
          <tr>
            <td v-for="(item, key) in coloumHeader" :style="{width:item.coloumProp.width}">{{item.label}}</td>
          </tr>
        </thead>
        <tbody style="display:block; max-height:400px;overflow-y: scroll;">
        <!-- TODO 这里可以在方法里重构数据 在一次打印 -->
          <template v-for="(val, idx) in coloumDate">
            <tr>
              <template v-for="(item, key) in coloumHeader">
                <td v-if="item.type === 'array'" style="padding: 0 0;" :style="{width:item.coloumProp.width}">
                  <component :is="item.component" v-bind="getAllProps(val[item.prop])"></component>
                </td>
                <td v-else-if="item.coloumProp.type === 'img'" :style="{width:item.coloumProp.width}">
                  <component :is="item.component" v-bind="getAllProps(val[item.prop])"></component>
                </td>
                <td v-else :style="{width:item.coloumProp.width}" v-bind="getColBind(val, item)">{{val[item.prop]}}</span></td>
              </template>
            </tr>
          </template>
        </tbody>
      </table>
    </div>
</template>
<script>
  import Array from './Components/latList.vue'
  import Img from './Components/imgList.vue'
  const tableComponents = {
    'array': Array,
    'img': Img
  }
  export default {
    name: 'table',
    props: {
      coloumHeader: Array,
      coloumDate: Array
    },
    mounted () {
      this.restColumn()
    },
    data () {
      return {}
    },
    methods: {
      restColumn () {
        const {
          coloumHeader
        } = this
        coloumHeader.map((item) => {
          if (item.coloumProp && item.coloumProp.type) {
            var componentType = item.coloumProp.type
            this.$set(item, 'component', tableComponents[componentType])
            this.$set(item, 'type', componentType)
            return item
          }
        })
      },
      restData () {
        const {
          coloumHeader
        } = this
        coloumHeader.map((item) => {
          if (item.coloumProp.type !== undefined) {
            this.recursionArr(item.prop)
          }
        })
      },
      recursionArr (str) {
        const {
          coloumDate
        } = this
        coloumDate.map((item) => {
          if (item.detailList.length > 0) {
            var tmp = []
            item.detailList.map(val => {
              var arr = []
              if (typeof val[str] === 'object' && val[str].length > 0) {
                tmp = arr.concat(val[str])
              } else if (typeof val[str] === 'string' && val[str] !== '') {
                tmp.push(val[str])
              }
            })
            this.$set(item, str, tmp)
            return item
          }
        })
      },
      getAllProps (obj) {
        var props = {data: obj}
        return props
      },
      getColBind (obj, col) {
        if (col.coloumProp.formatter && typeof col.coloumProp.formatter === 'function') {
          const bind = Object.assign({}, col.coloumProp.formatter(obj, col))
          return bind
        }
      }
    },
    computed: {
    },
    components: {
    },
    watch: {
      coloumDate (val, old) {
        if (val !== old) {
          this.restData()
        }
      }
    }
  }
</script>
