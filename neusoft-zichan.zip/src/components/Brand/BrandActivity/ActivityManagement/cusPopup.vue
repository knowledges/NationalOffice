<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk"  :size='dialogObj.size' v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <div class="container-fluid_new">
      <el-collapse-transition>
        <div v-if="isSelect" class="filter_more">
          <el-form ref="searchForm" :model="dialogObj.data.form" label-width="120px">
            <el-col :span='24' >
              <el-col :span='8'>
                <el-form-item prop="countyId" label="数据范围">
                  <!--<_cascader :selectOption="dialogObj.data.form.dataGrade" @on-change="getChangeValue"/>-->
                  <MultiSelectCascader ref="mults" :selectOption="dialogObj.data.form.dataGrade" :selectCondition="dialogObj.data.form.fpConds" :getTransmit="getTransmit"></MultiSelectCascader>
                </el-form-item>
              </el-col>
            </el-col>
            <el-col :gutter="24">
              <el-col :span='8'>
                <el-form-item label="客户档级">
                  <el-select v-model="dialogObj.data.form.customerGrade" multiple  :clearable="true" placeholder="请选择客户档级" :disabled ="this.dialogObj.disable">
                    <template v-for="item in customerGradeGroup">
                      <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="市场类型">
                  <el-select v-model="dialogObj.data.form.geoType" multiple  :clearable="true" placeholder="请选择市场类型" :disabled ="this.dialogObj.disable">
                    <template v-for="item in geoTypeGroup">
                      <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="客户集">
                  <el-select v-model="dialogObj.data.form.rtlcatId" multiple  :clearable="true" placeholder="请选择客户集" :disabled ="this.dialogObj.disable">
                    <template v-for="item in rtlcatIdGroup">
                      <el-option  :key="item.rowId"  :label="item.name" :value="item.rowId"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
            <el-col :gutter="24">
              <el-col :span='8'>
                <el-form-item label="业态">
                  <el-select v-model="dialogObj.data.form.businessType" multiple  :clearable="true"  placeholder="请选择业态" :disabled ="this.dialogObj.disable">
                    <template v-for="item in businessTypeGroup">
                      <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="规模">
                  <el-select v-model="dialogObj.data.form.operationScale" multiple :clearable="true"  placeholder="请选择规模" :disabled ="this.dialogObj.disable">
                    <template v-for="item in operationScaleGroup">
                      <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="客户星级">
                  <el-select v-model="dialogObj.data.form.starGrade" multiple :clearable="true"  placeholder="请选择客户星级" :disabled ="this.dialogObj.disable">
                    <el-option
                      v-for="item in options_starGrade"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
          </el-form>
        </div>
      </el-collapse-transition>
      <el-row class="filter_style">
        <el-col :span="24" style="padding: 0 0">
          <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData"/>
        </el-col>
      </el-row>
          <div>
        <_TABLE
          ref="table"
          stripe
          maxHeight="500"
          :data="dataSource"
          @update:data="tabChange" :reqParams="reqParams"
          :columns="columnHeader"
          :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
          :totalCount="totalCount" :hasPagination="hasPagination"
          @selection-change="selectionChange" :setPage=this.getPage ></_TABLE>
      </div>
    </div>
  </el-dialog>
  </div>
</template>

<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import api from '@/api'
  import log from '@/log'
  import axios from 'axios'
  import BasePath from '@/config/BasePath'
  import {getCodeList, getUser} from '@/config/info'
  import _cascader from '@/components/Template/Cascader/Cascader.vue'
  import MultiSelectCascader from '@/components/Template/MultiSelectCascader/MultiSelectCascader.vue'
  export default {
    props: ['dialogObj'],
    mounted () {
      getCodeList('YC_BUSINESS_TYPE', (data) => {
        this.businessTypeGroup = data
      }) // 零售业态
      getCodeList('YC_GEO_TYPE', (data) => {
        this.geoTypeGroup = data
      }) // 市场类型
      getCodeList('YC_OPERATION_SCALE', (data) => {
        this.operationScaleGroup = data
      }) // 经营规模
      getCodeList('CUSTOMER_GRADE', (data) => {
        this.customerGradeGroup = data
      }) // 客户档级
      let params1 = {}
      params1.defPersonId = getUser().personId
      params1.fields = {'include': 'rowId,name'}
      let starGradeParam = {} // 客户星级
      starGradeParam.companyId = getUser().companyId
      starGradeParam.typeCode = 'STAR_GRADE'
      axios.all([
        api.requestJava('POST', BasePath.SELECT_RTLCATIDGROUP, params1),
        api.requestJava('POST', BasePath.CUSTOMER_STARGRADE, starGradeParam) // 客户星级
      ])
      .then(axios.spread((first, _starGrade) => {
        this.rtlcatIdGroup = first.data.data
        this.options_starGrade = _starGrade.data.data
      }))
    },
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        if (Number(this.dialogObj.type) === 5) {
          this.btnGroups = []
        }
        this.query(1, this.pageSize)
        this.$refs.mults.resetAssignment()
      }
    },
    data () {
      return {
        tmp: [],
        tempParam: {},
        countyId: [],
        marketmgrId: [],
        custmgrId: [],
        /** table **/
        rtlcatIdGroup: [],
        options_starGrade: [],
        columnType: 'selection',
        hasPagination: true,
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        customerGradeGroup: [],
        operationScaleGroup: [],
        geoTypeGroup: [],
        businessTypeGroup: [],
        Group: [],
        moreS: [
          {
            colunm: 'customerGrade',
            type: 'string'
          },
          {
            colunm: 'geoType',
            type: 'string'
          },
          {
            colunm: 'businessType',
            type: 'string'
          },
          {
            colunm: 'routeId',
            type: 'string'
          },
          {
            colunm: 'operationScale',
            type: 'string'
          },
          {
            colunm: 'rtlcatId',
            type: 'string'
          },
          {
            colunm: 'starGrade',
            type: 'string'
          }
        ],
        columnHeader: [
          {
            prop: 'customerCode', // 列的值
            label: '客户代码', // 列的显示字段
            columnsProps: {width: 140, align: 'center'}
          },
          {
            prop: 'customerDesc', // 列的值
            label: '客户名称', // 列的显示字段
            columnsProps: {width: 200, align: 'left'}
          },
          {
            prop: 'addr',
            label: '经营地址',
            columnsProps: {align: 'left'}
          },
          {
            prop: 'tel',
            label: '联系电话',
            columnsProps: {width: 140, align: 'center'}
          },
          {
            prop: 'marketmgrNm',
            label: '市场经理',
            columnsProps: {width: 120, align: 'center'}
          },
          {
            prop: 'custmgrNm',
            label: '客户经理',
            columnsProps: {width: 120, align: 'center'}
          }
        ],
        tableData: [],
        dataSource: [], // 当前页的数据
        /** filter **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['customerCode', 'customerDesc', 'addr', 'marketmgrNm', 'custmgrNm'],
        isMore: true,
        isSelect: true,
        keyupend: false,   // 输入筛选；true：之前展示；false：之后展示
        templTableData: [], // 临时记录tableDate的值
        btnGroups: [
          {
            name: '确定',
            className: 'btn-success',
            iconName: 'fa-plus',
            event: this.addClk
          },
          {
            name: '筛选',
            className: 'btn-success',
            iconName: 'fa-search',
            event: this.query_New
          }
        ],
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        treeData: [],
        nodeKey: 'id',
        defaultCheckedKeys: [],
        isLoading: true
        /** 弹出层 **/
      }
    },
    methods: {
      getPage (page, size) {
        console.log('page', page)
        this.currentPage = page
        this.pageSize = size
        console.log('size', size)
        this.query(this.currentPage, this.pageSize)
      },
      query_New () {
        this.currentPage = 1
        this.query(this.currentPage, this.pageSize)
      },
      query (pageNum, pageSize) {
        var fpConds = this.dialogObj.data.form.fpConds
        let param = {}
        if (fpConds.countyId === '' || fpConds.marketmgrId === '' || fpConds.custmgrId === '' || this.countyId.toString() === '' || this.marketmgrId.toString() === '' || this.marketmgrId.toString() === '' || this.custmgrId.toString() === '') {
          param.companyId = getUser().companyId
        }
        param.countyId = this.countyId.toString() || fpConds.countyId
        param.marketmgrId = this.marketmgrId.toString() || fpConds.marketmgrId
        param.custmgrId = this.custmgrId.toString() || fpConds.custmgrId
        this.tempParam = param
        for (let i = 0; i < this.moreS.length; i++) {
          param[this.moreS[i].colunm] = this.toMoreChange(this.dialogObj.data.form[this.moreS[i].colunm], this.moreS[i].type)
        }
        param.status = '1'
        param.pageSize = pageSize
        param.pageNum = pageNum
        console.log('筛选客户：', JSON.stringify(param))
        this.reqParams.url = BasePath.ACTIVITY_CUSTOMER_SELECT
        this.reqParams.params = param
        api.requestJava('POST', BasePath.ACTIVITY_CUSTOMER_SELECT, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.dataSource = request.data.data
              this.tableData = request.data.data
              this.totalCount = Number(request.data.count)
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询方法
      toMoreChange (values, type) {
        let result = ''
        for (let i = 0; i < values.length; i++) {
          if (type === 'int') {
            result = result + values[i] + ','
          } else if (type === 'string') {
            result = result + "'" + values[i] + "'" + ','
          }
        }
        if (result.length > 0) {
          result = result.substr(0, result.length - 1)
        }
        return result
      },
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.table.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      onendChange (val) {}, // 过滤器修改事件
      headerClick (column, event) {},
      sortChange (msg) {},
      rowClick (msg) {},
      selectionChange (rows) {},
      addClk () {
        let param = {}
        param.companyId = getUser().companyId
        param.countyId = this.countyId.toString()
        param.marketmgrId = this.marketmgrId.toString()
        param.custmgrId = this.custmgrId.toString()
        this.tempParam = param
        for (let i = 0; i < this.moreS.length; i++) {
          param[this.moreS[i].colunm] = this.toMoreChange(this.dialogObj.data.form[this.moreS[i].colunm], this.moreS[i].type)
        }
        param.status = '1'
        param.companyId = getUser().companyId
        console.log('确定查询条件：', JSON.stringify(param))
        this.isLoading = true
        this.$emit('confirmBack', JSON.stringify(param))
      },
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      },
      isMoreClk () {
        this.isSelect = !this.isSelect
      },
      getChangeValue (val) {
//        this.tmp = val
        console.log('范围：', JSON.stringify(val))
      },
      /* 传递参数 -- 从多选中传递 */
      getTransmit (val, num) {
        if (num === 2) {
          this.countyId = val
        } else if (num === 3) {
          this.marketmgrId = val
        } else if (num === 4) {
          this.custmgrId = val
        }
      }
    },
    components: {
      _TABLE,
      _BTN_FILTER,
      _cascader,
      MultiSelectCascader
    }
  }
</script>
<style scoped>
  .el-select {
    display: inline-block;
    position: relative;
    width: 92%;
  }
  .el-dialog__body {
    color: #48576a;
    font-size: 14px;
  }
  .form-group{
    margin-top: 13px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 12px 11px 0;
    box-sizing: border-box;
  }
  .label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 700;
  }
  .notice {
    font-size: medium;
    color: red;
    padding-left: 14px;
    padding-top: 11px;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-8 {
    height: 46px;
  }
  .el-col-2 {
    height: 61px;
  }
  .el-col-7 {
    height: 16px;
  }
  .el-col-15 {
    height: 61px;
  }
  .container-fluid_new {
    background: #FFF;
    margin: 0 5px 5px 5px;
  }
</style>

