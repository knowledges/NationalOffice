<style scoped rel="stylesheet/scss" lang="scss">
  h3 {
    float: left;
    line-height: 80px;
    font-size: 1.6em;
  }
  .navbar-menu {
    ul {
      li {
        float: left;
        padding: 13px 20.5px;
        a {
          display: inline-block;
          color: #fff;
          text-align: center;
          letter-spacing: 2px;
          font-size: 16px;
          i {
            margin:0 auto 8px auto;
            display: block;
            width: 20px;
            height: 20px;
            font-size: 20px;
          }
        }
      }
    }
  }
  .dropdown .fa-home{
    font-size: 16px;
    color: #FFF!important;
  }
  #mask {
    position: fixed;
    z-index: -1;
    width: 100%;
    height: 100%;
    top: 0;
    -webkit-transition: opacity .5s linear;
    -moz-transition: opacity .5s linear;
    -o-transition: opacity .5s linear;
    transition: opacity .5s linear;
    opacity:0;
  }
  .fadein {
    opacity: 100!important;
    filter: alpha(opacity=100)!important;
    z-index: 1160!important;
  }
  .mask-model {
    display: inline-block;
    width: 100%;
    height: 100%;
    background: #FFF;
  }
  .mask-loading {
    position: absolute;
    top: 50%;
    width: 160px;
    height: 100px;
    left: 50%;
    margin-left: -80px;
    z-index: 1090;
  }
  .mask-loading  {
    img {
      margin-left: 55px;
      transition: transform 1s;
      animation: rotate 3s linear infinite;
    }
    p {
      text-align: center;
      margin-top: 15px;
      color: #000;
    }
  }
  .main-header {
    background-color: #009143 !important;
    color: #FFF !important;
    background: url(../../static/img/header.png);
    background-size: 100%;
    a.banner {
      float: left;
      display: inline-block;
      width: 145px;
    }
  }
  .notifications-menu {
    position: relative;
  }
  @-webkit-keyframes rotate {
    from{
      -webkit-transform: rotate(0deg);
    }
    to{
      -webkit-transform: rotate(360deg);
    }
  }
  @-moz-keyframes rotate {
    from {
      -moz-transform: rotate(0deg);
    }
    to {
      -moz-transform: rotate(360deg);
    }
  }
  @-ms-keyframes rotate {
    from {
      -ms-transform: rotate(0deg);
    }
    to {
      -ms-transform: rotate(360deg);
    }
  }
  @-o-keyframes rotate {
    from {
      -o-transform: rotate(0deg);
    }
    to {
      -o-transform: rotate(360deg);
    }
  }
  @keyframes rotate {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }
  @media screen and (min-width: 0px) and (max-width: 1198px) {
    .main-header {
      overflow: hidden;
    }
  }
</style>
<template>
  <div id="app">
    <template v-if="$route.name !== 'Survey'">
      <header class="main-header clearfix">
      <!--<header class="main-header" :style="{ 'background-color': primaryColor }">-->
      <span class="logo-mini">
        <a href="javascript:;;" class="banner">
          <img :src="user.logomini" alt="Logo" class="img-responsive center-block logo">
        </a>
        <h3 class="">江苏烟草客户服务子系统</h3>
      </span>
      <!-- Header Navbar -->
      <nav class="navbar navbar-static-top" role="navigation">
        <!-- Sidebar toggle button-->
        <a href="javascript:;" v-if="powerMenus.children && powerMenus.children.length>0" class="sidebar-toggle" data-toggle="offcanvas" role="button">
          <span class="sr-only">{{routeIdx}}</span>
        </a>
        <div class="navbar-menu">
          <ul style="margin-left: 30px">
            <li v-for="(item, key) in powerMenus.children" :key="key">
              <a href="javascript:;;" @click="routeClk(key)" :class="routeIdx == key && 'router-link-exact-active'">
                <i :class="item.resSicon"></i> {{item.resName}}
              </a>
            </li>
            <!--<li>-->
              <!--<router-link :to="{name: 'UserDemo'}">-->
                <!--<i class="fa fa-card"></i> 模拟-->
              <!--</router-link>-->
            <!--</li>-->
            <!--<li>-->
              <!--<router-link :to="{name: 'cascaderApi'}">-->
                <!--<i class="fa fa-card"></i> 业务组件-->
              <!--</router-link>-->
            <!--</li>-->
            <!--<li>-->
              <!--<router-link :to="{name: 'TableApi'}">-->
                <!--<i class="fa fa-card"></i> 业务组件-->
              <!--</router-link>-->
            <!--</li>-->
            <!--<li>-->
              <!--<router-link :to="{name: 'MulitCascader'}">-->
                <!--<i class="fa fa-card"></i> 多选级联-->
              <!--</router-link>-->
            <!--</li>-->
            <!--<li>-->
              <!--<router-link :to="{name: 'tableCascader'}">-->
              <!--<i class="fa fa-card"></i> 重写tab-->
              <!--</router-link>-->
            <!--</li>-->
          </ul>
        </div>
        <!-- Navbar Right Menu -->
        <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">
            <!-- Messages-->
            <!--<li class="dropdown messages-menu">-->
            <!--<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">-->
            <!--<i class="fa fa-envelope-o"></i>-->
            <!--<span class="label label-success">{{ userInfo.messages | count }}</span>-->
            <!--</a>-->
            <!--<ul class="dropdown-menu">-->
            <!--<li class="header">You have {{ userInfo.messages | count }} message(s)</li>-->
            <!--<li v-if="userInfo.messages.length > 0">-->
            <!--&lt;!&ndash; inner menu: contains the messages &ndash;&gt;-->
            <!--<ul class="menu">-->
            <!--<li>-->
            <!--&lt;!&ndash; start message &ndash;&gt;-->
            <!--<a href="javascript:;">-->
            <!--&lt;!&ndash; Message title and timestamp &ndash;&gt;-->
            <!--<h4>-->
            <!--Support Team-->
            <!--<small>-->
            <!--<i class="fa fa-clock-o"></i> 5 mins</small>-->
            <!--</h4>-->
            <!--&lt;!&ndash; The message &ndash;&gt;-->
            <!--<p>Why not consider this a test message?</p>-->
            <!--</a>-->
            <!--</li>-->
            <!--&lt;!&ndash; end message &ndash;&gt;-->
            <!--</ul>-->
            <!--&lt;!&ndash; /.menu &ndash;&gt;-->
            <!--</li>-->
            <!--<li class="footer" v-if="userInfo.messages.length > 0">-->
            <!--<a href="javascript:;">See All Messages</a>-->
            <!--</li>-->
            <!--</ul>-->
            <!--</li>-->
            <!-- /.messages-menu -->

            <!-- Notifications Menu -->
            <!--<li class="dropdown notifications-menu">-->
            <!--<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">-->
            <!--<i class="fa fa-bell-o"></i>-->
            <!--<span class="label label-warning">{{ userInfo.notifications | count }}</span>-->
            <!--</a>-->
            <!--<ul class="dropdown-menu">-->
            <!--<li class="header">You have {{ userInfo.notifications | count }} notification(s)</li>-->
            <!--<li v-if="userInfo.notifications.length > 0">-->
            <!--&lt;!&ndash; Inner Menu: contains the notifications &ndash;&gt;-->
            <!--<ul class="menu">-->
            <!--<li>-->
            <!--&lt;!&ndash; start notification &ndash;&gt;-->
            <!--<a href="javascript:;">-->
            <!--<i class="fa fa-users text-aqua"></i> 5 new members joined today-->
            <!--</a>-->
            <!--</li>-->
            <!--&lt;!&ndash; end notification &ndash;&gt;-->
            <!--</ul>-->
            <!--</li>-->
            <!--<li class="footer" v-if="userInfo.notifications.length > 0">-->
            <!--<a href="javascript:;">View all</a>-->
            <!--</li>-->
            <!--</ul>-->
            <!--</li>-->

            <!-- Tasks Menu -->
            <!--<li class="dropdown tasks-menu">-->
            <!--<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">-->
            <!--<i class="fa fa-flag-o"></i>-->
            <!--<span class="label label-danger">{{ userInfo.tasks | count }} </span>-->
            <!--</a>-->
            <!--<ul class="dropdown-menu">-->
            <!--<li class="header">You have {{ userInfo.tasks | count }} task(s)</li>-->
            <!--<li v-if="userInfo.tasks.length > 0">-->
            <!--&lt;!&ndash; Inner menu: contains the tasks &ndash;&gt;-->
            <!--<ul class="menu">-->
            <!--<li>-->
            <!--&lt;!&ndash; Task item &ndash;&gt;-->
            <!--<a href="javascript:;">-->
            <!--&lt;!&ndash; Task title and progress text &ndash;&gt;-->
            <!--<h3>-->
            <!--Design some buttons-->
            <!--<small class="pull-right">20%</small>-->
            <!--</h3>-->
            <!--&lt;!&ndash; The progress bar &ndash;&gt;-->
            <!--<div class="progress xs">-->
            <!--&lt;!&ndash; Change the css width attribute to simulate progress &ndash;&gt;-->
            <!--<div class="progress-bar progress-bar-aqua" style="width: 20%" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">-->
            <!--<span class="sr-only">20% Complete</span>-->
            <!--</div>-->
            <!--</div>-->
            <!--</a>-->
            <!--</li>-->
            <!--&lt;!&ndash; end task item &ndash;&gt;-->
            <!--</ul>-->
            <!--</li>-->
            <!--<li class="footer" v-if="userInfo.tasks.length > 0">-->
            <!--<a href="javascript:;">View all tasks</a>-->
            <!--</li>-->
            <!--</ul>-->
            <!--</li>-->

            <!-- User Hom Menu -->
            <template v-if="localPowerMenus !== '' && JSON.stringify(localPowerMenus) !== '{}' ">
              <li class="dropdown" style="line-height: 58">
                <router-link :to="{name: 'Home'}">
                  <i class="fa fa-home"></i>
                </router-link>
              </li>
              <!--Message Hom Menu-->
              <li class="dropdown notifications-menu">
                <router-link :to="{name: 'Message', params: {count:this.topicCount}}">
                  <i class="fa fa-bell-o"></i>
                  <span class="label label-warning">{{this.topicCount}}</span>
                </router-link>
              </li>
            </template>
            <!-- User Account Menu -->
            <li class="dropdown user user-menu">
              <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
                <!-- The user image in the navbar-->
                <!-- hidden-xs hides the username on small devices so only the image appears. -->
                <span class="hidden-xs">
                  {{ userInfo.userName || user.name }}
                  <i class="fa fa-sort-desc"></i>
                </span>
              </a>
              <ul class="dropdown-menu">
                <li  class="dropdown messages-menu">
                  <router-link :to="{name: 'ModifyPwd'}">
                    <i class="fa fa-lock"></i> 修改密码
                  </router-link>
                </li>
                <li  class="dropdown messages-menu">
                  <a href="javascript:;;" @click="logoutClk">
                    <i class="fa fa-power-off"></i> 注销
                  </a>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    </template>
    <router-view></router-view>
    <div id="mask" :class="isLoading.status ? 'fadein' : ''">
      <div class="mask-loading">
        <img src="../../static/img/loading.png" width="50" alt="">
        <p class="text-content">{{isLoading.msg}}</p>
      </div>
      <div class="mask-model"></div>
    </div>
    <!--<iframe :src="iframeUrl" style="display: none;" frameborder="0"></iframe>-->
  </div>
</template>

<script>
  import { mapState } from 'vuex'
  import { getUser } from '@/config/info'
  import { getFirstMonth, getDecember } from '@/utils/dateFormat'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import config from '@/config'
  export default {
    name: 'App',
    mounted () {
      this.$nextTick(() => {
        this.init()
      })
    },
    updated () {
      if (JSON.stringify(this.powerMenus) === '{}' && JSON.stringify(this.localPowerMenus) === '{}') {
        this.init()
      } else {
        if (this.$route.name !== 'VistPlan') {
          this.$store.dispatch('setLoading', JSON.stringify({'status': false}))
        }
      }
    },
    data () {
      return {
        user: {
          name: getUser() != null ? getUser().userName : '',
          logomini: config.root + '/static/img/login.png'
        },
        section: 'Head',
        powerMenus: '',
        topicCount: '',
        localPowerMenus: ''
//        iframeUrl: ''
      }
    },
    computed: {
      ...mapState([
        'userInfo',
        'powerMenu',
        'localPowerMenu',
        'isLoading',
        'routeIdx'
      ])
    },
    methods: {
      init () {
        setTimeout(() => {
          let powerMenu = JSON.parse(sessionStorage.getItem('powerMenu'))
          let localPowerMenu = JSON.parse(sessionStorage.getItem('localPowerMenu'))
          if (powerMenu !== null && powerMenu !== '' && powerMenu !== undefined && localPowerMenu !== null && localPowerMenu !== '' && localPowerMenu !== undefined) {
            this.powerMenus = powerMenu
            this.localPowerMenus = localPowerMenu
          } else {
            this.powerMenus = this.powerMenu
            this.localPowerMenus = this.localPowerMenu
          }
          if (this.$route.name !== 'Survey') {
            this.$store.dispatch('setLoading', JSON.stringify({'status': false}))
          }
          this.getTopicCount()
        }, 200)
      },
      getTopicCount () {
        let params = {}
        params.sectionName = ''
        params.my = '1'
        params.userId = getUser().id
        params.beginTime = getFirstMonth()
        params.endTime = getDecember()
        params.clickCount = '1'
        params.replayCount = '1'
        api.requestJava('POST', BasePath.COMMON_TOPICQUERY_COUNT, params)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.topicCount = request.data.data
            } else {
              this.$notify.error({ title: '提示', message: request.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      logoutClk () {
        /* TODO 请求登出接口 */
        localStorage.removeItem('information')
//        sessionStorage.removeItem('sessionMenus')
//        sessionStorage.removeItem('powerMenu')
        sessionStorage.setItem('sessionMenus', '0')
        this.$router.go(0)
      },
      routeClk (key) {
        this.$store.dispatch('setRouteIdx', key)
        document.body.className = 'skin-blue sidebar-mini pace-done'
        /* TODO 等所有模块确定在添加 */
      }
    },
    watch: {
      'powerMenu' (val, old) {
        this.powerMenus = val
//        this.iframeUrl = 'http://apps.js.tobacco.com.cn/dataviz-web'
      },
      'localPowerMenu' (val, old) {
        this.localPowerMenus = val
      }
    }
  }
</script>
