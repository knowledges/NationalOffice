<!-- 徐晓菁 -->
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible"   :close-on-press-escape="false" :before-close="cancleClk"  :close-on-click-modal="false">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <!--<el-form-item label="机构类型">-->
        <!--<el-select v-model="dialogObj.data.form.orgType" :clearable="true" placeholder="请选择机构类型">-->
          <!--<template v-for="item in orgTypeGroup">-->
            <!--<el-option  :key="item.rowId"  :label="item.name" :value="item.rowId"></el-option>-->
          <!--</template>-->
        <!--</el-select>-->
      <!--</el-form-item>-->
      <el-form-item label="机构代码">
        <el-input  v-model="dialogObj.data.form.unitCode" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item label="机构名称">
        <el-input  v-model="dialogObj.data.form.unitName" :disabled="true"></el-input>
      </el-form-item>
      <!--<el-form-item label="简称">-->
        <!--<el-input  v-model="dialogObj.data.form.shortName"></el-input>-->
      <!--</el-form-item>-->
      <!--<el-form-item label="角色类型">-->
        <!--<el-select v-model="dialogObj.data.form.orgRoleTypId" :clearable="true" placeholder="请选择角色类型">-->
          <!--<template v-for="item in orgRoleTypIdGroup">-->
            <!--<el-option  :key="item.rowId"  :label="item.name" :value="item.rowId"></el-option>-->
          <!--</template>-->
        <!--</el-select>-->
      <!--</el-form-item>-->
      <!--<el-form-item    label="上级机构">-->
       <!--<compositeInput :filterVal.sync="filterVal" @on-change="inputChange"></compositeInput>-->
      <!--</el-form-item>-->
      <!--<el-form-item label="地址">-->
        <!--<el-input  v-model="dialogObj.data.form.address"></el-input>-->
      <!--</el-form-item>-->
      <el-form-item label="是否启用">
        <el-checkbox v-model="dialogObj.data.form.status"></el-checkbox>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
      <el-button type="primary" @click="updateClk('addForm')">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import compositeInput from './compositeInput.vue'
  import api from '@/api'
  import axios from 'axios'
  import BasePath from '@/config/BasePath'
  export default {
    props: ['dialogObj'],
    mounted () {
      axios.all([
        api.requestJava('POST', BasePath.SELECT_ORGTYPEGROUP, {}),
        api.requestJava('POST', BasePath.SELECT_ORGROLETYPIDGROUP, {})
      ])
      .then(axios.spread((first, scend) => {
        this.orgTypeGroup = JSON.parse(JSON.stringify(first.data.data))
        this.orgRoleTypIdGroup = JSON.parse(JSON.stringify(scend.data.data))
        this.filterVal = this.dialogObj.data.form.parentName
      }))
    },
    updated () {
      this.filterVal = this.dialogObj.data.form.parentName
      console.log('this.dialogObj.data.form', this.dialogObj.data.form)
    },
    data () {
      return {
        orgTypeGroup: [],
        orgRoleTypIdGroup: [],
        addrules: {
          unitName: [
            {required: true, message: '请输入机构名称', trigger: 'blur'}
          ],
          orgType: [
            {required: true, message: '请选择机构类型', trigger: 'blur'}
          ],
          roleId: [
            {required: true, message: '请选择角色类型', trigger: 'blur'}
          ],
          parentId: [
            {required: true, message: '请选择上级机构', trigger: 'blur'}
          ]
        },
        filterVal: ''
      }
    },
    methods: {
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
        this.dialogObj.dialogVisible = false
      },
      changeValue (value) {
        console.log(value)
        let obj = {}
        obj = this.groupCode.find((item) => {
          if (item.id === value) {
            return item
          }
        })
        console.log(obj.label)
        return obj.label
      },
      updateClk (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$emit('confirmBack', this.dialogObj)
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      inputChange (msg) {
        this.dialogObj.data.form.relOrgUnitId = JSON.parse(msg).rowId
      }
    },
    components: {
      compositeInput
    }
  }
</script>

