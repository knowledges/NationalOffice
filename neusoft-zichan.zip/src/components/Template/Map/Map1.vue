<style scoped>
  #map{
    position: absolute;
    display: inline-block;
    width: 100%;
    height: 100%;
    background: #FFF;
  }
</style>
<template>
  <div id="map"></div>
</template>
<script>
  import {MP} from './map.js'
  import config from '@/config'
  var [BMap, map] = ''
  export default {
    name: 'BaiDu_Map',
    props: {
      zoom: { // 变焦
        type: Number,
        default: 12
      },
      coors: { // 坐标
        type: Array,
        default: []
      },
      coorGroup: { // 坐标
        type: Array,
        default: []
      },
      place: {
        type: Number,
        default: 24
      }
    },
    created () {
      this.init()
    },
    mounted () {
    },
    data () {
      return {
        ak: 'sFGGCnZu8HcewIdGMFGGaGypsfILG36G',
        BMap: '',
        imgUrl: config.root + '/static/img/icon_map.png',
        local_lng: '',
        local_lat: '',
        zoomGroup: [],
        tilesloaded: true
      }
    },
    methods: {
      init () {
        let _this = this
        MP(this.ak).then((Bmap) => {
          var myCity = new Bmap.LocalCity()
          myCity.get(function (result) {
            let localzoom = result.center
            _this.local_lng = localzoom.lng
            _this.local_lat = localzoom.lat
            console.log('init:', localzoom.lng, localzoom.lat)
            if (_this.coors.length <= 0) {
              console.log('数据为空')
              map = new Bmap.Map('map')
              map.centerAndZoom(result.name, 12)
              map.enableScrollWheelZoom(true) // 是否可以滚动
            }
          })
        })
      },
      create () {
        let _this = this
        MP(this.ak).then((Bmap) => {
          BMap = Bmap
          /* 显示地图 */
          map = new BMap.Map('map')
          let [lng, lat] = [_this.local_lng, _this.local_lat]
          if (_this.coors.length > 0 &&
            !isNaN(Number(_this.coors[0].lng)) &&
            !isNaN(Number(_this.coors[0].lat)) &&
            Number(_this.coors[0].lng) > 0 &&
            Number(_this.coors[0].lat) > 0) {
            lng = _this.coors[0].lng
            lat = _this.coors[0].lat
          }
          let point = new BMap.Point(lng, lat)
          console.log(lng, lat)
          map.centerAndZoom(point, 12) // 渲染地图
          map.enableScrollWheelZoom(true) // 是否可以滚动
          map.addControl(new BMap.NavigationControl())
          map.addControl(new BMap.ScaleControl())
          map.addControl(new BMap.OverviewMapControl())
          /* 创建批注 */
          var myCity = new Bmap.LocalCity()
          myCity.get(function (result) {
            if (Number(_this.place) === 24) {
              for (let i in _this.coors) {
                let [tmpLng, tmpLat] = ''
                if (!isNaN(Number(_this.coors[i].lng)) &&
                  !isNaN(Number(_this.coors[i].lat)) &&
                  Number(_this.coors[i].lng) > 0 &&
                  Number(_this.coors[i].lat) > 0) {
                  tmpLng = _this.coors[i].lng
                  tmpLat = _this.coors[i].lat
                } else {
                  let tmp = result.center
                  tmpLng = tmp.lng
                  tmpLat = tmp.lat
                }
                console.log('进来过了~', tmpLng, tmpLat)
                let points = new BMap.Point(tmpLng, tmpLat)
                let marker = new BMap.Marker(points)
                let label = new BMap.Label(_this.coors[i].name, {offset: new BMap.Size(15, -16)})
                label.setStyle({
                  color: '#FFF',
                  fontSize: '12px',
                  height: '20px',
                  lineHeight: '20px',
                  fontFamily: '微软雅黑',
                  position: 'relative',
                  padding: '5px 8px',
                  border: '2px solid #fff',
                  backgroundColor: 'green',
                  borderRadius: '6px',
                  letterSpacing: '2px'
                })
                map.addOverlay(marker)
                marker.setLabel(label)
              }
            }
            if (Number(_this.place) === 135) {
              for (let i in _this.coors) {
                let lng = (_this.coors[i] !== undefined && _this.coors[i].lng !== '0' && _this.coors[i].lng !== '') ? _this.coors[i].lng : _this.local_lng
                let lat = (_this.coors[i] !== undefined && _this.coors[i].lat !== '0' && _this.coors[i].lat !== '') ? _this.coors[i].lat : _this.local_lat
                let points = new BMap.Point(lng, lat)
                let icon = new BMap.Icon(_this.imgUrl, new BMap.Size(34, 42), {
                  anchor: new BMap.Size(10, 30)
                })
                let marker = new BMap.Marker(points, {icon: icon})
                let label = new BMap.Label(Number(++i), {offset: new BMap.Size(12, 8)})
                label.setStyle({
                  color: '#FFF',
                  fontSize: '12px',
                  height: '20px',
                  lineHeight: '20px',
                  fontFamily: '微软雅黑',
                  position: 'relative',
                  border: 'none',
                  backgroundColor: 'none',
                  fontWeight: '700'
                })
                map.addOverlay(marker)
                marker.setLabel(label)
              }
              for (var i = 0; i < _this.coors.length - 1; i++) {
                if (_this.coors[i] !== undefined && _this.coors[i].lng !== '' && _this.coors[i].lng !== '0') {
                  let startPoint = new BMap.Point(_this.coors[i].lng, _this.coors[i].lat)
                  let endPoint = new BMap.Point(_this.coors[i + 1].lng, _this.coors[i + 1].lat)
                  let polyline = new BMap.Polyline([startPoint, endPoint], {strokeColor: '#2e85fc', strokeWeight: 2, strokeOpacity: 1})  // 定义折线
                  map.addOverlay(polyline)     // 添加折线到地图上
                }
//              let startPoint = new Bmap.Point(_this.coors[i].lng, _this.coors[i].lat)
//              let endPoint = new Bmap.Point(_this.coors[i + 1].lng, _this.coors[i + 1].lat)
//              let walking = new Bmap.WalkingRoute(map, { renderOptions: { map: map, autoViewport: true } })
//              walking.search(startPoint, endPoint)
//              /* 替换icon */
//              let icon = new Bmap.Icon('http://api0.map.bdimg.com/images/blank.gif', new Bmap.Size(18, 35))
//              walking.setMarkersSetCallback(function (result) {
//                result[0].marker.setIcon(icon)
//                result[1].marker.setIcon(icon)
//              })
              }
              var count = 0
              for (var k = 0; k < _this.coorGroup.length; k++) {
                ++count
                if (_this.coorGroup[k] !== undefined && _this.coorGroup[k].lng !== '') {
                  let lng = _this.coorGroup[k] !== undefined && _this.coorGroup[k].lng !== '' ? _this.coorGroup[k].lng : _this.local_lng
                  let lat = _this.coorGroup[k] !== undefined && _this.coorGroup[k].lat !== '' ? _this.coorGroup[k].lat : _this.local_lat
                  let points = new BMap.Point(lng, lat)
                  let marker = new BMap.Marker(points)
                  marker.customerName = _this.coorGroup[k].customerName
                  marker.customerId = _this.coorGroup[k].customerId
                  marker.setTitle(marker.customerName)
                  let label = new BMap.Label(Number(count), {offset: new BMap.Size(5, 0)})
                  label.setStyle({
                    color: '#FFF',
                    fontSize: '12px',
                    height: '20px',
                    lineHeight: '20px',
                    fontFamily: '微软雅黑',
                    position: 'relative',
                    border: 'none',
                    backgroundColor: 'none',
                    fontWeight: '700'
                  })
                  BMap.addOverlay(marker)
                  marker.setLabel(label)
                  marker.addEventListener('click', function (e) {
                    var info = {}
                    info.customerId = marker.customerId
                    _this.$emit('mapBack', info)
                  })
                }
              }
            }
          })
        })
      },
      zoomIn (x, y, customerId, customerName) {
        let _this = this
        var allOverlay = map.getOverlays()
        let point = new BMap.Point(x, y)
        map.centerAndZoom(point, this.zoom)
        for (var k = 0; k < allOverlay.length; k++) {
          if (allOverlay[k].V.title !== '' && allOverlay[k].V.title !== undefined) {
            if (allOverlay[k].V.title === customerName) {
              console.log('标题：', allOverlay[k].V.title)
              allOverlay[k].setAnimation(BMAP_ANIMATION_DROP)
              allOverlay[k].addEventListener('click', function (e) {
                var info = {}
                info.customerId = customerId
                _this.$emit('mapBack', info)
              })
            } else {
              allOverlay[k].setAnimation(null)
            }
          }
        }
      }
    },
    watch: {
      coors (val, old) {
        if (val.length > 0) {
          setTimeout(() => {
            this.create()
          })
        }
      }
    }
  }
</script>
