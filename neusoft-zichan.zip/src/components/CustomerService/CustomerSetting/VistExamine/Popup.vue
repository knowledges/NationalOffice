<!-- 徐晓菁 -->
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <_TREECOMPONENT :search=searchable :data='this.dialogObj.data.form.steps'  :nodeKey="nodeKey"
                      :showCheckBox=showCheckBox :expandAll=expandAll ref='tree' :highlight='true'
                      :defaultCheckedKeys="defaultCheckedKeys"></_TREECOMPONENT>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import _TREECOMPONENT from '@/components/Template/Tree/Tree.vue'
  export default {
    props: ['dialogObj'],
    mounted () {
    },
    data () {
      return {
        tableData6: [
          {
            id: '12987122',
            name: '王小虎',
            amount1: '234',
            amount2: '3.2',
            amount3: 10
          },
          {
            id: '12987123',
            name: '王小虎',
            amount1: '165',
            amount2: '4.43',
            amount3: 12
          },
          {
            id: '12987124',
            name: '王小虎',
            amount1: '324',
            amount2: '1.9',
            amount3: 9
          },
          {
            id: '12987125',
            name: '王小虎',
            amount1: '621',
            amount2: '2.2',
            amount3: 17
          },
          {
            id: '12987126',
            name: '王小虎',
            amount1: '539',
            amount2: '4.1',
            amount3: 15
          }
        ],
        addrules: {},
        nodeKey: 'id',
        defaultCheckedKeys: [],
        searchable: true, // 是否带搜索框
        showCheckBox: false, // 是否带复选框
        expandAll: true // 是否展开所有节点
      }
    },
    methods: {
      objectSpanMethod ({ row, column, rowIndex, columnIndex }) {
        if (columnIndex === 0) {
          if (rowIndex % 2 === 0) {
            return {
              rowspan: 2,
              colspan: 1
            }
          } else {
            return {
              rowspan: 0,
              colspan: 0
            }
          }
        }
      },
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      },
      handleClick (row) {}
    },
    components: {
      _TREECOMPONENT
    }
  }
</script>
