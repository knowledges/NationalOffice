<!-- 徐晓菁 -->
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk"  :size='dialogObj.size' v-popupdra-directive="{'show': dialogObj.dialogVisible}">
  <div class="container-fluid_new">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='12'>
          <label class="el-form-item__label" style="width: 120px;">查询周期</label>
            <el-date-picker
              v-model="datetime"
              format="yyyy-MM-dd"
              type="daterange"
              :editable=false
              :clearable=false
              @change="datePickerChange"
              placeholder="选择日期范围"
              :picker-options="pickerOptions">
            </el-date-picker>
        </el-col>
        <el-col :span="12">
          <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" :tableData="tableData" @on-click="exportEve" :isMore="isMore"></_BTN_FILTER>
        </el-col>
      </el-col>
    </el-row>
    <div>
      <_TABLE
        ref="tableGrid"
        stripe
        maxHeight="500"
        @update:data="tabChange" :reqParams="reqParams"
        :data="dataSource"
        :columns="columnHeader"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData></_TABLE>
    </div>
  </div>
  </el-dialog>
</template>

<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import api from '@/api'
  import log from '@/log'
  import BasePath from '@/config/BasePath'
  import {dateFormat} from '@/utils/common'
  import {getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      this.searchForm.companyId = getUser().companyId
      let countyId = getUser().countyId
      if (countyId === null || countyId === 'null') {
        countyId = ''
      }
      this.searchForm.countyDept = countyId
      this.searchForm.empId = getUser().personId
      this.searchForm.userPlaceId = getUser().place
    },
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        this.searchForm.ruleId = this.dialogObj.data.form.rowId
//        alert(this.datetime[0] + '---------' + this.datetime2[0])
//        alert(this.datetime[1] + '---------' + this.datetime2[1])
//        alert(this.getTime(Date.parse(this.datetime[0])) === this.getTime(Date.parse(this.datetime2[0])) && this.getTime(Date.parse(this.datetime[1])) === this.getTime(Date.parse(this.datetime2[1])))
        if (this.getTime(Date.parse(this.datetime[0])) === this.getTime(Date.parse(this.datetime2[0])) && this.getTime(Date.parse(this.datetime[1])) === this.getTime(Date.parse(this.datetime2[1]))) {
          this.searchForm.warnDateBegin = this.getTime(Date.parse(this.datetime[0]))
          this.searchForm.warnDateEnd = this.getTime(Date.parse(this.datetime[1]))
          this.query()
        } else {
          this.datetime = [new Date(new Date().setDate(1)), new Date()]
        }
      }
    },
    data () {
      return {
        /** table **/
        datetime: [new Date(), new Date()],
        datetime2: [new Date(), new Date()],
        pickerOptions: {
          shortcuts: [{
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '当前月',
            onClick (picker) {
              const end = new Date()
              const start = new Date(new Date().setDate(1))
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }]
        },
        searchForm: {
          companyId: '',
          countyDept: '',
          empId: '',
          userPlaceId: '',
          warnDateBegin: '',
          warnDateEnd: '',
          ruleId: ''
        },
        hasPagination: true,
        currentPage: 1, // 默认当前第一页
        pageSize: 1000,  // 默认每页20条数据
        pageSizes: [1000], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        customerGradeGroup: [],
        operationScaleGroup: [],
        geoTypeGroup: [],
        businessTypeGroup: [],
        columnHeader: [
          {
            prop: 'warnitemid', // 列的值
            label: '序号', // 列的显示字段
            columnsProps: {width: 100, align: 'left'}
          },
          {
            prop: 'companydesc', // 列的值
            label: '公司', // 列的显示字段
            columnsProps: {width: 200, align: 'left'}
          },
          {
            prop: 'wranitem', // 列的值
            label: '责任主体', // 列的显示字段
            columnsProps: {width: 100, align: 'left'}
          },
          {
            prop: 'warnobj',
            label: '预警对象',
            columnsProps: {width: 250, align: 'left'}
          },
          {
            prop: 'warnobjcode',
            label: '预警对象代码',
            columnsProps: {width: 140, align: 'left'}
          },
          {
            prop: 'warndesc',
            label: '预警描述',
            columnsProps: {align: 'left'}
          }
        ],
        tableData: [],
        dataSource: [], // 当前页的数据
        /** filter **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['companydesc', 'wranitem'],
        isMore: true,
        isSelect: true,
        keyupend: false,   // 输入筛选；true：之前展示；false：之后展示
        templTableData: [], // 临时记录tableDate的值
        btnGroups: [],
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        treeData: [],
        nodeKey: 'id',
        defaultCheckedKeys: [],
        isLoading: true
        /** 弹出层 **/
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      datePickerChange () {
        this.searchForm.warnDateBegin = this.getTime(Date.parse(this.datetime[0]))
        this.searchForm.warnDateEnd = this.getTime(Date.parse(this.datetime[1]))
        this.query()
      },
      query () {
        let param = {}
        param = this.searchForm
        param.pageSize = this.pageSize
        param.pageNum = 1
        console.log('param', JSON.stringify(param))
        this.reqParams.url = BasePath.WARNINGINFO_OBJECT
        this.reqParams.params = param
        api.requestJava('POST', BasePath.WARNINGINFO_OBJECT, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.dataSource = request.data.data
              this.tableData = request.data.data
              this.totalCount = +request.data.count
//              this.totalCount = Number(request.data.count)
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询方法
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      onendChange (val) {}, // 过滤器修改事件
      select (selection, index) {}, // 选中某1条
      selectAll (data) {}, // 全选
      headerClick (column, event) {},
      sortChange (msg) {},
      rowClick (msg) {},
      selectionChange (rows) {},
      cancleClk () {
        this.isLoading = true
        this.dataSource = []
        this.tableData = []
        this.$emit('confirmBack', 'cancle')
      },
      isMoreClk () {
        this.isSelect = !this.isSelect
      }
    },
    components: {
      _TABLE,
      _BTN_FILTER
    }
  }
</script>
<style scoped>
  .el-select {
    display: inline-block;
    position: relative;
    width: 92%;
  }
  .el-dialog__body {
    color: #48576a;
    font-size: 14px;
  }
  .form-group{
    margin-top: 13px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 12px 11px 0;
    box-sizing: border-box;
  }
  .label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 700;
  }
  .notice {
    font-size: medium;
    color: red;
    padding-left: 14px;
    padding-top: 11px;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-8 {
    height: 46px;
  }
  .el-col-2 {
    height: 61px;
  }
  .el-col-7 {
    height: 16px;
  }
  .el-col-15 {
    height: 61px;
  }
  .container-fluid_new {
    background: #FFF;
    margin: 0 5px 5px 5px;
  }
</style>

