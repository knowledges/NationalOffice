<!--李晶-->
<style rel="stylesheet/scss" lang="scss" scoped>
  .el-col-24 {
    height: 36px;
  }
  .el-date-editor.el-input {
    width: 130px;
  }
</style>
<template>
  <div  class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='14'>
          <div v-if="isSelect">
            <el-form ref="searchForm" :model="searchForm" label-width="70px">
              <el-col :gutter="24">
                <el-col :span='8'>
                  <el-form-item label="月份">
                    <el-date-picker
                      v-model="searchForm.clDate"
                      type="month"
                      placeholder="选择月份">
                    </el-date-picker>
                  </el-form-item>
                </el-col>
                <el-col :span='16' >
                  <el-form-item prop="countyId" label="数据范围">
                    <_cascader @on-change="getChangeValue"/>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-form>
          </div>
        </el-col>
        <el-col :span="10">
          <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" :tableData="tableData" @on-click="exportEve"></_BTN_FILTER>
        </el-col>
      </el-col>
    </el-row>
    <div>
      <tableVue
        ref="tableGrid"
        stripe
        maxHeight="500"
        @update:data="tabChange" :reqParams="reqParams"
        :data="dataSource"
        :columns="columns"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData></tableVue>
    </div>
  </div>
</template>
<script>
  import tableVue from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import {getUser, getCodeList} from '@/config/info'
  import {dateFormat} from '@/utils/dateFormat.js'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import log from '@/log'
  import axios from 'axios'
  import { changeListValueByCode, getMonthBegin, getMonthEnd } from '@/utils/common'
  import _cascader from '@/components/Template/Cascader/Cascader.vue'
  export default {
    name: 'BrandTracking',
    props: {},
    mounted () {
      this.init()
      getCodeList('CUSTOMER_GRADE', (data) => {
        this.options_customerGrade = data
        this.changeValueDate.customerGrade.group = data
      }) // 客户级别
      let custMgrParam = {} // 客户经理
      custMgrParam.place = 135
      custMgrParam.countyDept = getUser().countyId
      custMgrParam.status = 1
      if (getUser().place === '24') {
        custMgrParam.manager = getUser().personId
      }
      custMgrParam.fields = {include: 'employeeName,rowId'}
      let countyIdParam = {} // 分公司
      countyIdParam.orgRoleTypId = '203'
      if (getUser().place !== '72') {
        countyIdParam.orgRoleCd = getUser().countyCode
      }
      countyIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
      axios.all([
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, custMgrParam), // 市场经理
        api.requestJava('POST', BasePath.SELECT_FACTORYIDGROUP, countyIdParam) // 分公司
      ])
        .then(axios.spread((_custMgr, _countyId) => {
          this.options_custMgr = _custMgr.data.data
          this.options_countyId = _countyId.data.data
          this.$nextTick(() => {
            this.$set(this.searchForm, 'countyId', getUser().countyId)
            if (getUser().place === '135') {
              this.$set(this.searchForm, 'custMgr', getUser().personId)
            }
          })
        }))
    },
    data () {
      return {
        tmp: [],
        queryParam: {
          companyId: getUser().companyId,
          countyId: '',
          marketMgrId: '',
          custMgrId: ''
        },
        custmgrDisable: false,
        countyIdDisable: false,
        isSelect: true,
        isMore: true, // 查询更多条件
        searchForm: {
          clDate: new Date(),
          countyId: '',
          custMgr: ''
        },
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['customerCd', 'customerNm', 'customerGrade', 'productNm'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        selectSells: [],
        totalCount: 0, // 表格总记录数
        hasPagination: true, // 是否有分页
        columns: [ // 表格列
          { label: '客户代码', prop: 'customerCd', columnsProps: {fixed: true, width: 150} },
          { label: '客户名称', prop: 'customerNm', columnsProps: {width: 200} },
          { label: '档级', prop: 'customerGrade', columnsProps: {width: 100, formatter: this.colFormatter_customerGrade} },
          { label: '卷烟名称', prop: 'productNm', columnsProps: {width: 200, formatter: this.colFormatter_nativePlace} },
          { label: '市场批发价(元/条)', prop: 'tradePrice', columnsProps: {width: 150, align: 'right', formatter: this.colFormatter_sex} },
          { label: '市场零售价(元/条)', prop: 'retailPriceL', columnsProps: {width: 150, align: 'right', formatter: this.colFormatter_birthday} },
          { label: '市场零售价(元/包)', prop: 'retailPriceP', columnsProps: {width: 150, align: 'right', formatter: this.colFormatter_birthday} },
          { label: '前期库存（条）', prop: 'invyPrior', columnsProps: {width: 150, align: 'right'} },
          { label: '当前库存（条）', prop: 'invyCurr', columnsProps: {width: 150, align: 'right'} },
          { label: '前期购进（条）', prop: 'buyPrior', columnsProps: {width: 150, align: 'right'} },
          { label: '本期购进（条）', prop: 'buyCurr', columnsProps: {width: 150, align: 'right'} },
          { label: '本期实际销量（条）', prop: 'saleQty', columnsProps: {width: 180, align: 'right'} }
        ],
        tableData: [],
        tableType: '4',
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        options_custMgr: [],
        options_countyId: [],
        changeValueDate: {
          customerGrade: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          }
        }
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      init () {
        let param = {}
        param.contentTag = '2'
        param.clDateL = getMonthBegin(dateFormat(Date.parse(this.searchForm.clDate), 'YYYY-MM-DD'), 'YYYY-MM-DD')
        param.clDateR = getMonthEnd(dateFormat(Date.parse(this.searchForm.clDate), 'YYYY-MM-DD'), 'YYYY-MM-DD')
        /* TODO 将 getChangeValue 内容添加到这里 */
        if (Number(getUser().unitLevel) === 1) { // 展示所有
          this.queryParam.companyId = getUser().companyId
          this.tmp.forEach((val, key) => {
            switch (key) {
              case 0:
                this.queryParam.companyId = val
                break
              case 1:
                this.queryParam.countyId = val
                break
              case 2:
                this.queryParam.marketMgrId = val
                break
              case 3:
                this.queryParam.custMgrId = val
                break
            }
          })
        } else if (Number(getUser().unitLevel) === 2) { // 展示该市下的所有分公司
          if (getUser().countyId === 'null') {
            this.queryParam.companyId = getUser().companyId
            this.tmp.forEach((val, key) => {
              switch (key) {
                case 0:
                  this.queryParam.countyId = val
                  break
                case 1:
                  this.queryParam.marketMgrId = val
                  break
                case 2:
                  this.queryParam.custMgrId = val
                  break
              }
            })
          } else if (getUser().countyId !== 'null' && Number(getUser().place) === 9999) {
            if (this.tmp.length > 0) {
              this.tmp.forEach((val, key) => {
                switch (key) {
                  case 0:
                    this.queryParam.marketMgrId = val
                    break
                  case 1:
                    this.queryParam.custMgrId = val
                    break
                }
              })
            } else {
              this.queryParam.companyId = getUser().companyId
              this.queryParam.countyId = getUser().countyId
            }
          } else if (getUser().countyId !== 'null' && getUser().deptId !== 'null' && Number(getUser().place) === 24) {
            this.queryParam.marketMgrId = getUser().personId
            this.queryParam.custMgrId = this.tmp[0]
          } else if (Number(getUser().place) === 135) {
            this.queryParam.custMgrId = getUser().personId
          }
        }
        Object.assign(param, this.queryParam)
        console.log(JSON.stringify(param))
        this.reqParams.url = BasePath.BRANDTRACK_GETLIST
        this.reqParams.params = param
        api.requestJava('POST', BasePath.BRANDTRACK_GETLIST, param, {})
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count) <= 0 ? 1 : Number(request.data.count)
              this.dataSource = request.data.data
              this.tableData = request.data.data
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      getChangeValue (val) {
        this.tmp = val
        console.log('范围：', val)
      },
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      headerClick () {},
      sortChange (msg) {},
      rowClick (msg) {},
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      query () {
        this.init()
      },
      colFormatter_customerGrade (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },
      sessionFailedBack (msg) {
        let headers = msg.data.form
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.sessionFailedDialogObj.dialogVisible = false
            }
          })
          .catch((err) => { console.log(err) })
      } // 会话失效
    },
    components: {
      tableVue,
      _BTN_FILTER,
      _cascader
    },
    watch: {}
  }
</script>
