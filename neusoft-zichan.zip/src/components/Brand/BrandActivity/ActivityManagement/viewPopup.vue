<!-- 徐晓菁 -->
<template>
  <div>
    <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk">
      <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
        <el-form-item label="活动事项">
          <el-select v-model="dialogObj.data.form.matterId"   @change="changeXp"  :clearable="true"  placeholder="请选择活动事项"  :disabled ="dialogObj.data.form.disabled">
            <template v-for="item in dialogObj.data.form.matterIdGroup">
              <el-option  :key="item.rowId"  :label="item.matterName" :value="item.rowId"></el-option>
            </template>
          </el-select>&nbsp;&nbsp;&nbsp;&nbsp;
        </el-form-item>
        <el-col :gutter="24">
          <el-col :span='12'>
            <el-form-item label="客户档级">
              <el-select v-model="dialogObj.data.form.customerGrade" multiple  :clearable="true" placeholder="请选择客户档级">
                <template v-for="item in dialogObj.data.form.customerGradeGroup">
                  <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                </template>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='12'>
            <el-form-item label="市场类型">
              <el-select v-model="dialogObj.data.form.geoType" multiple  :clearable="true" placeholder="请选择市场类型">
                <template v-for="item in dialogObj.data.form.geoTypeGroup">
                  <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                </template>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
        <el-col :gutter="24">
          <el-col :span='12'>
            <el-form-item label="业态">
              <el-select v-model="dialogObj.data.form.businessType" multiple  :clearable="true"  placeholder="请选择业态" >
                <template v-for="item in dialogObj.data.form.businessTypeGroup">
                  <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                </template>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span='12'>
            <el-form-item label="规模">
              <el-select v-model="dialogObj.data.form.operationScale" multiple :clearable="true"  placeholder="请选择规模" >
                <template v-for="item in dialogObj.data.form.operationScaleGroup">
                  <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                </template>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
        <el-form-item label="活动周期">
          <el-date-picker
            v-model="dialogObj.data.form.beginDate"
            type="date"
            format="yyyy-MM-dd"
            :editable=false
            :clearable=false
            :disabled ="this.dialogObj.disable"
            placeholder="选择开始时间">
          </el-date-picker>
          <span>至</span>
          <el-date-picker
            v-model="dialogObj.data.form.endDate"
            type="date"
            format="yyyy-MM-dd"
            :editable=false
            :clearable=false
            :disabled ="this.dialogObj.disable"
            placeholder="选择结束时间">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="活动主题">
          <el-input v-model="dialogObj.data.form.title" :disabled ="this.dialogObj.disable"></el-input>
        </el-form-item>
        <el-form-item label="活动描述">
          <el-input type="textarea" resize="none" v-model="dialogObj.data.form.notes" :disabled ="this.dialogObj.disable"></el-input>
        </el-form-item>
        <el-form-item label="收集内容"  >
          <el-select v-model="dialogObj.data.form.stepId"  multiple  :clearable="true" placeholder="请选择收集内容" :disabled ="this.dialogObj.disable">
            <template v-for="item in stepIdsGroup">
              <el-option  :key="item.rowId"  :label="item.title" :value="item.rowId"></el-option>
            </template>
          </el-select>
        </el-form-item>
        <el-form-item :label="reflabel"    v-if="isXp">
          <el-select v-model="dialogObj.data.form.ref"  filterable :clearable="true" placeholder="请选择" :disabled ="this.dialogObj.disable">
            <template v-for="item in refGroup">
              <el-option  :key="item.rowId"  :label="item.goodsDesc" :value="item.rowId"></el-option>
            </template>
          </el-select>
        </el-form-item>
        <el-form-item label="文件上传">
          <uploadTemp style="margin:7px;" :files="dialogObj.data.form.files" ref="uploadPic" :operation="operation"></uploadTemp>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer" style="text-align: right">
        <el-button @click="cancleClk('addForm')">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import api from '@/api'
  import axios from 'axios'
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      if (Number(this.dialogObj.type) === 3) {
        this.operation = true
      }
    },
    data () {
      return {
        operation: false,
        files: [
          {
            fileName: 'baidu.gif',
            fileData: 'https://www.baidu.com/img/baidu_jgylogo3.gif',
            src: 'https://www.baidu.com/img/baidu_jgylogo3.gif'
          }
        ],
        isXp: false,
        reflabel: '',
        isPp: false,
        matterIdGroup: [],
        stepIdsGroup: [],
        xpGroup: [],
        spGroup: [],
        refGroup: [],
        addrules: {},
        customerGradeGroup: [],
        operationScaleGroup: [],
        geoTypeGroup: [],
        businessTypeGroup: [],
        num: 1,
        isLoading: true
      }
    },
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
//        this.chuckCus()
        this.isLoading = false
        this.dialogObj.num = this.dialogObj.num + 1
        let xpparam = {}
        xpparam.unitId = getUser().companyId
        xpparam.fields = {'include': 'rowId,goodsDesc'}
        let params = {}
        params.prodUnitId = getUser().companyId
        params.onSchedule = 'Y'
        params.fields = {'include': 'rowId,title'}
        axios.all([
          api.requestJava('POST', BasePath.COMMODITY_SELECT, {'status': 'Y', 'isConfiscated': 'N', 'fields': {'include': 'rowId,goodsDesc'}}),
          api.requestJava('POST', BasePath.ACTIVITY_CIGARETTES_NEW, xpparam),
          api.requestJava('POST', BasePath.FW_FROMS_SELECTLIST, params)
        ])
          .then(axios.spread((first, two, three) => {
            this.spGroup = JSON.parse(JSON.stringify(first.data.data))
            this.xpGroup = JSON.parse(JSON.stringify(two.data.data))
            this.stepIdsGroup = JSON.parse(JSON.stringify(three.data.data))
          }))
        this.changeXp1()
      }
    },
    methods: {
      changeXp () {
//        alert('num=' + this.dialogObj.num)
        if (this.dialogObj.num > 1) {
          this.dialogObj.data.form.ref = ''
        }
        this.changeXp1()
      },
      changeXp1 () {
        var matterid = this.dialogObj.data.form.matterId
        if (matterid === '381012479574016011' || matterid === '381012479574016012' || matterid === '381012479574016013') {
          if (matterid === '381012479574016011') {
//            alert('新品')
            this.isXp = true
            this.refGroup = this.xpGroup
            this.reflabel = '新品选择'
          } else if (matterid === '381012479574016012' || matterid === '381012479574016013') {
//            alert('品牌')
            this.isXp = true
            this.refGroup = this.spGroup
            this.reflabel = '品牌选择'
          }
        } else {
          this.isXp = false
        }
      },
      openImg (msg) {
        alert('获取open 里参数', msg)
      },
      _upload_submit () {
        this.$refs.uploadTemp.submitUpload()
      },
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      },
      updateClk (formName) {
        if (this.dialogObj.data.form.matterId === '') {
          this.$message({type: 'info', message: '请选择活动事项!'})
          return
        }
        if (this.dialogObj.data.form.stepId.length === 0) {
          this.$message({type: 'info', message: '请选择收集内容!'})
          return
        }
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dialogObj.data.form.files = this.$refs.uploadPic.getFiles()
            this.dialogObj.data.form.status = '0'
            this.isLoading = true
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      upClk (formName) {
        if (this.dialogObj.data.form.matterId === '') {
          this.$message({type: 'info', message: '请选择活动事项!'})
          return
        }
        if (this.dialogObj.data.form.stepId.length === 0) {
          this.$message({type: 'info', message: '请选择收集内容!'})
          return
        }
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dialogObj.data.form.files = this.$refs.uploadPic.getFiles()
            this.dialogObj.data.form.status = '1'
            this.isLoading = true
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      }
    },
    components: {
      uploadTemp
    }
  }
</script>
<style scoped>
  .el-form-item {
    margin-bottom: 15px;
  }
  .el-dialog__body {
    padding: 12px 20px;
    color: #48576a;
    font-size: 14px;
    height: 490px;
  }
  .el-select {
    display: inline-block;
    position: relative;
    width: 60%;
  }
  .el-dialog__body {
    color: #48576a;
    font-size: 14px;
  }
  .fa-cog{
    color: #7f9eeb;
    font-size: 21px;
  }
  .notice{
    color: #7f9eeb;
    font-size: 16px;
  }
</style>
