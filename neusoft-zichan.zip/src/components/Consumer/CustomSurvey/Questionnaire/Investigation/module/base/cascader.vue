<!--三级联动-->
<template>
  <li id="cityQuModel" class="ui-draggable">
    <div :class="types === 'city'? 'dwToolbar_icon' : 'dwGoods_icon'"></div>
    <div class="dwQuTypeModel">
      <div class="surveyQuItemBody quDragBody">
        <div class="initLine"></div>
        <div class="quInputCase" style="display: none;">
          <input type="hidden" name="quType" :value="types">
          <input type="hidden" name="itemCode" value="">
          <input type="hidden" name="sortNbr" value="0">
          <input type="hidden" name="saveTag" value="0">
          <input type="hidden" name="hv" value="2">
        </div>
        <div class="surveyQuItem">
          <div class="surveyQuItemLeftTools">
            <ul class="surveyQuItemLeftToolsUl">
              <li title="移动排序" class="dwQuMove ui-draggable"><div class="dwQuIcon"></div></li>
              <li title="设置" class="dwQuSet ui-draggable"><div class="dwQuIcon"></div></li>
              <!--<li title="逻辑" class="dwQuLogic ui-draggable"><div class="dwQuIcon"><div class="quLogicInfo"></div></div></li>-->
              <li title="删除" class="dwQuDelete ui-draggable"><div class="dwQuIcon"></div></li>
            </ul>
          </div>
          <div class="surveyQuItemRightTools">
            <ul class="surveyQuItemRightToolsUl">
              <li class="questionUp ui-draggable"><div class="dwQuIcon"></div></li>
              <li class="questionDown ui-draggable"><div class="dwQuIcon"></div></li>
            </ul>
          </div>
          <div class="surveyQuItemContent">
            <div class="quCoTitle">
              <div class="quCoNum">1、</div>
              <div class="editAble quCoTitleEdit">{{title}}</div>
              <input type="hidden" name="quTitleSaveTag" value="0">
            </div>
            <div class="quCoItem">
              <ul>
                <li class="quCoItemUlLi ui-draggable">
                  <el-cascader
                    :options=[]
                    placeholder="  请选择  "
                  ></el-cascader>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </li>
</template>
<script>
  export default {
    props: ['types'],
    data () {
      return {
        title: ''
      }
    },
    mounted () {
      if (this.types === 'city') {
        this.title = '您所在的城市？'
      } else if (this.types === 'goods') {
        this.title = '请选择|输入商品名称？'
      }
    },
    methods: {
      bindClass () {
        if (this.types === 'city') {
          return 'dwToolbar_icon'
        } else if (this.types === 'goods') {
          return 'dwGoods_icon'
        }
      }
    }
  }
</script>
