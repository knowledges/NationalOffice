<style rel="stylesheet/scss" lang="scss" scoped>
  .container-fluid {
    margin: 0 0;
    padding: 0;
    background: #F1F1F1;
    .body {
      display: inline-block;
      width: 100%;
      min-height: 500px;
      background: #fff;
      margin-top: 40px;
      div.build-plus, div.build-seach, div.build-table {
        display: inline-block;
        width: 100%;
        padding: 0 25px;
      }
    }
    .build-plus, .build-table {
      margin-top: 15px;
    }
    .well {
      margin: 0 0;
      padding: 15px 25px!important;
      form {
        div {
          margin-bottom: 0;
        }
      }
    }
  }
  .build-plus{
    ul {
      li {
        float: left;
        line-height: 35px;
        margin: 0 5px;
      }
    }
  }
</style>
<template>
  <div class="container-fluid">
    <div class="body">
      <div v-if="Number($route.params.uId) === 0" class="build-plus">
        <ul>
          <li>所有工作表单</li>
          <li>|</li>
          <li><a href="javascript:;;" class="btn btn-link" @click="newDesignClk"><i class="fa fa-plus"></i> 新建工作表单</a></li>
        </ul>
      </div>
      <div v-if="Number($route.params.uId) === 0" class="build-seach">
        <div class="well well-lg">
          <el-form :inline="true" :model="mySurvey" class="demo-form-inline">
            <el-form-item label="状态">
              <el-select v-model="mySurvey.status" :clearable="true" placeholder="请选择">
                <el-option v-for="(item, key) in status" :key="key" :label="item.label" :value="item.value"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="名称">
              <el-input v-model="mySurvey.surveyName" placeholder="名称"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="searchClk" icon="search">查询</el-button>
            </el-form-item>
          </el-form>
        </div>
      </div>
      <div class="build-table">
        <tableVue
          ref="table"
          @update:data="tabChange"
          :reqParams="reqParams"
          stripe
          maxHeight="500"
          :data="dataSource"
          :columns="columnHeader"
          :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
          :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData >
        </tableVue>
      </div>

      <el-dialog :title="dialogDesign.title" :visible.sync="dialogDesign.dialogDesignVisible" size="tiny">
        <el-form :model="dialogDesign.form" :rules="dialogrules" ref="dialogDesign">
          <el-form-item label="岗位流程" prop="selected">
            <el-select v-model="dialogDesign.form.selected" :clearable="true" placeholder="请选择岗位流程">
              <el-option v-for="(item, key) in options"  :key="key" :label="item.title" :value="item.rowId"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="表单类别" prop="type">
            <el-select v-model="dialogDesign.form.type" :clearable="true" placeholder="请选择类别">
              <el-option v-for="(item, key) in formType" :key="key"  :label="item.label" :value="item.value"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="表单标题" prop="title" :label-width="dialogDesign.dialogLabelWidth">
            <el-input v-model="dialogDesign.form.title"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogDesign.dialogDesignVisible = false">取 消</el-button>
          <el-button type="primary" @click="newDesignEve('dialogDesign')">确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
    <el-dialog title="复制表单" :visible.sync="dialogCopy.dialogCopyVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="closeModalEve" :size="dialogCopy.size">
      <el-form :model="dialogCopy.form">
        <el-form-item label="复制标题：">
          <el-input v-model="dialogCopy.form.id" v-show="false"></el-input>
          <el-input v-model="dialogCopy.form.title" @onfocus="this.select()" :autofocus=true auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogCopy.dialogCopyVisible = false">取 消</el-button>
        <el-button type="primary" @click="updateFrmClk()">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import tableVue from '@/components/Template/table/Table.vue'
  import { getUser } from '@/config/info'
  import log from '@/log'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import axios from 'axios'
  const CAT = ['xf', 'pp', 'kh']
  export default{
    name: 'Investigation',
    mounted () {
      this.init({})
      if (Number(this.$route.params.uId) === 0) {
        this.getSelectFlowAndStep()
        this.headInit(true)
      } else {
        this.headInit(false)
      }
    },
    data () {
      return {
        mySurvey: {
          status: '',
          surveyName: ''
        }, // 搜索条件参数
        status: [
          {
            label: '设计',
            value: '0'
          }, {
            label: '发布',
            value: '1'
          }, {
            label: '结束',
            value: '2'
          }
        ], // 状态数据集
        dialogDesign: {
          dialogDesignVisible: false,
          title: '新建工作表单',
          dialogLabelWidth: '80px',
          form: {
            type: '',
            title: '',
            selected: '',
            onSchedule: 'Y'
          }
        },
        dialogCopy: {
          dialogCopyVisible: false,
          size: 'tiny',
          form: {
            rowId: '',
            title: '',
            copyFromId: ''
          }
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        hasPagination: true,
        tableType: '3',
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        totalCount: 0, // 表格总记录数
        columnHeader: [], // 表格头部列
        tableData: [], // 真个表格的数据
        dataSource: [], // 当前页的数据
        options: [],
        formType: [
          {
            label: '调研',
            value: 1
          },
          {
            label: '测试',
            value: 2
          },
          {
            label: '其他',
            value: 3
          }
        ], // 表单类别
        reqParams: {
          url: '',
          params: {}
        },
        dialogrules: {
          selected: [
            {required: true, message: '请选择岗位流程'}
          ],
          type: [
            {required: true, message: '请选择类别'}
          ],
          title: [
            {required: true, message: '请输入标题'},
            {type: 'string', message: '请输入标题'}
          ]
        }
      }
    },
    methods: {
      init (params) {
        params.prodUnitId = getUser().companyId
//        params.visitor = getUser().id
        params.fields = {'include': 'rowId,parentId,formCode,title,userName,createdBy,prodUnitName,createdTime,status'}
        params.formCode = '新建工作表单'
        params.pageNum = this.currentPage
        params.pageSize = this.pageSize
        /* 将已有的参数赋值给分页参数 */
        this.$set(this.reqParams, 'url', BasePath.FW_FROMS_SELECTLIST)
        this.$set(this.reqParams, 'params', params)
        api.requestJava('POST', BasePath.FW_FROMS_SELECTLIST, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.totalCount = Number(request.data.count)
              if (this.tableData !== undefined && this.tableData !== null && this.tableData !== '') {
                this.tableData.forEach((val, key) => {
                  for (let i in this.status) {
                    if (Number(val.status) === Number(this.status[i].value)) {
                      val.state = this.status[i].label
                      break
                    }
                  }
                })
                this.currentPage = 1
                this.queryData(this.currentPage, this.pageSize)
              } else {
                this.tableData = []
              }
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      /* 查询 */
      searchClk () {
        let params = {}
        params.status = this.mySurvey.status
        params.title = this.mySurvey.surveyName
        this.init(params)
      },
      newDesignClk () {
        this.dialogDesign.dialogDesignVisible = true
      },
      getSelectFlowAndStep () {
        api.requestJava('POST', BasePath.FW_FLOWS_SELECTLIST, {'unitId': getUser().companyId})
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.options = request.data.data
            }
          })
      },
      /* 新建问卷 */
      newDesignEve (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let params = this.dialogDesign.form
            params.cat = CAT[Number(this.dialogDesign.form.type) - 1]
            params.descText = params.title
            params.placeTypeId = getUser().place
            params.prodUnitId = getUser().companyId
            params.formCode = '新建工作表单'
            params.smallIcon = 'PPGZ.png'
            params.bigIcon = 'PPGZ.png'
            params.originApp = '18ea96ed-e053-4b26-be22-4631f8dc21e1'
            api.requestJava('POST', BasePath.FW_FROMS_INSERT, params)
              .then((request) => {
                this.dialogDesign.dialogDesignVisible = false
                if (Number(request.data.code) === 200) {
                  let data = request.data.data
                  let param1 = {}
                  param1.formId = data.rowId
                  param1.flowId = this.dialogDesign.form.selected
                  param1.parentId = this.dialogDesign.form.type
                  param1.formCode = data.formCode
                  param1.title = data.descText
                  param1.onSchedule = param1.isVisible = 'Y'
                  param1.multiCl = this.dialogDesign.form.type < 3 ? 'Y' : 'N'
                  param1.mustFlag = param1.isMust = param1.isInstore = 'N'
                  let param2 = {}
                  param2.rowId = data.rowId
                  param2.module = '2,Survey/' + data.rowId + '/0/0/0/0/0/0/1'
//                  alert('2,Survey/' + data.rowId + '/0/0/0/0/0/0/1')
                  axios.all([
                    api.requestJava('POST', BasePath.FW_STEPS_INSERT, param1),
                    api.requestJava('POST', BasePath.FW_FROMS_UPDATE, param2)
                  ])
                    .then(axios.spread((first, second) => {
                      if (Number(first.data.code) === 200 && Number(second.data.code) === 200) {
                        this.$router.push({name: 'Design', params: {rowId: param1.formId}})
                      } else {
                        throw new Error(JSON.stringify(request))
                      }
                    }))
                } else if (Number(request.data.code) === 401) {
                  this.logInvalid.dialogVisible = true
                } else {
                  this.$notify.error({title: '提示', message: request.data.message})
                  throw new Error(JSON.stringify(request))
                }
              })
              .catch((err) => {
                let culprit = this.$route.name
                log.work(err, culprit)
              })
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      /* 设计 */
      design (index, row) {
        if (row.createdBy === getUser().id) {
          this.$router.push({name: 'Design', params: {rowId: row.rowId}})
        } else {
          this.$notify({
            title: '警告',
            message: '你没有设计的权限',
            type: 'warning'
          })
        }
      },
      copyFrom (index, row) {
        this.$confirm('复制新增, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'success'
        }).then(() => {
          api.requestJava('POST', BasePath.FW_FROMS_COPYFULLFROM, {formId: row.rowId})
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.dialogCopy.form.rowId = row.rowId
                this.dialogCopy.form.title = request.data.data.title
                this.dialogCopy.dialogCopyVisible = true
              } else if (Number(request.data.code) === 401) {
                this.$message('登录失效')
                this.logInvalid.dialogVisible = true
              } else {
                this.$notify.error({title: '提示', message: request.data.message})
                throw new Error(JSON.stringify(request))
              }
            })
            .catch((err) => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消'
          })
        })
      },
      updateFrmClk () {
        let params = {}
        params.rowId = this.dialogCopy.form.rowId
        params.title = this.dialogCopy.form.title
        api.requestJava('POST', BasePath.FW_FROMS_UPDATE, params)
          .then((request) => {
            this.dialogCopy.dialogCopyVisible = false
            if (Number(request.data.code) === 200) {
              this.$router.push({name: 'Design', params: {rowId: this.dialogCopy.form.rowId}})
            } else if (Number(request.data.code) === 401) {
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 修改标题
      look (index, row) {
        let temp = {}
        temp.formId = row.rowId
        temp.stepId = 0
        temp.userId = getUser().id
        temp.customerId = 0
        temp.brandId = 0
        temp.companyId = getUser().companyId
        temp.personId = getUser().personId
        temp.disabled = 0
        temp.visitingRecId = 0
        temp.planId = 0
        temp.visitor = 0
        temp.visitorName = 0
        temp.customerName = 0
        let str = JSON.stringify(temp)
        let enCode = encodeURI(str)
        this.$router.push({name: 'Survey', params: {str: enCode}})
      },
      find (index, row) {
        /* TODO */
        this.$router.push({name: 'Find', params: {fromId: row.rowId, companyId: getUser().companyId}})
      },
      /* 分析 */
      analyse (index, row) {
        this.$router.push({name: 'Analyse', params: {fromId: row.rowId, companyId: getUser().companyId}})
      },
      /* 删除 */
      del (index, row) {
        if (row.createdBy === getUser().id) {
          this.$confirm('确定删除此条信息吗？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            api.requestJava('POST', BasePath.FW_ITEMS_SELECTELIST, {'formId': row.rowId})
              .then((request) => {
                if (Number(request.data.code) === 200) {
                  if (request.data.data.length > 0) {
                    this.$message({type: 'info', message: '该工作表单已经存在内容不能删除！'})
                  } else {
                    let params = {}
                    params.rowId = row.rowId
                    params.deletedFlag = 1
                    api.requestJava('POST', BasePath.FW_FROMS_UPDATE, params)
                      .then((request) => {
                        if (Number(request.data.code) === 200) {
//                        this.totalCount = 17
//                        this.totalCount = request.data.count
                          this.init({})
                        } else if (Number(request.data.code) === 401) {
                          this.logInvalid.dialogVisible = true
                        } else {
                          this.$notify.error({title: '提示', message: request.data.message})
                          throw new Error(JSON.stringify(request))
                        }
                      })
                      .catch((err) => {
                        let culprit = this.$route.name
                        log.work(err, culprit)
                      })
                  }
                } else if (Number(request.data.code) === 401) {
                  this.logInvalid.dialogVisible = true
                } else {
                  this.$notify.error({title: '提示', message: request.data.message})
                  throw new Error(JSON.stringify(request))
                }
              })
          }).catch(() => {
            this.$message({type: 'info', message: '已取消删除!'})
          })
        } else {
          this.$notify({
            title: '警告',
            message: '你没有删除的权限',
            type: 'warning'
          })
        }
      },
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      rowClick (msg) {},
      headerClick (msg) {},
      sortChange (msg) {},
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      selectionChange () { },
      closeModalEve () {
        this.dialogCopy.dialogCopyVisible = false
      },
      headInit (isTrue) {
        if (isTrue) {
          this.columnHeader = [
            {
              prop: 'title', // 列的值
              label: '表单', // 列的显示字段
              columnsProps: {type: 'text'}
            },
            {
              prop: 'prodUnitName',
              label: '创建者',
              columnsProps: {type: 'text'}
            },
            {
              prop: 'state',
              label: '状态',
              columnsProps: {type: 'text'}
            },
            {
              label: '操作',
              prop: 'operation',
              columnsProps: {type: 'button', width: 480},
              cptProperties: [
                {
                  size: 'small',
                  eventClick: this.design,
                  label: '设计', // 按钮的名称
                  value: 'design', // 按钮的值
                  type: 'success',
                  icon: 'edit'
                },
                {
                  size: 'small',
                  eventClick: this.copyFrom,
                  label: '复制新增', // 按钮的名称
                  value: 'copyFrom', // 按钮的值
                  type: 'success',
                  icon: 'copy'
                },
                {
                  size: 'small',
                  eventClick: this.look,
                  label: '预览', // 按钮的名称
                  value: 'look', // 按钮的值
                  type: 'success',
                  icon: 'search'
                },
                {
                  size: 'small',
                  eventClick: this.find,
                  label: '查询', // 按钮的名称
                  value: 'find', // 按钮的值
                  type: 'success',
                  icon: 'search'
                },
//                {
//                  size: 'small',
//                  eventClick: this.analyse,
//                  label: '分析', // 按钮的名称
//                  value: 'analyse', // 按钮的值
//                  type: 'info',
//                  icon: 'document'
//                },
                {
                  size: 'small',
                  eventClick: this.del,
                  label: '删除',
                  value: 'del',
                  type: 'danger',
                  icon: 'delete'
                }
              ]
            }
          ]
        } else {
          this.columnHeader = [
            {
              prop: 'title', // 列的值
              label: '表单', // 列的显示字段
              columnsProps: {type: 'text'}
            },
            {
              prop: 'prodUnitName',
              label: '创建者',
              columnsProps: {type: 'text'}
            },
            {
              prop: 'createdTime',
              label: '创建时间',
              columnsProps: {type: 'text'}
            },
            {
              prop: 'state',
              label: '状态',
              columnsProps: {width: 80}
            },
            {
              label: '操作',
              prop: 'operation',
              columnsProps: {width: 180, type: 'button'},
              cptProperties: [
                {
                  size: 'small',
                  eventClick: this.find,
                  label: '查询', // 按钮的名称
                  value: 'find', // 按钮的值
                  type: 'success',
                  icon: 'search'
                },
                {
                  size: 'small',
                  eventClick: this.analyse,
                  label: '分析', // 按钮的名称
                  value: 'analyse', // 按钮的值
                  type: 'info',
                  icon: 'document'
                }
              ]
            }
          ]
        }
      }
    },
    components: {
      _POPUP,
      tableVue
    },
    watch: {
      '$route' (val, old) {
        setTimeout(() => {
          if (val.params.uId !== old.params.uId) {
            if (Number(this.$route.params.uId) === 0) {
              this.headInit(true)
            } else {
              this.headInit(false)
            }
          }
        })
      }
    }
  }
</script>
