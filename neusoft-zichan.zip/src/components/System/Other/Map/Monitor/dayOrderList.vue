<template>
  <div class="container-fluid_new">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span="24">
          <el-col :span='8'>
            <div class="form-group">
              <div class="input-group"><label class="el-form-item__label_new" >总数量：</label>
                <span>{{qtySum}}</span>
              </div>
            </div>
          </el-col>
          <el-col :span='8'>
            <div class="form-group">
              <div class="input-group"><label class="el-form-item__label_new" >总金额：</label>
                <span>{{amtSum}}</span>
              </div>
            </div>
          </el-col>
        </el-col>
      </el-col>
    </el-row>
    <div>
      <_TABLE
        ref="table"
        stripe
        maxHeight="500"
        @update:data="tabChange" :reqParams="reqParams"
        :data="dataSource"
        :columns="columnHeader"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
        @selection-change="selectionChange"></_TABLE>
    </div>
    <MY_POPUP_SALES :dialogObj='sales' @confirmBack="salesEve"/>
  </div>
</template>
<style scoped>
  .container-fluid_new {
    background: #FFF;
  }
  .form-group {
    margin: 0!important;
    cursor: pointer;
  }
  .el-form-item__label, .el-form-item__label_new {
    /* font-weight: 500; */
    padding-left: 44px;
    padding-top: 5px;
  }
</style>
<script>
  import MY_POPUP_SALES from '@/components/Home/ClientManager/salesPopup.vue'
  import _TABLE from '@/components/Template/table/Table.vue'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import log from '@/log'
  import {dateFormat} from '@/utils/common'
  export default {
    props: {
      custId: {
        type: String,
        default: ''
      }
    },
    mounted () {
      console.log('获取客户信息5：', JSON.parse(this.custId))
      this.init(JSON.parse(this.custId))
    },
    data () {
      return {
        /** table **/
        cust: {},
        qtySum: '',
        amtSum: '',
        isSelect: false,
        isMore: true, // 查询更多条件
        currentPage: 1, // 默认当前第一页
        pageSize: 500,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        tableType: '3',
        columnHeader: [
          {
            prop: 'itemName', // 列的值
            label: '卷烟名称', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'price', // 列的值
            label: '价格', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'qtyOrd',
            label: '数量',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          },
          {
            prop: 'amt',
            label: '金额',
            columnsProps: {align: 'left'}
          }
        ],
        dataSource: [],
        tableData: [],
        hasPagination: true,
        sales: {
          title: '订单商品明细',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              custId: '',
              custName: '',
              itemId: '',
              itemName: '',
              qtyNeed: '',
              qtyOrd: '',
              price: '',
              amt: ''
            }
          }
        }
      }
    },
    methods: {
      init (val) {
        var myDate = new Date()
        var yearText = dateFormat(myDate.getTime(), 'YYYYMMDD')
        let orderParam = {}
        orderParam.custId = val.customerCode
        orderParam.bornDate = yearText
        console.log('orderParam', JSON.stringify(orderParam))
        this.reqParams.url = BasePath.CUSTOMER_DAYORDER
        this.reqParams.params = orderParam
        api.requestJava('POST', BasePath.CUSTOMER_DAYORDER, orderParam)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.qtySum = request.data.data.qtySum
              this.amtSum = request.data.data.amtSum
              this.tableData = request.data.data.detailEntities
              this.currentPage = 1
              this.totalCount = this.tableData.length
              this.queryData(this.currentPage, this.pageSize)
            } else {
              this.$notify.error({ title: '提示', message: request.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      modify (index, row) {
        this.$emit('confirmBack', row.orderCd)
      }, // 查询接口
      selectionChange (rows) {},
      isMoreClk () {
        this.isSelect = !this.isSelect
      },
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      headerClick () {},
      sortChange (msg) {},
      rowClick (msg) {},
      salesEve (msg) {
        this.sales.dialogVisible = false
        let tmp = {
          title: '订单商品明细',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              custId: '',
              custName: '',
              itemId: '',
              itemName: '',
              qtyNeed: '',
              qtyOrd: '',
              price: '',
              amt: ''
            }
          }
        }
        Object.assign(this.sales, tmp)
      } // 修改事件
    },
    components: {
      _TABLE,
      MY_POPUP_SALES
    },
    watch: {
      custId (val, old) {
        this.init(JSON.parse(val))
      }
    }
  }
</script>
