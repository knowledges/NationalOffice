// 通过当前的日期获得为当月的第几周，方法里面要传入三个值分别为当前日期的年、月、日三个值
export function getMonthWeek (a, b, c) {
  // a = d = 当前日期
  // b = 6 - w = 当前周的还有几天过完(不算今天)
  // a + b 的和在除以7 就是当天是当前月份的第几周
  var date = new Date(a, parseInt(b) - 1, c)
  var w = date.getDay()
  var d = date.getDate()
  return Math.ceil((d + 6 - w) / 7)
}
// 通过当前的日期获得为当年的第几周,方法里面要传入三个值分别为当前日期的年、月、日三个值
export function getYearWeek (a, b, c) {
  // date1是当前日期
  // date2是当年第一天
  // d是当前日期是今年第多少天
  // 用d + 当前年的第一天的周差距的和在除以7就是本年第几周
  var date1 = new Date(a, parseInt(b) - 1, c)
  var date2 = new Date(a, 0, 1)
  d = Math.round((date1.valueOf() - date2.valueOf()) / 86400000)
  return Math.ceil((d + ((date2.getDay() + 1) - 1)) / 7)
}
// 通过年月，获取当月第一天
export function getMonthBegin (date, type) {
  var now = new Date(date) // 当前日期
  var nowMonth = now.getMonth() // 当前月
  var nowYear = now.getFullYear() // 当前年
  var monthStartDate = new Date(nowYear, nowMonth, 1)
  return dateFormat(Date.parse(monthStartDate), type)
}
// 通过年月，获取当月最后一天
export function getMonthEnd (date, type) {
  var now = new Date(date) // 当前日期
  var nowMonth = now.getMonth() // 当前月
  var nowYear = now.getFullYear() // 当前年
  var monthStartDate = new Date(nowYear, nowMonth, 1)
  var monthEndDate = new Date(nowYear, nowMonth + 1, 1)
  var days = (monthEndDate - monthStartDate) / (1000 * 60 * 60 * 24)
  var monthEndDate1 = new Date(nowYear, nowMonth, days)
  return dateFormat(Date.parse(monthEndDate1), type)
}
// 按照日期格式，获取当前日期，type是YYYY-MM，YYYY-MM-DD
export function getNowTime (type) {
  return dateFormat(new Date().getTime(), type)
}
// moreS 多选字段，moreA 模糊查询字段，item  searchform
//  模糊查询: {"fluzzy":{"and":"userCode:1,userName:测试"}}
//  or: "fluzzy":{"or":"userCode,userName:测试"}}
//  下拉框多选in: {"fluzzy":{"in":"userCode:1,2,3|userName:'测试','管理员'"}}
export function fluzzy (moreS, moreA, item) {
  let fluzzy = {}
  let inS = ''
  for (let i = 0; i < moreS.length; i++) {
    if (item[moreS[i].colunm].length > 0) {
      inS = inS + this.moreS[i].colunm + ':' + this.toMoreChange(item[moreS[i].colunm], moreS[i].type) + '|'
    }
  }
  if (inS.length > 0) {
    inS = inS.substr(0, inS.length - 1)
    // console.log('inS', inS)
    fluzzy.in = inS
  }
  let inA = ''
  for (let i = 0; i < moreA.length; i++) {
    if (item[moreA[i].colunm] !== '') {
      inA = inA + moreA[i].colunm + ':' + item[moreA[i].colunm] + ','
    }
  }
  if (inA.length > 0) {
    inA = inA.substr(0, inA.length - 1)
    // console.log('inA', inA)
    fluzzy.and = inA
  }
  return fluzzy
}
// 数组转成用逗号分隔的字符串
export function toMoreChange (values, type) {
  let result = ''
  for (let i = 0; i < values.length; i++) {
    if (type === 'int') {
      result = result + values[i] + ','
    } else if (type === 'string') {
      result = result + "'" + values[i] + "'" + ','
    }
  }
  if (result.length > 0) {
    result = result.substr(0, result.length - 1)
  }
  return result
}
// 获取下拉框汉字
export function changeValue (group, key, value, key1) {
  let obj = {}
  obj = group.find((item) => {
    if (item[key] === value) {
      return item
    }
  })
  return obj.key1
}
// 列表页面修改id，code之类转换成中文
export function changeListValueByCode (changeValueDate, row, column) {
  var unixDate = row[column.property]
  let type = changeValueDate[column.property].type
  var result = ''
  if (unixDate === '' || unixDate === 'null') {
    result = ''
  } else {
    if (type === 'text') {
      let group = changeValueDate[column.property].group
      let key = changeValueDate[column.property].key
      let value = changeValueDate[column.property].value
      for (let i = 0; i < group.length; i++) {
        let obj = group[i]
        if (obj[key] === unixDate) {
          result = obj[value]
          break
        }
      }
    } else if (type === 'date') {
      result = dateFormat(unixDate, 'YYYY-MM-DD')
    } else if (type === 'date1') {
      result = dateFormat(Date.parse(unixDate), 'YYYY-MM-DD')
    }
    return result
  }
}
// 时间格式化
export function dateFormat (date, formatStr) {
  var moment = require('moment')
  var formatDate = new Date(parseInt(date))
  if (date === undefined) {
    return ''
  }
  return moment(formatDate).format(formatStr)
}
// 页面转换数组值
export function convertVal (group, src, key, value) {
  let result = ''
  var i = 0
  group.forEach((e) => {
    let obj = group[i]
    if (obj[key] === src) {
      result = obj[value]
    }
    i++
  })
  return result
}
// 获取当前周第一天
export function weekStart (date, type) {
  var now = new Date(date) // 当前日期
  var nowDayOfWeek = now.getDay() // 今天本周的第几天
  var nowDay = now.getDate() // 当前日
  var nowMonth = now.getMonth() // 当前月
  var nowYear = now.getFullYear() // 当前年
  var weekStartDate = new Date(nowYear, nowMonth, nowDay - nowDayOfWeek)
  return dateFormat(Date.parse(weekStartDate), type)
}
// 获取当前周第一天
export function weekEnd (date, type) {
  var now = new Date(date) // 当前日期
  var nowDayOfWeek = now.getDay() // 今天本周的第几天
  var nowDay = now.getDate() // 当前日
  var nowMonth = now.getMonth() // 当前月
  var nowYear = now.getFullYear() // 当前年
  var weekEndDate = new Date(nowYear, nowMonth, nowDay + (6 - nowDayOfWeek))
  return dateFormat(Date.parse(weekEndDate), type)
}
// 获取昨天
export function lastDate (date, type) {
  let d = new Date(date)
  let end = d.setDate(d.getDate() - 1)
  return dateFormat(end, type)
}
// 获取明天
export function nextDate (date, type) {
  let d = new Date(date)
  let end = d.setDate(d.getDate() + 1)
  return dateFormat(end, type)
}
// 获取上个月
export function lastMonth (type) {
  let lastDate = new Date(new Date().setMonth(new Date().getMonth() - 1))
  return dateFormat(Date.parse(lastDate), type)
}
// 获取下个月
export function nextMonth (type) {
  let nextDate = new Date(new Date().setMonth(new Date().getMonth() + 1))
  return dateFormat(Date.parse(nextDate), type)
}
// 获取前三个月
export function last3Month (type) {
  let last3Date = new Date(new Date().setMonth(new Date().getMonth() - 3))
  return dateFormat(Date.parse(last3Date), type)
}
// 装换json串 从[{value: "0", label: "不拜访"},{value: "1", label: "现场拜访"},{value: "2", label: "电话拜访"}]
// 到{0: "不拜访", 1: "现场拜访", 2: "电话拜访"}
export function changJson (list, key, value) {
  let param = {}
  for (let i = 0; i < list.length; i++) {
    let obj = list[i]
    param[obj[key]] = obj[value]
  }
  // console.log('changJson', param)
  return param
}
// 用 {0: "不拜访", 1: "现场拜访", 2: "电话拜访"} 方式的json串转换中文
export function changeListValueByCode1 (changeValueDate, row, column) {
  var unixDate = row[column.property]
  let type = changeValueDate[column.property].type
  var result = ''
  if (unixDate === '' || unixDate === 'null') {
    result = ''
  } else {
    if (type === 'text') {
      let group = changeValueDate[column.property].group
      if (unixDate in group) {
        result = group[unixDate]
      } else {
        result = ''
      }
    }
    return result
  }
}
