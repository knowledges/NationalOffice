<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false">
    <el-form  label-width="80px" ref="query" :rules="addrules">
      <el-row>
        <el-col :gutter="18">
          <el-col :span='8'   v-for="(col, key) in dialogObj.data"   :key="col.name">
            <el-form-item  prop="col.name" :label="col.label" >
              <el-select v-model="col.value" :clearable="true" placeholder="请选择" @change="handlechange(col.value, key)">
                <el-option
                  v-for="item in col.options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
        <el-button @click="resetForm('addForm')">取 消</el-button>
        <el-button type="primary" @click="submitForm('query')">确 定</el-button>
    </div>
  </el-dialog>
</template>
      <script>
        import {getCodeList} from '@/config/info'
        export default {
          props: ['dialogObj'],
          mounted () {
            this.dialogObj.data.forEach((item, index) => {
              getCodeList(item.code, (data) => {
                item.options = data
                // this.addrules.push()
              }) // 市场类型
            })
          },
          data () {
            return {
              optval: '',
              addrules: {
                roleCode: [
                  {required: true, message: '请输入角色代码', trigger: 'blur'}
                ]
              },
              value: '',
              form: {}
            }
          },
          methods: {
            clearMethod () {
              this.dialogObj.data.forEach((item, index) => {
                item.value = ''
              })
            },
            resetForm (formName) {
              this.dialogObj.dialogVisible = false
              this.clearMethod()
            },
            submitForm (formName) {
              this.dialogObj.dialogVisible = false
              this.$emit('confirmBack', this.dialogObj)
            },
            handlechange (val, index) {
            //   this.dialogObj.data[index].value = val
              this.$set(this.dialogObj.data[index], 'value', val)
            }
          }
        }
      </script>

      <style scoped>
        .item__label_popup {
          text-align: right;
          vertical-align: middle;
          float: right;
          font-size: 14px;
          color: #48576a;
          line-height: 1;
          padding: 11px 8px 11px 0;
          box-sizing: border-box;
          /* display: inline-block; */
        }
        .el-input, .el-input__inner {
          /*width: '';*/
          display: inline-block;
        }
      </style>
