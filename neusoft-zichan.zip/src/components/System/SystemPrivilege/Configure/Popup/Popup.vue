<!-- 徐晓菁 -->
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-form-item label="参数名称">
        <el-input  v-model="dialogObj.data.form.paramName"></el-input>
      </el-form-item>
      <el-form-item label="参数编码">
        <el-input v-model="dialogObj.data.form.paramCode"></el-input>
      </el-form-item>
      </el-form-item>
      <el-form-item label="参数值">
        <el-input type="textarea" resize="none" v-model="dialogObj.data.form.valueCode"></el-input>
      </el-form-item>
      <el-form-item label="描述信息"  v-if="dialogObj.type != 2">
        <el-input type="textarea" resize="none" v-model="dialogObj.data.form.paramDesc"></el-input>
      </el-form-item>
      <el-form-item label="维护标识"  v-if="dialogObj.type != 2">
        <el-select v-model="dialogObj.data.form.modifyFlag" :clearable="true" placeholder="请选择维护标识">
          <template v-for="item in modifyFlagGroup">
            <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
          </template>
        </el-select>
      </el-form-item>
      <el-form-item label="参数分组"  v-if="dialogObj.type != 2">
        <el-select v-model="dialogObj.data.form.paramGrpCode" :clearable="true" placeholder="请选择参数分组">
          <template v-for="item in paramGrpCodeGroup">
            <el-option  :key="item.rowId"  :label="item.shortNm" :value="item.rowId"></el-option>
          </template>
        </el-select>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
      <el-button type="success" @click="updateClk('addForm')"  v-if="dialogObj.type != 3">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import api from '@/api'
  import axios from 'axios'
  import {getCodeList} from '@/config/info'
  import BasePath from '@/config/BasePath'
  export default {
    props: ['dialogObj'],
    mounted () {
      getCodeList('AD_APP_PARAM_MODIFY_FLAG', (data) => {
        this.modifyFlagGroup = data
      }) // 零售业态
      axios.all([
        api.requestJava('POST', BasePath.SELECT_PARAMGRPCODEGROUP, {})
      ])
      .then(axios.spread((first) => {
        this.paramGrpCodeGroup = JSON.parse(JSON.stringify(first.data.data))
      }))
    },
    data () {
      return {
        paramGrpCodeGroup: [],
        modifyFlagGroup: [],
        addrules: {
          paramName: [
            {required: true, message: '请输入参数名称', trigger: 'blur'}
          ],
          paramCode: [
            {required: true, message: '请输入参数编码', trigger: 'blur'}
          ],
          valueCode: [
            {required: true, message: '请输入参数值', trigger: 'blur'}
          ]
        }
      }
    },
    methods: {
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      },
      updateClk (formName) {
        if (Number(this.dialogObj.type) === 1) {
          this.dialogObj.data.form.paramGrpName = this.changeValue(this.dialogObj.data.form.paramGrpCode)
        }
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      changeValue (value) {
        let obj = {}
        obj = this.paramGrpCodeGroup.find((item) => {
          if (item.rowId === value) {
            return item
          }
        })
        return obj.shortNm
      }
    }
  }
</script>
