<template>
<div>
  <el-select v-show="row._edit" v-model="row[col.prop]" placeholder="请选择" @change="col.eventChange(row)">
    <el-option
      v-for="item in col.options"
      :key="item.value"
      :label="item.label"
      :value="item.value">
    </el-option>
  </el-select> 
  <span v-show="!row._edit">{{ text }}</span>
</div>
</template>
<script>
export default {
  props: {
    row: Object,
    col: Object,
    data: Array
    // KeyDownEvent: {
    //   type: Function,
    //   default: function (ev) {
    //   }
    // }
  },
  methods: {
    change: function (val) {
      this.$emit('input', val)
    }
  },
  computed: {
    text () {
      return this.row[this.col.prop]
    }
  }
}
</script>
<style>

</style>
