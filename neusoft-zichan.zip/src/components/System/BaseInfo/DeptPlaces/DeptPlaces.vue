<!-- 徐晓菁 -->
<style scoped>
  .cust_row_l{
    position: absolute;
    top:0;
    left: 10px;
    z-index:9;
    width: 315px;
    border: none;
  }
  .cust_btn_box {
    box-shadow: 2px 3px 6px #666;
    padding: 0!important;
  }
  .cust_btn_l{
    background: #fff;
    border-radius: 50%;
    box-shadow: 2px 2px 5px #999;
    position: absolute;
    top: 50%;
    left: 0;
    margin-top: -18px;
  }
  .moveL-enter-active {
    animation: moveL-in .5s;
  }
  .moveL-leave-active {
    animation: moveL-in .5s reverse;
  }
  @keyframes moveL-in {
    0% {
      transform: translate(-315px, 0px);
    }
    80% {
      transform: translate(25px, 0px);
    }
    100% {
      transform: translate(-5px, 0px);
    }
  }
</style>
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :span="24" style="padding: 0 0">
        <_BTN_FILTER :filterMethod="inputChange"  :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData" :isMore="isMore"/></_BTN_FILTER>
      </el-col>
    </el-row>
    <el-row :gutter="24" class="cust_el_row">
      <el-col :span="6" class="cust_el_col">
        <div class="bg-purple">
          <_TREECOMPONENT :search=searchable :data='treeData' :nodeClick='showTree' :nodeKey="nodeKey"
                          :showCheckBox=showCheckBox :expandAll=expandAll ref='tree' :highlight='true'
                          :defaultCheckedKeys="defaultCheckedKeys"></_TREECOMPONENT>
        </div>
      </el-col>
      <el-col :span="18">
        <_TABLE
          ref="tableGrid"
          stripe
          @update:data="tabChange"
          :reqParams="reqParams"
          maxHeight="500"
          :data="dataSource"
          :columns="columnHeader"
          :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
          :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
          @selection-change="selectionChange"></_TABLE>
      </el-col>
    </el-row>
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve"  v-popupdra-directive="{'show': edit.dialogVisible}"/>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import MY_POPUP_CONFIG from './Popup.vue'
  import _TREECOMPONENT from '@/components/Template/Tree/Tree.vue'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import log from '@/log'
  import axios from 'axios'
  import { changeListValueByCode } from '@/utils/common'
  import {getUser} from '@/config/info'
  export default {
    mounted () {
      // this.queryData(this.currentPage, this.pageSize)
      let params1 = {}
      params1.companyId = getUser().companyId
      params1.whereClause = ` and ORG_TYPE like '2%' `
      axios.all([
        api.requestJava('POST', BasePath.SELECT_DEPTIDGROUP, params1)
      ])
      .then(axios.spread((first) => {
        this.changeValueDate.deptId.group = JSON.parse(JSON.stringify(first.data.data))
      }))
      this.init()
      this.queryUpper({})
    },
    data () {
      return {
        /** 查询更多条件 **/
        isTree: false,
        isMore: false,
        /** table **/
        columnType: 'selection',
        hasPagination: true,
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '新增',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.addClk
          },
          {
            name: '批量删除',
            className: 'btn-danger',
            iconName: 'fa-remove',
            event: this.batchDelClk
          }
        ],
        /** table **/
        columnHeader: [
          {
            prop: 'placeCode', // 列的值
            label: '岗位代码', // 列的显示字段
            columnsProps: {width: 150, align: 'left'}
          },
          {
            prop: 'placeName',
            className: 'header', // 列的css样式（选填）
            label: '岗位名称',
            columnsProps: {width: 150, align: 'left'}
          },
          {
            prop: 'isLeader',
            label: '是否主管岗位',
            columnsProps: {
              width: 150,
              align: 'center',
              formatter: this.changeValue
            }
          },
          {
            prop: 'status',
            label: '状态',
            columnsProps:
            {
              width: 80,
              align: 'center',
              formatter: this.changeValue
            }
          },
          {
            prop: 'deptId',
            label: '所属部门',
            columnsProps:
            {
              width: 250,
              align: 'left',
              formatter: this.changeValue
            }
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 200, type: 'button'},
            cptProperties: [
              {
                label: '修改',
                value: 'modify',
                icon: 'edit',
                size: 'small',
                type: 'warning',
                eventClick: this.modify
              },
              {
                label: '删除',
                value: 'del',
                icon: 'delete',
                size: 'small',
                type: 'danger',
                eventClick: this.del
              }
            ]
          }
        ],
        changeValueDate: {
          isLeader: {
            type: 'text',
            group: [{value: 'Y', label: '是'}, {value: 'N', label: '否'}],
            key: 'value',
            value: 'label'
          },
          status: {
            type: 'text',
            group: [{value: '0', label: '停用'}, {value: '1', label: '启用'}],
            key: 'value',
            value: 'label'
          },
          deptId: {
            type: 'text',
            group: [{value: 'Y', label: '是'}, {value: 'N', label: '否'}],
            key: 'rowId',
            value: 'unitName'
          }
        },
        treeData: [],
        tableData: [
          {
            rowId: '',
            placeCode: '',
            placeName: '',
            quantity: '',
            responsilibility: '',
            mgrPlace: '',
            placeTypeId: '',
            deptId: '',
            isLeader: '',
            mgrTypCd: '',
            prepareDt: '',
            approvedDept: '',
            status: '',
            quantityDown: '',
            quantityUp: '',
            ageDown: '',
            ageUp: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            lastUpdTime: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: ''
          },
          {
            rowId: '',
            placeCode: '',
            placeName: '',
            quantity: '',
            responsilibility: '',
            mgrPlace: '',
            placeTypeId: '',
            deptId: '',
            isLeader: '',
            mgrTypCd: '',
            prepareDt: '',
            approvedDept: '',
            status: '',
            quantityDown: '',
            quantityUp: '',
            ageDown: '',
            ageUp: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            lastUpdTime: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: ''
          },
          {
            rowId: '',
            placeCode: '',
            placeName: '',
            quantity: '',
            responsilibility: '',
            mgrPlace: '',
            placeTypeId: '',
            deptId: '',
            isLeader: '',
            mgrTypCd: '',
            prepareDt: '',
            approvedDept: '',
            status: '',
            quantityDown: '',
            quantityUp: '',
            ageDown: '',
            ageUp: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            lastUpdTime: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: ''
          },
          {
            rowId: '',
            placeCode: '',
            placeName: '',
            quantity: '',
            responsilibility: '',
            mgrPlace: '',
            placeTypeId: '',
            deptId: '',
            isLeader: '',
            mgrTypCd: '',
            prepareDt: '',
            approvedDept: '',
            status: '',
            quantityDown: '',
            quantityUp: '',
            ageDown: '',
            ageUp: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            lastUpdTime: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: ''
          },
          {
            rowId: '',
            placeCode: '',
            placeName: '',
            quantity: '',
            responsilibility: '',
            mgrPlace: '',
            placeTypeId: '',
            deptId: '',
            isLeader: '',
            mgrTypCd: '',
            prepareDt: '',
            approvedDept: '',
            status: '',
            quantityDown: '',
            quantityUp: '',
            ageDown: '',
            ageUp: '',
            createdBy: '',
            createdTime: '',
            lastUpdBy: '',
            lastUpdTime: '',
            modificationNum: '',
            deletedFlag: '',
            originFlag: '',
            originApp: ''
          }
        ],
        tableType: '4',
        dataSource: [], // 当前页的数据
        /** filter **/
        filmode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        filType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['placeCode', 'placeName'], // 过滤的字段
        keyupend: false,   // 输入筛选；true：之前展示；false：之后展示
        templTableData: [], // 临时记录tableDate的值
        /** 弹出层 **/
        edit: {
          title: '商品信息预览',
          type: 'addCommodityManagement',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              rowId: '',
              placeCode: '',
              placeName: '',
              quantity: '',
              responsilibility: '',
              mgrPlace: '',
              placeTypeId: '',
              deptId: '',
              isLeader: '',
              mgrTypCd: '',
              prepareDt: '',
              approvedDept: '',
              status: '',
              quantityDown: '',
              quantityUp: '',
              ageDown: '',
              ageUp: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: ''
            }
          }
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        sel_all_row: [],
        unitTree: [],
        /** 树形属性 **/
        nodeKey: 'id',
        defaultCheckedKeys: [],
        searchable: true, // 是否带搜索框
        showCheckBox: false, // 是否带复选框
        expandAll: true // 是否展开所有节点
      }
    },
    methods: {
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      showTreeClk () {
        this.isTree = !this.isTree
      },
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = this.currentPage
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      showTree (data) {  // 节点单击事件
        this.unitTree = JSON.parse(data)
        console.log('unitTrss', JSON.parse(data))
        let param = {}
        param.deptId = JSON.parse(data).rowId
        this.queryUpper(param)
      },
      init () {
        let orgTreeparam = {}
        orgTreeparam.orgrelTypeId = 2
        orgTreeparam.treeRoot = getUser().companyId
        api.requestJava('POST', BasePath.ORGUNIT_TREE, orgTreeparam)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.treeData.push(request.data.data)
              // this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$notify.error({ title: '查询失败', message: request.data.message })
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      queryData (page, size) {
      // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      addClk () {
        this.edit.data.form.deptIdGroup = this.changeValueDate.deptId.group
        this.edit.dialogVisible = true
      }, // 新增
      modify (index, row) {
        Object.assign(this.edit.data.form, row)
        this.edit.data.form.deptIdGroup = this.changeValueDate.deptId.group
        this.edit.dialogVisible = true
      }, // 修改
      del (index, row) {
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.deleteUpper(row.rowId)
        }).catch(() => {
          this.$message({type: 'info', message: '已取消删除!'})
        })
      },  // 删除
      batchDelClk () {
        if (this.sel_all.length > 0) {
          this.$confirm('确定删除此条信息吗？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.deleteBatchUpper()
          })
        .catch(() => {
          this.$message({type: 'info', message: '已取消删除!'})
        })
        }
      },  // 批量删除
      onendChange (val) {}, // 过滤器修改事件
      deleteUpper (val) {
        let params = {}
        params.rowId = val
        console.log('params', params)
        api.requestJava('POST', BasePath.DEPTPLACES_DELETE, params)
        .then((request) => {
          if (Number(request.data.code) === 200) {
            this.$notify({title: '成功', message: request.data.message, type: 'success'})
            let param = {}
            param.deptId = this.unitTree.rowId
            this.queryUpper(param)
          } else if (Number(request.data.code) === 401) {
            this.$message('登录失效')
            this.logInvalid.dialogVisible = true
          } else {
            this.$notify.error({title: '提示', message: request.data.message})
            throw new Error(JSON.stringify(request))
          }
        })
        .catch((err) => {
          let culprit = this.$route.name
            // this.toggleLoading()
          log.work(err, culprit)
        })
      }, // 删除接口
      deleteBatchUpper () {
        let params = {}
        params.rowId = this.sel_all
        api.requestJava('POST', BasePath.DEPTPLACES_DELETEBATCH, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              let param = {}
              param.deptId = this.unitTree.rowId
              this.queryUpper(param)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 删除接口
      findByCodeUpper () {
        let param = {}
        param.placeCode = this.edit.data.form.placeCode
        api.requestJava('POST', BasePath.DEPTPLACES_SELECT, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (Object.prototype.toString.call(request.data.data[0]) !== '[object Array]') {
                this.$message({type: 'info', message: '岗位代码重复!'})
              } else {
                this.saveUpper()
              }
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      queryUpper (param) {
        param.status = 1
        param.pageSize = this.pageSize
        param.pageNum = 1
        this.reqParams.url = BasePath.DEPTPLACES_SELECT
        this.reqParams.params = param
        api.requestJava('POST', BasePath.DEPTPLACES_SELECT, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.totalCount = +request.data.count
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
              // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      editEve (msg) {
        if (msg === 'update') {
          if (this.edit.data.form.rowId === '') {
            this.findByCodeUpper()
          } else {
            this.saveUpper()
          }
        }
        this.edit.dialogVisible = false
        let tmp = {
          title: '商品信息预览',
          type: 'addCommodityManagement',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              rowId: '',
              placeCode: '',
              placeName: '',
              quantity: '',
              responsilibility: '',
              mgrPlace: '',
              placeTypeId: '',
              deptId: '',
              isLeader: '',
              mgrTypCd: '',
              prepareDt: '',
              approvedDept: '',
              status: '',
              quantityDown: '',
              quantityUp: '',
              ageDown: '',
              ageUp: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: ''
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      saveUpper () {
        let params = this.edit.data.form
        console.log('params', params)
        var url = BasePath.DEPTPLACES_UPDATE
        if (this.edit.data.form.rowId === '') {
          url = BasePath.DEPTPLACES_INSERT
        }
        api.requestJava('POST', url, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              let param = {}
              param.deptId = this.unitTree.rowId
              this.queryUpper(param)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 保存
      sortChange (msg) {},
      rowClick (msg) {},
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      selectionChange (rows) {}
    },
    components: {
      _TABLE,
      _POPUP,
      _BTN_FILTER,
      MY_POPUP_CONFIG,
      _TREECOMPONENT
    }
  }
</script>
