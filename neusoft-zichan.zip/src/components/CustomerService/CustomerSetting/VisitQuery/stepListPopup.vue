<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false"  :size='dialogObj.size' :before-close="cancleClk" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-table :data="this.dialogObj.data.form.products"  >
        <el-table-column prop="productName" label="规格名称" ></el-table-column>
        <el-table-column prop="saleTime" label="销售时点" ></el-table-column>
        <el-table-column prop="unit" label="销售单位" ></el-table-column>
        <el-table-column prop="quantity" label="销售数量" ></el-table-column>
        <el-table-column prop="amount" label="实际销售总额" ></el-table-column>
        <el-table-column prop="notes" label="备注" ></el-table-column>
      </el-table>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
    </div>
  </el-dialog>
  <!--<MY_POPUP_SALES :dialogObj='sales' @confirmBack="salesEve"/>-->
  </div>
</template>

<script>
//  import MY_POPUP_SALES from './salesPopup.vue'
  export default {
    props: ['dialogObj'],
    mounted () {
    },
    data () {
      return {
        addrules: {}
//        sales: {
//          title: '驻店销售记录',
//          type: '3',
//          dialogVisible: false,
//          data: {
//            form: {
//              rowId: '',
//              visitingRecId: '',
//              visitor: '',
//              visitorName: '',
//              customerId: '',
//              cusotmerName: '',
//              visitDate: '',
//              productId: '',
//              productCode: '',
//              productName: '',
//              saleTime: '',
//              unit: '',
//              quantity: '',
//              amount: '',
//              notes: '',
//              status: '',
//              createdBy: '',
//              createdTime: '',
//              lastUpdBy: '',
//              lastUpdTime: '',
//              modificationNum: '',
//              deletedFlag: '',
//              originFlag: '',
//              originApp: ''
//            }
//          }
//        }
      }
    },
    methods: {
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      },
      handleClick (row) {
        Object.assign(this.sales.data.form, row)
        this.sales.dialogVisible = true
      },
      salesEve (msg) {
        this.sales.dialogVisible = false
        let tmp = {
          title: '驻店销售记录',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              visitingRecId: '',
              visitor: '',
              visitorName: '',
              customerId: '',
              cusotmerName: '',
              visitDate: '',
              productId: '',
              productCode: '',
              productName: '',
              saleTime: '',
              unit: '',
              quantity: '',
              amount: '',
              notes: '',
              status: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: ''
            }
          }
        }
        Object.assign(this.sales, tmp)
      } // 修改事件
    },
    components: {
//      MY_POPUP_SALES
    }
  }
</script>
