<!--qiu.bl-->
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :span="24" style="padding: 0 0">
        <_BTN_FILTER :isMore="isMore" :btnGroups="btnGroups" :fileName="fileName" :filterMethod="inputChange"
                     @on-click="exportEve" :tableData="tableData"/>
      </el-col>
    </el-row>
    <div>
      <tableVue
        ref="tableGrid"
        stripe
        maxHeight="500"
        @update:data="tabChange" :reqParams="reqParams"
        :data="dataSource"
        :columns="columns"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
        @cell-dblclick="celldbClick"></tableVue>
    </div>
    <div>
      <el-dialog
        title="分配商品"
        :visible.sync="dialogVisible"
        width="100%" size="large"
        :before-close="handleClose">
        <div class="qq">
          <el-transfer
            v-model="targetValue"
            filterable
            :titles="['可选商品列表', '已选商品列表']"
            :format="{
              noChecked: '${total}',
              hasChecked: '${checked}/${total}'
            }"
            :filter-method="filterMethod"
            class="treepop scoped"
            :render-content="renderFunc"
            @change="handleChange"
            :data="allData">
          </el-transfer>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
  import tableVue from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import BasePath from '@/config/BasePath'
  import { getUser } from '@/config/info'
  import api from '@/api'
  import log from '@/log'
  export default {
    mounted () {
      /** 调用初始化数据 **/
      this.init()
    },
    data () {
      return {
        dialogVisible: false,
        saveDisabled: false,
        sourceData: [], // sourceData(),
        targetValue: [], // goalData()
        allData: [],
        cigCatId: '',
        renderFunc (h, option) {
          return h('span', option.goodsCode + '-' + option.goodsDesc)
        }, // 穿梭框显示的字段
        filterMethod (query, item) {
          let temp = item.goodsCode + item.goodsDesc
          return temp.indexOf(query) > -1
        }, // 穿梭框的过滤方法
        isMore: false,
        fileName: [ 'name', 'code' ],
        btnGroups: [
          {
            name: '',
            className: 'btn-primary',
            iconName: 'fa-th',
            event: this.isMoreClk
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        hasPagination: true, // 是否有分页
        columns: [ // 表格列
          { label: '商品集名称', prop: 'name', columnsProps: {width: 200} },
          { label: '商品集代码', prop: 'code', columnsProps: {width: 150} },
          { label: '商品数量', prop: 'modificationNum', columnsProps: {width: 150} },
          { label: '最新时间', prop: 'lastUpdTime', columnsProps: {width: 200} },
          { label: '类型', prop: 'scope', columnsProps: {width: 150, formatter: this.colFormatter_type} },
          { label: '操作', prop: 'operation', columnsProps: {type: 'button'}, cptProperties: [{ label: '查询', value: 'find', type: 'success', icon: 'edit', eventClick: this.find }] }
        ],
        tableData: [],
        tableType: '4',
        dataSource: [] // 当前页的数据
      }
    },
    methods: {
      init () {
        let param = {}
        param.whereClause = 'and def_ou_id= ' + getUser().companyId + ' and scope=2'
        console.log('whereClause:' + JSON.stringify(param))
        this.reqParams.url = BasePath.CIGCATEGORYS_SELECTLIST
        this.reqParams.params = param
        api.requestJava('POST', BasePath.CIGCATEGORYS_SELECTLIST, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      isMoreClk () {
        this.queryCustomer.dialogVisible = true
      },
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      handleChange (targetValue, direction, movedKeys) {
        console.log(targetValue)
      },
      handleClose () {
        this.sourceData = []
        this.targetValue = []
        this.allData = []
        this.dialogVisible = false
      },
      find (index, row) {
        this.cigCatId = row.rowId
        this.source_goal(index, row)
        this.dialogVisible = true
      },
      source_goal (index, row) {
        this.sourceData = []
        this.targetValue = []
        this.allData = []
        let sourceParam = {}
        sourceParam.cigCatId = row.rowId
//        sourceParam.fields = {'include': 'productId,goodsDesc'}
        console.log('sourceParam' + JSON.stringify(sourceParam))
        api.requestJava('POST', BasePath.CIGCATEGORYS_COMMODITY_SELECTLIST, sourceParam)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              for (let i = 0; i <= request.data.data.length; i++) {
                console.log('1返回' + JSON.stringify(request.data.data))
                this.sourceData.push({
                  key: request.data.data[i].productId + '',
                  goodsCode: request.data.data[i].goodsCode,
                  goodsDesc: request.data.data[i].goodsDesc
                })
                this.allData.push({
                  key: request.data.data[i].productId + '',
                  goodsCode: request.data.data[i].goodsCode,
                  goodsDesc: request.data.data[i].goodsDesc
                })
              }
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
        let goalParam = {}
        goalParam.cigCatId = row.rowId
        console.log('goalParam' + JSON.stringify(goalParam))
        api.requestJava('POST', BasePath.CIGCATEGORYS_SELECTLIST_DETAIL, goalParam)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              for (let i = 0; i <= request.data.data.length; i++) {
                this.targetValue.push(
                  request.data.data[i].productId + ''
                )
                this.allData.push({
                  key: request.data.data[i].productId + '',
                  goodsCode: request.data.data[i].goodsCode,
                  goodsDesc: request.data.data[i].goodsDesc
                })
              }
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      celldbClick (row, column, cell, event) {
        this.$set(row, '_edit', !row._edit)
        if (!row._edit) {
          if (!this.numberChange(row)) {
            row._edit = true
          } else {
            this.$set(row, '_edit', !row._edit)
          }
        }
      },
      colFormatter_type (row, column) {
        let retStr = ''
        switch (row.scope) {
          case '1':
            retStr = '个人'
            break
          case '2':
            retStr = '公用'
            break
          default :
            retStr = '其他'
        }
        return retStr
      }
    },
    components: {
      tableVue,
      _BTN_FILTER

    }
  }
</script>
<style scoped rel="stylesheet/scss" lang="scss">
  .addS {
    margin-bottom: 10px;
  }
  .btn-more {
    background-color: #337ab7;
    color: #FFF
  }
</style>
