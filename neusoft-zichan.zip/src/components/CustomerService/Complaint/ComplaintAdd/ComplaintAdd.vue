<!-- 黄龙 -->
<template>
  <div class="container-fluid">
      <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='12'>
          <div>
        <el-form ref="searchForm" :model="searchForm" label-width="120px">
          <el-col :gutter="24">
            <el-col :span='12'>
              <el-form-item label="受理类型" >
                <el-select v-model="searchForm.cats" multiple  placeholder="请选择受理类型">
                  <el-option
                    v-for="item in optionsCat"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span='12'>
              <div class="block">
                <el-form-item label="受理时间">
                  <el-date-picker
                    v-model="datetime"
                    format="yyyy-MM-dd"
                    type="daterange"
                    :editable=false
                    :clearable=false
                    @change="datePickerChange"
                    placeholder="选择日期范围"
                    :picker-options="pickerOptions">
                  </el-date-picker>
                </el-form-item>
              </div>
            </el-col>
          </el-col>
        </el-form>
       </div>
        </el-col>
        <el-col :span="12">
          <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData" :isMore="isMore"/></_BTN_FILTER>
        </el-col>
      </el-col>
      </el-row>
    <div>
      <_TABLE
        ref="tableGrid"
        stripe
        maxHeight="500"
        @update:data="tabChange" :reqParams="reqParams"
        :data="dataSource"
        :columns="columnHeader"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData></_TABLE>
    </div>
    <MY_POPUP_CONFIG :dialogObj='addDialogObj' @confirmBack="addBack"/>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import MY_POPUP_CONFIG from './ComplaintAddProp.vue'
  import log from '@/log'
  import api from '@/api'
  import { dateFormat } from '@/utils/dateFormat.js'
  import { getUser, getCodeList } from '@/config/info'
  import BasePath from '@/config/BasePath'
  import axios from 'axios'
  import { changeListValueByCode } from '@/utils/common'
  export default {
    mounted () {
      getCodeList('COMPLAINT_TYPE', (data) => {
        this.optionsCat = data
      })
      let params1 = {}
      params1.companyId = getUser().companyId
      params1.whereClause = ` and ORG_TYPE like '2%' `
      axios.all([
        api.requestJava('POST', BasePath.SELECT_DEPTIDGROUP, params1)
      ])
      .then(axios.spread((first) => {
        this.deptIdGroup = first.data.data
        this.changeValueDate.deptId.group = first.data.data
        console.log('SFSDFSDFDSFSDF' + JSON.stringify(this.changeValueDate.deptId.group))
      }))
      var myDate = new Date()
      this.searchForm.companyId = getUser().companyId
      this.searchForm.receiveTimeR = this.getTime(myDate.getTime()) + ' 23:59:59'
      this.searchForm.receiveTimeL = this.getTime(myDate.setDate(1)) + ' 00:00:00'
      console.log('searchForm', this.searchForm)
      this.query()
    },
    data () {
      return {
        isMore: true, // 查询更多条件
        optionsCat: [],
        deptIdGroup: [],
        hasPagination: true,
        datetime: [new Date().setDate(1), new Date()],
        pickerOptions: {
          shortcuts: [{
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '当前月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setDate(1)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }]
        },
        /** 过滤的字段 **/
        fileName: ['cat', 'licenseNo', 'customerName'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '新增',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.addClk
          },
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'cat', // 列的值
            label: '受理类型', // 列的显示字段
            columnsProps: {width: 100, align: 'left'}
          },
          {
            prop: 'deptId', // 列的值
            label: '受理部门', // 列的显示字段
            columnsProps: {width: 200, align: 'left', formatter: this.changeValue}
          },
          {
            prop: 'receiveTime', // 列的值
            label: '受理时间', // 列的显示字段
            columnsProps: {width: 200, align: 'left'}
          },
          {
            prop: 'licenseNo', // 列的值
            label: '许可证号码', // 列的显示字段
            columnsProps: {width: 150, align: 'left'}
          },
          {
            prop: 'customerName', // 列的值
            label: '客户名称', // 列的显示字段
            columnsProps: {width: 250, align: 'left'}
          },
          {
            prop: 'tel', // 列的值
            label: '联系电话', // 列的显示字段
            columnsProps: {width: 150, align: 'left'}
          },
          {
            prop: 'addr', // 列的值
            label: '经营地址', // 列的显示字段
            columnsProps: {width: 300, align: 'left'}
          },
          {
            prop: 'handlingTime', // 列的值
            label: '处理时间', // 列的显示字段
            columnsProps: {width: 300, align: 'left'}
          },
          {
            prop: 'status', // 列的值
            label: '处理状态', // 列的显示字段
            columnsProps: {width: 300, align: 'left', formatter: this.changeValue}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 250, type: 'button', fixed: 'right'},
            cptProperties: [
              {
                label: '删除',
                value: 'del',
                icon: 'delete',
                size: 'small',
                type: 'danger',
                eventClick: this.del
              },
              {
                label: '预览', // 按钮的名称
                value: 'view', // 按钮的值
                type: 'primary',
                size: 'small',
                icon: 'search',
                eventClick: this.modify // 按钮的方法
              }
            ]
          }
        ],
        changeValueDate: {
          deptId: {
            type: 'text',
            group: [],
            key: 'rowId',
            value: 'unitName'
          },
          status: {
            type: 'text',
            group: [{
              value: '1',
              label: '未处理'
            }, {
              value: '3',
              label: '已处理'
            }],
            key: 'value',
            value: 'label'
          }
        },
        moreS: [
          {
            colunm: 'cats',
            type: 'string'
          }
        ],
        tableData: [],
        cat: [],
        tableType: '3',
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        /** searchForm **/
        searchForm: {
//          receiveTime: '',
          companyId: '',
          receiveTimeL: '',
          receiveTimeR: '',
//          status: '',
          cats: ''
        },
        addDialogObj: {
          title: '咨询投诉信息编辑',
          type: '1',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              unitName: getUser().deptName,
              receiver: '',
              receiverName: '',
              receiveTime: '',
              customerName: '',
              licenseNo: '',
              companyId: '',
              addr: '',
              tel: '',
              cat: '',
              contents: '',
              custmgrId: '',
              employeeName: '',
              custmgrNm: '',
              receiveTimeL: '',
              receiveTimeR: '',
              status: '',
              files: []
            }
          }
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        }
      }
    },
    methods: {
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      datePickerChange () {
        this.searchForm.receiveTimeL = this.getTime(Date.parse(this.datetime[0])) + ' 00:00:00'
        this.searchForm.receiveTimeR = this.getTime(Date.parse(this.datetime[1])) + ' 23:59:59'
//        this.searchForm.receiveTimeL = this.getTime(Date.parse(this.datetime[0]))
//        this.searchForm.receiveTimeR = this.getTime(Date.parse(this.datetime[1]))
        console.log('searchForm', this.searchForm)
      },
      query () {
        let params = this.searchForm
        params.haveAttach = '1'
        if (this.searchForm.cats.length > 0) {
          let param1 = {}
          for (let i = 0; i < this.moreS.length; i++) {
            param1.in = 'cat:' + this.toMoreChange(this.searchForm[this.moreS[i].colunm], this.moreS[i].type)
            params.fluzzy = param1
          }
        }
        this.queryUpper(params)
      }, // 查询方法
      queryUpper (params) {
        this.reqParams.url = BasePath.COMPLAINTREC_SELECTNAME
        this.reqParams.params = params
        api.requestJava('POST', BasePath.COMPLAINTREC_SELECTNAME, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.dataSource = request.data.data
              this.tableData = request.data.data
              console.log('获取数据:' + JSON.stringify(this.tableData))
              this.totalCount = Number(request.data.count)
              let tempfiles = request.data.data.files
              var i = 0
              tempfiles.forEach((e) => {
                if (tempfiles[i].fileType === 'complaint_attach_photo') {
                  this.addDialogObj.data.form.files.push(tempfiles[i])
                }
                i++
              })
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      modify (index, row) {
        console.log('ROW:::' + JSON.stringify(row))
        this.addDialogObj.type = '2'
        Object.assign(this.addDialogObj.data.form, row)
        this.addDialogObj.dialogVisible = true
      }, // 修改
      addBack (msg) {
        if (msg !== 'cancle') {
          this.add()
        }
        this.clearObject()
      },
      add () {
        let paraminfo = this.addDialogObj.data.form
        console.log('paraminfoparaminfo' + JSON.stringify(paraminfo))
        paraminfo.haveAttach = 1
        let files = []
        var j = 0
        if (paraminfo.files.length > 0) {
          paraminfo.files.forEach((e) => {
            let complaintPhoto = {}
            complaintPhoto.fileName = paraminfo.files[j].fileName
            complaintPhoto.fileType = 'complaint_attach_photo'
            complaintPhoto.fileData = paraminfo.files[j].fileData
            files.push(complaintPhoto)
            j++
          })
          paraminfo.files = files
        }
        var post = BasePath.COMPLAINTREC_UPDATE
        if (paraminfo.rowId === '') {
          post = BasePath.COMPLAINTREC_INSERT
        }
        api.requestJava('POST', post, paraminfo)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$message({type: 'success', message: '新增成功!'})
              this.query()
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      toMoreChange (values, type) {
        let result = ''
        for (let i = 0; i < values.length; i++) {
          if (type === 'int') {
            result = result + values[i] + ','
          } else if (type === 'string') {
            result = result + "'" + values[i] + "'" + ','
          }
        }
        if (result.length > 0) {
          result = result.substr(0, result.length - 1)
        }
        return result
      },
      getCurrent () {
        var date = new Date()
        var seperator1 = '-'
        var seperator2 = ':'
        var month = date.getMonth() + 1
        var strDate = date.getDate()
        var hour = date.getHours() // 时
        var minutes = date.getMinutes() // 分
        var seconds = date.getSeconds() // 秒
        if (month >= 1 && month <= 9) {
          month = '0' + month
        }
        if (strDate >= 0 && strDate <= 9) {
          strDate = '0' + strDate
        }
        if (hour >= 0 && hour <= 9) {
          hour = '0' + hour
        }
        if (minutes >= 0 && minutes <= 9) {
          minutes = '0' + minutes
        }
        if (seconds >= 0 && seconds <= 9) {
          seconds = '0' + seconds
        }
        var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate + ' ' + hour + seperator2 + minutes + seperator2 + seconds
        return currentdate
      },
      listToString (values, type) {
        let result = ''
        for (let i = 0; i < values.length; i++) {
          if (type === 'int') {
            result = result + values[i] + ','
          }
        }
        if (result.length > 0) {
          result = result.substr(0, result.length - 1)
        }
        return result
      },
      del (index, row) {
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let params = {}
          params.rowId = row.rowId
          api.requestJava('POST', BasePath.COMPLAINTREC_DELETE, params)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.query()
                this.$message({type: 'success', message: '删除成功!'})
              } else if (Number(request.data.code) === 401) {
                this.sessionFailDialogObj.dialogVisible = true
              } else {
                throw new Error(JSON.stringify(request))
              }
            })
        }).catch(() => {
          this.$message({type: 'info', message: '已取消删除!'})
        })
      },
      batchDelClk () {},  // 批量删除
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      onendChange (val) {}, // 过滤器修改事件
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      dateFormatter (row, column) {
        var unixDate = row[column.property]
        return dateFormat(unixDate, 'YYYY-MM-DD')
      },  // 时间格式化
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      headerClick (column, event) {},
      addClk () {
        this.addDialogObj.data.form.deptId = getUser().deptId
        this.addDialogObj.data.form.receiveTime = this.getCurrent()
        this.addDialogObj.data.form.receiver = getUser().personId
        this.addDialogObj.data.form.receiverName = getUser().userName
        this.addDialogObj.data.form.companyId = getUser().companyId
        this.addDialogObj.data.form.files = []
        this.addDialogObj.dialogVisible = true
      },
      sortChange (msg) {},
      rowClick (msg) {},
      clearObject () {
        let temp = {
          title: '咨询投诉信息编辑',
          type: 'addUser',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              unitName: getUser().deptName,
              receiver: '',
              receiverName: '',
              receiveTime: '',
              customerName: '',
              licenseNo: '',
              companyId: '',
              addr: '',
              tel: '',
              cat: '',
              contents: '',
              custmgrId: '',
              employeeName: '',
              custmgrNm: '',
              receiveTimeL: '',
              receiveTimeR: '',
              status: '',
              files: []
            }
          }
        }
        Object.assign(this.addDialogObj, temp)
      }
    },
    components: {
      _TABLE,
      _POPUP,
      MY_POPUP_CONFIG,
      _BTN_FILTER
    }
  }
</script>

<style scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label{
   margin: 0px!important;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }

  .filter_style .el-col-24 {
    height: 36px;
  }
  .el-form-item {
    margin-bottom: 12px;
  }
</style>
