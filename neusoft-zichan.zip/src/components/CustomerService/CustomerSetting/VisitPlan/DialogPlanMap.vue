<!--qiu.bl-->
<style rel="stylesheet/scss" lang="scss" scoped>
  #dialog_div{
    display: inline-block;
    width: 100%;
    height: 450px;
  }
  #dialog_map {
    display: inline-block;
    width: 100%;
    height: 100%;
    background: #f1f2f3;
  }
  #dialog_timer {
    position: absolute;
    width: 100%;
    height: 35px;
    top: 55px;
    left: 0px;
    padding: 0 20px;
    z-index: 9;
    background: #FFF;
  }
</style>
<template>
    <div>
      <el-dialog
        title="客户分布"
        :visible.sync="dialog.Visible"
        :size='dialog.size'
        width="50%"
        :close-on-click-modal="false" :close-on-press-escape="false"
        :before-close="handleClose">
        <div id="dialog_timer" v-if="isShow">
          <el-form :inline="true" class="demo-form-inline">
            <el-form-item label="拜访日期">
              <el-date-picker
                v-model="planTimer"
                type="date"
                @change="fondOne"
                placeholder="选择日期">
              </el-date-picker>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="findAll">查询所有客户数</el-button>
            </el-form-item>
          </el-form>
        </div>
        <div id="dialog_div">
          <div id="dialog_map"></div>
        </div>
      </el-dialog>
    </div>
</template>
<script>
  import BMapLib from 'BMapLib'
  import {MP, getCityShowMap, ShowMap} from '@/components/Template/Map/map.js'
  import {getUser} from '@/config/info'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  var [BMap, map] = ''
  export default {
    name: 'DialogPlanMap',
    props: {
      coors: {
        type: Array,
        default: []
      },
      open: Boolean,
      isShow: {
        type: Boolean,
        default: true
      }
    },
    mounted () {
//      this.init()
      this.dialog.coors = this.coors
    },
    data () {
      return {
        ak: 'sFGGCnZu8HcewIdGMFGGaGypsfILG36G',
        zoom: 12,
        planTimer: '',
        dialog: {
          size: 'large',
          city: {},
          Visible: false,
          coors: []
        }
      }
    },
    methods: {
      init () {
        Promise.all([MP(this.ak)]).then((bmap) => {
          BMap = bmap[0]
          map = new BMap.Map('dialog_map')
          getCityShowMap((result) => {
            let params = this.dialog.city = result.center
            if (this.dialog.coors.length <= 0) {
              params = result.center
            } else {
              var t = this.getCoorVal()
              if (t === null) {
                params = result.center
              } else {
                params.lng = t.x
                params.lat = t.y
              }
            }
            ShowMap(map, params, this.zoom)
            this.getMarkerCluster()
          })
        })
      },
      getMarkerCluster () { // 获取聚合数据
        var markers = []
        var pt = null
        this.dialog.coors.forEach((item, key) => {
          if (Number(item.x) > 0 && Number(item.y) > 0) {
            pt = new BMap.Point(item.x, item.y)
            var lab = new BMap.Marker(pt)
            this.$set(lab, 'info', item)
            markers.push(lab)
            /* 显示名字 */
            let label = new BMap.Label('法人：' + item.legalPerson, {offset: new BMap.Size(15, -16)})
            label.setStyle({
              color: '#FFF',
              fontSize: '12px',
              height: '20px',
              lineHeight: '20px',
              fontFamily: '微软雅黑',
              position: 'relative',
              padding: '5px 8px',
              border: '2px solid #fff',
              backgroundColor: 'green',
              borderRadius: '6px',
              letterSpacing: '2px'
            })
            lab.setLabel(label)
            lab.addEventListener('click', () => {
              let params = {}
              params.haveAttach = 1
              params.rowId = item.customerId || item.rowId
              api.requestJava('POST', BasePath.CUSTOMER_SELECTONE, params)
                .then((request) => {
                  if (Number(request.data.code) === 200) {
                    var data = request.data.data
                    const h = this.$createElement
                    this.$msgbox({
                      title: data.customerDesc,
                      message: h('div', null, [
                        h('p', null, '地址：' + data.addr),
                        h('p', null, '客户档级：' + data.customerGradeName),
                        h('p', null, '零售业态：' + data.businessTypeName),
                        h('p', null, '法人：' + data.legalPerson)
                      ])
                    })
                  } else {
                    throw new Error(JSON.stringify(request))
                  }
                })
                .catch((err) => {
                  console.error(err)
                })
//              var rowId = lab.info.rowId
//              this.$alert(lab.info.addr + '\/n' + 11111, lab.info.customerName || lab.info.customerDesc, {})
//              this.$notify({
//                title: lab.info.customerName || lab.info.customerDesc,
//                message: lab.info.addr
//              })
            })
          }
        })
        if (markers.length > 0) {
          // 最简单的用法，生成一个marker数组，然后调用markerClusterer类即可。
          var markerClusterer = new BMapLib.MarkerClusterer(map, {markers: markers})
          console.log(markerClusterer)
        }
      },
      /* 弹出框关闭 */
      handleClose () {
        this.dialog.Visible = false
        this.$parent.open = false
      },
      findAll () {
        /* 查询所有 */
        this.dialog.coors = this.coors
        this.init()
      },
      fondOne (e) {
        this.dialog.coors = []
        /* 查询具体某一天 */
        var params = {}
        params.companyId = getUser().companyId
        params.custmgrId = getUser().personId
        params.queryDate = e
        params.status = '0,1,2,4,9'
        api.requestJava('POST', BasePath.VISITPLAN_TODATE_SELECTLIST, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.dialog.coors = request.data.data
              this.init()
            }
          })
      },
      getCoorVal () {
        var obj = null
        this.dialog.coors.forEach((item, key) => {
          if (Number(item.x) > 0 && Number(item.y)) {
            obj = item
            return obj
          }
        })
        return obj
      }
    },
    components: {},
    watch: {
      coors (n, o) {
        if (n.length > 0) {
          this.dialog.coors = n
        }
      },
      open (n, o) {
        this.dialog.Visible = n
      }
    }
  }
</script>
