/*
* @Author: sunlandong
* @Date:   2017-03-11 12:06:55
* @Last Modified by:   sunlandong
* @Last Modified time: 2017-03-11 16:36:56
*/
import MSDataTransfer from './dataTranslate.js'
export default {
  MSDataTransfer
}
