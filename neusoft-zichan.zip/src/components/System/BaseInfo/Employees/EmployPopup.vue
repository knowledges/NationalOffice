<!--张文艺-->
<template>
    <div>
      <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="closeModalEve" :size='dialogObj.size'>
        <div v-if= "dialogObj.type == 'addEmployee'">
          <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="countyDept" label="分公司" >
                  <el-select v-model="dialogObj.data.form.countyDept" @change="onChange" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in optionsCountyDept"
                      :key="item.orgUnitId"
                      :label="item.orgRoleNm"
                      :value="item.orgUnitId">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="department" label="部门">
                  <el-select v-model="dialogObj.data.form.deptId"  @change="onChangePlace" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in optionsDepartment"
                      :key="item.orgUnitId"
                      :label="item.orgRoleNm"
                      :value="item.orgUnitId">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="employeeCode" label="工号">
                  <el-input v-model="dialogObj.data.form.employeeCode" auto-complete="off" class="inputInline" value="number"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item  prop="employeeName" label="姓名" >
                  <el-input v-model="dialogObj.data.form.employeeName" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="shortCode" label="助记码">
                  <el-input v-model="dialogObj.data.form.shortCode" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12'>
                <el-form-item  prop="idcard" label="身份证号" >
                  <el-input v-model="dialogObj.data.form.idcard" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12' >
                <el-form-item prop="sex" label="性别">
                  <el-select v-model="dialogObj.data.form.sex" filterable :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in optionsSex"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="edubg" label="学历">
                  <el-select v-model="dialogObj.data.form.edubg" filterable :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in optionsEdubg"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
            <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="email" label="邮件" >
                  <el-input v-model="dialogObj.data.form.email" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item  prop="priCnict" label="手机" >
                  <el-input v-model="dialogObj.data.form.priCnict" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="isManager" label="是否主管" >
                  <el-switch
                    v-model="dialogObj.data.form.isManager"
                    on-text=""
                    off-text="">
                  </el-switch>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="status" label="是否启用">
                  <el-switch
                    v-model="dialogObj.data.form.status"
                    on-text=""
                    off-text="">
                  </el-switch>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="duty" label="职务" >
                  <el-select v-model="dialogObj.data.form.duty" filterable :clearable="true" placeholder="请选择">
                  <el-option
                    v-for="item in optionsDuty"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="place" label="岗位">
                  <el-select v-model="dialogObj.data.form.place" @change="onChangeValue" filterable :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in optionsPlace"
                      :key="item.placeCode"
                      :label="item.placeName"
                      :value="item.placeCode">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="manager" label="直线经理" >
                  <el-select v-model="dialogObj.data.form.manager" filterable :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in optionsManager"
                      :key="item.rowId"
                      :label="item.employeeName"
                      :value="item.rowId">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item prop="birthday" label="出生日期">
                  <el-date-picker type="date" placeholder="选择日期" v-model="dialogObj.data.form.birthday" style="width: 100%;"></el-date-picker>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
        </el-form>
          <div slot="footer" class="dialog-footer" style="text-align: right">
            <el-button @click="resetForm('addForm')">取 消</el-button>
            <el-button type="primary" @click="submitForm('addForm')">确 定</el-button>
          </div>
        </div>
        <div v-if="dialogObj.type == 'query'">
          <el-form :model="dialogObj.data.form" label-width="100px" ref="query" :rules="queryrules">
            <el-row>
              <el-col :span='24'>
                <el-col :span='12'>
                  <el-form-item  prop="tel" label="工号" >
                    <el-input v-model="dialogObj.data.form.employeeCode" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span='12' >
                  <el-form-item prop="phone" label="姓名">
                    <el-input v-model="dialogObj.data.form.employeeName" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span='24'>
                <el-col :span='12'>
                  <el-form-item  prop="tel" label="性别" >
                    <el-input v-model="dialogObj.data.form.sex" auto-complete="off" class="inputInline"></el-input>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-row>
          </el-form>
          <div slot="footer" class="dialog-footer" style="text-align: right">
            <el-button @click="resetForm('query')">取 消</el-button>
            <el-button type="primary" @click="submitForm('query')">确 定</el-button>
          </div>
        </div>
      </el-dialog>
  </div>
</template>
<script>
  import InputTemp from '@/components/Template/filter/InputTemp.vue'
  import DatePickerTemp from '@/components/Template/DatePicker/DatePickerTemp.vue'
  import { getUser, getCodeList } from '@/config/info'
  import api from '@/api'
  import log from '@/log'
  import axios from 'axios'
  import BasePath from '@/config/BasePath'
  export default {
    mounted () {
      let param = {}
      param.unitId = getUser().companyId
      param.NextTypeId = '203'
      param.fields = {include: 'orgUnitId,orgRoleNm'}
//      this.onChange()
//      this.onChangePlace()
//      this.onChangeValue()
      getCodeList('YC_SEX', (data) => {
        this.optionsSex = data
      })
      getCodeList('YC_EDU_BACKGROUND', (data) => {
        this.optionsEdubg = data
      })
      getCodeList('YC_DUTY', (data) => {
        this.optionsDuty = data
      })
      let companyIdParam = {} // 分公司
      companyIdParam.NextTypeId = '203'
      companyIdParam.orgUnitId = getUser().countyId
      companyIdParam.unitId = getUser().companyId
      companyIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
      let divisionIdParam = {} // 部门
      divisionIdParam.orgUnitId = getUser().countyId
      divisionIdParam.orgRoleTypId = '207'
      divisionIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
      divisionIdParam.unitId = getUser().companyId
      axios.all([
        api.requestJava('POST', BasePath.NEXTORGUNIT_SELECT, companyIdParam), // 公司
        api.requestJava('POST', BasePath.SELECT_FACTORYIDGROUP, divisionIdParam) // 部门
      ])
        .then(axios.spread((_countyDept, _deptId) => {
          this.optionsCountyDept = _countyDept.data.data
//          this.optionsDepartment = _deptId.data.data
          console.log('optionsCountyDept' + JSON.stringify(this.optionsCountyDept))
        }))
      this.init()
    },
    props: ['dialogObj'],
    data () {
      var checkCard = (rule, value, callback) => {
        let idCardReg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/
        if (!value) {
          return callback()
        }
        setTimeout(() => {
          if (RegExp(idCardReg).test(value) === false) {
            callback(new Error('请输入正确的身份证号'))
          } else {
            callback()
          }
        }, 1000)
      }
      var checkemail = (rule, value, callback) => {
        let emailReg = /^(\w)+(\.\w+)*@(\w)+((\.\w+)+)$/
        if (!value) {
          return callback()
        }
        setTimeout(() => {
          if (RegExp(emailReg).test(value) === false) {
            callback(new Error('请输入正确的邮件格式'))
          } else {
            callback()
          }
        }, 1000)
      }
      return {
        dialogVisible: false,
        formLabelWidth: '120px',
        filmode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤
        fileName: ['value'],
        filType: 0, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        keyup: false, // 输入筛选；true：之前展示；false：之后展示
        optionsSex: [],
        optionsEdubg: [],
        optionsDuty: [],
        optionsCountyDept: [],
        optionsDepartment: [],
        optionsPlace: [],
        optionsManager: [],
        addrules: {
          employeeCode: [
            {required: true, message: '请输入工号', trigger: 'blur'}
          ],
          employeeName: [
            {required: true, message: '请输入姓名', trigger: 'blur'}
          ],
          idcard: [
            {validator: checkCard, trigger: 'blur'}
          ],
          email: [
            {validator: checkemail, trigger: 'blur'}
          ]
        },
        queryrules: {}
      }
    },
    methods: {
      submitForm (formName) {
        // this._upload_submit()
        this.$refs[formName].validate((valid) => {
          if (valid) {
            // this.$refs.uploadTemp.submitUpload()
            this.dialogObj.dialogVisible = false
            this.$emit('confirmBack', this.dialogObj)
            setTimeout(() => {
              this.$refs[formName].resetFields()
            }, 1000)
          } else {
            return false
          }
        })
      },
      closeModalEve () {
        this.dialogObj.dialogVisible = false
      },
      resetForm (formName) {
        this.dialogObj.dialogVisible = false
      },
      startTime (val) {
        this.dialogObj.data.form.date = val
      },
      getPlace () {
        api.requestJava('POST', BasePath.DEPTPLACESTYPE_SELECT, {'fields': {'include': 'rowId,name'}})
          .then((request) => {
            if (Number(request.data.code) === 200) {
//              this.optionsPlace = request.data.data
//              console.log('岗位：' + JSON.stringify(this.optionsPlace))
//              localStorage.setItem('optionsPlace', JSON.stringify(request.data.data))
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      getManager () {
//        this.optionsManager = JSON.parse(localStorage.getItem('optionsManager'))
        let params = {}
        params.place = '24'
        params.companyId = getUser().companyId
        params.countyDept = getUser().countyId
        params.status = 1
        params.fields = {include: 'rowId,employeeName'}
        if (this.optionsManager === null || this.optionsManager === '' || this.optionsManager.length === 0 || this.optionsManager === undefined) {
          api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.optionsManager = request.data.data
                localStorage.setItem('optionsManager', JSON.stringify(request.data.data))
              } else if (Number(request.data.code) === 401) {
                this.sessionFailedDialogObj.dialogVisible = true
              } else {
                throw new Error(JSON.stringify(request))
              }
            })
        }
      },
      onChange () {
        let param = {}
        param.unitId = this.dialogObj.data.form.countyDept
        param.NextTypeId = '207'
        param.fields = {include: 'orgRoleNm,orgUnitId'}
        api.requestJava('POST', BasePath.NEXTORGUNIT_SELECT, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.optionsDepartment = request.data.data
              localStorage.setItem('optionsDepartment', JSON.stringify(request.data.data))
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      onChangePlace () {
        if (this.dialogObj.data.form.deptId !== '') {
          let param = {}
          param.deptId = this.dialogObj.data.form.deptId
          param.fields = {include: 'rowId,placeCode,placeName'}
          api.requestJava('POST', BasePath.DEPTPLACES_SELECT, param)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.optionsPlace = request.data.data
                console.log('岗位：' + JSON.stringify(this.optionsPlace))
                localStorage.setItem('optionsPlace', JSON.stringify(request.data.data))
              } else if (Number(request.data.code) === 401) {
                this.sessionFailedDialogObj.dialogVisible = true
              } else {
                throw new Error(JSON.stringify(request))
              }
            })
            .catch((err) => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
          // 获取上级领导
          let params = {}
          params.place = '24'
          params.deptId = this.dialogObj.data.form.deptId
          params.status = 1
          params.fields = {include: 'rowId,employeeName'}
          api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.optionsManager = request.data.data
                localStorage.setItem('optionsManager', JSON.stringify(request.data.data))
              } else if (Number(request.data.code) === 401) {
                this.sessionFailedDialogObj.dialogVisible = true
              } else {
                throw new Error(JSON.stringify(request))
              }
            })
        }
      },
      onChangeValue (obj) {
        this.dialogObj.data.form.placeId = this.optionsPlace.find(item => Number(item.placeCode) === Number(obj)).rowId
      }
    },
    components: {
      InputTemp,
      DatePickerTemp
    }
  }
</script>
