<!--  Auther:luoshuo -->
<!--  多选题分析 -->
<template>
  <div>
    <div class="checkBoxTitle">
      <div>{{idx + 1}}、{{question.itemTitle}}[填空题]</div>
    </div>
    <div>
      <table id="checkBox" class="checkBoxTableStyle">
        <tbody>
          <tr v-for="item in question.options" :key="item.id" class="checkBoxTrOptions">
            <td width="2%" height="30px">&nbsp;</td>
            <td width="48%">{{item.val}}</td>
            <td width="40%"><el-progress :stroke-width="strokeWidth" text-inside :percentage="item.percent"></el-progress></td>
            <td width="10%">&nbsp;&nbsp;{{item.selected}}次</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div>
      <el-tabs v-model="checkBoxModel" type="card" @tab-click="handleClick">
        <el-tab-pane label="柱状图" name="histogram">
           <ve-histogram :data="checkBoxChartData" :settings="checkBoxChartSettings" :labelMap="labelMap" width="100%"></ve-histogram>
        </el-tab-pane>
        <el-tab-pane label="饼图" name="pie">
          <ve-pie :data="checkBoxChartData" :settings="checkBoxChartSettings" width="700px" class="checkBoxMargin"></ve-pie>
        </el-tab-pane>
        <el-tab-pane label="条形图" name="bar">
          <ve-bar :data="checkBoxChartData" :settings="checkBoxChartSettings" width="700px" class="checkBoxMargin"></ve-bar>
        </el-tab-pane>
        <el-tab-pane label="折线图" name="line">
          <ve-line :data="checkBoxChartData" :settings="checkBoxChartSettings" width="700px" class="checkBoxMargin"></ve-line>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      strokeWidth: 18,
      checkBoxModel: 'histogram',
      labelMap: '次数',
      checkBoxChartData: {
        columns: ['val', 'selected', 'percent'],
        rows: [
        ]
      },
      checkBoxChartSettings: {
        metrics: ['selected'],
        dimension: ['val'],
        labelMap: {
          'selected': '总数'
        }
      }
    }
  },
  methods: {
    handleClick (tab, event) {

    }
  },
  props: {
    question: {
      type: Object,
      required: true
    },
    idx: Number
  },
  mounted () {
    this.$nextTick(() => {
      this.checkBoxChartData.rows = this.question.detailList
    })
  }
}
</script>
<style>
.checkBoxTitle {
  color: #625F5F;
  font-size: x-large;
  display: inline-block;
}
.checkBoxTableStyle {
  border: 1px solid #c5b6b6;
  width: 100%;
  margin: 5px;
}
.checkBoxTrOptions {
  color: rgb(155, 150, 150);
  font: '14px/20px "Microsoft Yahei","微软雅黑","SimSun","宋体","Arial Narrow",HELVETICA';
  font-size: '20px';
}
.checkBoxMargin {
  margin: 0 auto;
}
</style>
