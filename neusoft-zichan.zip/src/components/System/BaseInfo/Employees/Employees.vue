<!--张文艺-->
<style scoped>
  .cust_row_r{
    position: absolute;
    top:0;
    right: 20px;
    z-index:1;
    width: 315px;
    border: none;
  }
  .cust_btn_box {
    box-shadow: -2px 3px 6px #666;
    padding: 0!important;
  }
  .cust_btn_r{
    background: #fff;
    border-radius: 50%;
    box-shadow: 2px 2px 5px #999;
    position: absolute;
    top: 50%;
    right: 0;
    margin-top: -18px;
  }
  .moveR-enter-active {
    animation: moveR-in .5s;
  }
  .moveR-leave-active {
    animation: moveR-in .5s reverse;
  }
  @keyframes moveR-in {
    0% {
      transform: translate(250px, 0px);
    }
    80% {
      transform: translate(-40px, 0px);
    }
    100% {
      transform: translate(0px, 0px);
    }
  }
</style>
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :span="24" style="padding: 0 0">
        <_BTN_FILTER :isMore="isMore" :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :filterMethod="inputChange" :tableData="tableData"/>
      </el-col>
    </el-row>
    <el-row :gutter="24" class="cust_el_row">
      <el-col :span="6">
        <div class="bg-purple">
          <_TREECOMPONENT :search=searchable :data='treeData' :nodeClick='showTree' :nodeKey="nodeKey"
                          :showCheckBox=showCheckBox :expandAll=expandAll :expandedKey="expandedKey" ref='tree' :highlight='true'
                          :defaultCheckedKeys="defaultCheckedKeys"></_TREECOMPONENT>
        </div>
      </el-col>
      <el-col :span="18">
        <_TABLE ref="tableGrid"
                @update:data="tabChange"
                :reqParams="reqParams"
                stripe
                maxHeight="500"
                :data="dataSource"
                :columns="columnHeader"
                :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
                :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
        ></_TABLE>
      </el-col>
    </el-row>
    <_POPUP :dialogObj='addOrUpdateDialogObj' ref="childs" @confirmBack="addOrUpdateBack"/>
    <_POPUP :dialogObj='queryDialogObj' @confirmBack="queryBack"/>
    <_SESSIONPOPUP :dialogObj='sessionFailDialogObj' @confirmBack="seaaionFailBack"/>
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _POPUP from '@/components/System/BaseInfo/Employees/EmployPopup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import _SESSIONPOPUP from '@/components/Template/Popup/Popup.vue'
  import _TREECOMPONENT from '@/components/Template/Tree/Tree.vue'
  import api from '@/api'
  import log from '@/log'
  import { getUser, getCodeList } from '@/config/info'
  import BasePath from '@/config/BasePath'
  import { convertVal } from '@/utils/common'
  import axios from 'axios'
  export default {
    mounted () {
      /** 调用初始化数据 **/
      getCodeList('YC_SEX', (data) => {
        this.optionsSex = data
      })
      let companyIdParam = {} // 分公司
      companyIdParam.orgRoleTypId = '203'
//      companyIdParam.orgUnitId = getUser().countyId
      companyIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
      let divisionIdParam = {} // 部门
//      divisionIdParam.orgUnitId = getUser().companyId
      divisionIdParam.orgRoleTypId = '207'
      divisionIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
      divisionIdParam.companyId = getUser().companyId
      let placeParam = {} // 岗位
      placeParam.countyDept = getUser().countyId
      placeParam.fields = {include: 'placeCode,placeName'}
      axios.all([
        api.requestJava('POST', BasePath.SELECT_FACTORYIDGROUP, companyIdParam), // 公司
        api.requestJava('POST', BasePath.SELECT_FACTORYIDGROUP, divisionIdParam), // 部门
        api.requestJava('POST', BasePath.DEPTPLACES_SELECT, placeParam) // 岗位
      ])
        .then(axios.spread((_countyDept, _deptId, _place) => {
          this.options_count_deptParam = _countyDept.data.data
          this.options_deptIdParam = _deptId.data.data
          this.options_placeParam = _place.data.data
          this.addOrUpdateDialogObj.optionscount_dept = this.options_count_deptParam
          this.addOrUpdateDialogObj.optionsDepartment = this.options_deptIdParam
          console.log('options_deptIdParam' + JSON.stringify(this.options_deptIdParam))
        }))
      this.init(getUser().companyId)
      this.treeInit()
    },
    data () {
      return {
        expandedKey: [], // 默认展开的数组
        isTree: false,
        /** 查询更多条件 **/
        isMore: true,
        /** 过滤的字段 **/
        fileName: ['employeeCode', 'employeeName', 'company', 'sex'],
        /** 定义按钮组 **/
        btnGroups: [
          {
            name: '',
            className: 'btn-primary',
            iconName: 'fa-th',
            event: this.isMoreClk
//          },
//          {
//            name: '新增',
//            className: 'btn-info',
//            iconName: 'fa-plus',
//            event: this.addClk
          }
        ],
        /** table **/
        tableType: '4',
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        hasPagination: true,
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'employeeCode', // 列的值
            label: '工号', // 列的显示字段
            columnsProps: {width: '150px', align: 'left'}
          },
          {
            prop: 'employeeName', // 列的值
            label: '姓名', // 列的显示字段
            columnsProps: {width: '100px', align: 'left'}
          },
          {
            prop: 'sex', // 列的值
            label: '性别', // 列的显示字段
            columnsProps: {width: '80px', align: 'left', formatter: this.colFormatter_sex}
          },
          {
            prop: 'countyDept', // 列的值
            label: '分公司', // 列的显示字段
            columnsProps: {width: '150px', align: 'left', formatter: this.colFormatter_count_dept}
          },
          {
            prop: 'deptId', // 列的值
            label: '部门', // 列的显示字段
            columnsProps: {width: '150px', align: 'left', formatter: this.colFormatter_deptId}
          },
          {
            prop: 'place', // 列的值
            label: '主岗位', // 列的显示字段
            columnsProps: {width: '150px', align: 'left', formatter: this.colFormatter_place}
          },
          {
            prop: 'status', // 列的值
            label: '状态', // 列的显示字段
            columnsProps: {width: '80px', align: 'left', formatter: this.colFormatter_status}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 200, type: 'button'},
            cptProperties: [
              {
                label: '修改',
                value: 'modify',
                icon: 'edit',
                size: 'small',
                type: 'warning',
                eventClick: this.modify
              },
              {
                label: '删除',
                value: 'del',
                icon: 'delete',
                size: 'small',
                type: 'danger',
                eventClick: this.del
              }
            ]
          }
        ],
        /** 表格数据 **/
        tableData: [],
        dataSource: [], // 当前页的数据
        optionsSex: [],
        optionsEdubg: [],
        optionsDuty: [],
        treeData: [],
        nodeKey: 'id',
        defaultCheckedKeys: [],
        searchable: true, // 是否带搜索框
        showCheckBox: false, // 是否带复选框
        expandAll: true, // 是否展开所有节点
        /** 批量删除 **/
        sel_all: [],
        addOrUpdateDialogObj: {
          title: '新增人员',
          type: 'addEmployee',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              companyId: '',
              employeeCode: '',
              employeeName: '',
              shortCode: '',
              idcard: '',
              sex: '',
              edubg: '',
              isManager: '',
              status: '',
              duty: '',
              manager: '',
              birthday: '',
              priCnict: '',
              place: '',
              countyDept: '',
              deptId: '',
              qlfs: '',
              placeCat: '',
              placeId: ''
            }
          }
        },
        queryDialogObj: {
          title: '查询',
          dialogVisible: false,
          type: 'query',
          data: {
            form: {
              employeeCode: '',
              emoloyeeName: '',
              sex: ''
            }
          }
        },
        sessionFailDialogObj: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        tempPlace: '',
        companyId: '',
        options_count_deptParam: [],
        options_deptIdParam: [],
        options_placeParam: [],
        options_status: [{value: '1', label: '启用'}, {value: '0', label: '停用'}]
      }
    },
    methods: {
      showTreeClk () {
        this.isTree = !this.isTree
      },
      treeInit () {
        this.treeData = []
        let orgTreeparam = {}
        orgTreeparam.orgrelTypeId = 2
        orgTreeparam.treeRoot = getUser().companyId
        api.requestJava('POST', BasePath.ORGUNIT_TREE, orgTreeparam, {})
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.expandedKey = request.data.data.id
              let cityTreeObj = request.data.data
              let treeObj = {}
              this.$set(treeObj, 'id', cityTreeObj.id)
              this.$set(treeObj, 'label', cityTreeObj.label)
              this.$set(treeObj, 'type', 'company')
              let proChildrens = []
              let requestProChildren = request.data.data.children
              requestProChildren.forEach((data, key) => {
                let provinceChildren = {}
                this.$set(provinceChildren, 'id', data.rowId)
                this.$set(provinceChildren, 'label', data.label)
                this.$set(provinceChildren, 'type', 'country')
                proChildrens.push(provinceChildren)
              })
              treeObj.children = proChildrens
              this.treeData.push(treeObj)
              this.queryData(this.currentPage, this.pageSize)
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      init (companyId) {
        this.companyId = getUser().companyId
        let params = {}
        params.companyId = companyId
        params.fields = {'include': 'countyDept,employeeCode,employeeName,rowId,companyId,shortCode,idcard,sex,edubg,isManager,status,duty,manager,birthday,priCnict,place,countyDept,deptId,qlfs,placeCat'}
        params.pageSize = this.pageSize
        params.pageNum = 1
//        params.status = 1
        this.reqParams.url = BasePath.EMPLOYEE_SELECT
        this.reqParams.params = params
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (request.data.data.length > 0) {
                this.tableData = request.data.data
              } else {
                this.tableData = []
              }
              this.totalCount = +request.data.count
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.sessionFailDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      initTempTree (params) {
        params.companyId = getUser().companyId
        params.fields = {'include': 'countyDept,employeeCode,employeeName,rowId,companyId,shortCode,idcard,sex,edubg,isManager,status,duty,manager,birthday,priCnict,place,countyDept,deptId,qlfs,placeCat'}
        params.pageSize = this.pageSize
        params.pageNum = 1
//        params.status = 1
        this.reqParams.url = BasePath.EMPLOYEE_SELECT
        this.reqParams.params = params
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (request.data.data.length > 0) {
                this.tableData = request.data.data
              } else {
                this.tableData = []
              }
              this.totalCount = +request.data.count
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.sessionFailDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      addClk () {
        this.clearObjct()
//        this.addOrUpdateDialogObj.optionscount_dept = this.options_count_deptParam
//        this.addOrUpdateDialogObj.optionsDepartment = this.options_deptIdParam
        this.addOrUpdateDialogObj.title = '新增人员'
        this.addOrUpdateDialogObj.dialogVisible = true
//        alert(JSON.stringify(this.addOrUpdateDialogObj.optionscount_dept))
//        alert(JSON.stringify(this.addOrUpdateDialogObj.optionsDepartment))
      },
      modify (index, row) {
        this.tempPlace = row.place
        Object.assign(this.addOrUpdateDialogObj.data.form, row)
        this.addOrUpdateDialogObj.data.form.isManager = (Number(row.isManager) === 1)
        this.addOrUpdateDialogObj.data.form.status = (Number(row.status) === 1)
        this.$refs.childs.onChange()
        this.$refs.childs.onChangePlace()
        this.addOrUpdateDialogObj.data.form.countyDept = row.countyDept
        /* TODO 公司和部门替换为字典 */
        this.addOrUpdateDialogObj.data.form.company = ''
        this.addOrUpdateDialogObj.data.form.department = ''
        this.addOrUpdateDialogObj.title = '修改人员'
        this.addOrUpdateDialogObj.dialogVisible = true
      },
      addOrUpdateBack (msg) {
        if (msg === false) {
          this.clearObjct()
        } else {
          let rowId = msg.data.form.rowId
          if (rowId === '') {
            this.add(msg)
          } else {
            this.update(msg)
          }
        }
      },
      del (index, row) {
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let params = {}
          params.employeeId = row.rowId
          api.requestJava('POST', BasePath.EMPPLACES_DELETE, params)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                let employeeParams = {}
                employeeParams.rowId = row.rowId
                api.requestJava('POST', BasePath.EMPLOYEE_DELETE, employeeParams)
                  .then((request) => {
                    if (Number(request.data.code) === 200) {
                      this.init(this.companyId)
                      this.$message({type: 'success', message: '删除成功!'})
                    } else if (Number(request.data.code) === 401) {
                      this.sessionFailDialogObj.dialogVisible = true
                    } else {
                      throw new Error(JSON.stringify(request))
                    }
                  })
              } else if (Number(request.data.code) === 401) {
                this.sessionFailDialogObj.dialogVisible = true
              } else {
                throw new Error(JSON.stringify(request))
              }
            })
        }).catch(() => {
          this.$message({type: 'info', message: '已取消删除!'})
        })
      },  // 删除
      batchDelClk () {
        if (this.sel_all.length > 0) {
          this.$confirm('确定要批量删除吗？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            api.requestJava('POST', BasePath.EMPLOYEE_DELETEBATCH, this.sel_all)
              .then((request) => {
                if (Number(request.data.code) === 200) {
                  this.init(this.companyId)
                  this.$message({type: 'success', message: '删除成功!'})
                } else if (Number(request.data.code) === 401) {
                  this.sessionFailDialogObj.dialogVisible = true
                } else {
                  throw new Error(JSON.stringify(request))
                }
              })
          }).catch(() => {
            this.$message({type: 'info', message: '已取消删除!'})
          })
        }
      },  // 批量删除
      clearObjct () {
        let addOrUpdateDialogObjTemp = {
          title: '新增人员',
          type: 'addEmployee',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              company: '',
              department: '',
              employeeCode: '',
              employeeName: '',
              shortCode: '',
              idcard: '',
              sex: '',
              edubg: '',
              isManager: '',
              status: '',
              duty: '',
              manager: '',
              priCnict: '',
              birthday: '',
              place: '',
              countyDept: '',
              deptId: '',
              qlfs: '',
              placeCat: ''
            }
          }
        }
        let queryDialogObjTemp = {
          title: '查询',
          dialogVisible: false,
          type: 'query',
          data: {
            form: {
              employeeCode: '',
              employeeName: '',
              sex: ''
            }
          }
        }
        Object.assign(this.addOrUpdateDialogObj, addOrUpdateDialogObjTemp)
        Object.assign(this.queryDialogObj, queryDialogObjTemp)
      },
      showTree (data) {
        this.companyId = data.id
        let param = {}
        if (data.type === 'country') {
          param.countyDept = data.id
        }
        this.initTempTree(param)
      },
      sortChange (msg) {},
      rowClick (msg) {},
      add (msg) {
        let data = msg.data.form
        let paraminfo = data
        if (data.isManager === true) {
          paraminfo.isManager = '1'
        } else {
          paraminfo.isManager = '0'
        }
        if (data.status === true) {
          paraminfo.status = '1'
        } else {
          paraminfo.status = '0'
        }
        paraminfo.companyId = getUser().companyId
        api.requestJava('POST', BasePath.EMPLOYEE_INSERT, paraminfo)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              let placeParam = {}
              placeParam.orgId = paraminfo.deptId
              placeParam.placeId = paraminfo.placeId
              placeParam.placeCode = paraminfo.place
              placeParam.employeeId = request.data.data
              placeParam.isMainpost = 'Y'
              placeParam.status = '1'
              this.inserPlace(placeParam)
              this.init(this.companyId)
              this.clearObjct()
              this.$message({type: 'success', message: '新增成功!'})
            } else if (Number(request.data.code) === 401) {
              this.sessionFailDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      inserPlace (param) {
        api.requestJava('POST', BasePath.EMPPLACES_INSERT, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
            } else if (Number(request.data.code) === 401) {
              this.sessionFailDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      isMoreClk () {
        this.queryDialogObj.dialogVisible = true
      },
      update (msg) {
        let data = msg.data.form
        let paraminfo = data
        if (data.isManager === true) {
          paraminfo.isManager = '1'
        } else {
          paraminfo.isManager = '0'
        }
        if (data.status === true) {
          paraminfo.status = '1'
        } else {
          paraminfo.status = '0'
        }
        paraminfo.companyId = getUser.companyId
        api.requestJava('POST', BasePath.EMPLOYEE_UPDATE, paraminfo)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (Number(this.tempPlace) !== Number(paraminfo.place)) {
                let placeParam = {}
                placeParam.orgId = paraminfo.deptId
                placeParam.placeId = paraminfo.placeId
                placeParam.placeCode = paraminfo.place
                placeParam.employeeId = paraminfo.rowId
                placeParam.isMainpost = 'Y'
                placeParam.status = '1'
                this.inserPlace(placeParam)
              }
              this.init(this.companyId)
              this.clearObjct()
              this.$message({type: 'success', message: '修改成功!'})
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      queryBack (msg) {
        if (msg === false) {
          this.clearObjct()
        } else {
          let paraminfo = msg.data.form
//          paraminfo.status = 1
          api.requestJava('POST', BasePath.EMPLOYEE_SELECT, paraminfo)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.tableData = request.data.data
                this.queryData(this.currentPage, this.pageSize)
                this.clearObjct()
              } else if (Number(request.data.code) === 401) {
                this.sessionFailedDialogObj.dialogVisible = true
              } else {
                throw new Error(JSON.stringify(request))
              }
            })
            .catch((err) => {
              this.$store.commit('TOGGLE_LOADING')
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        }
      }, // 多条件查询
      seaaionFailBack (msg) {
        let headers = msg.data.form
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.sessionFailedDialogObj.dialogVisible = false
            }
          })
          .catch((err) => { console.log(err) })
      }, // 会话失效
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      headerClick (column, event) {},
      colFormatter_sex (row, column) {
        return convertVal(this.optionsSex, row.sex, 'value', 'label')
      },
      colFormatter_count_dept (row, column) {
        return convertVal(this.options_count_deptParam, row.countyDept, 'orgUnitId', 'orgRoleNm')
      },
      colFormatter_deptId (row, column) {
        return convertVal(this.options_deptIdParam, row.deptId, 'orgUnitId', 'orgRoleNm')
      },
      colFormatter_place (row, column) {
        return convertVal(this.options_placeParam, row.place, 'placeCode', 'placeName')
      },
      colFormatter_status (row, column) {
        return convertVal(this.options_status, row.status, 'value', 'label')
      }
    },
    components: {
      _TABLE,
      _POPUP,
      _BTN_FILTER,
      _SESSIONPOPUP,
      _TREECOMPONENT
    }
  }
</script>
<style scoped>
  .box{
    width:100%
  }
  .tree{
    width:25%;
    float:left
  }
  .table{
    width:75%;
    float:right
  }
</style>
