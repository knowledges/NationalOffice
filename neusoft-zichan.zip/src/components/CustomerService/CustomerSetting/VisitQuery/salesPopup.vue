<!-- 徐晓菁 -->
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-form-item label="规格名称">
        <el-input v-model="dialogObj.data.form.productName"></el-input>
      </el-form-item>
      <el-form-item label="销售时点">
        <el-input v-model="dialogObj.data.form.saleTime"></el-input>
      </el-form-item>
      <el-form-item label="销售单位">
        <el-input v-model="dialogObj.data.form.unit"></el-input>
      </el-form-item>
      <el-form-item label="销售数量">
        <el-input v-model="dialogObj.data.form.quantity"></el-input>
      </el-form-item>
      <el-form-item label="实际销售总价">
        <el-input v-model="dialogObj.data.form.amount"></el-input>
      </el-form-item>
      <el-form-item label="备注"  >
        <el-input type="textarea" resize="notes" v-model="dialogObj.data.form.notes"></el-input>
      </el-form-item>
      <!--<el-form-item label="文件上传">-->
        <!--<uploadTemp style="margin:7px;" :files="dialogObj.data.form.files" ref="uploadPic"></uploadTemp>-->
      <!--</el-form-item>-->
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
    </div>
  </el-dialog>

</template>

<script>
  export default {
    props: ['dialogObj'],
    mounted () {
    },
    data () {
      return {
        addrules: {}
//        edit: {
//          title: '查看',
//          type: '3',
//          dialogVisible: false,
//          data: {
//            form: {
//              files: [],
//              rowId: '',
//              companyId: '',
//              stepId: '',
//              formId: '',
//              formCode: '',
//              title: '',
//              visitingRecId: '',
//              planId: '',
//              visitor: '',
//              visitorName: '',
//              customerId: '',
//              cusotmerName: '',
//              startTime: '',
//              endTime: '',
//              positionX: '',
//              positionY: '',
//              serialNo: '',
//              onSchedule: '',
//              clCode: '',
//              clDesc: '',
//              notes: '',
//              status: '',
//              createdBy: '',
//              createdTime: '',
//              lastUpdBy: '',
//              lastUpdTime: '',
//              modificationNum: '',
//              deletedFlag: '',
//              originFlag: '',
//              originApp: '',
//              endDate: '',
//              beginDate: ''
//            }
//          }
//        }
      }
    },
    methods: {
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      }
//      handleClick (row) {
//        this.findByIdUpper(row)
//      },
//      editEve (msg) {
//        if (msg === 'update') {
//        }
//        this.edit.dialogVisible = false
//        let tmp = {
//          title: '查看',
//          type: '3',
//          dialogVisible: false,
//          data: {
//            form: {
//              files: [],
//              rowId: '',
//              companyId: '',
//              stepId: '',
//              formId: '',
//              formCode: '',
//              title: '',
//              visitingRecId: '',
//              planId: '',
//              visitor: '',
//              visitorName: '',
//              customerId: '',
//              cusotmerName: '',
//              startTime: '',
//              endTime: '',
//              positionX: '',
//              positionY: '',
//              serialNo: '',
//              onSchedule: '',
//              clCode: '',
//              clDesc: '',
//              notes: '',
//              status: '',
//              createdBy: '',
//              createdTime: '',
//              lastUpdBy: '',
//              lastUpdTime: '',
//              modificationNum: '',
//              deletedFlag: '',
//              originFlag: '',
//              originApp: '',
//              endDate: '',
//              beginDate: ''
//            }
//          }
//        }
//        Object.assign(this.edit, tmp)
//      }, // 修改事件
//      findByIdUpper (row) {
//        let param = {}
//        param.rowId = row.rowId
//        param.haveAttach = '1'
//        api.requestJava('POST', BasePath.VISITQUERY_STEPSSELECT, param)
//          .then((request) => {
//            if (Number(request.data.code) === 200) {
//              Object.assign(this.edit.data.form, row)
//              this.edit.data.form.steps = request.data.data
//              this.edit.dialogVisible = true
//            } else if (Number(request.data.code) === 401) {
//              this.$message('登录失效')
//              this.logInvalid.dialogVisible = true
//            } else {
//              this.$notify.error({title: '提示', message: request.data.message})
//              throw new Error(JSON.stringify(request))
//            }
//          })
//          .catch((err) => {
//            let culprit = this.$route.name
//            log.work(err, culprit)
//          })
//      } // 查询接口
    },
    components: {
    }
  }
</script>
