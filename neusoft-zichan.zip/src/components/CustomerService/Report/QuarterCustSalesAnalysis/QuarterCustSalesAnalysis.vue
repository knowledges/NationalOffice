<style scoped>
  .el-form-item__label{
    margin: 0px!important;
  }
  .filter_style .el-col-24 {
    height: 36px;
  }
  .el-form-item {
    margin-bottom: 12px;
  }
  .input-group .input-group-addon {
    border-radius: 0;
    border-color: rgba(210, 214, 222, 0.03);
    background-color: #fff;
  }
  .input-group .form-control {
    text-align: center;
    position: relative;
    z-index: 2;
    font-size: 19px;
    width: 100%;
    margin-bottom: 0;
    border-color: rgba(210, 214, 222, 0.03);
  }
</style>
<template>
  <div  class="container-fluid">
    <div>
      <el-row class="filter_style">
        <el-col :gutter="24">
          <el-col :span='12'>
            <div v-if="isSelect">
              <el-form ref="searchForm" :model="searchForm" label-width="120px">
                <el-col :gutter="24">
                  <el-col :span='12'>
                    <div class="form-group">
                      <div class="input-group">
                        <div class="input-group-addon" @click="changeData(-1)"><i class="el-icon-caret-left"></i></div>
                        <input type="text" class="form-control" v-model="planTime">
                        <div class="input-group-addon" @click="changeData(1)"><i class="el-icon-caret-right"></i></div>
                      </div>
                    </div>
                  </el-col>
                  <el-col :span='12'>
                    <el-form-item label="客户服务部">
                      <el-select v-model="searchForm.countyDept" :clearable="true" placeholder="请选择客户服务部" :disabled="searchForm.disabled">
                        <template v-for="item in options_countyDept">
                          <el-option  :key="item.orgUnitId"  :label="item.orgRoleNm" :value="item.orgUnitId"></el-option>
                        </template>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-col>
              </el-form>
            </div>
          </el-col>
          <el-col :span="12" style="padding: 0 0">
            <_BTN_FILTER :isMore="isMore" :btnGroups="btnGroups" :fileName="fileName" :filterMethod="inputChange"
                         @on-click="exportEve" :tableData="tableData"/>
          </el-col>
        </el-col>
      </el-row>
      <tableVue
        ref="tableGrid"
        stripe
        maxHeight="500"
        :data="dataSource"
        :columns="columns"
        @update:data="tabChange" :reqParams="reqParams"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.getPage></tableVue>
      <_POPUP :dialogObj='dialogObj' @confirmBack="confirmBack" v-popupdra-directive="{'show': dialogObj.dialogVisible}"/>
    </div>
  </div>
</template>
<script>
  import tableVue from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import _POPUP from './Popup.vue'
  import {getUser, getCodeList} from '@/config/info'
  import {dateFormat} from '@/utils/dateFormat.js'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import axios from 'axios'
  import log from '@/log'
  import { changeListValueByCode, lastMonth } from '@/utils/common'
  export default {
    mounted () {
      this.cptProperties = [
        {
          label: '预览',
          value: 'modify',
          icon: 'search',
          size: 'small',
          type: 'primary',
          eventClick: this.modify
        }
      ]
      getCodeList('YC_GEO_TYPE', (data) => {
        this.options_geoType = data
      }) // 市场类型
      getCodeList('YC_BUSINESS_TYPE', (data) => {
        this.options_businessType = data
      }) // 零售业态
      getCodeList('YC_OPERATION_SCALE', (data) => {
        this.options_operationScale = data
      }) // 经营规模
      getCodeList('CUSTOMER_GRADE', (data) => {
        this.options_customerGrade = data
        this.changeValueDate.customerGrade.group = data
      }) // 客户级别
      getCodeList('YC_CUST_STATUS', (data) => {
        this.options_stauts = data
      }) // 客户状态
//      this.init()
      let rtlcatIdparams = {}
      rtlcatIdparams.parentId = getUser().personId
      axios.all([
        api.requestJava('POST', BasePath.SELECT_RTLCATIDGROUP, rtlcatIdparams)
      ])
        .then(axios.spread((_rtlcatId) => {
          this.rtlcatIdGroup = JSON.parse(JSON.stringify(_rtlcatId.data.data))
        }))
      let _this = this
      let custMgrParam = {} // 客户经理
      custMgrParam.place = 135
      custMgrParam.county_dept = getUser().companyId
      custMgrParam.fields = {include: 'employeeName,rowId'}
      custMgrParam.status = 1
      let companyIdParam = {}
      companyIdParam.NextTypeId = '203'
      companyIdParam.unitId = getUser().companyId
      companyIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
      console.log(getUser().countyId !== 'null' && Number(getUser().place) === 9999)
      if (getUser().countyId !== 'null' && Number(getUser().place) === 9999 || Number(getUser().place) === 24 || Number(getUser().place) === 135) {
        this.searchForm.countyDept = getUser().countyId
      }
      console.log(JSON.stringify(companyIdParam))
      axios.all([
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, custMgrParam), // 市场经理
        api.requestJava('POST', BasePath.NEXTORGUNIT_SELECT, companyIdParam)
      ])
        .then(axios.spread(function (_custmgrId, _countyDept) {
          _this.options_custmgrId = JSON.parse(JSON.stringify(_custmgrId.data.data))
          _this.options_countyDept = JSON.parse(JSON.stringify(_countyDept.data.data))
        }))
      this.initDate(dateFormat(new Date().getTime(), 'YYYYMMDD'))
    },
    data () {
      return {
        options_countyDept: [],
        dtQuarterId: '',
        dtLastquarterId: '',
        dtCpquarterId: '',
        timeDate: {},
        queryParams: {},
//        custmgrDisable: false,
        isSelect: true,
        isMore: true, // 查询更多条件
        searchForm: {
          periodId: lastMonth('YYYY-MM-DD'),
          custmgrId: '',
          countyDept: ''
        },
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['customerDesc', 'addr', 'customerCode'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '查询',
            className: 'btn-success',
            iconName: 'fa-search',
            event: this.query
          },
          {
            name: '',
            className: 'btn-primary',
            iconName: 'fa-th',
            event: this.isMoreClk
          }
        ],
        /** 弹出层 **/
        dialogObj: {
          title: '筛选条件',
          type: 'query',
          dialogVisible: false,
          data: {
            form: {
              customerGrade: '',
              geoType: '',
              businessType: '',
              operationScale: '',
              rtlcatId: '',
              custmgrId: ''
            }
          }
        },
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        selectSells: [],
        totalCount: 0, // 表格总记录数
        hasPagination: true, // 是否有分页
        columns: [],
        columnsA: [
          { label: '客户名称', prop: 'customerDesc', columnsProps: {width: 300} },
          { label: '经营地址', prop: 'addr', columnsProps: {width: 300} },
          { label: '客户代码', prop: 'customerCode', columnsProps: {width: 200} },
          { label: '客户档级', prop: 'customerGrade', columnsProps: {width: 100, formatter: this.colFormatter_customerGrade} },
          { label: '季度', prop: 'periodName', columnsProps: {width: 150} },
          { label: '状态', prop: 'status', columnsProps: {width: 100, formatter: this.colFormatter_status} },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {type: 'button', textAlign: 'center'},
            cptProperties: [{ label: '撰写', icon: 'edit', value: 'modify', type: 'success', size: 'small', eventClick: this.modify }]
          }
        ],
        columnsB: [
          { label: '客户名称', prop: 'customerDesc', columnsProps: {width: 300} },
          { label: '经营地址', prop: 'addr', columnsProps: {width: 300} },
          { label: '客户代码', prop: 'customerCode', columnsProps: {width: 200} },
          { label: '客户档级', prop: 'customerGrade', columnsProps: {width: 100, formatter: this.colFormatter_customerGrade} },
          { label: '月份', prop: 'periodName', columnsProps: {width: 150} },
          { label: '状态', prop: 'status', columnsProps: {width: 100, formatter: this.colFormatter_status} },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {type: 'button', textAlign: 'center'},
            cptProperties: [{ label: '预览', icon: 'search', value: 'modify', type: 'primary', size: 'small', eventClick: this.modify }]
          }
        ],
        tableData: [],
        tableType: '4',
        planTime: '',
        rtlcatIdGroup: [], // 客户集id
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        sessionFailedDialogObj: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        options_customerGrade: [],
        options_operationScale: [],
        options_businessType: [],
        options_geoType: [],
        options_stauts: [],
        options_custmgrId: [],
        changeValueDate: {
          customerGrade: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          }
        }
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYYMM')
      },  // 时间格式化
      isMoreClk () {
//        this.isSelect = !this.isSelect
        this.dialogObj.dialogVisible = true
      },
      init () {
        let param = {}
        param.companyId = getUser().companyId
        param.objectType = 3
        param.periodId = this.dtQuarterId
        if (getUser().place === '135') { // 客户经理
          this.searchForm.custmgrId = getUser().personId
          param.reportorId = getUser().personId
          this.searchForm.disabled = true
          this.columns = this.columnsA
        } else if (getUser().place === '24') { // 市场经理
          param.marketmgrId = getUser().personId
          param.status = '1'
          this.searchForm.disabled = true
          this.columns = this.columnsB
        } else if (getUser().countyId !== 'null' && Number(getUser().place) === 9999) { // 分公司
          param.countyDept = getUser().countyId
          param.status = '1'
          this.searchForm.disabled = true
          this.columns = this.columnsB
        } else {
          param.status = '1'
          this.columns = this.columnsB
        }
        param.pageSize = this.pageSize
        param.pageNum = 1
        console.log('lllllparam:' + JSON.stringify(param))
        this.queryParams = param
        this.getPage(1, this.pageSize, this.queryParams)
      },
      getPage (page, size) {
        this.currentPage = page
        this.pageSize = size
        this.queryData(this.currentPage, this.pageSize, this.queryParams)
      },
      queryData (page, size, param) {
        param.pageSize = size
        param.pageNum = page
        console.log('queryDataparam:' + JSON.stringify(param))
        this.reqParams.url = BasePath.CUSTSALESANALYSIS_SELECT
        this.reqParams.params = param
        api.requestJava('POST', BasePath.CUSTSALESANALYSIS_SELECT, param, {})
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.dataSource = request.data.data
              this.tableData = request.data.data
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      headerClick () {},
      sortChange (msg) {},
      rowClick (msg) {},
      modify (index, row) {
        this.$router.push({name: 'QuarterCustSalesAnalysisEdit', params: {rowId: row.customerId, status: row.status, dtQuarterId: this.dtQuarterId, dtLastquarterId: this.dtLastquarterId, dtCpquarterId: this.dtCpquarterId, planTime: this.planTime}})
      }, // 修改
      sessionFailedBack (msg) {
        let headers = msg.data.form
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.sessionFailedDialogObj.dialogVisible = false
            }
          })
          .catch((err) => { console.log(err) })
      }, // 会话失效
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      colFormatter_status (row, column) {
        let retStr = ''
        switch (row.status) {
          case '0':
            retStr = '保存'
            break
          case '1':
            retStr = '提交'
            break
          case '9':
            retStr = '作废'
            break
        }
        return retStr
      },
      colFormatter_customerGrade (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },
      toMoreChange (values, type) {
        let result = ''
        for (let i = 0; i < values.length; i++) {
          if (type === 'int') {
            result = result + values[i] + ','
          } else if (type === 'string') {
            result = result + "'" + values[i] + "'" + ','
          }
        }
        if (result.length > 0) {
          result = result.substr(0, result.length - 1)
        }
        // alert(result)
        return result
      },
      confirmBack (msg) {
        let param = {}
        param.objectType = 2
        let data = msg.data.form
        if (data.customerGrade.length > 0) {
          param.customerGrade = this.toMoreChange(data.customerGrade, 'string')
        }
        if (data.geoType.length > 0) {
          param.geoType = this.toMoreChange(data.geoType, 'string')
        }
        if (data.rtlcatId.length > 0) {
          param.rtlcatId = this.toMoreChange(data.rtlcatId, 'int')
        }
        if (data.operationScale.length > 0) {
          param.operationScale = this.toMoreChange(data.operationScale, 'string')
        }
        if (data.businessType.length > 0) {
          param.businessType = this.toMoreChange(data.businessType, 'string')
        }
        if (data.custmgrId.length > 0) {
          param.custmgrId = this.toMoreChange(data.custmgrId, 'int')
        }
        param.companyId = getUser().companyId
        param.objectType = 2
        param.periodId = this.getTime(Date.parse(this.searchForm.periodId))
        if (getUser().place === '135') {
          param.reportorId = getUser().personId
        } else if (getUser().place === '24') {
          param.marketmgrId = getUser().personId
        }
        Object.assign(this.queryParams, param)
        this.getPage(1, this.pageSize, this.queryParams)
      },
      query () {
        let param = {}
        param.companyId = getUser().companyId
        param.objectType = 3
        param.periodId = this.dtQuarterId
        if (getUser().place === '135') { // 客户经理
          this.searchForm.custmgrId = getUser().personId
          param.reportorId = getUser().personId
          this.columns = this.columnsA
        } else if (getUser().place === '24') { // 市场经理
          param.marketmgrId = getUser().personId
          param.status = '1'
          this.columns = this.columnsB
        } else {
          param.status = '1'
        }
        param.countyDept = this.searchForm.countyDept
        param.pageSize = this.pageSize
        param.pageNum = 1
        console.log('lllllparam:' + JSON.stringify(param))
        this.queryParams = param
        this.getPage(1, this.pageSize, this.queryParams)
      },
      changeData (num) {
        var pattern = /(\d{4})(\d{2})(\d{2})/
        if (Number(num) === 1) {
          var date = new Date(this.timeDate.endDt.toString().replace(pattern, '$1-$2-$3'))
          let next = date.setDate(date.getDate() + 1)
          console.log(dateFormat(next, 'YYYYMMDD'))
          this.initDate(dateFormat(next, 'YYYYMMDD'))
        } else {
          var update = new Date(this.timeDate.beginDt.toString().replace(pattern, '$1-$2-$3'))
          let up = update.setDate(update.getDate() - 1)
          this.initDate(dateFormat(up, 'YYYYMMDD'))
        }
      },
      initDate (time) {
        let params = {}
        params.whereClause = ` and ( '${time}' BETWEEN begin_Dt and end_Dt)`
        console.log('params::: ' + JSON.stringify(params))
        api.requestJava('POST', BasePath.REGIONALSALES_QUARTER_SELECTLIST, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.timeDate = request.data.data
              this.planTime = this.timeDate.dtQuarterNm
              this.dtQuarterId = this.timeDate.dtQuarterId
              this.dtLastquarterId = this.timeDate.dtLastquarterId
              this.dtCpquarterId = this.timeDate.dtCpquarterId
              this.init()
              console.log('季度:' + JSON.stringify(request.data.data))
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }
    },
    components: {
      tableVue,
      _BTN_FILTER,
      _POPUP
    },
    watch: {
      '$route' (val, old) {
        if (val.params.rowId !== old.params.rowId) {
          this.initDate(dateFormat(new Date().getTime(), 'YYYYMMDD'))
        }
      }
    }
  }
</script>
