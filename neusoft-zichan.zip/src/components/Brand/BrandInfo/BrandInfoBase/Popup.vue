<!-- 徐晓菁 -->
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false"  :close-on-press-escape="false" :before-close="cancleClk"  :size='dialogObj.size'>
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="120px">
      <el-collapse>
        <el-collapse-item title="识别信息" name="1">
          <div>
            <el-col :gutter="24">
              <el-col :span='8'>
                <el-form-item label="品牌" >
                  <el-select v-model="dialogObj.data.form.brandId" :clearable="true" placeholder="请选择品牌">
                    <template v-for="item in dialogObj.data.form.brandIdGroup">
                      <el-option  :key="item.rowId"  :label="item.brandDesc" :value="item.rowId"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
              <el-form-item label="厂家">
                <el-select v-model="dialogObj.data.form.factoryId" :clearable="true" placeholder="请选择厂家">
                  <template v-for="item in factoryIdGroup">
                    <el-option  :key="item.orgUnitId"  :label="item.orgRoleNm" :value="item.orgUnitId"></el-option>
                  </template>
                </el-select>
              </el-form-item>
                </el-col>
              <el-col :span='8'>
                <el-form-item label="引入时间">
                  <el-input  v-model="dialogObj.data.form.impDate"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
            <el-col :gutter="24">
              <el-col :span='8'>
                <el-form-item label="卷烟代码">
                  <el-input  v-model="dialogObj.data.form.goodsCode"></el-input>
                </el-form-item>
                </el-col>
              <el-col :span='8'>
                <el-form-item label="卷烟名称">
                  <el-input  v-model="dialogObj.data.form.goodsDesc"></el-input>
                </el-form-item>
                </el-col>
              <el-col :span='8'>
                <el-form-item label="标准名称">
                  <el-input  v-model="dialogObj.data.form.stdName"></el-input>
                </el-form-item>
              </el-col>
              </el-col>
            <el-col :gutter="24">
              <el-col :span='8'>
            <el-form-item label="简码">
              <el-input  v-model="dialogObj.data.form.shortCode"></el-input>
            </el-form-item>
              </el-col>
              <el-col :span='8'>
            <el-form-item label="简称">
              <el-input v-model="dialogObj.data.form.shortName"></el-input>
            </el-form-item>
              </el-col>
            </el-col>
          </div>
        </el-collapse-item>
        <el-collapse-item title="类别信息" name="2">
          <div>
            <el-col :gutter="24">
              <el-col :span='8'>
            <el-form-item label="卷烟级别">
              <el-select v-model="dialogObj.data.form.goodsGrade" :clearable="true" placeholder="请选择卷烟级别">
                <template v-for="item in dialogObj.data.form.goodsGradeGroup">
                  <el-option  :key="item.rowId"  :label="item.gradeDesc" :value="item.rowId"></el-option>
                </template>
              </el-select>
            </el-form-item>
              </el-col>
              <el-col :span='8'>
              <el-form-item label="是否省内烟">
                <el-switch on-text="" off-text="" v-model="dialogObj.data.form.isInprovince"></el-switch>
              </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="是否罚没烟">
                  <el-switch on-text="" off-text="" v-model="dialogObj.data.form.isConfiscated"></el-switch>
                </el-form-item>
              </el-col>
            </el-col>
            <el-col :gutter="24">
              <el-col :span='8'>
                <el-form-item label="省份">
                  <el-select v-model="dialogObj.data.form.provinceId" :clearable="true" placeholder="请选择省份">
                    <template v-for="item in provinceIdGroup">
                      <el-option  :key="item.countryId"  :label="item.regionName" :value="item.countryId"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="包装规格">
                  <el-input  v-model="dialogObj.data.form.packageSpec"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="烟型">
                  <el-select v-model="dialogObj.data.form.cigaretteType" :clearable="true" placeholder="请选择烟型">
                    <template v-for="item in cigaretteTypeGroup">
                      <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
            <el-col :gutter="24">
              <el-col :span='8'>
                <el-form-item label="是否低档烟">
                  <el-switch on-text="" off-text="" v-model="dialogObj.data.form.isOther"></el-switch>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="是否启用">
                  <el-switch on-text="" off-text="" v-model="dialogObj.data.form.status"></el-switch>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="是否低焦油">
                  <el-switch on-text="" off-text="" v-model="dialogObj.data.form.isLowTar"></el-switch>
                </el-form-item>
                </el-col>
              </el-col>
          </div>
        </el-collapse-item>
        <el-collapse-item title="包装信息" name="3">
          <div>
            <el-col :gutter="24">
              <el-col :span='8'>
                <el-form-item label="包装模块">
                  <el-select v-model="dialogObj.data.form.pcktmpId" :clearable="true" placeholder="请选择包装模块">
                    <template v-for="item in pcktmpIdGroup">
                      <el-option  :key="item.rowId"  :label="item.packageName" :value="item.rowId"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
                </el-col>
              </el-col>
            <el-table :data="this.dialogObj.data.form.packageMx"  >
              <el-table-column prop="grade" label="包装级别" ></el-table-column>
              <el-table-column prop="unit" label="单位" ></el-table-column>
              <el-table-column prop="quantity" label="数量"></el-table-column>
              <el-table-column prop="barcode" label="条形码" ></el-table-column>
              <el-table-column prop="isdefault" label="缺省包装" width="120"></el-table-column>
              <el-table-column prop="status" label="是否启用"></el-table-column>
            </el-table>
          </div>
        </el-collapse-item>
        <el-collapse-item title="详细信息" name="4">
          <div>
            <el-col :gutter="24">
              <el-col :span='8'>
                <el-form-item label="主体颜色">
                  <el-input  v-model="dialogObj.data.form.color1"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="滤嘴颜色">
                  <el-input v-model="dialogObj.data.form.color2"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="总长度（毫米）">
                  <el-input  v-model="dialogObj.data.form.totalLen"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
            <el-col :gutter="24">
              <el-col :span='8'>
                <el-form-item label="烟支长度（毫米）">
                  <el-input  v-model="dialogObj.data.form.cigaretteLen"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="滤嘴长度（毫米）">
                  <el-input  v-model="dialogObj.data.form.snipeLen"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="周长（毫米）">
                  <el-input v-model="dialogObj.data.form.cigaretteGirth"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
            <el-col :gutter="24">
              <el-col :span='8'>
                <el-form-item label="焦油含量（毫克）">
                  <el-input  v-model="dialogObj.data.form.tarScalar"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="烟气烟碱量（毫克）">
                  <el-input  v-model="dialogObj.data.form.nicotineScalar"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="烟气一氧化碳量（毫克）">
                  <el-input  v-model="dialogObj.data.form.monoxide"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </div>
        </el-collapse-item>
      </el-collapse>
          </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import api from '@/api'
  import axios from 'axios'
  import BasePath from '@/config/BasePath'
  import {getCodeList} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      getCodeList('CIGARETTE_TYPE', (data) => {
        this.cigaretteTypeGroup = data
      }) // 烟型
      axios.all([
        api.requestJava('POST', BasePath.SELECT_FACTORYIDGROUP, {'orgRoleTypId': '40'}),
        api.requestJava('POST', BasePath.SELECT_PROVINCEIDGROUP, {'level': '1'}),
        api.requestJava('POST', BasePath.SELECT_PCKTMPIDGROUP, {'status': '1'})
      ])
      .then(axios.spread((scend, three, four) => {
        this.factoryIdGroup = JSON.parse(JSON.stringify(scend.data.data))
        this.provinceIdGroup = JSON.parse(JSON.stringify(three.data.data))
        this.pcktmpIdGroup = JSON.parse(JSON.stringify(four.data.data))
      }))
    },
    data () {
      return {
        brandIdGroup: [], // 品牌
        factoryIdGroup: [], // 厂家
        provinceIdGroup: [], // 省份
        pcktmpIdGroup: [], // 包装模板
        goodsGradeGroup: [], // 卷烟级别
        cigaretteTypeGroup: [], // 烟型
        addrules: {}
      }
    },
    methods: {
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      }
    }
  }
</script>


