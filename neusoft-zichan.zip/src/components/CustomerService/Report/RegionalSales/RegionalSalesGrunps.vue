<!-- 徐晓菁 -->
<style scoped rel="stylesheet/scss" lang="scss">
  .editDiv{
  }
  .buttonDiv{
    width: 50%;
  }
  .form-group {
    width: 100%;
    align-content: left;
  }
  .form-group-title {
    margin: auto;
    width: 100%;
    align-content: center;
    text-align: center;
  }
  .input-group-title {
    position: relative;
    display: table;
    border-collapse: separate;
    margin: auto;
    padding-bottom: 14px;
  }
  .sfc-div {
    float: left;
  }
  .notice {
    font-size: medium;
    color: red;
    padding-left: 14px;
    padding-top: 11px;
  }
  .input-group .input-group-addon {
    border-radius: 0;
    border-color: rgba(210, 214, 222, 0.03);
    background-color: #fff;
  }
  .input-group .form-control {
    text-align: center;
    position: relative;
    z-index: 2;
    font-size: 19px;
    width: 100%;
    margin-bottom: 0;
    border-color: rgba(210, 214, 222, 0.03);
  }
</style>
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk" :size='dialogObj.size'>
      <el-row  v-if="dialogObj.type == 2">
        <el-col :span="8">
          <el-button-group>
            <el-button  type="success"  @click="updateClk('addForm')" ><i  class="fa fa-save"></i>&nbsp;保存</el-button>
            <el-button  type="success"  @click="upClk('addForm')" ><i  class="fa fa-cloud-upload"></i>&nbsp;提交</el-button>
            <el-button    @click="cancleClk('addForm')" ><i  class="fa fa-remove"></i>&nbsp;取 消</el-button>
          </el-button-group>
        </el-col>
        <el-col :span="7">
          <div class="form-group">
            <div class="input-group">
              <div class="input-group-addon" @click="changeData(-1)"><i class="el-icon-caret-left"></i></div>
              <input type="text" class="form-control" v-model="planTime">
              <div class="input-group-addon" @click="changeData(1)"><i class="el-icon-caret-right"></i></div>
            </div>
          </div>
        </el-col>
        <el-col :span='9'>
          <div class="form-group">
            <div class="input-group">
              <p class="notice">{{ totalNum }}</p>
            </div>
          </div>
        </el-col>
      </el-row>
      <el-row  v-if="dialogObj.type == 1">
        <el-col :span='24'>
          <div class="form-group-title">
            <div class="input-group-title">
              <h1>{{ dialogObj.data.form.title }}</h1>
            </div>
          </div>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <div class="editDiv">
            <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
              <el-collapse>
                <el-collapse-item title="关键指标" name="1">
                <div>
                  <el-table :data="analyticalData1Date" >
                    <el-table-column prop="itemDesc" label="关键指标" sortable></el-table-column>
                    <el-table-column prop="qty1" label="本期" sortable></el-table-column>
                    <el-table-column prop="qty2" label="同期" sortable></el-table-column>
                    <el-table-column prop="qty3" label="同比增长（%）" sortable></el-table-column>
                    <el-table-column prop="qty4" label="上期" sortable></el-table-column>
                    <el-table-column prop="qty5" label="环比增长（%）" sortable></el-table-column>
                  </el-table>
                </div>
                </el-collapse-item>
                <el-collapse-item title="分类别销售分析" name="2">
                <div>
                  <el-table :data="analyticalData2Date" >
                    <el-table-column prop="gradeName" label="分类别销售分析"    sortable ></el-table-column>
                    <el-table-column prop="qty1" label="本期（箱）" sortable></el-table-column>
                    <el-table-column prop="qty2" label="同期（箱）" sortable></el-table-column>
                    <el-table-column prop="qty3" label="同比增长（%）"  sortable></el-table-column>
                    <el-table-column prop="qty4" label="上期（箱）" sortable></el-table-column>
                    <el-table-column prop="qty5" label="环比增长（%）" sortable></el-table-column>
                  </el-table>
                </div>
                </el-collapse-item>
                <el-collapse-item title="分价位销售分析" name="3">
                <div>
                  <el-table :data="analyticalData3Date" >
                    <el-table-column prop="prilvName" label="分价位销售分析"   sortable  ></el-table-column>
                    <el-table-column prop="qty1" label="本期（箱）" sortable></el-table-column>
                    <el-table-column prop="qty2" label="同期（箱）" sortable></el-table-column>
                    <el-table-column prop="qty3" label="同比增长（%）" sortable></el-table-column>
                    <el-table-column prop="qty4" label="上期（箱）" sortable></el-table-column>
                    <el-table-column prop="qty5" label="环比增长（%）" sortable></el-table-column>
                  </el-table>
                </div>
                </el-collapse-item>
                <el-collapse-item title="新品分析" name="4">
                  <div>
                    <el-table :data="analyticalData4Date" >
                      <el-table-column prop="goodsDesc" label="新品分析" sortable ></el-table-column>
                      <!--<el-table-column prop="qty1" label="铺货目标" sortable></el-table-column>-->
                      <el-table-column prop="qty2" label="铺货率（%）"sortable></el-table-column>
                      <el-table-column prop="qty2" label="重购率（%）"sortable></el-table-column>
                    </el-table>
                  </div>
                </el-collapse-item>
                <el-collapse-item title="客户档次变化情况及销售分析" name="5">
                  <div>
                    <el-table :data="analyticalData5Date">
                      <el-table-column prop="customerGrade" label="客户档次" width="150" sortable></el-table-column>
                      <el-table-column label="客户数（户）">
                        <el-table-column prop="qty1" label="本期"  sortable></el-table-column>
                        <el-table-column prop="qty2" label="上期" sortable></el-table-column>
                        <el-table-column prop="qty3" label="增减（%）" sortable></el-table-column>
                      </el-table-column>
                      <el-table-column label="销售情况 （箱）">
                        <el-table-column prop="qty4" label="本期" sortable></el-table-column>
                        <el-table-column prop="qty5" label="上期" sortable></el-table-column>
                        <el-table-column prop="qty6" label="环比增长（%）" sortable></el-table-column>
                      </el-table-column>
                    </el-table>
                  </div>
                </el-collapse-item>
                <el-collapse-item title="总结" name="6">
                  <div>
                    <el-form-item label="简要分析">
                      <el-input type="textarea" resize="none" v-model="dialogObj.data.form.contents.analysis"></el-input>
                    </el-form-item>
                    <el-form-item label="下步措施">
                      <el-input type="textarea" resize="none" v-model="dialogObj.data.form.contents.measure"></el-input>
                    </el-form-item>
                  </div>
                </el-collapse-item>
            </el-collapse>
          </el-form>
          </div>
        </el-col>
      </el-row>
      <div  v-if="dialogObj.type == 1"  slot="footer" class="dialog-footer" style="text-align: right">
        <el-button @click="cancleClk('addForm')">取 消</el-button>
      </div>
    </el-dialog>
</template>

<script>
  import log from '@/log'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import { dateFormat } from '@/utils/dateFormat.js'
  import {getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
//      this.initDate(dateFormat(new Date().getTime(), 'YYYYMMDD'))
    },
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        if (this.dialogObj.type === 2) {
          if (this.dialogObj.data.form.periodId === '') {
            this.initDate(dateFormat(new Date().getTime(), 'YYYY-MM-DD'))
          } else {
            this.initDate(this.dialogObj.data.form.periodId)
          }
        } else {
          this.initDate1(this.dialogObj.data.form.periodId)
        }
      }
    },
    data () {
      return {
        isLoading: true,
        monthText: '111',
        totalNum: '状态：',
        planTime: '',
        addrules: {},
        analyticalData1Date: [],
        analyticalData2Date: [],
        analyticalData3Date: [],
        analyticalData4Date: [],
        analyticalData5Date: [],
        timeDate: {},
        searchForm: {
          startDate: '',
          endDate: '',
          companyId: '',
          creatBy: '',
          objectCd: '',
          upDate: '',
          nextDate: '',
          periodId: ''
        }
      }
    },
    methods: {
      saveUpper () {
        let params = this.edit.data.form.goods
        console.log('params', JSON.stringify(params))
        var url = BasePath.WEEKORDERREPORT_BRANDSAVE
        api.requestJava('POST', url, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              this.query()
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 保存
      handleClick (tab, event) {
        console.log(tab, event)
      },
      changeData (num) {
        if (Number(num) === 1) {
          var date = new Date(Date.parse(this.timeDate.endDate))
          let next = date.setDate(date.getDate() + 1)
          this.initDate(dateFormat(next, 'YYYY-MM-DD'))
        } else {
          var date1 = new Date(Date.parse(this.timeDate.startDate))
          let next1 = date1.setDate(date1.getDate() - 1)
          this.initDate(dateFormat(next1, 'YYYY-MM-DD'))
        }
      },
      initDate (time) {
        let params = {}
        params.periodType = '3'
        params.whereClause = ` and ( '${time}' BETWEEN START_DATE and END_DATE)`
        api.requestJava('POST', BasePath.REGIONALSALES_QUARTER, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.timeDate = request.data.data[0]
              this.planTime = this.timeDate.periodName
              this.searchForm.creatBy = getUser().personId
              this.searchForm.startDate = dateFormat(Date.parse(this.timeDate.startDate), 'YYYYMMDD')
              this.searchForm.endDate = dateFormat(Date.parse(this.timeDate.endDate), 'YYYYMMDD')
              this.searchForm.companyId = getUser().companyId
              this.searchForm.objectCd = getUser().userCode
              var date = new Date(Date.parse(this.timeDate.startDate))
              let nextDate = date.setDate(date.getDate() - 1)
              let upDate = date.setDate(date.getDate() - (Number(this.timeDate.numOfDays) - 1))
              this.searchForm.upDate = dateFormat(upDate, 'YYYYMMDD')
              this.searchForm.nextDate = dateFormat(nextDate, 'YYYYMMDD')
              this.getPeriodsId()
              this.query()
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      initDate1 (time) {
        let params = {}
        params.periodType = '3'
        params.whereClause = ` and ( '${time}' BETWEEN START_DATE and END_DATE)`
        api.requestJava('POST', BasePath.REGIONALSALES_QUARTER, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.timeDate = request.data.data[0]
              this.planTime = this.timeDate.periodName
              this.searchForm.creatBy = this.dialogObj.data.form.objectId
              this.searchForm.startDate = dateFormat(Date.parse(this.timeDate.startDate), 'YYYYMMDD')
              this.searchForm.endDate = dateFormat(Date.parse(this.timeDate.endDate), 'YYYYMMDD')
              this.searchForm.companyId = this.dialogObj.data.form.companyId
              this.searchForm.objectCd = this.dialogObj.data.form.objectCd
              var date = new Date(Date.parse(this.timeDate.startDate))
              let nextDate = date.setDate(date.getDate() - 1)
              let upDate = date.setDate(date.getDate() - (Number(this.timeDate.numOfDays) - 1))
              this.searchForm.upDate = dateFormat(upDate, 'YYYYMMDD')
              this.searchForm.nextDate = dateFormat(nextDate, 'YYYYMMDD')
              this.getPeriodsId()
              this.query()
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      getPeriodsId () {
        let params = {}
        params.beginDt = this.searchForm.startDate
        params.endDt = this.searchForm.endDate
        console.log('searchForm', JSON.stringify(params))
        api.requestJava('POST', BasePath.REGIONALSALES_QUARTER_SELECTLIST, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.searchForm.periodId = request.data.data.dtQuarterCd
              this.analyticalData1()
              this.analyticalData2()
              this.analyticalData3()
              this.analyticalData4()
              this.analyticalData5()
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      analyticalData1 () {
        let params = this.searchForm
        console.log('searchForm', JSON.stringify(params))
        api.requestJava('POST', BasePath.REGIONALSALES_ANALYTICALDATA1_KEY, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (request.data.data !== '') {
                this.analyticalData1Date = request.data.data
              }
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      analyticalData2 () {
        let params = this.searchForm
        api.requestJava('POST', BasePath.REGIONALSALES_ANALYTICALDATA2_CATEGORY, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (request.data.data !== '') {
                this.analyticalData2Date = request.data.data
              }
              console.log('this.analyticalData2Date', this.analyticalData2Date)
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      analyticalData3 () {
        let params = this.searchForm
        api.requestJava('POST', BasePath.REGIONALSALES_ANALYTICALDATA3_PRICE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (request.data.data !== '') {
                this.analyticalData3Date = request.data.data
              }
              console.log('this.analyticalData3Date', this.analyticalData3Date)
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      analyticalData4 () {
        let params = this.searchForm
        api.requestJava('POST', BasePath.REGIONALSALES_ANALYTICALDATA4_NEWPRODUCTS, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (request.data.data !== '') {
                this.analyticalData4Date = request.data.data
              }
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      analyticalData5 () {
        let params = this.searchForm
        console.log('analyticalData5', JSON.stringify(params))
        api.requestJava('POST', BasePath.REGIONALSALES_ANALYTICALDATA5_SALES, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (request.data.data !== '') {
                this.analyticalData5Date = request.data.data
              }
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      },
      getNowTime () {
        return dateFormat(new Date().getTime(), 'YYYY-MM-DD')
      },  // 时间格式化
      updateClk (formName) {
        if (Number(this.dialogObj.data.form.status) === 1) {
          this.$message({type: 'info', message: '该记录已提交，不可修改!'})
          return
        }
        this.isLoading = true
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      upClk (formName) {
        if (Number(this.dialogObj.data.form.status) === 1) {
          this.$message({type: 'info', message: '该记录已提交，不可修改!'})
          return
        }
        this.isLoading = true
        this.dialogObj.data.form.status = '1'
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.$emit('confirmBack', 'update')
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      query () {
        let params = {}
        params.objectType = '3'
        params.objectCd = getUser().userCode
        if (this.dialogObj.type === 1) {
          params.objectCd = this.dialogObj.data.form.objectCd
        }
        params.whereClause = 'and (PERIOD_ID BETWEEN ' + this.searchForm.startDate + ' and ' + this.searchForm.startDate + ')'
        this.queryUpper(params)
      }, // 查询方法
      queryUpper (params) {
        api.requestJava('POST', BasePath.WEEKORDERREPORT_SELECT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              let rows = request.data.data
              if (rows.length > 0) {
                this.dialogObj.data.form = request.data.data[0]
                this.dialogObj.data.form.contents = JSON.parse(request.data.data[0].contents)
                if (Number(this.dialogObj.data.form.status) === 0) {
                  this.totalNum = '状态：撰写'
                } else if (Number(this.dialogObj.data.form.status) === 1) {
                  this.totalNum = '状态：提交'
                } else {
                  this.totalNum = '状态：作废'
                }
              } else {
                this.dialogObj.data.form.rowId = ''
                this.dialogObj.data.form.periodId = dateFormat(Date.parse(this.timeDate.startDate), 'YYYYMMDD')
                this.dialogObj.data.form.objectType = '3'
                this.dialogObj.data.form.objectId = getUser().personId
                this.dialogObj.data.form.objectCd = getUser().userCode
                this.dialogObj.data.form.objectNm = getUser().userName
                this.dialogObj.data.form.otherPr = ''
                this.dialogObj.data.form.reportorId = getUser().personId
                this.dialogObj.data.form.reportorNm = getUser().userName
                this.dialogObj.data.form.title = this.timeDate.periodName + getUser().userName + '区域销售分析报告'
                this.dialogObj.data.form.status = '0'
                this.dialogObj.data.form.fbNum = '0'
                this.dialogObj.data.form.cEval = '0.0'
                this.dialogObj.data.form.deptname = getUser().deptName
                this.dialogObj.data.form.periodName = this.timeDate.periodName
                this.dialogObj.data.form.companyId = getUser().companyId
                this.dialogObj.data.form.countyDept = getUser().countyId
                this.dialogObj.data.form.creatBy = getUser().personId
                this.totalNum = '状态：撰写'
                this.dialogObj.data.form.contents = {}
                this.dialogObj.data.form.contents.analysis = ''
                this.dialogObj.data.form.contents.measure = ''
              }
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      } // 查询接口
    }
  }
</script>
