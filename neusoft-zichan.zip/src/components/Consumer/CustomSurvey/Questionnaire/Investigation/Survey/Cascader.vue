<template>
  <li class="li_surveyQuItemBody surveyQu_1">
    <div class="surveyQuItemBody">
      <div class="initLine"></div>
      <div class="quInputCase" style="display: none;">
        <input type="hidden" name="quType" :value="Cascader.inputType" />
        <input type="hidden" name="quId" :value="Cascader.itemCode" />
        <input type="hidden" name="orderById" :value="Cascader.rowId + 1" />
        <input type="hidden" name="saveTag" value="1" />
        <input type="hidden" name="hoverTag" value="0" />
        <input type="hidden" name="isRequired" :value="Cascader.mustFlag" />
        <input type="hidden" name="hv" value="2" />
        <input type="hidden" name="randOrder" value="0" />
        <input type="hidden" name="cellCount" value="0" />
        <div class="quLogicInputCase">
          <input type="hidden" name="quLogicItemNum" value="0" />
        </div>
      </div>
      <div class="surveyQuItem">
        <div class="surveyQuItemContent">
          <div class="quCoTitle">
            <div class="quCoNum">
              {{Cascader.sortNbr}}、
            </div>
            <div class="editAble quCoTitleEdit">
              {{Cascader.title}}<span v-if="Cascader.mustFlag">（此题必答）</span>
            </div>
            <input type="hidden" name="quTitleSaveTag" value="1" />
          </div>
          <div class="quCoItem">
            <template v-if="Cascader.dataList.length <= 0">
              <el-cascader v-model="Object.prototype.toString.call(Cascader.val) !== '[object Array]' ? Cascader.val = [] : Cascader.val"
                           :options="Cascader.option"
                           placeholder="  请选择  "
                           @change='handlChange' change-on-select filterable></el-cascader>
              <!--:props="props"-->
              <!--@active-item-change="handleItemChange"-->
            </template>
            <template v-else>
              <input class="form-control" type="text" disabled="disabled" v-model="Cascader.val">
            </template>
          </div>
        </div>
      </div>
    </div>
  </li>
</template>
<script>
//  import api from '@/api'
//  import BasePath from '@/config/BasePath'
  export default {
    props: ['Cascader', 'header', 'tmpProduct', 'tmpCity'],
    mounted () {
      this.init(this.Cascader.inputType)
    },
    data () {
      return {
        options: [],
        props: {
          label: 'label',
          value: 'value',
          children: 'children'
        }
      }
    },
    methods: {
      init (type) {
        var tmp = []
        if (type === 'city') {
          tmp = this.tmpCity
          console.log('city', this.tmpCity)
        } else if (type === 'goods') {
          tmp = this.tmpProduct
          console.log('product', this.tmpCity)
        }
        this.recursion(tmp, type)
        this.$set(this.Cascader, 'option', tmp)
      },
//      init (type) {
//        let url = ''
//        var params = {}
//        if (type === 'city') {
//          url = BasePath.SELECT_TREELIST
//          params.treeRoot = '86'
//          params.fluzzy = {'in': 'level:1,2'}
//        } else if (type === 'goods') {
//          url = BasePath.COMMODITY_SELECT
//          params.status = 'Y'
//          params.isConfiscated = 'N'
//          params.sorter = 'goods_code'
//        }
//        api.requestJava('POST', url, params, {'headers': this.header})
//          .then((request) => {
//            var tmp = []
//            if (Number(request.data.code) === 200) {
//              if (type === 'city') {
//                tmp = request.data.data.children
//              } else {
//                tmp = request.data.data
//              }
//              this.recursion(tmp, type)
//              this.$set(this.Cascader, 'option', tmp)
//            } else {
//              console.log('获取失败~')
//            }
//          })
//      },
      recursion (arr, type) {
        arr.forEach((item, key) => {
          if (item.children !== undefined && item.children.length > 0) {
            this.recursion(item.children, type)
          }
          let code = ''
          if (type === 'city') {
            code = item.label
            this.$set(item, 'value', code)
          } else if (type === 'goods') {
//            this.$set(item, 'label', item.goodsDesc)
//            this.$set(item, 'value', item.goodsDesc)
            this.$set(item, 'label', item.label)
            this.$set(item, 'value', item.label)
          }
        })
      },
      handleItemChange (val) {
        console.log('handleItemChange', val)
      },
      handlChange (val) {
        console.log('handlChange:', val)
      }
    },
    watch: {
    }
  }
</script>
