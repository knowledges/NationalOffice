<!--张文艺-->
<template>
  <div>
    <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :size='dialogObj.size'>
      <div v-if="dialogObj.type == 'addGoodColl'">
        <el-form :model="dialogObj.data.form" :rules="addCustomerColl" label-width="100px" ref="addCustomerColl">
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="name" label="商品集名称" >
                  <el-input v-model="dialogObj.data.form.name" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="code" label="商品集代码">
                  <el-input v-model="dialogObj.data.form.code" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
        </el-form>
        <div slot="footer" class="dialog-footer" style="text-align: right">
          <el-button @click="resetForm('addCustomerColl')">取 消</el-button>
          <el-button type="primary" @click="submitForm('addCustomerColl')">确 定</el-button>
        </div>
      </div>
      <div v-if="dialogObj.type == 'query'">
        <el-form :model="dialogObj.data.form" label-width="100px" ref="query">
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="tel" label="客户代码" >
                  <el-input v-model="dialogObj.data.form.customerCode" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="phone" label="客户名称">
                  <el-input v-model="dialogObj.data.form.vipGrade" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="tel" label="经营业态" >
                  <el-input v-model="dialogObj.data.form.businessType" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="phone" label="市场类型">
                  <el-input v-model="dialogObj.data.form.geoType" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="tel" label="销售规模" >
                  <el-input v-model="dialogObj.data.form" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='12' >
                <el-form-item prop="phone" label="客户级别">
                  <el-input v-model="dialogObj.data.form.vipGrade" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span='24'>
              <el-col :span='12'>
                <el-form-item  prop="tel" label="订货批次" >
                  <el-input v-model="dialogObj.data.form.orderRate" auto-complete="off" class="inputInline"></el-input>
                </el-form-item>
              </el-col>
            </el-col>
          </el-row>
        </el-form>
        <div slot="footer" class="dialog-footer" style="text-align: right">
          <el-button @click="resetForm('query')">取 消</el-button>
          <el-button type="primary" @click="submitForm('query')">确 定</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  export default {
    props: ['dialogObj'],
    data () {
      return {
        optionsCompany: [],
        dialogVisible: false,
        size: '120px',
        addCustomerColl: {
          name: [{required: true, message: '请输入客户集名称', trigger: 'blur'}],
          code: [{required: true, message: '请输入客户集代码', trigger: 'blur'}],
          shortCd: [{required: true, message: '请输入客户集简码', trigger: 'blur'}],
          shortNm: [{required: true, message: '请输入客户集简称', trigger: 'blur'}],
          companyId: [{required: true, message: '请选择公司', trigger: 'blur'}]
        }
      }
    },
    methods: {
      submitForm (formName) {
        // this._upload_submit()
        this.$refs[formName].validate((valid) => {
          if (valid) {
            // this.$refs.uploadTemp.submitUpload()
            this.dialogObj.dialogVisible = false
            this.$emit('confirmBack', this.dialogObj)
            setTimeout(() => {
              this.$refs[formName].resetFields()
            }, 1000)
          } else {
            return false
          }
        })
      },
      resetForm (formName) {
        this.$refs[formName].resetFields()
        this.$emit('confirmBack', false)
        this.dialogObj.dialogVisible = false
      }
    }
  }
</script>
