<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk"  :size='dialogObj.size' v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <div class="container-fluid_new">
      <div>
        <_TABLE
          ref="table"
          stripe
          maxHeight="500"
          :data="dataSource"
          :columns="columnHeader"
          :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
          :totalCount="totalCount" :hasPagination="hasPagination"
          @selection-change="selectionChange" :setPage=this.queryData ></_TABLE>
      </div>
    </div>
  </el-dialog>
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve" />
  </div>
</template>

<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import MY_POPUP_CONFIG from '@/components/Montior/WarningInfoDeal/Popup.vue'
  import log from '@/log'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {},
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        this.query(1, this.pageSize)
      }
    },
    data () {
      return {
        /** table **/
        columnType: 'selection',
        hasPagination: true,
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [10, 20, 40, 50, 100], // 分页数选择项
        totalCount: 0, // 表格总记录数
        Group: [],
        columnHeader: [
          {
            prop: 'name', // 列的值
            label: '预警项', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'descText', // 列的值
            label: '描述', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'count', // 列的值
            label: '预警数', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 120, type: 'button'},
            cptProperties: [
              {
                label: '查看',
                value: 'query',
                icon: 'search',
                size: 'small',
                type: 'primary',
                eventClick: this.modify
              }
            ]
          }
        ],
        tableData: [
          {
            warningObjName: '南京市下关区兰德烟酒店',
            customerCode: '320107002098',
            desc: '重复IP订货',
            date: '2017-12-14'
          },
          {
            warningObjName: '南京娄成惠烟酒百货店',
            customerCode: '320113010471',
            desc: '最近3个月未订货',
            date: '2017-12-13'
          },
          {
            warningObjName: '豆豆烟酒百货店',
            customerCode: '320113010556',
            desc: '最近6个月未订货',
            date: '2017-12-14'
          },
          {
            warningObjName: '南京市栖霞区燕子矶信誉烟酒店',
            customerCode: '320113010645',
            desc: '超五倍均量',
            date: '2017-12-12'
          },
          {
            warningObjName: '南京张吉勤副食品商店',
            customerCode: '320113031242',
            desc: '重复IP订货',
            date: '2017-12-14'
          },
          {
            warningObjName: '南京市下关区才兰烟酒店',
            customerCode: '320107002862',
            desc: '最近3个月未订货',
            date: '2017-12-13'
          }
        ],
        dataSource: [], // 当前页的数据
        /** filter **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['customerCode', 'customerDesc'],
        isMore: true,
        isSelect: true,
        keyupend: false,   // 输入筛选；true：之前展示；false：之后展示
        templTableData: [], // 临时记录tableDate的值
        btnGroups: [],
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        treeData: [],
        nodeKey: 'id',
        defaultCheckedKeys: [],
        isLoading: true,
        edit: {
          title: '预警明细查看',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              rowId: '',
              cat: '',
              name: '',
              descText: '',
              priority: '',
              checkFlag: '',
              receiverType: '',
              exeMode: '',
              interface: '',
              templateId: '',
              status: ''
            }
          }
        }
        /** 弹出层 **/
      }
    },
    methods: {
      query () {
        let params = {}
        params.status = '1'
        this.queryUpper(params)
      }, // 查询方法
      queryUpper (params) {
        params.companyId = getUser().companyId
        params.empId = getUser().personId
        params.status = 1
//        params.fields = {'include': 'rowId,name,cat,descText,priority,checkFlag,count'}
        /* 将已有的参数赋值给分页参数 */
        api.requestJava('POST', BasePath.WARNINGINFO_RULE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      modify (index, row) {
        this.edit.title = row.name + '预警明细'
        Object.assign(this.edit.data.form, row)
        this.edit.dialogVisible = true
      }, // 修改// 修改
      editEve (msg) {
        this.edit.dialogVisible = false
        let tmp = {
          title: '预警明细查看',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              rowId: '',
              cat: '',
              name: '',
              descText: '',
              priority: '',
              checkFlag: '',
              receiverType: '',
              exeMode: '',
              interface: '',
              templateId: '',
              status: ''
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = this.currentPage
        let size = this.pageSize
        this.dataSource = JSON.parse(val).filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      onendChange (val) {}, // 过滤器修改事件
      select (selection, index) {}, // 选中某1条
      selectAll (data) {}, // 全选
      headerClick (column, event) {},
      sortChange (msg) {},
      rowClick (msg) {},
      selectionChange (rows) {},
      addClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'update')
      },
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      },
      isMoreClk () {
        this.isSelect = !this.isSelect
      }
    },
    components: {
      _TABLE,
      _BTN_FILTER,
      MY_POPUP_CONFIG
    }
  }
</script>
<style scoped>
  .el-select {
    display: inline-block;
    position: relative;
    width: 92%;
  }
  .el-dialog__body {
    color: #48576a;
    font-size: 14px;
  }
  .form-group{
    margin-top: 13px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 12px 11px 0;
    box-sizing: border-box;
  }
  .label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 700;
  }
  .notice {
    font-size: medium;
    color: red;
    padding-left: 14px;
    padding-top: 11px;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-8 {
    height: 46px;
  }
  .el-col-2 {
    height: 61px;
  }
  .el-col-7 {
    height: 16px;
  }
  .el-col-15 {
    height: 61px;
  }
</style>
<style scoped>
  .container-fluid_new {
    background: #FFF;
    margin: 0 5px 5px 5px;
  }
</style>

