<template>
  <div>
    <el-date-picker v-show="row._edit"
       type="date" placeholder="选择日期"
      v-model="dateStr"></el-date-picker>
    <span v-show="!row._edit">{{ text }}</span>
  </div>
</template>

<script>
import { dateFormat } from '@/utils/dateFormat.js'
export default {
  data () {
    return {
      dateStr: ''
    }
  },
  props: {
    row: Object,
    col: Object,
    data: Array
    // KeyDownEvent: {
    //   type: Function,
    //   default: function (ev) {
    //   }
    // }
  },
  mounted () {
  },
  directives: {
    focus: {
      inserted: function (el, {value}) {
        if (value) {
          el.focus()
        }
      }
    }
  },
  methods: {
  },
  watch: {
    dateStr (oldValue, newValue) {
      if (this.row._edit) {
        var date = new Date(this.dateStr)
        if (this.col.dateType === 'unix') {
          // var curDate = this.dateStr.replace(/-/g, '/')
          this.row[this.col.prop] =
          Date.parse(new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds())))
        } else {
          this.row[this.col.prop] =
          date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate()
        }
      }
    }
  },
  computed: {
    text () {
      if (this.col.dateType === 'unix') {
        var unixDate = this.row[this.col.prop]
        this.dateStr = dateFormat(unixDate, 'YYYY-MM-DD') // 'YYYY-MM-DD HH:mm:ss'
        return this.dateStr
      }
      this.dateStr = this.row[this.col.prop]
      return this.dateStr
    }
  }
}
</script>
<style>
@import './tableInput.css';
</style>