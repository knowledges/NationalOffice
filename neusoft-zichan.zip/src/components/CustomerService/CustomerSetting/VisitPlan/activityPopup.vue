<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk"  :size='dialogObj.size' v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <div class="container-fluid_new">
      <el-row class="filter_style">
        <el-col :span="24" style="padding: 0 0">
          <_BTN_FILTER @on-change="inputChange"  :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData"/>
         </el-col>
      </el-row>
      <div>
        <_TABLE
          ref="table"
          stripe
          maxHeight="500"
          :data="dataSource"
          :columns="columnHeader"
          :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
          :totalCount="totalCount" :hasPagination="hasPagination"
          @selection-change="selectionChange" :setPage=this.getPage  ></_TABLE>
      </div>
    </div>
  </el-dialog>
  <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve" />
  </div>
</template>

<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import api from '@/api'
  import log from '@/log'
  import axios from 'axios'
  import { changeListValueByCode } from '@/utils/common'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  import MY_POPUP_CONFIG from '@/components/Brand/BrandActivity/ActivityManagement/Popup.vue'
  export default {
    props: ['dialogObj'],
    mounted () {
      axios.all([
        api.requestJava('POST', BasePath.SELECT_MATTERIDGROUP, {status: '1'})
      ])
      .then(axios.spread((first) => {
        this.matterIdGroup = JSON.parse(JSON.stringify(first.data.data))
      }))
    },
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        this.query(1, this.pageSize)
        axios.all([
          api.requestJava('POST', BasePath.SELECT_MATTERIDGROUP, {status: '1'})
        ])
        .then(axios.spread((first) => {
          this.changeValueDate.matterId.group = JSON.parse(JSON.stringify(first.data.data))
        }))
      }
    },
    data () {
      return {
        /** table **/
        columnType: 'selection',
        hasPagination: true,
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [10, 20, 40, 50, 100], // 分页数选择项
        totalCount: 0, // 表格总记录数
        Group: [],
        moreS: [
          {
            colunm: 'customerGrade',
            type: 'string'
          },
          {
            colunm: 'geoType',
            type: 'string'
          },
          {
            colunm: 'businessType',
            type: 'string'
          },
          {
            colunm: 'routeId',
            type: 'string'
          },
          {
            colunm: 'operationScale',
            type: 'string'
          }
        ],
        changeValueDate: {
          matterId: {
            type: 'text',
            group: [],
            key: 'rowId',
            value: 'matterName'
          }
        },
        columnHeader: [
          {
            prop: 'matterId', // 列的值
            label: '活动事项', // 列的显示字段
            columnsProps: {width: 200, align: 'left', formatter: this.changeValue}
          },
          {
            prop: 'title', // 列的值
            label: '活动标题', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'beginDate',
            label: '活动周期开始',
            columnsProps: {width: 140, align: 'center'}
          },
          {
            prop: 'endDate',
            label: '活动周期结束',
            columnsProps: {width: 140, align: 'center'}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 200, type: 'button'},
            cptProperties: [
              {
                label: '查看',
                value: 'query',
                icon: 'search',
                size: 'small',
                type: 'primary',
                eventClick: this.modify
              }
            ]
          }
        ],
        tableData: [],
        dataSource: [], // 当前页的数据
        /** filter **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['customerCode', 'customerDesc'],
        isMore: true,
        isSelect: true,
        keyupend: false,   // 输入筛选；true：之前展示；false：之后展示
        templTableData: [], // 临时记录tableDate的值
        btnGroups: [],
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        treeData: [],
        nodeKey: 'id',
        defaultCheckedKeys: [],
        isLoading: true,
        edit: {
          title: '活动发起',
          type: '5',
          num: 1,
          disable: true,
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              matterArr: [],
              matterId: '',
              stepIds: '',
              stepId: [],
              unitId: '',
              deptId: '',
              maker: '',
              makerNm: '',
              parentId: '',
              beginDate: '',
              endDate: '',
              fpConds: '',
              title: '',
              notes: '',
              status: '',
              createdBy: '',
              ref: '',
              haveAttach: '',
              files: []
            }
          }
        }
        /** 弹出层 **/
      }
    },
    methods: {
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      editEve (msg) {
        this.edit.dialogVisible = false
        let tmp = {
          title: '活动发起',
          type: '5',
          num: 1,
          disable: true,
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              matterArr: [],
              matterId: '',
              stepIds: '',
              stepId: [],
              unitId: '',
              deptId: '',
              maker: '',
              makerNm: '',
              parentId: '',
              beginDate: '',
              endDate: '',
              fpConds: '',
              title: '',
              notes: '',
              status: '',
              createdBy: '',
              haveAttach: '',
              ref: '',
              files: []
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      modify (index, row) {
        this.findByIdUpper(row)
      }, // 修改
      findByIdUpper (row) {
        let param = {}
        param.rowId = row.rowId
        param.haveAttach = '1'
        api.requestJava('POST', BasePath.ACTIVITY_SELECTONE, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              Object.assign(this.edit.data.form, row)
              this.edit.data.form.files = request.data.data.files
              this.edit.data.form.matterIdGroup = this.matterIdGroup
              if (row.stepIds !== '') {
                let steps = row.stepIds
                this.edit.data.form.stepId = steps.split(',')
              }
              console.log('修改', this.edit.data.form)
              this.edit.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      getPage (page, size) {
        this.currentPage = page
        this.pageSize = size
        this.query(this.currentPage, this.pageSize)
      },
      query_New () {
        this.currentPage = '1'
        this.query(this.currentPage, this.pageSize)
      },
      query (pageNum, pageSize) {
        let param = {}
        param.status = '1'
        param.pageSize = pageSize
        param.pageNum = pageNum
        param.whereClause = ' and   curdate() between begin_date and end_date  and  UNIT_ID in (' + getUser().companyId + ',' + getUser().countyId + ')'
        console.log('param', JSON.stringify(param))
        api.requestJava('POST', BasePath.ACTIVITY_SELECTLIST, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.dataSource = request.data.data
              this.totalCount = Number(request.data.count)
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询方法
      toMoreChange (values, type) {
        let result = ''
        for (let i = 0; i < values.length; i++) {
          if (type === 'int') {
            result = result + values[i] + ','
          } else if (type === 'string') {
            result = result + "'" + values[i] + "'" + ','
          }
        }
        if (result.length > 0) {
          result = result.substr(0, result.length - 1)
        }
        return result
      },
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = this.currentPage
        let size = this.pageSize
        this.dataSource = JSON.parse(val).filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      onendChange (val) {}, // 过滤器修改事件
      select (selection, index) {}, // 选中某1条
      selectAll (data) {}, // 全选
      headerClick (column, event) {},
      sortChange (msg) {},
      rowClick (msg) {},
      selectionChange (rows) {},
      addClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'update')
      },
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      },
      isMoreClk () {
        this.isSelect = !this.isSelect
      }
    },
    components: {
      _TABLE,
      _BTN_FILTER,
      MY_POPUP_CONFIG
    }
  }
</script>
<style scoped>
  .el-dialog__body {
    /* padding: 33px 20px; */
    color: #48576a;
    font-size: 21px;
    height: 536px;
  }
  .container-fluid_new {
    background: #FFF;
    margin: 0 5px 5px 5px;
  }
</style>

