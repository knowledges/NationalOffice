<template>
  <div class="container-fluid" >
    <el-form   label-width="100px" :model="cusAnalyForm" ref="form">
      <el-row :gutter="24">
        <el-col :offset="16" :span="24">
          <el-button type="success" @click="backClk">返回</el-button>
          <el-button type="success" @click="save(0)" :disabled="saveDisabled">保存</el-button>
          <el-button type="success" @click="save(1)" :disabled="saveDisabled">提交</el-button>
          <el-button type="success" @click="getPdf()">下载 PDF</el-button>
        </el-col>
      </el-row>
      <div id="pdfDom">
      <el-row :gutter="24">
        <el-col :span="24 " :offset="4">
          <div class="text-align:center" style="height: 50px">
          <h3 style="padding-left:10px">{{cusAnalyForm.customerDesc}} {{cusAnalyForm.periodYearMonth}}月度卷烟经营分析报告</h3>
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="20" >
        <el-col :span="6"><div style="height: 30px">许可证号：   {{cusAnalyForm.permitNo}}</div></el-col>
        <el-col :span="6"><div>商店名称：  {{cusAnalyForm.customerDesc}}</div></el-col>
        <el-col :span="6"><div>法人：  {{cusAnalyForm.legalPerson}}</div></el-col>
        <el-col :span="6"><div>业态：  {{cusAnalyForm.businessType}}</div></el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="6"><div style="height: 30px">本月档级：   {{cusAnalyForm.customerGrade}}</div></el-col>
        <el-col :span="6"><div>上月档级：   {{cusAnalyForm.customerGrade}}</div></el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="6"><div style="height: 20px">尊敬的    {{cusAnalyForm.customerDesc}}   商户:</div></el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="6"><div style="height: 20px">您好!</div></el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="20"><div style="height: 20px">现把贵店  {{cusAnalyForm.periodId}}  月度卷烟经营情况分析报告如下,不妥之处敬请批评指正。</div></el-col>
      </el-row>
      <el-collapse v-model="activeNames" accordion>
        <el-collapse-item title="一、月度总体卷烟经营情况" name="1">
          <el-table :data="tableData1" style="width: 100%">
            <el-table-column prop="itemdesc" label="月度指标" width="180"></el-table-column>
            <el-table-column prop="qty1" label="当月" width="180"></el-table-column>
            <el-table-column prop="qty2" label="上月"></el-table-column>
            <el-table-column prop="qty3" label="去年同期"></el-table-column>
            <el-table-column prop="qty4" label="同比%"></el-table-column>
          </el-table>
          <el-row :gutter="20">
            <el-col :span="20"><div>当月订货数量{{cusAnalyForm.orderNumMonth}}条，{{cusAnalyForm.orderNumUpOrLow}}平均水平{{cusAnalyForm.orderNumRate}}%，处在本区域同类客户的{{cusAnalyForm.orderNumPosition}}水平;</div></el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="20"><div>当月订货金额{{cusAnalyForm.orderAmtMonth}}元，{{cusAnalyForm.orderAmtUpOrLow}}平均水平{{cusAnalyForm.orderAmtRate}}%，处在本区域同类客户的 {{cusAnalyForm.orderAmtPosition}}水平;</div></el-col>
          </el-row>
        </el-collapse-item>
        <el-collapse-item title="二、当月订购量前5位卷烟情况" name="2">
          <el-table :data="tableData2" style="width: 100%">
            <el-table-column prop="cigProductNm" label="卷烟名称" width="180"></el-table-column>
            <el-table-column prop="qty1" label="订货量" width="180"></el-table-column>
            <el-table-column prop="qty2" label="订货额（元）"></el-table-column>
            <el-table-column prop="qty3" label="排名"></el-table-column>
            <el-table-column prop="qty4" label="占总量比"></el-table-column>
          </el-table>
          <el-row :gutter="20">
            <el-col :span="20"><div>贵店当月主销卷烟规格前5位合计销量   {{cusAnalyForm.qtyTotal}}     条，占总体销量比重   {{cusAnalyForm.qtyProportion}}  %，卷烟销售集中程度 {{cusAnalyForm.qtyPosition}}</div></el-col>
          </el-row>
        </el-collapse-item>
        <el-collapse-item title="三、半年来新品卷烟订购情况" name="3">
          <el-row :gutter="20">
            <el-col :span="8"><div>半年来订购新品规格数：   {{cusAnalyForm.qty6}}</div></el-col>
            <el-col :span="8"><div>半年来订购总规格数：  {{cusAnalyForm.qty7}}</div></el-col>
            <el-col :span="8"><div>半年新品规格数占总规格数比重     ：  {{cusAnalyForm.qty8}}</div></el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="8"><div>半年来新品订购量：   {{cusAnalyForm.qty9}}</div></el-col>
            <el-col :span="8"><div>半年来订购总量：  {{cusAnalyForm.qty10}}</div></el-col>
            <el-col :span="8"><div>半年新品订购量占总量比重：  {{cusAnalyForm.qty11}}</div></el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="20"><div>贵店新品卷烟共销售了  {{cusAnalyForm.qty5}} 条，半年累计订购量  {{cusAnalyForm.qty10}}    条，占总量比重   {{cusAnalyForm.qtyNewRate}}    %，{{cusAnalyForm.qtyNewPosition}}    同档客户平均水平</div></el-col>
          </el-row>
        </el-collapse-item>
        <el-collapse-item title="四、近三月分价位卷烟订货量情况" name="4">
          <el-table :data="tableData3" style="width: 100%">
            <el-table-column prop="cigProductNm" label="价格区间" width="180"></el-table-column>
            <el-table-column prop="qty1" label="当月" width="180"></el-table-column>
            <el-table-column prop="qty2" label="上月"></el-table-column>
            <el-table-column prop="qty3" label="再上月"></el-table-column>
          </el-table>
          <el-row :gutter="20">
            <el-col :span="20"><div>贵店所订购卷烟主要集中在 {{cusAnalyForm.priceRange}} 等价格区间以内，近三月呈现     {{cusAnalyForm.trends}}趋势；</div></el-col>
          </el-row>
        </el-collapse-item>
        <!--<el-collapse-item title="五、当前卷烟经营状况诊断与分析" name="5">-->
        <!--</el-collapse-item>-->
        <el-collapse-item title="五、卷烟经营建议" name="6">
          <el-row :gutter="20">
            <el-col :span="20"><div>针对上述三个方面的分析，为进一步提高贵店经营水平，特提出如下卷烟经营建议</div></el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="6"><div>（一） 客户总体经营方面</div></el-col>
          </el-row>
          <el-row :gutter="20">
              <div>
                <el-input type="textarea"  resize="none" v-model="cusAnalyForm.cust" auto-complete="off" class="inputInline"></el-input>
              </div>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="6"><div>（二） 满足消费者需求方面</div></el-col>
          </el-row>
          <el-row :gutter="20">
            <div>
              <el-input type="textarea" resize="none" v-model="cusAnalyForm.consumer" auto-complete="off" class="inputInline"></el-input>
            </div>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="6"><div>（三） 卷烟品牌销售方面</div></el-col>
          </el-row>
          <el-row :gutter="20">
            <div>
              <el-input type="textarea" resize="none" v-model="cusAnalyForm.prd" auto-complete="off" class="inputInline"></el-input>
            </div>
          </el-row>
        </el-collapse-item>
      </el-collapse>
      <el-row :gutter="20">
        <el-col :span="20"><div style="height: 23px;">尊敬的客户,希望以上分析与建议对您卷烟经营能有所帮助，愿您我双方携手共进，互利共赢！</div></el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="20"><div style="height: 23px;">最后,祝您生意兴隆,家庭幸福,万事如意!</div></el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="20"><div style="text-align: right;"> {{cusAnalyForm.companyNm}} 　　客户经理：{{cusAnalyForm.mgrNm}}</div></el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="20"><div style="text-align: right;"> {{cusAnalyForm.date}}</div></el-col>
      </el-row>
      </div>
    </el-form>
  </div>
</template>
<style>
  .el-collapse-item__header {
    font-size: inherit;
  }
</style>
<style scoped rel="stylesheet/scss" lang="scss">
  h3 {
    font-size: 30px;
  }
  div {
    font-size: 20px!important;
  }
  #pdfDom {
    font-size: 20px;
  }
  /*@import url("//unpkg.com/element-ui@2.0.1/lib/theme-chalk/index.css");*/
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>
<script>
  import _TABLE from '@/components/Template/TabPagin/Table.vue'
  import api from '@/api'
  import log from '@/log'
  import {getUser, getCodeList} from '@/config/info'
  import BasePath from '@/config/BasePath'
  import { dateFormat } from '@/utils/dateFormat.js'
  import { convertVal } from '@/utils/common.js'
  import axios from 'axios'
  export default {
    mounted () {
      getCodeList('YC_BUSINESS_TYPE', (data) => {
        this.group_businessType = data
      }) // 零售业态
      getCodeList('CUSTOMER_GRADE', (data) => {
        this.group_customerGrade = data
      }) // 客户级别
      let custMgrParam = {} // 客户经理
      custMgrParam.place = 135
      custMgrParam.county_dept = getUser().companyId
      custMgrParam.fields = {include: 'employeeName,rowId'}
      custMgrParam.status = 1
      console.log('custMgrParam: ' + JSON.stringify(custMgrParam))
      axios.all([
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, custMgrParam) // 客户经理
      ])
        .then(axios.spread((_custMgr) => {
          this.options_custMgr = _custMgr.data.data
          this.init()
        }))
    },
    data () {
      return {
        activeNames: ['1', '2', '3', '4', '6'],
        _rowId: '',
        rowId: this.$route.params.rowId,
        isSelect: false,
        isMore: true, // 查询更多条件
        activeName: '1',
        isModify: false,
        saveDisabled: false,
        cusAnalyForm: {
          companyId: '',
          customerId: '',
          customerCode: '',
          customerDesc: '',
          periodId: this.$route.params.periodId,
          permitNo: '',
          legalPerson: '',
          businessType: '',
          customerGrade: '',
          companyNm: getUser().companyName,
          periodYearMonth: '',
          mgrNm: getUser().userName,
          orderNumMonth: 0,
          orderNumUpOrLow: '低于',
          orderNumRate: 0,
          orderNumPosition: '下游',
          orderAmtMonth: 0,
          orderAmtUpOrLow: '低于',
          orderAmtRate: 0,
          orderAmtPosition: '下游',
          status: this.$route.params.status
        },
        tableData1: [],
        tableData2: [],
        tableData3: [],
        group_businessType: [],
        group_customerGrade: [],
        options_custMgr: [],
        orderNumMonth: 0,
        orderAmtMonth: 0,
        htmlTitle: ''
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYY年MM月DD日')
      },  // 时间格式化
      init () {
        if (Number(this.$route.params.status) === 1 || Number(getUser().place) !== 135) {
          this.saveDisabled = true
        }
        // 获取客户信息
        let param = {}
        param.rowId = this.rowId

        api.requestJava('POST', BasePath.CUSTOMER_SELECTONE, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.cusAnalyForm = Object.assign({}, this.cusAnalyForm, request.data.data)
              this.cusAnalyForm.companyNm = getUser().companyName
              this.cusAnalyForm.date = this.getTime(Date.parse(new Date()))
              this.cusAnalyForm.periodId = this.$route.params.periodId
              this.cusAnalyForm.periodYearMonth = this.$route.params.periodId.substring(0, 4) + '年' + this.$route.params.periodId.substr(4) + '月'
              this.cusAnalyForm.businessType = convertVal(this.group_businessType, request.data.data.businessType, 'value', 'label')
              this.cusAnalyForm.customerGrade = convertVal(this.group_customerGrade, request.data.data.customerGrade, 'value', 'label')
              this.cusAnalyForm.mgrNm = convertVal(this.options_custMgr, request.data.data.custmgrId, 'rowId', 'employeeName')

              let param = {}
              param.periodId = this.$route.params.periodId
              param.customerCode = this.cusAnalyForm.customerCode
              // 月度总体卷烟经营情况
              this.First(param)
              // 当月订购量前5位卷烟情况
              this.Third(param)
              // 近三月分价位卷烟订货量情况
              this.Fourth(param)
              this.Fifth()
              this.htmlTitle = this.cusAnalyForm.customerDesc + this.cusAnalyForm.periodId + '月度卷烟经营分析报告'
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      First (param) {
        // 月度总体卷烟经营情况
        api.requestJava('POST', BasePath.CUSTSALESANALYSIS_ANAYSIS4, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              let arr = request.data.data
              if (arr.length > 0) {
                this.tableData1 = arr
                arr.forEach((val, key) => {
                  if (val.itemdesc === '订货量') {
                    this.$set(this.cusAnalyForm, 'orderNumMonth', Number(val.qty1))
                  }
                  if (val.itemdesc === '订货额') {
                    this.$set(this.cusAnalyForm, 'orderAmtMonth', Number(val.qty1))
                  }
                })
                this.Second()
              }
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      Second () {
        // 客户经理总体指标分析
        let paramCustMgr = {}
        paramCustMgr.periodId = this.$route.params.periodId
        paramCustMgr.customerCode = this.cusAnalyForm.customerCode
        paramCustMgr.customerGrade = this.cusAnalyForm.customerGrade
        api.requestJava('POST', BasePath.CUSTSALESANALYSIS_ANAYSIS5, paramCustMgr)
          .then(request => {
            if (Number(request.data.code) === 200) {
              let arr5 = request.data.data
              console.log('this.cusAnalyForm:', this.cusAnalyForm)
              if (arr5 !== '') {
                let qty1 = arr5.qty1.replace(/,/gi, '')
                let qty2 = arr5.qty2.replace(/,/gi, '')
                let qty3 = arr5.qty3.replace(/,/gi, '')
                let qty4 = arr5.qty4.replace(/,/gi, '')
                let qty5 = arr5.qty5.replace(/,/gi, '')
                let qty6 = arr5.qty6.replace(/,/gi, '')
                let qty7 = arr5.qty7.replace(/,/gi, '')
                let qty8 = arr5.qty8.replace(/,/gi, '')
                let qty9 = arr5.qty9.replace(/,/gi, '')
                let qty10 = arr5.qty10.replace(/,/gi, '')
                let qty11 = arr5.qty11.replace(/,/gi, '')
                var numRate = (Number(this.cusAnalyForm.orderNumMonth) - Number(qty1)) / Number(qty1)
                this.cusAnalyForm.orderNumRate = numRate.toFixed(1)
                this.$set(this.cusAnalyForm, 'orderNumRate', numRate.toFixed(1))
                console.log(this.cusAnalyForm.orderNumMonth)
                console.log(this.cusAnalyForm.orderNumRate)
                if (Number(qty1) - Number(this.orderNumMonth) > 0) {
                  this.cusAnalyForm.orderNumUpOrLow = '低于'
                } else {
                  this.cusAnalyForm.orderNumUpOrLow = '高于'
                }
                var upNumber = Number(this.orderNumMonth) + Number(this.orderNumMonth) * 0.1
                var lowNumber = Number(this.orderNumMonth) - Number(this.orderNumMonth) * 0.1
                if (Number(upNumber) < qty3) {
                  this.cusAnalyForm.orderNumPosition = '上游'
                } else if (Number(lowNumber) > qty3) {
                  this.cusAnalyForm.orderNumPosition = '下游'
                } else {
                  this.cusAnalyForm.orderNumPosition = '中游'
                }
                var amtRate = (this.cusAnalyForm.orderAmtMonth - Number(qty2)) / Number(qty2)
                this.cusAnalyForm.orderAmtRate = Math.abs(amtRate).toFixed(1)
                if (Number(qty2) - Number(this.orderAmtMonth) > 0) {
                  this.cusAnalyForm.orderAmtUpOrLow = '低于'
                } else {
                  this.cusAnalyForm.orderAmtUpOrLow = '高于'
                }
                var upAmtNumber = Number(this.orderAmtMonth) + Number(this.orderAmtMonth) * 0.1
                var lowAmtNumber = Number(this.orderAmtMonth) - Number(this.orderAmtMonth) * 0.1
                if (Number(upAmtNumber) < qty4) {
                  this.cusAnalyForm.orderAmtPosition = '上游'
                } else if (Number(lowAmtNumber) > qty4) {
                  this.cusAnalyForm.orderAmtPosition = '下游'
                } else {
                  this.cusAnalyForm.orderAmtPosition = '中游'
                }
                // 新品
                this.cusAnalyForm.qty5 = qty5
                this.cusAnalyForm.qty6 = qty6
                this.cusAnalyForm.qty7 = qty7
                this.cusAnalyForm.qty8 = qty8
                this.cusAnalyForm.qty9 = qty9
                this.cusAnalyForm.qty10 = qty10
                this.cusAnalyForm.qty11 = qty11
                var tempNewRate = Number(qty9) / Number(qty10) * 100
                this.cusAnalyForm.qtyNewRate = tempNewRate.toFixed(2)
                let upNewNumber = Number(qty9) + Number(qty9) * 0.1
                let lowNewNumber = Number(qty9) - Number(qty9) * 0.1
                if (Number(upNewNumber) < qty5) {
                  this.cusAnalyForm.qtyNewPosition = '高于'
                } else if (Number(lowNewNumber) > qty5) {
                  this.cusAnalyForm.qtyNewPosition = '低于'
                } else {
                  this.cusAnalyForm.qtyNewPosition = '持平'
                }
              }
            }
          })
      },
      Third (param) {
        // 当月订购量前5位卷烟情况
        api.requestJava('POST', BasePath.CUSTSALESANALYSIS_ANAYSIS6, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              if (request.data.data.length !== 0) {
                var i = 0
                let arr = request.data.data
                if (arr.length > 0) {
                  this.tableData2 = arr
                }
                request.data.data.forEach((e) => {
                  if (i === 5) {
                    this.cusAnalyForm.qtyTotal = request.data.data[i].qty1
                    this.cusAnalyForm.qtyProportion = request.data.data[i].qty4
                    if (request.data.data[i].qty4 > 40 && request.data.data[i].qty4 < 50) {
                      this.cusAnalyForm.qtyPosition = '较高'
                    } else if (request.data.data[i].qty4 > 50) {
                      this.cusAnalyForm.qtyPosition = '高'
                    } else {
                      this.cusAnalyForm.qtyPosition = '正常'
                    }
                  }
                  i++
                })
              }
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      Fourth (param) {
        // 近三月分价位卷烟订货量情况
        api.requestJava('POST', BasePath.CUSTSALESANALYSIS_ANAYSIS7, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              if (request.data.data.length !== 0) {
                this.tableData3 = request.data.data.detailEntities
                this.cusAnalyForm.priceRange = request.data.data.cigProductNm
                this.cusAnalyForm.trends = request.data.data.trends
                this.currentPage = 1
                this.queryData(this.currentPage, this.pageSize)
              }
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      Fifth () {
        let param = {}
        param.objectId = this.rowId
        api.requestJava('POST', BasePath.CUSTSALESANALYSIS_SELECTONE, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              if (request.data.data === '') {
                this.isModify = false
              } else {
                this.isModify = true
                this._rowId = request.data.data.rowId
                let contents = JSON.parse(request.data.data.contents)
                this.cusAnalyForm.cust = contents.cust
                this.cusAnalyForm.consumer = contents.consumer
                this.cusAnalyForm.prd = contents.prd
              }
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      save (val) {
        let param = {}
        param.periodId = this.cusAnalyForm.periodId
        param.objectType = 2
        param.objectId = this.rowId
        param.objectCd = this.cusAnalyForm.customerCode
        param.objectNm = this.cusAnalyForm.customerDesc
        param.companyId = this.cusAnalyForm.companyId
        param.countyDept = getUser().countyId
        param.otherPr = ''
        param.reportorId = getUser().personId
        param.reportorNm = getUser().userName
        param.title = this.cusAnalyForm.customerDesc + this.cusAnalyForm.periodId + '月度卷烟经营分析报告'
        let content = {}
        content.cust = this.cusAnalyForm.cust
        content.consumer = this.cusAnalyForm.consumer
        content.prd = this.cusAnalyForm.prd
        param.contents = JSON.stringify(content)
        param.status = val
        let url = ''
        if (this.isModify) {
          param.rowId = this._rowId
          url = BasePath.WEEKORDERREPORT_UPDATE
        } else {
          url = BasePath.CUSTSALESANALYSIS_INSERT
        }
        api.requestJava('POST', url, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              if (val === 1) {
                this.$message({ type: 'success', message: '提交成功!' })
                this.saveDisabled = true
              } else {
                this.$message({ type: 'success', message: '保存成功!' })
              }
              this.init()
            } else {
              this.$notify.error({ title: '提示', message: request.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      backClk () {
        this.$router.push({name: 'CustSalesAnalysis', params: {rowId: 1}})
      }
    },
    components: {
      _TABLE
    }
  }
</script>

