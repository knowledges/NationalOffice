<!-- 徐晓菁 -->
<template>
  <div class="container-fluid">
    <div>
       <_TABLE
         ref="table"
         stripe
         maxHeight="500"
         :data="dataSource"
         :columns="columnHeader"
         :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
         :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
         @selection-change="selectionChange"></_TABLE>
    </div>
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve" />
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import {dateFormat} from '@/utils/common'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import MY_POPUP_CONFIG from './Popup.vue'
  import log from '@/log'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import {getCodeList} from '@/config/info'
  let Timer = null
  export default {
    mounted () {
      getCodeList('MOBILE_APP', (data) => {
        this.appGroup = data
      }) // 零售业态
      this.queryUpper()
    },
    data () {
      return {
        isSelect: true,
        isMore: true, // 查询更多条件
        appGroup: [], // 拜访情况
        /** 过滤的字段 **/
        fileName: ['matterName', 'makerNm', 'title'],
        /** 定义按钮 **/
        btnGroups: [],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 10,  // 默认每页20条数据
        pageSizes: [2, 5, 10, 20, 40, 50], // 分页数选择项
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'appPath',
            label: '二维码',
            columnsProps: {width: 250, type: 'img', meta: 'qrcode'},
            eventClick: this.ImgShow
          },
          {
            prop: 'name', // 列的值
            label: '应用名称', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'ver',
            label: '版本',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          },
          {
            prop: 'notes',
            label: '备注',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          },
          {
            prop: 'releaseTime',
            label: '释放时间',
            columnsProps: {width: 200, align: 'left'}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 200, type: 'button'},
            cptProperties: [
              {
                label: '修改',
                value: 'modify',
                icon: 'edit',
                size: 'small',
                type: 'warning',
                eventClick: this.modify
              }
            ]
          }
        ],
        hasPagination: true,
        tableData: [],
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        edit: {
          title: '应用发布',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              name: '',
              appName: '',
              ver: '',
              releaseTime: '',
              appPath: '',
              notes: '',
              status: '',
              old: ''
            }
          }
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        sel_all_row: []
      }
    },
    methods: {
      queryUpper () {
        api.requestJava('POST', BasePath.VERIONUP_SELECTLIST, {})
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = []
              for (let i = 0; i < request.data.data.length; i++) {
                let rowS = request.data.data[i]
                for (let j = 0; j < this.appGroup.length; j++) {
                  if (request.data.data[i].appName === this.appGroup[j].value) {
                    rowS.name = this.appGroup[j].label
                  }
                }
                this.tableData.push(rowS)
              }
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      modify (index, row) {
        this.findByIdUpper(1, row)
      }, // 修改// 修改
      findByIdUpper (type, row) {
        console.log('row:', row)
        let param = {}
        param.appName = row.appName
        param.ver = row.ver
        param.haveAttach = '1'
//        param.whereClause = 'order by CREATED_TIME desc  limit 1'
        console.log('param', param)
        api.requestJava('POST', BasePath.VERIONUP_LOG_SELECTONE, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (type === 1) {
                this.edit.data.form.rowId = row.rowId
                this.edit.data.form.name = row.name
                this.edit.data.form.appName = row.appName
                this.edit.data.form.ver = row.ver
                this.edit.data.form.releaseTime = row.releaseTime
                this.edit.data.form.appPath = row.appPath
                this.edit.data.form.notes = row.notes
                this.edit.data.form.status = row.status
                this.edit.data.form.files = row.files
//                Object.assign(this.edit.data.form, row)
                this.edit.data.form.old = row.ver
                if (request.data.data !== '') {
                  this.edit.data.form.files = request.data.data.files
                }
                this.edit.dialogVisible = true
              } else if (type === 2) {
              } else {
                if (request.data.data === '') {
                  this.saveLogUpper()
                } else {
                  this.$message({type: 'info', message: '版本号与历史版本号重复!'})
                  return
                }
              }
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      findUrlUpper (row, callback) {
        let param = {}
        param.appName = row.appName
        param.haveAttach = '1'
        param.whereClause = 'order by CREATED_TIME desc  limit 1'
        console.log('param', param)
        api.requestJava('POST', BasePath.VERIONUP_LOG_SELECTONE, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              callback(request.data.data)
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      editEve (msg) {
        if (msg === 'update') {
          this.findByIdUpper(3, this.edit.data.form)
        } else if (msg === 'roleback') {
          this.saveUpper()
        } else {
          this.clear()
        }
      }, // 修改事件
      clear () {
        this.edit.dialogVisible = false
        let tmp = {
          title: '应用发布',
          type: '3',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              name: '',
              appName: '',
              ver: '',
              releaseTime: '',
              appPath: '',
              notes: '',
              status: '',
              old: '',
              createdBy: '',
              createdTime: '',
              lastUpdBy: '',
              lastUpdTime: '',
              modificationNum: '',
              deletedFlag: '',
              originFlag: '',
              originApp: '',
              files: []
            }
          }
        }
        Object.assign(this.edit, tmp)
      },
      saveLogUpper () {
        let params = {}
        params.appName = this.edit.data.form.appName
        params.ver = this.edit.data.form.ver
        params.releaseTime = dateFormat(new Date().getTime(), 'YYYY-MM-DD HH:mm:ss')
        params.appPath = this.edit.data.form.appPath
        params.notes = this.edit.data.form.notes
        params.status = '1'
        params.haveAttach = 1
        let files = []
        let tmp = this.edit.data.form.files
        console.log(tmp)
        for (let i = 0; i < tmp.length; i++) {
          let rowS = {}
          rowS.fileName = tmp[i].fileName
          rowS.fileType = 'app'
          rowS.fileData = tmp[i].fileData
          files.push(rowS)
        }
        params.files = files
        api.requestJava('POST', BasePath.VERIONUP_LOG_INSERT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              Timer = setInterval(() => {
                this.IntervalMethod(params)
              }, 10000)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 保存
      saveUpper () {
        let params = this.edit.data.form
        params.releaseTime = dateFormat(new Date().getTime(), 'YYYY-MM-DD HH:mm:ss')
        console.log('params', params)
        api.requestJava('POST', BasePath.VERIONUP_UPDATE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$notify({title: '成功', message: request.data.message, type: 'success'})
              this.clear()
              this.queryUpper()
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({ title: '提示', message: request.data.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 保存
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = this.currentPage
        let size = this.pageSize
        this.dataSource = JSON.parse(val).filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.table.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      onendChange (val) {}, // 过滤器修改事件
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      select (selection, index) {}, // 选中某1条
      selectAll (data) {}, // 全选
      headerClick (column, event) {},
      addClk () {
        var myDate = new Date()
        this.edit.data.form.beginDate = this.getTime(myDate.getTime())
        this.edit.data.form.endDate = this.getTime(myDate.getTime())
        this.edit.data.form.matterIdGroup = this.matterIdGroup
        this.edit.dialogVisible = true
      },
      sortChange (msg) {},
      rowClick (msg) {},
      selectionChange (rows) {},
      getNowTime (type) {
        return dateFormat(new Date().getTime(), type)
      },
      IntervalMethod (params) {
        this.findUrlUpper(params, (request) => {
          delete this.edit.data.form.files
          if (request.files.length > 0) {
            clearInterval(Timer)
            this.edit.data.form.appPath = request.files[0].fileData
            this.saveUpper()
          }
        })
      },
      ImgShow () {}
    },
    components: {
      _TABLE,
      _POPUP,
      MY_POPUP_CONFIG,
      _BTN_FILTER
    }
  }
</script>

<style scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-24 {
    height: 36px;
  }

</style>
