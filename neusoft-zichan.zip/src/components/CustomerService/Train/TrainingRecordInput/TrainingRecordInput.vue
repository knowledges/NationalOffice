<!--赵继越-->
<style scoped>
  .el-form-item__label{
    margin: 0px!important;
  }
  .filter_style .el-col-24 {
    height: 36px;
  }
  .el-form-item {
    margin-bottom: 12px;
  }
</style>
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='12'>
          <div v-if="isSelect">
            <el-form ref="searchForm" :model="searchForm" label-width="120px">
                <el-col :span='16'>
                  <div class="block">
                    <el-form-item label="培训日期">
                      <el-date-picker
                        v-model="searchForm.gatherDate"
                        type="daterange"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期">
                      </el-date-picker>
                    </el-form-item>
                  </div>
                </el-col>
            </el-form>
          </div>
        </el-col>
        <el-col :span="12">
          <_BTN_FILTER :isMore="isMore" :btnGroups="btnGroups" :fileName="fileName" :filterMethod="inputChange"
                       @on-click="exportEve" :tableData="tableData"/>
        </el-col>
      </el-col>
    </el-row>
    <div >
      <_TABLE :columns="columnHeader" :tableData="dataSource" :tableHeight="400"
              @update:data="tabChange" :reqParams="reqParams"
              :btnMode=true :btns="btns"
              :pageSizes="pageSizes" :currentPage=currentPage :pageSize=pageSize
              :totalCount=totalCount :queryData=this.queryData
              :checkBox=true
              :hasPagination="true"
              ref="tableGrid" :tableType=tableType ></_TABLE>
    </div>
    <_POPUP :dialogObj='sessionFailedDialogObj' @confirmBack="sessionFailedBack" />
    <MY_POPUP_CONFIG :dialogObj='addRecordDialogObj' @confirmBack="addBack"/>
    <MY_POPUP_CONFIG :dialogObj='eidRecordDialogObj' @confirmBack="_upload_submit"/>

  </div>
</template>
<script>
  import _TABLE from '@/components/Template/TabPagin/Table.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import MY_POPUP_CONFIG from './Popup.vue'
  import {getUser} from '@/config/info'
  import api from '@/api'
  import log from '@/log'
  import BasePath from '@/config/BasePath'
  import {dateFormat} from '@/utils/dateFormat'
  //  import {getUser} from '@/config/info'
  export default {
    mounted () {
      /** 调用初始化数据 **/
      let params = {}
      params.companyId = getUser().companyId
      this.init(params)
    },
    data () {
      return {
        isSelect: true,
        isMore: true, // 查询更多条件
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['trainDate', 'trainerNm', 'trainAddr', 'contents', 'trainingObjs'],
        searchForm: {
          gatherDateL: new Date(),
          gatherDateR: new Date(),
          gatherDate: [new Date(), new Date()]
        },
        btnGroups: [
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          },
          {
            name: '新增',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.addClk
          }
        ],
        /** table **/
        tableType: '3',
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            value: 'trainDate', // 列的值
            label: '培训日期', // 列的显示字段
            align: 'left' // 列的对齐方式，[left, center, right]，选填，默认是left
          }, {
            value: 'trainAddr',
            align: 'left',
            label: '培训地点'
          }, {
            value: 'trainerNm',
            align: 'left',
            label: '培训人员'
          }, {
            value: 'trainingObjs',
            label: '培训对象',
            align: 'left'
          }, {
            value: 'contents',
            label: '培训内容',
            align: 'left'
          }
        ],
        tableData: [],
        dataSource: [], // 当前页的数据
        btns: {
          btnArr: [
            {
              label: '修改', // 按钮的名称
              value: 'modify', // 按钮的值
              type: 'warning',
              icon: 'edit',
              functionName: this.modify // 按钮的方法
            },
            {
              label: '删除',
              value: 'del',
              type: 'danger',
              icon: 'delete',
              functionName: this.del
            },
            {
              label: '预览', // 按钮的名称
              value: 'view', // 按钮的值
              type: 'primary',
              icon: 'search',
              functionName: this.view // 按钮的方法
            }
          ],
          value: 'operation',
          label: '操作',
          width: '300px'
        },
        /** 弹出层 **/
        addRecordDialogObj: {
          title: '新增用户',
          type: 'addRecord',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              companyId: '',
              deptId: '',
              trainerId: '',
              trainerNm: '',
              trainDate: '',
              trainAddr: '',
              trainingObjs: '',
              contents: '',
              status: '',
              haveAttach: '1',
              files: []
            }
          }
        },
        eidRecordDialogObj: {
          title: '修改用户',
          type: 'eidRecord',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              companyId: '',
              deptId: '',
              trainerId: '',
              trainerNm: '',
              trainDate: '',
              trainAddr: '',
              trainingObjs: '',
              contents: '',
              status: '',
              haveAttach: '1',
              files: []
            }
          }
        },
        sessionFailedDialogObj: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              trainerNm: '',
              trainDate: ''
            }
          }
        }
      }
    },
    methods: {
      init (params) {
        params.pageNum = this.currentPage
        params.pageSize = this.pageSize
        params.trainDateL = this.getTime(Date.parse(this.searchForm.gatherDate[0]))
        params.trainDateR = this.getTime(Date.parse(this.searchForm.gatherDate[1]))
        this.reqParams.url = BasePath.DEPTPLACES_SELECT
        this.reqParams.params = params
        api.requestJava('POST', BasePath.TRAININGRECORD_SELECTLIST, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      sortChange (msg) {},
      rowClick (msg) {},
      query () {
        let params = {}
        params.trainDateL = this.getTime(Date.parse(this.searchForm.gatherDate[0]))
        params.trainDateR = this.getTime(Date.parse(this.searchForm.gatherDate[1]))
        params.companyId = getUser().companyId
        console.log('====', params)
        this.queryUpper(params)
      }, // 查询方法
      queryUpper (params) {
        api.requestJava('POST', BasePath.TRAININGRECORD_SELECTLIST, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      sessionFailedBack (msg) {
        let headers = msg.data.form
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.sessionFailedDialogObj.dialogVisible = false
            }
          })
          .catch((err) => { console.log(err) })
      }, // 会话失效
      del (index, row) {
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let param = {}
          param.rowId = row.rowId
          api.requestJava('POST', BasePath.TRAININGRECORD_DELETE, param)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.init(this.currentPage)
              } else if (Number(request.data.code) === 401) {
                this.sessionFailedDialogObj.dialogVisible = true
              } else {
                throw new Error(JSON.stringify(request))
              }
            })
            .catch((err) => {
              this.$store.commit('TOGGLE_LOADING')
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        })
      },
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      queryData (page, size) {
      // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      addClk () {
        this.clearObject()
        this.addRecordDialogObj.data.form.trainerNm = getUser().userName
        this.addRecordDialogObj.data.form.trainerId = getUser().personId
        this.addRecordDialogObj.data.form.deptId = getUser().deptId
        this.addRecordDialogObj.data.form.companyId = getUser().companyId
        this.addRecordDialogObj.title = '新增计划'
        this.addRecordDialogObj.dialogVisible = true
      }, // 新增
      addBack (msg) {
        this.add(msg)
      },
      _upload_submit (msg) {
        let params = msg.data.form
        let files = []
        for (let i = 0; i < msg.data.form.files.length; i++) {
          if (msg.data.form.files[i].fileName === '') {
            return
          }
          console.log('files', this.msg.data.form.files[i])
          let rowS = {}
          rowS.fileName = msg.data.form.files[i].fileName
          rowS.fileType = 'training_record_photo'
          rowS.fileData = msg.data.form.files[i].fileData
          files.push(rowS)
        }
        params.files = files
        params.haveAttach = '1'
        console.log(JSON.stringify(params))
        api.requestJava('POST', BasePath.TRAININGRECORD_UPDATE, params)
          .then(request => {
            console.log(request.data.code)
            if (Number(request.data.code) === 200) {
//              this.init(this.currentPage)
              this.query()
            } else {
              this.$notify.error({ title: '提示', message: '更新错误' })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
        this.clearObject()
      }, // 提交
      clearObject () {
        let temp = {
          title: '新增用户',
          type: 'addRecord',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              companyId: '',
              deptId: '',
              trainerId: '',
              trainerNm: '',
              trainDate: '',
              trainAddr: '',
              trainingObjs: '',
              haveAttach: '1',
              contents: '',
              status: '',
              files: []
            }
          }
        }
        Object.assign(this.addRecordDialogObj, temp)
      },
      add (msg) {
        let params = {}
        let files = []
        for (let i = 0; i < msg.data.form.files.length; i++) {
          if (msg.data.form.files[i].fileName === '') {
            return
          }
          console.log('files', msg.data.form.files[i])
          let rowS = {}
          rowS.fileName = msg.data.form.files[i].fileName
          rowS.fileType = 'training_record_photo'
          if ('src' in msg.data.form.files[i]) {
            let src = msg.data.form.files[i].src
            if (src.split(',').length > 0) {
              rowS.fileData = src.split(',')[1]
            }
          } else {
            rowS.fileData = msg.data.form.files[i].fileData
          }
          files.push(rowS)
        }
        params.files = files
        params.companyId = msg.data.form.companyId
        params.deptId = msg.data.form.deptId
        params.trainerId = msg.data.form.trainerId
        params.trainerNm = msg.data.form.trainerNm
        params.trainDate = dateFormat(msg.data.form.trainDate.getTime(), 'YYYY-MM-DD')
        params.trainAddr = msg.data.form.trainAddr
        params.trainingObjs = msg.data.form.trainingObjs
        params.haveAttach = '1'
        params.contents = msg.data.form.contents
        params.status = msg.data.form.status
        console.log(params)
        api.requestJava('POST', BasePath.TRAININGRECORD_INSERT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.clearObject()
//              this.init()
              this.query()
              this.$message({type: 'success', message: '新增成功!'})
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      modify (index, row) {
        if (Number(row.status) === 1 || Number(row.status) === 2) {
          this.$message({type: 'info', message: '该记录已生效或终止，不可修改!'})
          return
        }
        this.findByIdUpper(row)
      }, // 修改
      view (index, row) {
        let param = {}
        param.rowId = row.rowId
        param.haveAttach = '1'
        api.requestJava('POST', BasePath.TRAININGRECORD_SELECTLIST, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              Object.assign(this.eidRecordDialogObj.data.form, row)
              this.eidRecordDialogObj.data.form.files = request.data.data[0].files
              this.eidRecordDialogObj.type = 'view'
              this.eidRecordDialogObj.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 修改
      findByIdUpper (row) {
        let param = {}
        param.rowId = row.rowId
        console.log('修改2', row.rowId)
        param.haveAttach = '1'
        api.requestJava('POST', BasePath.TRAININGRECORD_SELECTLIST, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              Object.assign(this.eidRecordDialogObj.data.form, row)
              this.eidRecordDialogObj.data.form.files = request.data.data[0].files
              console.log('修改2', request.data.data[0].files)
              this.eidRecordDialogObj.type = 'eidRecord'
              this.eidRecordDialogObj.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      headerClick (column, event) {}
    },
//    exportEve () {
//      this.$refs.tableGrid.exportExcel()
//    }, // 导出Elxc
    components: {
      _TABLE,
      _POPUP,
      _BTN_FILTER,
      MY_POPUP_CONFIG
    }
  }
</script>
<style scoped>
  .cust_row_r{
    position: absolute;
    top:0;
    right: 20px;
    z-index:1;
    width: 315px;
    border: none;
  }
  .cust_btn_box {
    box-shadow: -2px 3px 6px #666;
    padding: 0!important;
  }
  .cust_btn_r{
    background: #fff;
    border-radius: 50%;
    box-shadow: 2px 2px 5px #999;
    position: absolute;
    top: 50%;
    right: 0;
    margin-top: -18px;
  }
  .moveR-enter-active {
    animation: moveR-in .5s;
  }
  .moveR-leave-active {
    animation: moveR-in .5s reverse;
  }
  @keyframes moveR-in {
    0% {
      transform: translate(250px, 0px);
    }
    80% {
      transform: translate(-40px, 0px);
    }
    100% {
      transform: translate(0px, 0px);
    }
  }
</style>
