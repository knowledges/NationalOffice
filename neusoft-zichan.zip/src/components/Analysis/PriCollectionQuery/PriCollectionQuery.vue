<!--李晶-->
<style rel="stylesheet/scss" lang="scss" scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-24 {
    height: 36px;
  }
</style>
<template>
  <div  class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='12'>
          <div v-if="isSelect">
            <el-form ref="searchForm" :model="searchForm" label-width="100px">
              <el-col :gutter="24">
                <el-col :span='12'>
                  <el-form-item label="日期">
                    <el-date-picker
                      v-model="searchForm.gatherDate"
                      type="date"
                      placeholder="选择日期">
                    </el-date-picker>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-form>
          </div>
        </el-col>
        <el-col :span="12">
          <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" :tableData="tableData" @on-click="exportEve" :isMore="isMore"></_BTN_FILTER>
        </el-col>
      </el-col>
    </el-row>
    <div>
      <tableVue
        ref="tableGrid"
        stripe
        maxHeight="500"
        :data="dataSource"
        @update:data="tabChange" :reqParams="reqParams"
        :columns="columns"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
      ></tableVue>
    </div>
  </div>
</template>
<script>
  import tableVue from '@/components/Template/table/Table.vue'
  import { getUser } from '@/config/info'
  import { dateFormat } from '@/utils/dateFormat.js'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import { changeListValueByCode } from '@/utils/common'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import log from '@/log'
  export default {
    name: 'MaterielQuery',
    props: {},
    mounted () {
      this.init()
    },
    data () {
      return {
        billTypeDisable: false,
        queryParams: {},
        isSelect: true,
        isMore: true, // 查询更多条件
        searchForm: {
          gatherDate: new Date()
        },
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['barcodeLoaf', 'goodsDesc'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        options_billType: [],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        selectSells: [],
        totalCount: 0, // 表格总记录数
        hasPagination: true, // 是否有分页
        columns: [ // 表格列
          { label: '卷烟条码', prop: 'barcodeLoaf', columnsProps: {fixed: true, width: 200} },
          { label: '卷烟名称', prop: 'goodsDesc', columnsProps: {fixed: true, width: 200} },
          { label: '批发价', prop: 'tradePrice', columnsProps: {fixed: true, width: 100} },
          { label: '调拨价', prop: 'purchasePrice', columnsProps: {fixed: true, width: 100} },
          { label: '南京', prop: 'gatherPriceNj', columnsProps: {} },
          { label: '无锡', prop: 'gatherPriceWx', columnsProps: {} },
          { label: '徐州', prop: 'gatherPriceXz', columnsProps: {} },
          { label: '常州', prop: 'gatherPriceCz', columnsProps: {} },
          { label: '苏州', prop: 'gatherPriceSz', columnsProps: {} },
          { label: '南通', prop: 'gatherPriceNt', columnsProps: {} },
          { label: '连云港', prop: 'gatherPriceLyg', columnsProps: {} },
          { label: '淮安', prop: 'gatherPriceHa', columnsProps: {} },
          { label: '盐城', prop: 'gatherPriceYc', columnsProps: {} },
          { label: '扬州', prop: 'gatherPriceYz', columnsProps: {} },
          { label: '镇江', prop: 'gatherPriceZj', columnsProps: {} },
          { label: '宿迁', prop: 'gatherPriceSq', columnsProps: {} },
          { label: '泰州', prop: 'gatherPriceTz', columnsProps: {} }
        ],
        tableData: [],
        tableType: '4',
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        changeValueDate: {
          billType: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          }
        },
        headerClick () {},
        sortChange (msg) {},
        rowClick (msg) {}
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      init () {
        let param = {}
        param.gatherDate = this.getTime(Date.parse(this.searchForm.gatherDate))
        param.companyId = getUser().companyId
        this.querySearch(param)
      },
      query () {
        let param = {}
        param.gatherDate = this.getTime(Date.parse(this.searchForm.gatherDate))
        this.querySearch(param)
      },
      querySearch (param) {
        this.reqParams.url = BasePath.PRICOLLECTION_SELECTLIST
        this.reqParams.params = param
        api.requestJava('POST', BasePath.PRICOLLECTION_SELECTLIST, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              console.log(request.data.data)
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.dataSource = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
              console.log('返回数据：' + JSON.stringify(request.data.data))
            } else {
              this.$notify.error({ title: '提示', message: '查询接口调用失败！' })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      addClk () {
        this.$router.push({name: 'MaterielAdd', params: {uId: this.$route.params.uId}})
      },
      colFormatter_billType (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },
      confirmBack (msg) {
      }
    },
    components: {
      tableVue,
      _BTN_FILTER
    },
    watch: {}
  }
</script>
