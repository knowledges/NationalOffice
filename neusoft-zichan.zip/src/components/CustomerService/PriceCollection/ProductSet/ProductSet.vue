<!-- 黄龙 -->
<style scoped>
.el-form-item{
  margin-bottom: 12px!important;
}
</style>
<template>
  <div class="container-fluid">
    <el-collapse-transition>
      <div v-if="isSelect" class="filter_more">
        <el-form ref="searchForm" :model="searchForm" label-width="120px">
          <el-col :span="24">
            <el-col :span='8'>
              <el-form-item label="商品代码" >
                <template>
                  <el-input v-model="searchForm.goodsCode"   placeholder="请输入商品代码" auto-complete="off" class="inputInline" style="width:218px"></el-input>
                </template>
              </el-form-item>
            </el-col>
            <el-col :span='8'>
              <el-form-item label="商品名称">
                <el-input v-model="searchForm.goodsDesc"   placeholder="请输入商品名称" auto-complete="off" class="inputInline" style="width:218px"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='8'>
              <el-form-item label="卷烟类别">
                <el-select v-model="searchForm.gradeIdDesc"  :clearable="true"  placeholder="请选择卷烟级别">
                  <el-option
                    v-for="item in options_gradeIdDesc"
                    :key="item.gradeCode"
                    :label="item.gradeDesc"
                    :value="item.gradeCode">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-col>
          <el-col :gutter="24">
            <el-col :span='8'>
              <el-form-item label="异常范围">
                <el-input v-model="searchForm.downUpRate"   placeholder="请输入异常范围" auto-complete="off" class="inputInline" style="width:218px"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='8'>
              <el-form-item label="优先级">
                <el-input v-model="searchForm.weight"   placeholder="请输入优先级" auto-complete="off" class="inputInline" style="width:218px"></el-input>
              </el-form-item>
            </el-col>
          </el-col>
        </el-form>
      </div>
    </el-collapse-transition>
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span="24">
          <_BTN_FILTER :isMore="isMore" :btnGroups="btnGroups" :fileName="fileName" :filterMethod="inputChange" @on-click="exportEve" :tableData="tableData"/>
        </el-col>
      </el-col>
    </el-row>
    <div>
      <_TABLE :columns="columnHeader" :tableData="dataSource" :tableHeight="400"
              @update:data="tabChange" :reqParams="reqParams"
              :sortChange="sortChange" :rowClick="rowClick" :btnMode=true :btns="btns"
              :pageSizes="pageSizes" :currentPage=currentPage :pageSize=pageSize
              :totalCount=totalCount :queryData=this.queryData
              :checkBox=true
              :select="select" :selectAll="selectAll" :hasPagination="true"
              ref="tableGrid" :tableType=tableType :headerClick="modify" :celldbClick="celldbClick"></_TABLE>
    </div>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/TabPagin/Table.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import api from '@/api'
  import log from '@/log'
  import {getCodeList, getUser} from '@/config/info'
  import BasePath from '@/config/BasePath'
  export default {
    mounted () {
      this.getGradeType()
      this.init()
      getCodeList('VISITING_STATUS', (data) => {
        this.options_weight = data
      }) // 优先级
    },
    data () {
      return {
        isSelect: false,
        isMore: true, // 查询更多条件
        showSummary: true,
        iconArr: ['fa fa-ban', 'fa fa-home', 'fa fa-phone'],
        /** 过滤的字段 **/
        fileName: ['goodsCode', 'barcodeLoaf', 'goodsDesc'],
        btnGroups: [
          {
            name: '',
            className: 'btn-primary',
            iconName: 'fa-th',
            event: this.isMoreClk
          },
          {
            name: '保存',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.save
          },
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          },
          {
            name: '设置',
            className: 'btn-danger',
            iconName: 'fa-cog',
            event: this.setup
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 500,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            value: 'goodsCode', // 列的值
            label: '商品代码', // 列的显示字段
            align: 'left' // 列的对齐方式，[left, center, right]，选填，默认是left
          }, {
            value: 'barcodeLoaf',
            align: 'left',
            label: '商品条码'
          }, {
            value: 'goodsDesc',
            label: '商品名称',
            align: 'left'
          }, {
            value: 'gradeIdDesc',
            label: '卷烟类别',
            align: 'left'
          }, {
            value: 'kindGradeDesc',
            label: '价位区间',
            align: 'left'
          }, {
            value: 'tradePrice',
            label: '批发价',
            align: 'left'
          },
          {
            value: 'retailPrice',
            label: '零售价',
            align: 'left'
          },
          { width: '130',
            value: 'downUpRate',
            editable: true,
            type: 'input',
            label: '异常范围(±%)',
            align: 'left'
          },
          {
            value: 'weight',
            editable: true,
            type: 'input',
            label: '优先级',
            align: 'left'
          },
          {
            value: 'isGather', // 列的值
            label: '是否采集', // 列的显示字段
            className: 'header', // 列的css样式（选填）
            editable: true,
            type: 'checkbox',
            align: 'center' // 列的对齐方式，[left, center, right]，选填，默认是left
          }
        ],
        tableData: [],
        btns: {},
        tableType: '1',
        planTime: '',
        totalNum: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        /** searchForm **/
        searchForm: {
          rowId: '',
          productId: '',
          weight: '',
          downUpRate: '',
          companyId: '',
          retailPrice: '',
          isGather: '',
          cigKind: '',
          gradeIdDesc: '',
          goodsCode: '',
          barcodeLoaf: '',
          kindGradeDesc: '',
          tradePrice: '',
          goodsDesc: '',
          status: ''
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        sums: []
      }
    },
    methods: {
      celldbClick (row, column, cell, event) {
        if (row.isGather) {
          this.$set(row, 'editable', !row.editable)
        }
      },
      setup () {
        this.tableData.forEach((data, index, arr) => {
          if (data.isGather) {
            data.downUpRate = this.searchForm.downUpRate
            data.weight = this.searchForm.weight
          }
        })
        this.queryData(this.currentPage, this.pageSize)
      },
      isMoreClk () {
        this.isSelect = !this.isSelect
      },
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      query () {
        let params = {}
        params.goodsCode = this.searchForm.goodsCode
        params.goodsDesc = this.searchForm.goodsDesc
        params.gradeId = this.searchForm.gradeIdDesc
        params.downUpRate = this.searchForm.downUpRate
        params.weight = this.searchForm.weight
        params.companyId = getUser().companyId
        // params.visitStatus = '0'
        this.queryUpper(params)
      },
      queryUpper (params) {
        api.requestJava('POST', BasePath.GATHER_SELECTGATCH, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      init () {
        let param = {}
        param.companyId = getUser().companyId
        /* 将已有的参数赋值给分页参数 */
        this.$set(this.reqParams, 'url', BasePath.GATHER_SELECTGATCH)
        this.$set(this.reqParams, 'params', param)
        api.requestJava('POST', BasePath.GATHER_SELECTGATCH, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      save () {
        this.$confirm('确定保存设置吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.saveUpper()
        }).catch(() => {
          this.$message({type: 'info', message: '已取消保存操作!'})
        })
      },
      saveUpper () {
        let params = []
        for (let i = 0; i < this.tableData.length; i++) {
          if (this.tableData[i].isGather) {
            let rowS = {}
          //  rowS.rowId = this.tableData[i].rowId
            rowS.productId = this.tableData[i].rowId
            rowS.weight = this.tableData[i].weight
            rowS.downUpRate = this.tableData[i].downUpRate
        //    rowS.isGather = this.tableData[i].isGather
       //     rowS.goodsGradeDesc = this.tableData[i].goodsGradeDesc
            rowS.productCode = this.tableData[i].goodsCode
            rowS.productName = this.tableData[i].goodsDesc
      //      rowS.barcodeLoaf = this.tableData[i].barcodeLoaf
       //     rowS.kindGradeDesc = this.tableData[i].kindGradeDesc
       //     rowS.prange = this.tableData[i].prange
       //     rowS.status = this.tableData[i].status
            rowS.companyId = getUser().companyId
       //     rowS.tradePrice = this.tableData[i].tradePrice
       //     rowS.cigKind = this.tableData[i].cigKind
       //     rowS.goodsGrade = this.tableData[i].goodsGrade
            params.push(rowS)
          }
        }
        if (params.length === 0) {
          this.$message({type: 'info', message: '请选择需要采集的数据!'})
          return
        } else {
          let param2 = []
          let param = {}
          param.companyId = getUser().companyId
          api.requestJava('POST', BasePath.GATHER_SELECT, param)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                var a = 0
                for (a = 0; a < request.data.data.length; a++) {
                  let param1 = {}
                  param1.rowId = request.data.data[a].rowId
                  param2.push(param1)
                }
                if (request.data.data.length > 0) {
                  api.requestJava('POST', BasePath.GATHER_DELETEBATCH, param2)
                    .then((request) => {
                      if (Number(request.data.code) === 200) {
                        api.requestJava('POST', BasePath.GATHER_INSERTBATCH, params)
                          .then((request) => {
                            if (Number(request.data.code) === 200) {
                              this.$notify({title: '成功', message: '保存成功', type: 'success', duration: 1000})
                              this.init()
                            } else if (Number(request.data.code) === 401) {
                              this.$message('数据录入失败')
                              this.logInvalid.dialogVisible = true
                            } else {
                              this.$notify.error({ title: '提示', message: request.data.message })
                              throw new Error(JSON.stringify(request))
                            }
                          })
                          .catch((err) => {
                            let culprit = this.$route.name
                            log.work(err, culprit)
                          })
                      } else if (Number(request.data.code) === 401) {
                        this.sessionFailDialogObj.dialogVisible = true
                      } else {
                        throw new Error(JSON.stringify(request))
                      }
                    })
                } else {
                  api.requestJava('POST', BasePath.GATHER_INSERTBATCH, params)
                    .then((request) => {
                      if (Number(request.data.code) === 200) {
                        this.$notify({title: '成功', message: '保存成功', type: 'success', duration: 1000})
                        this.init()
                      } else if (Number(request.data.code) === 401) {
                        this.$message('数据录入失败')
                        this.logInvalid.dialogVisible = true
                      } else {
                        this.$notify.error({ title: '提示', message: request.data.message })
                        throw new Error(JSON.stringify(request))
                      }
                    })
                    .catch((err) => {
                      let culprit = this.$route.name
                      log.work(err, culprit)
                    })
                }
              } else if (Number(request.data.code) === 401) {
                this.$message('数据录入失败')
                this.logInvalid.dialogVisible = true
              } else {
                this.$notify.error({ title: '提示', message: request.data.message })
                throw new Error(JSON.stringify(request))
              }
            })
        }
      }, // 保存
      getGradeType () {
        api.requestJava('POST', BasePath.SELECT_GOODSGRADEGROUP, {'gradeType': 1, 'fields': {'include': 'gradeCode,gradeDesc'}})
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.options_gradeIdDesc = request.data.data
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      sortChange (msg) {},
      rowClick (msg) {},
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      select (selection, index) {}, // 选中某1条
      selectAll (data) {}, // 全选
      modify (index, row) {
        row.editable = !row.editable
        // this.dialogFormVisible = true
        // this.form = row
        // this.$message(row.name + '现在不可修改')
      },
      del (index, row) {},  // 删除
      batchDelClk () {},  // 批量删除
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
        this.setFiexHeigth()
      }, // 分页请求
      onendChange (val) {}, // 过滤器修改事件
      deleteUpper (val) {}, // 删除接口
      setFiexHeigth () {
        let form1 = document.getElementById('form1')
        let fixed = document.getElementsByClassName('el-table__fixed')
        if (Number(fixed.length) === 1) {
          setTimeout(() => {
            fixed[0].style.height = (parseInt(form1.style.height) - parseInt('1px')) + 'px'
          })
        } else {
          console.log('存在多个固定列，注意检查')
        }
      } // 给flex 列 修改 高度
    },
    components: {
      _TABLE,
      _POPUP,
      _BTN_FILTER
    }
  }
</script>


