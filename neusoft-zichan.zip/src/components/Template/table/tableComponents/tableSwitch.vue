<template>
  <div>
    <el-switch
      v-show="row._edit" :on-text="onText" :off-text="offText"
      :on-value="onValue" :off-value="offValue" :width="width"
      :allow-focus="allowFocus"
      @change="eventChange" @blur="eventBlur"
      @focus="eventFocus"
      v-model="row[col.prop]" ></el-switch>
    <span v-show="!row._edit">{{ text }}</span>
  </div>
</template>

<script>
export default {
  props: {
    row: Object,
    col: Object,
    data: Array
    // KeyDownEvent: {
    //   type: Function,
    //   default: function (ev) {
    //   }
    // }
  },
  mounted () {
  },
  methods: {
  },
  computed: {
    text () {
      if (this.row[this.col.prop] === this.col.cptProperties.onValue) {
        return this.col.cptProperties.onText
      }
      return this.col.cptProperties.offText
    },
    width () {
      return this.col.cptProperties.width ? this.col.cptProperties.width : '60'
    },
    onText () {
      return this.col.cptProperties.onText ? this.col.cptProperties.onText : ''
    },
    offText () {
      return this.col.cptProperties.offText ? this.col.cptProperties.offText : ''
    },
    onValue () {
      return this.col.cptProperties.onValue ? this.col.cptProperties.onValue : ''
    },
    offValue () {
      return this.col.cptProperties.offValue ? this.col.cptProperties.offValue : ''
    },
    allowFocus () {
      return this.col.cptProperties.allowFocus ? this.col.cptProperties.allowFocus : ''
    },
    eventChange () {
      return this.col.cptProperties.eventChange ? this.col.cptProperties.eventChange : function () {}
    },
    eventFocus () {
      return this.col.cptProperties.eventFocus ? this.col.cptProperties.eventFocus : function () {}
    },
    eventBlur () {
      return this.col.cptProperties.eventBlur ? this.col.cptProperties.eventBlur : function () {}
    }
  }
}
</script>