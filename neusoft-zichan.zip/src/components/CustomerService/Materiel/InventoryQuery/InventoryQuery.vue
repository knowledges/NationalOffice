<!-- 徐晓菁 -->
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span='12'>
          <div v-if="isSelect">
            <el-form ref="searchForm" :model="searchForm" label-width="120px">
              <el-col :gutter="24">
                <el-col :span='12'>
                  <div class="block">
                    <el-form-item label="市场经理">
                      <el-select v-model="searchForm.mktMgrId"  :clearable="true" placeholder="请选择市场经理"  @change="handleItemChange()">
                        <template v-for="item in mktMgrIdGroup">
                          <el-option  :key="item.rowId"  :label="item.employeeName" :value="item.rowId" ></el-option>
                        </template>
                      </el-select>
                    </el-form-item>
                  </div>
                </el-col>
                <el-col :span='12'>
                  <el-form-item label="客户经理" >
                    <el-select v-model="searchForm.custMgrId"  :clearable="true" placeholder="请选择客户经理">
                      <template v-for="item in custMgrIdGroup">
                        <el-option  :key="item.rowId"  :label="item.employeeName" :value="item.rowId"></el-option>
                      </template>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-col>
            </el-form>
          </div>
        </el-col>
        <el-col :span="12">
          <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData" :isMore="isMore"/></_BTN_FILTER>
        </el-col>
      </el-col>
    </el-row>
     <div>
       <_TABLE
         ref="tableGrid"
         stripe
         maxHeight="500"
         @update:data="tabChange" :reqParams="reqParams"
         :data="dataSource"
         :columns="columnHeader"
         :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
         :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
         @selection-change="selectionChange"></_TABLE>
    </div>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import { changeListValueByCode, dateFormat } from '@/utils/common'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import log from '@/log'
  import api from '@/api'
  import axios from 'axios'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  export default {
    mounted () {
      this.searchForm.companyId = getUser().companyId
      this.query()
      let params1 = {}
      params1.companyId = getUser().companyId
      params1.place = '135'
      params1.status = 1
      let params2 = {}
      params2.companyId = getUser().companyId
      params2.place = '24'
      params1.status = 1
      axios.all([
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params1),
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params2)
      ])
      .then(axios.spread((first, second) => {
        this.custMgrIdGroup = JSON.parse(JSON.stringify(first.data.data))
        this.allCustMgrIdGroup = JSON.parse(JSON.stringify(first.data.data))
        this.mktMgrIdGroup = JSON.parse(JSON.stringify(second.data.data))
      }))
    },
    data () {
      return {
        isSelect: true,
        mktMgrIdGroup: [],
        custMgrIdGroup: [],
        allCustMgrIdGroup: [],
        isMore: true, // 查询更多条件
        monthText: '',
        isCus: false,
        isMin: false,
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['handlerNm', 'materialNm'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        hasPagination: true,
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'handlerNm',
            label: '经手人',
            columnsProps: {align: 'left'}
          }, {
            prop: 'materialNm',
            label: '物品名称',
            columnsProps: {align: 'left'}
          }, {
            prop: 'inventoryQty',
            label: '库存量',
            columnsProps: {width: 150, align: 'left'}
          }, {
            prop: 'inventoryAmt',
            label: '含税库存额',
            columnsProps: {width: 180, align: 'left'}
          }, {
            prop: 'inventoryTam',
            label: '库存额',
            columnsProps: {width: 150, align: 'left'}
          }, {
            prop: 'lockQty',
            label: '锁定量',
            columnsProps: {width: 150, align: 'left'}
          }
        ],
        tableData: [],
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        /** searchForm **/
        searchForm: {
          mktMgrId: '',
          companyId: '',
          custMgrId: ''
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        sel_all_row: []
      }
    },
    methods: {
      handleItemChange () {
        if (this.searchForm.mktMgrId !== '') {
          this.custMgrIdGroup = []
          this.searchForm.custMgrId = ''
          for (let i = 0; i < this.allCustMgrIdGroup.length; i++) {
            if (this.allCustMgrIdGroup[i].manager === this.searchForm.mktMgrId) {
              this.custMgrIdGroup.push(this.allCustMgrIdGroup[i])
            }
          }
        } else {
          this.custMgrIdGroup = this.allCustMgrIdGroup
        }
      },
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      query () {
        let params = {}
        params.companyId = this.searchForm.companyId
        if (this.searchForm.mktMgrId !== '') {
          let bra = this.searchForm.mktMgrId
          let children = this.custMgrIdGroup
          for (let i = 0; i < children.length; i++) {
            bra = bra + ',' + children[i].rowId
          }
          params.fluzzy = {'in': 'handlerId:' + bra}
        }
        params.handlerId = this.searchForm.custMgrId
        params.status = 1
        console.log('params', JSON.stringify(params))
        this.queryUpper(params)
      }, // 查询方法
      queryUpper (params) {
        this.reqParams.url = BasePath.INVENTORY_INVENTORYREMAINDER
        this.reqParams.params = params
        api.requestJava('POST', BasePath.INVENTORY_INVENTORYREMAINDER, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              console.log('tableData', request.data.data)
              this.tableData = request.data.data
              this.totalCount = Number(request.data.count)
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      sortChange (msg) {},
      rowClick (msg) {},
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      dateFormatter (row, column) {
        var unixDate = row[column.property]
        return dateFormat(unixDate, 'YYYY-MM-DD HH:mm:ss')
      },  // 时间格式化
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      inputChange (val) {
        console.log('val我来了', val)
        /** 搜索功能回调 **/
        let page = this.currentPage
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      onendChange (val) {}, // 过滤器修改事件
      selectionChange (rows) {}
    },
    components: {
      _TABLE,
      _POPUP,
      _BTN_FILTER
    }
  }
</script>

<style scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-24 {
    height: 36px;
  }
</style>
