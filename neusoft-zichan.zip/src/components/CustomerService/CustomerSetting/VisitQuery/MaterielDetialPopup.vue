<!-- 李晶 -->
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
      <el-form-item label="物料代码">
        <el-input v-model="dialogObj.data.form.materialCd"></el-input>
      </el-form-item>
      <el-form-item label="物料名称"  >
        <el-input type="textarea" resize="none" v-model="dialogObj.data.form.materialNm"></el-input>
      </el-form-item>
      <el-form-item label="单位"  >
        <el-input type="textarea" resize="none" v-model="dialogObj.data.form.unit"></el-input>
      </el-form-item>
      <el-form-item label="个数"  >
        <el-input type="textarea" resize="none" v-model="dialogObj.data.form.quantity"></el-input>
      </el-form-item>
      <el-form-item label="图片">
        <uploadTemp style="margin:7px;" :files="dialogObj.data.form.files" ref="uploadPic" :operation="false" ></uploadTemp>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
    </div>
  </el-dialog>

</template>

<script>
  import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
  export default {
    props: ['dialogObj'],
    mounted () {
    },
    data () {
      return {
        addrules: {}
      }
    },
    methods: {
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      }
    },
    components: {
      uploadTemp
    }
  }
</script>
