<!--qiu.bl-->
<style rel="stylesheet/scss" lang="scss" scoped>
  img {
    cursor: pointer;
  }
</style>
<template>
  <div>
    <template v-for="(item, key) in data">
      <img :src='prefix + item.fileData' @click="dislogClk(item, key)" width="30" height="50" alt="零售烟">
    </template>
    <el-dialog :title="dialog.title" :visible.sync="dialog.isShow" style="text-align: center;z-index: 2000; overflow: inherit">
      <el-button @click="upclk">上一张</el-button>
      <img :src="prefix + dialog.img" width="300" height="450" alt="">
      <el-button @click="downclk">下一张</el-button>
    </el-dialog>
  </div>
</template>
<script>
  import config from '@/config'
  export default {
    name: 'imgList',
    props: ['data'],
    data () {
      return {
        prefix: config.FILE_ADDR,
        dialog: {
          title: '',
          img: '',
          idx: 0,
          isShow: false
        }
      }
    },
    methods: {
      dislogClk (obj, idx) {
        this.dialog.idx = idx
        this.dialog.img = obj.fileData
        this.dialog.isShow = true
        var arr = obj.fileName.split('/')
        var arr2 = arr[arr.length - 1]
        this.dialog.title = arr2.split('.')[0]
      },
      upclk () {
        if (Number(this.dialog.idx) === 0) {
          alert('已经是第一张了')
          return
        }
        this.dialog.idx = this.dialog.idx - 1
        var tmp = this.data[Number(this.dialog.idx)]
        this.dialog.img = tmp.fileData
        var arr = tmp.fileName.split('/')
        var arr2 = arr[arr.length - 1]
        this.dialog.title = arr2.split('.')[0]
      },
      downclk () {
        if (Number(this.data.length) === Number(this.dialog.idx + 1)) {
          alert('已经是最后一张了')
          return
        }
        this.dialog.idx = this.dialog.idx + 1
        var tmp = this.data[Number(this.dialog.idx)]
        this.dialog.img = tmp.fileData
        var arr = tmp.fileName.split('/')
        var arr2 = arr[arr.length - 1]
        this.dialog.title = arr2.split('.')[0]
      }
    }
  }
</script>
