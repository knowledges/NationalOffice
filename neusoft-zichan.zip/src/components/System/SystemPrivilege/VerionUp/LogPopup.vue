<!-- 徐晓菁 -->
<template>
  <div>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false" :before-close="cancleClk"  :size='dialogObj.size' v-popupdra-directive="{'show': dialogObj.dialogVisible}">
    <div class="container-fluid_new">
      <el-row class="filter_style">
        <el-col :span="24" style="padding: 0 0">
          <_BTN_FILTER @on-change="inputChange" :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData"/>
        </el-col>
      </el-row>
          <div>
            <_TABLE
              ref="table"
              stripe
              maxHeight="500"
              :data="dataSource"
              :columns="columnHeader"
              :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
              :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
              @selection-change="selectionChange"></_TABLE>
      </div>
    </div>
  </el-dialog>
  </div>
</template>

<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import api from '@/api'
  import log from '@/log'
  import BasePath from '@/config/BasePath'
  import {getCodeList} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      getCodeList('MOBILE_APP', (data) => {
        this.appGroup = data
      }) // 零售业态
    },
    updated () {
      if (this.isLoading && this.dialogObj.dialogVisible) {
        this.isLoading = false
        this.queryUpper()
      }
    },
    data () {
      return {
        /** table **/
        columnType: 'selection',
        hasPagination: true,
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [10, 20, 40, 50, 100], // 分页数选择项
        totalCount: 0, // 表格总记录数
        appGroup: [],
        columnHeader: [
          {
            prop: 'name', // 列的值
            label: '应用名称', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'ver',
            label: '版本',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          },
          {
            prop: 'notes',
            label: '备注',
            className: 'header', // 列的css样式（选填）
            columnsProps: {align: 'left'}
          },
          {
            prop: 'releaseTime',
            label: '释放时间',
            columnsProps: {width: 200, align: 'left'}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 200, type: 'button'},
            cptProperties: [
              {
                label: '选择',
                value: 'modify',
                icon: 'edit',
                size: 'small',
                type: 'warning',
                eventClick: this.modify
              }
            ]
          }
        ],
        tableData: [],
        dataSource: [], // 当前页的数据
        /** filter **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['ver'],
        isMore: true,
        isSelect: true,
        keyupend: false,   // 输入筛选；true：之前展示；false：之后展示
        templTableData: [], // 临时记录tableDate的值
        btnGroups: [
//          {
//            name: '确定',
//            className: 'btn-success',
//            iconName: 'fa-plus',
//            event: this.addClk
//          },
//          {
//            name: '筛选',
//            className: 'btn-success',
//            iconName: 'fa-search',
//            event: this.query_New
//          }
        ],
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        treeData: [],
        nodeKey: 'id',
        defaultCheckedKeys: [],
        isLoading: true
        /** 弹出层 **/
      }
    },
    methods: {
      modify (index, row) {
        this.dialogObj.data.form.ver = row.ver
        this.dialogObj.data.form.appPath = row.appPath
        this.dialogObj.data.form.files = row.files
        this.isLoading = true
        this.$emit('confirmBack', 'update')
      }, // 修改// 修改
      queryUpper () {
        let param = {}
        param.haveAttach = 1
        param.appName = this.dialogObj.data.form.appName
        api.requestJava('POST', BasePath.VERIONUP_LOG_SELECTLIST, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = []
              for (let i = 0; i < request.data.data.length; i++) {
                let rowS = request.data.data[i]
                if (request.data.data[i].files.length > 0) {
                  rowS.appPath = request.data.data[i].files[0].fileData
                }
                for (let j = 0; j < this.appGroup.length; j++) {
                  if (request.data.data[i].appName === this.appGroup[j].value) {
                    rowS.name = this.appGroup[j].label
                  }
                }
                this.tableData.push(rowS)
              }
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = this.currentPage
        let size = this.pageSize
        this.dataSource = JSON.parse(val).filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.table.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      onendChange (val) {}, // 过滤器修改事件
      select (selection, index) {}, // 选中某1条
      selectAll (data) {}, // 全选
      headerClick (column, event) {},
      sortChange (msg) {},
      rowClick (msg) {},
      selectionChange (rows) {},
      addClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'update')
      },
      cancleClk () {
        this.isLoading = true
        this.$emit('confirmBack', 'cancle')
      },
      isMoreClk () {
        this.isSelect = !this.isSelect
      }
    },
    components: {
      _TABLE,
      _BTN_FILTER
    }
  }
</script>
<style scoped>
  .el-select {
    display: inline-block;
    position: relative;
    width: 92%;
  }
  .el-dialog__body {
    color: #48576a;
    font-size: 14px;
  }
  .form-group{
    margin-top: 13px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 12px 11px 0;
    box-sizing: border-box;
  }
  .label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 700;
  }
  .notice {
    font-size: medium;
    color: red;
    padding-left: 14px;
    padding-top: 11px;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-8 {
    height: 46px;
  }
  .el-col-2 {
    height: 61px;
  }
  .el-col-7 {
    height: 16px;
  }
  .el-col-15 {
    height: 61px;
  }
  .container-fluid_new {
    background: #FFF;
    margin: 0 5px 5px 5px;
  }
</style>

