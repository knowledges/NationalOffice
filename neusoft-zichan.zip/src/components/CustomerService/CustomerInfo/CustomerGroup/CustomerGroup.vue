<!--张文艺-->
<template>
  <div class="container-fluid">
    <el-row class="filter_style">
      <el-col :span="24" style="padding: 0 0">
        <_BTN_FILTER :isMore="isMore" :btnGroups="btnGroups" :fileName="fileName"
                     @on-click="exportEve" :tableData="tableData" :filterMethod="inputChange"/>
      </el-col>
    </el-row>
    <div>
      <_TABLE :columns="columnHeader" :tableData="dataSource" :tableHeight="400"
              :btnMode=true :btns="btns"
              @update:data="tabChange" :reqParams="reqParams"
              :pageSizes="pageSizes" :currentPage=currentPage :pageSize=pageSize
              :totalCount=totalCount :queryData=this.queryData
              :hasPagination="true"
              ref="tableGrid" :tableType=tableType></_TABLE>
    </div>
    <div>
      <el-dialog
        title="分配客户"
        :visible.sync="dialogVisible"
        width="100%" size="large"
        :before-close="handleClose">
        <div class="button">
          <el-button-group>
            <el-button type="primary" icon="el-icon-edit" @click="isShow">筛选条件</el-button>
            <el-button type="primary" icon="el-icon-search" @click="queryList()">查询</el-button>
          </el-button-group>
        </div>
        <el-collapse-transition>
          <div v-if="isSelect" class="searchForm">
          <el-form ref="searchForm" :model="searchForm" label-width="120px">
            <el-col :gutter="24">
              <el-col :span='8'>
                <el-form-item label="市场经理" v-if="isMan">
                  <el-select v-model="searchForm.marketmgrId" @change="onchange()"  filterable  :clearable="true"  placeholder="请选择市场经理">
                    <template v-for="item in optionsmarketmgrId">
                      <el-option  :key="item.rowId"  :label="item.employeeName" :value="item.rowId"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="客户经理" v-if="isCus">
                  <el-select v-model="searchForm.custmgrId"  filterable  :clearable="true"  placeholder="请选择客户经理">
                    <template v-for="item in rtlcatIdGroup">
                      <el-option  :key="item.rowId"  :label="item.employeeName" :value="item.rowId"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='8' >
                <el-form-item prop="batchNo" label="订货批次">
                  <el-select v-model="searchForm.batchNo" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_batchNo"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='6'>
                <el-form-item  prop="starGrade" label="客户星级" >
                  <el-select v-model="searchForm.starGrade" :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in options_starGrade"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
            <el-col :gutter="24">
              <el-col :span='8'>
                <el-form-item label="代码/名称">
                  <el-input v-model="searchForm.searchTxt" auto-complete="off" class="inputInline" style="width:220px"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="经营业态">
                  <el-select v-model="searchForm.businessType" multiple  :clearable="true" placeholder="请选择经营业态">
                    <template v-for="item in optionsbusinessType">
                      <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="销售规模">
                  <el-select v-model="searchForm.operationScale" multiple :clearable="true" placeholder="请选择销售规模">
                    <template v-for="item in operationScaleGroup">
                      <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
            <el-col :gutter="24">
              <el-col :span='8'>
                <el-form-item label="客户级别">
                  <el-select v-model="searchForm.customerGrade" multiple  :clearable="true"  placeholder="请选择客户级别">
                    <template v-for="item in optionsCustomerGrade">
                      <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="市场类型">
                  <el-select v-model="searchForm.geoType" multiple :clearable="true" placeholder="请选择">
                    <el-option
                      v-for="item in optionsGeoType"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span='8'>
                <el-form-item label="启用状态">
                  <el-select v-model="searchForm.status" multiple :clearable="true"  placeholder="请选择启用状态">
                    <template v-for="item in operationStatus">
                      <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                    </template>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-col>
          </el-form>
        </div>
        </el-collapse-transition>
        <div class="transfer">
          <el-transfer
            filterable
            :filter-method="filterMethod" class="scoped"
            filter-placeholder="请输入客户代码"
            v-model="value1"
            :titles="['待选客户', '已选客户']"
            :render-content="renderFunc"
            :data="data">
          </el-transfer>
        </div>
        <span slot="footer" class="dialog-footer">
      <el-button @click="handleClose()">取 消</el-button>
      <el-button type="primary" @click="submit">确 定</el-button>
      </span>
      </el-dialog>
    </div>
    <_POPUP :dialogObj='addCustomerColl' @confirmBack="addCustomerCollBack"/>
    <_ORDERPOPUP :dialogObj='orderCustomer' @confirmBack="orderCustomerBack" ref="orderCustomerRef"/>
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/TabPagin/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import _POPUP from '@/components/CustomerService/CustomerInfo/CustomerGroup/CustomerGroupPopup.vue'
  import _ORDERPOPUP from '@/components/CustomerService/CustomerInfo/CustomerGroup/CustomerGroupOrderPopup.vue'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import axios from 'axios'
  import log from '@/log'
  import { getUser, getCodeList } from '@/config/info'
  export default {
    mounted () {
      /** 调用初始化数据 **/
      this.init()
      getCodeList('YC_GEO_TYPE', (data) => {
        this.optionsGeoType = data
      }) // 市场类型
      getCodeList('YC_CUST_STATUS', (data) => {
        this.operationStatus = data
      }) // 启用状态
      getCodeList('YC_BUSINESS_TYPE', (data) => {
        this.optionsbusinessType = data
      }) // 经营业态
      getCodeList('CUSTOMER_GRADE', (data) => {
        this.optionsCustomerGrade = data
      }) // 客户级别
      getCodeList('YC_OPERATION_SCALE', (data) => {
        this.operationScaleGroup = data
      }) // 销售规模
      let params1 = {}
      let params2 = {}
      params2.status = 1
      params2.companyId = getUser().companyId
      params2.place = '135'
      params1.companyId = getUser().companyId
      params1.place = '24'
      params1.status = 1
      if (Number(getUser().place) === 24) {
        params2.manager = getUser().personId
        this.searchForm.marketmgrId = getUser().personId
        this.isMan = false
        this.isCus = true
      } else if (Number(getUser().place) === 135) {
        this.isMan = false
        this.isCus = false
        this.searchForm.custmgrId = getUser().personId
      } else {
        this.isMan = true
        this.isCus = true
      }
      let companyparams = {}
      companyparams.companyId = getUser().companyId
      let starGradeParam = {} // 客户星级
      starGradeParam.companyId = getUser().companyId
      starGradeParam.typeCode = 'STAR_GRADE'
      axios.all([
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params1),
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params2),
        api.requestJava('POST', BasePath.CUSTOMER_BANTCHNO, companyparams), // 公司批次
        api.requestJava('POST', BasePath.CUSTOMER_STARGRADE, starGradeParam) // 客户星级
      ])
      .then(axios.spread((first, second, third, _starGrade) => {
        this.optionsmarketmgrId = first.data.data
        this.rtlcatIdGroup = second.data.data
        this.options_batchNo = third.data.data
        this.options_starGrade = _starGrade.data.data
        console.log('市场经理:' + JSON.stringify(this.options_batchNo))
      }))
    },
    data () {
      return {
        isSelect: false,
        searchForm: {
          marketmgrId: '',
          custmgrId: '',
          searchTxt: '',
          businessType: '',
          operationScale: '',
          customerGrade: '',
          geoType: '',
          batchNo: '',
          starGrade: '',
          status: '',
          notes: false
        },
        dialogVisible: false,
        data: [], // 穿梭框数据源
        value1: [],
        renderFunc (h, option) {
          return h('span', option.customerCode + '-' + option.customerDesc)
        }, // 穿梭框显示的字段
        filterMethod (query, item) {
          let temp = item.customerCode + item.customerDesc
          return temp.indexOf(query) > -1
        }, // 穿梭框的过滤方法
        optionsGeoType: [],
        operationStatus: [],
        optionsbusinessType: [],
        optionsCustomerGrade: [],
        operationScaleGroup: [],
        optionsmarketmgrId: [],
        options_batchNo: [],
        options_starGrade: [],
        rtlcatIdGroup: [],
        isMan: false,
        isCus: false,
        isMore: false,
        fileName: ['name', 'code'],
        btnGroups: [{
          name: '新增客户集',
          className: 'btn-danger',
          iconName: 'fa-plus',
          event: this.addCustomerCollClk
        }],
        /** table **/
        tableType: '3',
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            value: 'name', // 列的值
            label: '客户集名称', // 列的显示字段
            align: 'left' // 列的对齐方式，[left, center, right]，选填，默认是left
          }, {
            value: 'modificationNum',
            align: 'left',
            label: '客户数量'
          }, {
            value: 'lastUpdTime',
            align: 'left',
            label: '最新时间'
          }
        ],
        tableData: [],
        dataSource: [], // 当前页的数据
        btns: {
          btnArr: [
            {
              label: '分配客户', // 按钮的名称
              value: 'modify', // 按钮的值
              type: 'warning',
              icon: 'edit',
              functionName: this.modify // 按钮的方法
            },
            {
              label: '修改', // 按钮的名称
              value: 'modify', // 按钮的值
              type: 'warning',
              icon: 'edit',
              functionName: this.modify1 // 按钮的方法
            },
            {
              label: '删除', // 按钮的名称
              value: 'del', // 按钮的值
              type: 'danger',
              icon: 'delete',
              functionName: this.del // 按钮的方法
            },
            {
              label: '顺序维护', // 按钮的名称
              value: 'modify', // 按钮的值
              type: 'warning',
              icon: 'edit',
              functionName: this.modifyOrder // 按钮的方法
            }
          ],
          value: 'operation',
          label: '操作',
          width: '400px'
        },
        /** 新增客户集弹出框 **/
        addCustomerColl: {
          title: '客户集定义',
          type: 'addCustomerColl',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              name: '',
              code: '',
              searchTxt: '',
              shortNm: '',
              companyId: getUser().companyId,
              createdBy: getUser().personId,
              defPersonId: getUser().personId,
              notes: false
            }
          }
        },
        orderCustomer: {
          title: '客户排序',
          type: 'orderCustomer',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              customerCode: '',
              customerDesc: '',
              modificationNum: ''
            }
          }
        },
        moreS: [
          {
            colunm: 'businessType',
            type: 'string'
          },
          {
            colunm: 'operationScale',
            type: 'string'
          },
          {
            colunm: 'customerGrade',
            type: 'string'
          },
          {
            colunm: 'geoType',
            type: 'string'
          },
          {
            colunm: 'status',
            type: 'string'
          }
        ],
        rowIdData: '',
        alldata: ''
      }
    },
    methods: {
      init () {
        let params = {}
        params.defPersonId = getUser().personId
        params.pageNum = this.currentPage
        params.pageSize = this.pageSize
        /* 将已有的参数赋值给分页参数 */
        this.$set(this.reqParams, 'url', BasePath.CUSTOMERGROUP_SELECTLIST)
        this.$set(this.reqParams, 'params', params)
        api.requestJava('POST', BasePath.CUSTOMERGROUP_SELECTLIST, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.totalCount = Number(request.data.count)
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
              this.changeCheckBoxValueNumtoBoolean(this.searchForm)
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      isShow () {
        this.isSelect = !this.isSelect
      },
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      isMoreClk () {},
      queryList () {
        let param = {}
        for (let i = 0; i < this.moreS.length; i++) {
          param[this.moreS[i].colunm] = this.toMoreChange(this.searchForm[this.moreS[i].colunm], this.moreS[i].type)
        }
        param.searchTxt = this.searchForm.searchTxt
        param.batchNo = this.searchForm.batchNo
        param.starGrade = this.searchForm.starGrade
        console.log('查询param', JSON.stringify(param))
        if (Number(getUser().place) === 24) {
          if (this.searchForm.custmgrId !== '') {
            param.custmgrId = this.searchForm.custmgrId
          }
          param.marketmgrId = getUser().personId
        } else if (Number(getUser().place) === 135) {
          param.custmgrId = getUser().personId
        } else {
          if (this.searchForm.marketmgrId !== '') {
            param.marketmgrId = this.searchForm.marketmgrId
          }
          if (this.searchForm.custmgrId !== '') {
            param.custmgrId = this.searchForm.custmgrId
          }
        }
        param.countyDept = getUser().countyId
        param.companyId = getUser().companyId
        param.pageSize = 500
        param.pageNum = 1
        console.log('datapushparam' + JSON.stringify(param))
        api.requestJava('POST', BasePath.ACTIVITY_CUSTOMER_SELECT, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              console.log('客户数：' + request.data.data.length)
              let datapush = []
              for (let i = 0; i < this.value1.length; i++) {
                for (let j = 0; j < this.alldata.length; j++) {
                  if (Number(this.value1[i]) === Number(this.alldata[j].key)) {
                    datapush.push(this.alldata[j])
                  }
                }
              }
              for (let i = 0; i < request.data.data.length; i++) {
                let haves = true
                for (let j = 0; j < this.value1.length; j++) {
                  if (Number(this.value1[j]) === Number(request.data.data[i].rowId)) {
                    haves = false
                    continue
                  }
                }
                if (haves) {
                  datapush.push({
                    key: request.data.data[i].rowId,
                    customerCode: request.data.data[i].customerCode,
                    customerDesc: request.data.data[i].customerDesc
                  })
                }
              }
              console.log('datapush' + JSON.stringify(datapush))
              this.data = datapush
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      modify (index, row) {
        this.rowIdData = row.rowId
        let param = {}
        if (Number(getUser().place) === 24) {
          param.marketmgrId = getUser().personId
        } else if (Number(getUser().place) === 135) {
          param.custmgrId = getUser().personId
        } else {
          param.countyId = getUser().countyDept
        }
        console.log('param', param)
        param.companyId = getUser().companyId
        param.pageSize = 500
        param.pageNum = 1
        api.requestJava('POST', BasePath.ACTIVITY_CUSTOMER_SELECT, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              let datapush = []
              for (let i = 0; i < request.data.data.length; i++) {
                datapush.push({
                  key: request.data.data[i].rowId,
                  customerCode: request.data.data[i].customerCode,
                  customerDesc: request.data.data[i].customerDesc
                })
              }
              this.data = datapush
              this.alldata = datapush
              this.queryCustomerByCustomerGroup(row)
              this.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      modifyOrder (index, row) {
        let param = {}
        param.rtlcatId = row.rowId
        api.requestJava('POST', BasePath.CUSTOMERLISTBYCUSTOMERGROUP, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.$refs.orderCustomerRef.dataSource = request.data.data
              this.$refs.orderCustomerRef.totalCount = request.data.data.length
              this.orderCustomer.data.form.disabled = true
              this.orderCustomer.dialogVisible = true
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      modify1 (index, row) {
        this.addCustomerColl.data.form = row
        this.changeCheckBoxValueNumtoBoolean(row)
        this.addCustomerColl.data.form.disabled = true
        this.addCustomerColl.dialogVisible = true
      },
      queryCustomerByCustomerGroup (row) {
        let param = {}
        param.rtlcatId = row.rowId
        api.requestJava('POST', BasePath.CUSTOMERLISTBYCUSTOMERGROUP, param)
          .then((request) => {
            if (Number(request.status) === 200) {
              let datapush = []
              for (let i = 0; i < request.data.data.length; i++) {
                datapush[i] = request.data.data[i].rowId
              }
              this.value1 = datapush
              console.log('value1', this.value1)
            } else if (Number(request.status) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      del (index, row) {
        this.$confirm('客户集已关联客户，确定删除吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let params = {}
          params.rowId = row.rowId
          api.requestJava('POST', BasePath.CUSTOMERGROUP_DELETE, params)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.init()
                this.$message({type: 'success', message: '删除成功!'})
              } else if (Number(request.data.code) === 401) {
                this.sessionFailDialogObj.dialogVisible = true
              } else {
                throw new Error(JSON.stringify(request))
              }
            })
        }).catch(() => {
          this.$message({type: 'info', message: '已取消删除!'})
        })
      },
      addCustomerCollClk () {
        this.addCustomerColl.dialogVisible = true
      },
      addCustomerCollBack (msg) {
        if (msg) {
          let data = msg.data.form
          let paraminfo = data
          if (paraminfo.notes === true) { paraminfo.notes = 1 } else { paraminfo.notes = 0 } // 是否特殊
          console.log('paraminfo', JSON.stringify(paraminfo))
          let past = BasePath.CUSTOMERGROUP_INSERT
          if (data.rowId !== '') {
            past = BasePath.CUSTOMERGROUP_UPDATE
          }
          api.requestJava('POST', past, paraminfo)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.clearObject()
                this.init()
                this.$message({type: 'success', message: '新增成功!'})
              } else if (Number(request.data.code) === 401) {
                this.sessionFailedDialogObj.dialogVisible = true
              } else {
                throw new Error(JSON.stringify(request))
              }
            })
        }
      },
      orderCustomerBack (msg) {
        console.log(msg)
        var i = 0
        let params = []
        msg.forEach((e) => {
          let param = {}
          param.rowId = msg[i].classifiedId
          param.modificationNum = msg[i].ordernumber
          params.push(param)
          i++
        })
        console.log(JSON.stringify(params))
        api.requestJava('POST', BasePath.CUSTOMERGROUP_UPDATEBATCH, params)
          .then((request) => {
            if (Number(request.status) === 200) {
              this.clearObject()
              this.init()
              this.$message({type: 'success', message: '更新成功!'})
            } else if (Number(request.status) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      handleClose () {
        this.rowIdData = ''
        this.value1 = []
        this.dialogVisible = false
      },
      submit () {
        console.log('---', this.value1)
        let param = {}
        let rowId = this.rowIdData
        param.rtlcatId = rowId
        let datapush = []
        for (let i = 0; i < this.value1.length; i++) {
          datapush.push({
            rtlcatId: rowId,
            customerId: this.value1[i]
          })
        }
        console.log('datapush', datapush)
        api.requestJava('POST', BasePath.CUSTOMERGROUPDETAIL_DELETE, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              if (datapush.length > 0) {
                api.requestJava('POST', BasePath.CUSTOMERGROUP_INSERTCUSTOMERS, datapush)
                  .then((request) => {
                    if (Number(request.data.code) === 200) {
                      this.init()
                      this.$message({type: 'success', message: '更新成功!'})
                      this.dialogVisible = false
                      this.isSelect = false
                    } else if (Number(request.data.code) === 401) {
                      this.sessionFailedDialogObj.dialogVisible = true
                    } else {
                      throw new Error(JSON.stringify(request))
                    }
                  })
              }
              this.$message({type: 'success', message: '更新成功!'})
              this.dialogVisible = false
              this.isSelect = false
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      clearObject () {
        let temp = {
          title: '商品集定义',
          type: 'addCustomerColl',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              name: '',
              code: '',
              searchTxt: '',
              shortNm: '',
              companyId: getUser().companyId,
              createdBy: getUser().personId,
              defPersonId: getUser().personId
            }
          }
        }
        Object.assign(this.addCustomerColl, temp)
      },
      toMoreChange (values, type) {
        let result = ''
        for (let i = 0; i < values.length; i++) {
          if (type === 'int') {
            result = result + values[i] + ','
          } else if (type === 'string') {
            result = result + "'" + values[i] + "'" + ','
          }
        }
        if (result.length > 0) {
          result = result.substr(0, result.length - 1)
        }
        return result
      },
      onchange () {
        this.rtlcatIdGroup = []
        let params = {}
        params.status = 1
        params.manager = this.searchForm.marketmgrId
        params.companyId = getUser().companyId
        console.log('param', JSON.stringify(params))
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.rtlcatIdGroup = request.data.data
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      changeCheckBoxValueNumtoBoolean (src) {
        if (Number(this.addCustomerColl.data.form.notes) === 1) { this.addCustomerColl.data.form.notes = true } else { this.addCustomerColl.data.form.notes = false } // 是否特殊
      }
    },
    components: {
      _BTN_FILTER,
      _POPUP,
      _ORDERPOPUP,
      _TABLE
    }
  }
</script>
<style scoped rel="stylesheet/scss" lang="scss">
  .addS {
    margin-bottom: 10px;
  }
  .btn-more {
    background-color: #337ab7;
    color: #FFF
  }
  .qq {
    margin-left:45px;
  }
  .searchForm {
    margin-left: 20px;
    margin-bottom: 20px;
    margin-top: 42px;
  }
  .button{
    float: right;
    margin-right: 30px;
  }
  .transfer{
    margin-top: 42px;
    margin-left: 30px;
  }
</style>
