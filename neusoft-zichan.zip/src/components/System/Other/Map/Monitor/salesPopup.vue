<!-- 徐晓菁 -->
<template>
  <div>
    <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :close-on-press-escape="false"  :size='dialogObj.size' :before-close="cancleClk" v-popupdra-directive="{'show': dialogObj.dialogVisible}">
      <el-form :model="dialogObj.data.form" :rules="addrules" ref="addForm" label-width="100px">
        <el-table :data="this.dialogObj.data.form.products"  >
          <el-table-column prop="cigProductNm" label="商品名称" width="200"></el-table-column>
          <el-table-column prop="orderQty" label="订货量（条）"  ></el-table-column>
          <el-table-column prop="price" label="单价（元）"  ></el-table-column>
          <el-table-column prop="orderAmt" label="总金额（元）" ></el-table-column>
        </el-table>
      </el-form>
      <div slot="footer" class="dialog-footer" style="text-align: right">
        <el-button @click="cancleClk('addForm')">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    props: ['dialogObj'],
    mounted () {
    },
    data () {
      return {
        addrules: {}
      }
    },
    methods: {
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      }
    },
    components: {
    }
  }
</script>
