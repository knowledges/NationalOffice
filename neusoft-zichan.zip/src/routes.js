import LoginView from './components/Login.vue'
import ModifyPwdModular from './components/ModifyPwd.vue'
import SurveyModular from './components/Consumer/CustomSurvey/Questionnaire/Investigation/Survey.vue'
// import CeshiModel from './components/Consumer/CustomSurvey/Questionnaire/Investigation/ceshi.vue'
import TableApi from './components/Template/table/tableAPI.vue'
import cascaderApi from './components/Template/Cascader/Cascader.vue'
import MulitCascader from './components/Template/MultiSelectCascader/MultiSelectCascader.vue'
import tableCascader from './components/Template/Restructure/TableAPI.vue'
// import DemoCascader from './components/Demo/User.vue'
// Routes
const routes = [
  {
    path: '/login',
    component: LoginView,
    name: 'Login',
    meta: {
      keepAlive: false
    }
  },
  {
    path: '/modifypwd',
    component: ModifyPwdModular,
    name: 'ModifyPwd',
    meta: {
      keepAlive: false
    }
  },
  /**
   * @params fromdId 表单Id
   * @params stepId 提交之后，查答案的
   * @params userId 当前用户
   * @params customerId 当前拜访客户id
   * @params brandId 关联的品牌
   * @params companyId 公司id
   * @params personId 分公司id
   * @params disabled 是否可以执行操作
   * @params visitingRecId 拜访记录id
   * @params planId 活动id
   * @params visitor 拜访人id
   * @params visitorName 拜访人姓名
   * @params customerName 当前拜访客户name
   */
  {
    path: '/survey/:str',
    component: SurveyModular,
    name: 'Survey',
    meta: {
      description: '问卷调查设计',
      keepAlive: false
    }
  },
  // {
  //   path: '/ceshi/:str',
  //   component: CeshiModel,
  //   name: 'Ceshi',
  //   meta: {
  //     description: '测试的demo',
  //     keepAlive: false
  //   }
  // },
  {
    path: '/TableApi',
    component: TableApi,
    name: 'TableApi',
    meta: {
      description: '问卷调查设计',
      keepAlive: false
    }
  },
  {
    path: '/cascaderApi',
    component: cascaderApi,
    name: 'cascaderApi',
    meta: {
      description: 'cascader级联',
      keepAlive: false
    }
  },
  {
    path: '/MulitCascader',
    component: MulitCascader,
    name: 'MulitCascader',
    meta: {
      description: 'cascader多选级联',
      keepAlive: false
    }
  },
  {
    path: '/tableCascader',
    component: tableCascader,
    name: 'tableCascader',
    meta: {
      description: 'cascader多选级联',
      keepAlive: false
    }
  }
  // {
  //   path: '/userDemo',
  //   component: DemoCascader,
  //   name: 'UserDemo',
  //   meta: {
  //     description: 'cascader多选级联',
  //     keepAlive: false
  //   }
  // }
]

export default routes
