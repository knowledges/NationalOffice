<template>
  <li id="paragraphQuModel">
    <!--段落说明 -->
    <div class="dwToolbar_icon"></div>
    <div class="dwQuTypeModel">
      <div class="surveyQuItemBody quDragBody">
        <div class="initLine"></div>
        <div class="quInputCase" style="display: none;">
          <input type="hidden" name="quType" value="PARAGRAPH" >
          <input type="hidden" name="itemCode" value=""> <!-- 唯一编码 -->
          <input type="hidden" name="sortNbr" value="0"> <!--排序-->
          <input type="hidden" name="saveTag" value="0"> <!-- 是否修改 -->
          <input type="hidden" name="hv" value="2"> <!-- 类型 2：基础类型 3：表格类型 -->

          <!--<input type="hidden" name="quId" value="">-->
          <!--<input type="hidden" name="orderById" value="0"/>-->
          <!--<input type="hidden" name="saveTag" value="0">-->
          <!--<input type="hidden" name="hoverTag" value="0">-->
          <!--<input type="hidden" name="isRequired" value="1">-->
          <!--<input type="hidden" name="hv" value="2">-->
          <!--<input type="hidden" name="randOrder" value="0">-->
          <!--<input type="hidden" name="cellCount" value="0">-->
          <!--<div class="quLogicInputCase">-->
            <!--<input type="hidden" name="quLogicItemNum" value="0">-->
          <!--</div>-->
        </div>
        <div class="surveyQuItem">
          <div class="surveyQuItemLeftTools">
            <ul class="surveyQuItemLeftToolsUl">
              <!--<li title="移动排序" class="dwQuMove"><div class="dwQuIcon"></div></li>
              <li title="设置" class="dwQuSet"><div class=dwQuIcon></div></li>
              <li title="逻辑" class="dwQuLogic"><div class="dwQuIcon"><div class="quLogicInfo"></div></div></li> -->
              <li title="删除" class="dwQuDelete"><div class="dwQuIcon"></div></li>
            </ul>
          </div>
          <div class="surveyQuItemRightTools">
            <ul class="surveyQuItemRightToolsUl">
              <li class="questionUp"><div class="dwQuIcon"></div></li>
              <li class="questionDown"><div class="dwQuIcon"></div></li>
            </ul>
          </div>
          <div class="surveyQuItemContent" style="min-height: 45px;">
            <div class="quCoTitle">
              <div class="quCoNum" style="display: none;">1、</div>
              <div class="editAble quCoTitleEdit" ><p><strong>分段标记</strong></p></div>
              <input type="hidden" name="quTitleSaveTag" value="0">
            </div>
          </div>
        </div>
      </div>
    </div>
  </li>
</template>
