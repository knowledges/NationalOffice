<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false" :size='dialogObj.size'>
    <div  class="container-fluid">
      <el-form :model="dialogObj.data.form"  label-width="160px" ref="query">
        <el-row>
          <el-col :gutter="24">
            <el-col :span='8'>
              <el-form-item prop="billType" label="单据类别" >
                <el-select v-model="dialogObj.data.form.billType" visible-change="false" :clearable="true" placeholder="请选择" :disabled=true>
                  <el-option
                    v-for="item in options_billType"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span='8'>
              <el-form-item prop="billNo" label="单据编号" >
                <el-input v-model="dialogObj.data.form.billNo" :disabled=true></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='8'>
              <el-form-item prop="bizDate" label="业务日期" >
                <el-date-picker
                  v-model="dialogObj.data.form.bizDate"
                  type="date"
                  :disabled=true
                  placeholder="选择日期">
                </el-date-picker>
              </el-form-item>
            </el-col>
          </el-col>
          <el-col :gutter="24">
            <el-col :span='8'>
                <el-form-item prop="handlerId" label="领用主体" >
                  <el-select v-model="dialogObj.data.form.handlerNm" filterable :clearable="true" placeholder="请选择" :disabled=true>
                    <el-option
                      v-for="item in options_handlerId"
                      :key="item.rowId"
                      :label="item.employeeName"
                      :value="item.rowId">
                    </el-option>
                  </el-select>
                </el-form-item>
            </el-col>
            <el-col :span='8'>
              <div v-if="this.dialogObj.data.form.billType === '11'">
                <el-form-item prop="customerDesc" label="供货商" >
                  <el-input v-model="dialogObj.data.form.customerDesc" :disabled=true></el-input>
                </el-form-item>
              </div>
              <div v-else-if="this.dialogObj.data.form.billType === '21'">
                <el-form-item prop="customerId" label="发放主体" >
                  <el-input v-model="dialogObj.data.form.customerDesc" :disabled=true></el-input>
                </el-form-item>
              </div>
              <div v-else>
                <el-form-item prop="customerId" label="发放主体" >
                  <el-select v-model="dialogObj.data.form.customerDesc" filterable :clearable="true" placeholder="请选择" :disabled=true>
                    <el-option
                      v-for="item in options_customerId"
                      :key="item.rowId"
                      :label="item.employeeName"
                      :value="item.rowId">
                    </el-option>
                  </el-select>
                </el-form-item>
              </div>
            </el-col>
          </el-col>
        </el-row>
      </el-form>
      <div>
        <tableVue
          ref="tableGrid"
          stripe
          maxHeight="500"
          column-type="selection"
          :data="dataSource"
          :columns="columns"
          :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
          :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
          @cell-dblclick="celldbClick"></tableVue>
      </div>
      <div>
        <el-row>
          <el-col :gutter="20">
            <el-col :span='8'>
              <el-form-item  prop="signature" label="签名" align="center" >
              </el-form-item>
              <div id="signaturePic">
                <uploadTemp style="margin:20px;" :files="dialogObj.data.form.signature" ref="signature" :operation="false"></uploadTemp>
              </div>
            </el-col>
          </el-col>
        </el-row>
      </div>
    </div>
  </el-dialog>
</template>
      <script>
        import tableVue from '@/components/Template/table/Table.vue'
        import { getCodeList } from '@/config/info'
//        import BasePath from '@/config/BasePath'
        import uploadTemp from '@/components/template/PicUpload/PicUpload.vue'
//        import api from '@/api'
//        import axios from 'axios'
//        import log from '@/log'
        export default {
          props: ['dialogObj'],
          mounted () {
            getCodeList('RM_MTRL_BILL_TYPE', (data) => {
              this.options_billType = data
            }) // 单据类别
//            let _this = this
//            let allParam = {} // 所有人员
//            allParam.companyId = getUser().companyId
//            allParam.fields = {include: 'employeeName,rowId'}
//            let cusParam = {} // 客户经理下的客户
//            cusParam.custmgrId = getUser().personId
//            cusParam.fields = {include: 'customerDesc,rowId'}
//            axios.all([
//              api.requestJava('POST', BasePath.EMPLOYEE_SELECT, allParam), // 所有人员
//              api.requestJava('POST', BasePath.CUSTOMER_SELECT, cusParam) // 客户经理下的客户
//            ])
//              .then(axios.spread(function (_allId, _cusId) {
//                _this.options_handlerId = JSON.parse(JSON.stringify(_allId.data.data))
//                _this.options_customerId = JSON.parse(JSON.stringify(_allId.data.data))
//              }))
            this.init()
          },
          data () {
            return {
              value: '',
              form: {},
              props: {
                value: 'label',
                children: 'cities'
              },
              options_all: [],
              options_cust: [],
              options_billType: [],
              options_handlerId: [],
              options_customerId: [],
              /** table **/
              currentPage: 1, // 默认当前第一页
              pageSize: 100,  // 默认每页20条数据
              pageSizes: [50, 100, 200], // 分页数选择项
              selectSells: [],
              totalCount: 0, // 表格总记录数
              hasPagination: true, // 是否有分页
              columns: [ // 表格列
                { label: '物料代码', prop: 'materialCd', columnsProps: {width: 250} },
                { label: '物料名称', prop: 'materialNm', columnsProps: {width: 350} },
                { label: '单位', prop: 'unit', columnsProps: {width: 250} },
                { label: '数量', prop: 'quantity', columnsProps: {type: 'input'}, eventChange: this.selectChange, eventKey: this.eventKey }
              ],
              tableData: [],
              tableType: '4',
              planTime: '',
              dataSource: [], // 当前页的数据
              /** filter **/
              templTableData: [], // 临时记录tableDate的值
              headerClick () {},
              sortChange (msg) {},
              rowClick (msg) {}
            }
          },
          methods: {
            init () {
              this.tableData = this.dialogObj.data.form.detailEntities
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            },
            clearMethod () {
              this.dialogObj.data.form.rowId = ''
              this.dialogObj.data.form.billType = ''
              this.dialogObj.data.form.billNo = ''
              this.dialogObj.data.form.handlerId = ''
              this.dialogObj.data.form.handlerNm = ''
              this.dialogObj.data.form.bizDate = ''
              this.dialogObj.data.form.customerId = ''
              this.dialogObj.data.form.customerDesc = ''
              this.dialogObj.data.form.detailEntities = []
            },
            queryData (page, size) {
              // 前段分页
              this.totalCount = this.tableData.length
              this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
            }, // 分页请求
            select (selection, index) {
              if (selection[0] !== undefined) {
                this.sel_all = []
                for (var i in selection) {
                  this.sel_all.push(selection[i].rowId)
                }
                console.log(this.sel_all)
              }
            },
            celldbClick (row, column, cell, event) {
              this.$set(row, '_edit', !row._edit)
              if (!row._edit) {
                if (!this.numberChange(row)) {
                  row._edit = true
                } else {
                  this.$set(row, '_edit', !row._edit)
                }
              }
            }
          },
          components: {
            tableVue, uploadTemp
          },
          watch: {}
        }
      </script>

      <style scoped>
        .item__label_popup {
          text-align: right;
          vertical-align: middle;
          float: right;
          font-size: 14px;
          color: #48576a;
          line-height: 1;
          padding: 11px 8px 11px 0;
          box-sizing: border-box;
          /* display: inline-block; */
        }
        .el-input, .el-input__inner {
          /*width: '';*/
          display: inline-block;
        }
      </style>
