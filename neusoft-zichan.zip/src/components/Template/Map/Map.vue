<style scoped>
  #map{
    position: absolute;
    display: inline-block;
    width: 100%;
    height: 100%;
    background: #FFF;
  }
</style>
<template>
  <div id="map"></div>
</template>
<script>
  import {MP, ShowMap, getCityShowMap, createMarker, drawLine, calcDis} from './map.js'
  import config from '@/config'
  var [BMap, map] = ''
  export default {
    name: 'BaiDu_Map',
    props: {
      zoom: { // 变焦
        type: Number,
        default: 12
      },
      coors: { // 坐标 -- 客户经理坐标
        type: Array,
        default: []
      },
      coorGroup: { // 坐标 -- 零售户坐标
        type: Array,
        default: []
      },
      place: {
        type: Number,
        default: 24
      }
    },
    created () { },
    mounted () {
      this.init()
    },
    data () {
      return {
        ak: 'sFGGCnZu8HcewIdGMFGGaGypsfILG36G',
        BMap: '',
        imgUrl: config.root + '/static/img/icon_map.png',
        local_lng: '',
        local_lat: '',
        zoomGroup: [],
        tilesloaded: true
      }
    },
    methods: {
      init () {
        var _this = this
        Promise.all([MP(this.ak)]).then((ARR) => {
          BMap = ARR[0]
          map = new BMap.Map('map')
          getCityShowMap((result) => {
            let params = result.center
            _this.local_lng = params.lng
            _this.local_lat = params.lat
            /* 在首页的时候'采用最近一次拜访客户时签到的坐标为地图中心' */
            /* 在客户经理详情页面'采用零售户的坐标为地图中心' */
            if (this.$route.name === 'MapMonitor') {
              if (this.coorGroup[0] !== undefined && Number(this.coorGroup[0].lng) > 0 && Number(this.coorGroup[0].lat) > 0) {
                ShowMap(map, this.coorGroup[0], this.zoom)
              } else {
                ShowMap(map, params, this.zoom)
              }
            } else {
              if (this.coors[0] !== undefined && Number(this.coors[0].lng) > 0 && Number(this.coors[0].lat) > 0) {
                ShowMap(map, this.coors[0], this.zoom)
              } else {
                ShowMap(map, params, this.zoom)
              }
            }
            this.getPowerDis(map)
          })
        })
        .catch((reason) => {
          console.log('Handle rejected promise (' + reason + ') here.')
        })
      },
      getPowerDis (map) {
        if (Number(this.place) === 24 || Number(this.place) === 9999) {
          /* 批注的标签样式 */
          let styleObj = {
            color: '#FFF',
            fontSize: '12px',
            height: '20px',
            lineHeight: '20px',
            fontFamily: '微软雅黑',
            position: 'relative',
            padding: '5px 8px',
            border: '2px solid #fff',
            backgroundColor: 'green',
            borderRadius: '6px',
            letterSpacing: '2px'
          }
          /**
           * @param 【array obj】 地图实例对象
           * 需要修改批注（icon）的默认样式【true：修改， false：不修改】
           * @param array [1,2] 批注icon 修改偏移的坐标
           * @param obj {x:15, y: -16} 批注标签样式的偏移坐标
           * @param styleObj 批注的标签样式
           * */
          this.customMarker(map, false, null, {x: 15, y: -16}, styleObj)
        } else if (Number(this.place) === 135) {
          var count = 0
          for (var k = 0; k < this.coorGroup.length; k++) {
            ++count
//            console.log('坐标：', this.coorGroup[k])
            if (isNaN(Number(this.coorGroup[k].lng)) ||
              isNaN(Number(this.coorGroup[k].lat)) ||
              Number(this.coorGroup[k].lng) <= 0 ||
              Number(this.coorGroup[k].lat) <= 0) {
              /* 使用地图默认位置 */
//              this.coorGroup[k].lng = this.local_lng
//              this.coorGroup[k].lat = this.local_lat
            } else {
              if (Number(k) + 1 >= this.coorGroup.length) {
                drawLine(map, this.coorGroup[k], this.coorGroup[k])
              } else {
                drawLine(map, this.coorGroup[k], this.coorGroup[k + 1])
              }
              let points = new BMap.Point(this.coorGroup[k].lng, this.coorGroup[k].lat)
              let marker = new BMap.Marker(points)
              marker.customerName = this.coorGroup[k].customerName
              marker.customerId = this.coorGroup[k].customerId
              marker.setTitle(marker.customerName)
              let label = new BMap.Label(Number(count), {offset: new BMap.Size(5, 0)})
              if (Number(count) > 9) {
                label = new BMap.Label(Number(count), {offset: new BMap.Size(0, 0)})
              }
              label.setStyle({
                color: '#FFF',
                fontSize: '12px',
                height: '20px',
                lineHeight: '20px',
                fontFamily: '微软雅黑',
                position: 'relative',
                border: 'none',
                backgroundColor: 'none',
                fontWeight: '700'
              })
              map.addOverlay(marker)
              marker.setLabel(label)
              marker.addEventListener('click', (e) => {
                var info = {}
                info.customerId = marker.customerId
                this.$emit('mapBack', info)
              })
            }
          }
        }
      },
      customMarker (map, isUpdateIcon, iconCoor, labsCoor, styleObj) {
        for (let i in this.coors) {
//          console.log('heeell', this.coors[i])
          if (isNaN(Number(this.coors[i].lng)) ||
            isNaN(Number(this.coors[i].lat)) ||
            Number(this.coors[i].lng) <= 0 ||
            Number(this.coors[i].lat) <= 0) {
            /* 使用地图默认位置 */
            this.coors[i].lng = this.local_lng
            this.coors[i].lat = this.local_lat
          }
          if (Number(this.place) === 135) {
            this.coors[i].name = Number(i) + 1
          }
          createMarker(map, this.coors[i], isUpdateIcon, iconCoor, this.imgUrl, labsCoor, styleObj)
        }
      }, // 自定义创建批注方法
      zoomIn (x, y, customerId, customerName) {
        console.log('定位的坐标：', x, y)
        let _this = this
        var allOverlay = map.getOverlays()
        let point = new BMap.Point(x, y)
        map.centerAndZoom(point, this.zoom)
        for (var k = 0; k < allOverlay.length; k++) {
          if (allOverlay[k].V.title !== '' && allOverlay[k].V.title !== undefined) {
            if (allOverlay[k].V.title === customerName) {
//              console.log('标题：', allOverlay[k].V.title)
              allOverlay[k].setAnimation(BMAP_ANIMATION_DROP)
              allOverlay[k].addEventListener('click', function (e) {
                var info = {}
                info.customerId = customerId
                _this.$emit('mapBack', info)
              })
            } else {
              allOverlay[k].setAnimation(null)
            }
          }
        }
      },
      calculateMileage (positionAX, positionAY, positionBX, positionBY) {
//        alert(calcDis(map, positionAX, positionAY, positionBX, positionBY))
        var tmp = calcDis(map, positionAX, positionAY, positionBX, positionBY)
        this.$emit('backCalcDis', tmp)
//        return calcDis(map, positionAX, positionAY, positionBX, positionBY)
      }
    },
    watch: {
      coors (val, old) {
        if (val.length > 0) {
          setTimeout(() => {
            this.init()
          })
        }
      }
    }
  }
</script>
