<template>
  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <!--<div class="user-panel">-->
      <!--<div class="pull-left image">-->
      <!--<img :src="pictureUrl" />-->
      <!--</div>-->
      <!--<div class="pull-left info">-->
      <!--<div>-->
      <!--<p class="white">{{ displayName }}</p>-->
      <!--</div>-->
      <!--<a href="javascript:;">-->
      <!--<i class="fa fa-circle text-success"></i> Online-->
      <!--</a>-->
      <!--</div>-->
      <!--</div>-->

      <!--search form (Optional)-->
      <form v-on:submit.prevent="searchClk" class="sidebar-form">
        <div class="input-group">
          <input type="text"
                 name="search"
                 id="search"
                 v-model="search"
                 class="search form-control"
                 data-toggle="hideseek"
                 placeholder="搜索菜单"
                 data-list=".sidebar-menu">
          <span class="input-group-btn">
            <button type="submit" name="search" id="search-btn" class="btn btn-flat">
              <i class="fa fa-search"></i>
            </button>
          </span>
        </div>
      </form>
      <!--/.search form-->

      <!-- Sidebar Menu -->
      <ul class="sidebar-menu">
        <sidebar-menu :model="slide" v-for="(slide, key) in Menus" :key="key"/>
      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>
</template>
<script>
  import SidebarMenu from './SidebarMenu'
  import { mapState } from 'vuex'
  export default {
    name: 'Sidebar',
    props: ['displayName', 'pictureUrl'],
    data () {
      return {
        Menus: [],
        powerMenus: [],
        search: ''
      }
    },
    mounted () {
      let _this = this
      _this.init()
      window.onresize = function temp () {
        _this.init()
      }
      var routingIdx = sessionStorage.getItem('routingIndex') !== null ? sessionStorage.getItem('routingIndex') : this.$route.meta.parent
      this.$store.dispatch('setRouteIdx', Number(routingIdx))
      this.$nextTick(() => {
        setTimeout(() => {
          this.getMenus()
        }, 200)
      })
    },
    methods: {
      init () {
        let tmp = document.documentElement.clientHeight - 80
        document.getElementsByClassName('sidebar')[0].style.height = tmp + 'px'
        document.getElementById('app').style.height = document.documentElement.clientHeight + 'px'
      },
      getMenus () {
        let menu = JSON.parse(sessionStorage.getItem('powerMenu'))
        if (menu !== null && menu !== '' && menu !== undefined) {
          this.powerMenus = menu
        } else {
          this.powerMenus = this.powerMenu
        }
        this.Menus = this.powerMenus.children.length > 0 && this.powerMenus.children[Number(this.routeIdx)].children
      },
      searchClk () {
        this.searchMenus(this.search, this.powerMenus.children)
      },
      searchMenus (lab, item) {
        if (lab !== '') {
          item.forEach((val, key) => {
            if (val.label.indexOf(lab) >= 0) {
              this.Menus = []
              return this.Menus.push(val)
            }
            if (val.children && val.children.length > 0) {
              this.searchMenus(lab, val.children)
            }
          })
        } else {
          this.Menus = this.powerMenus.children[Number(this.routeIdx)].children
        }
      }
    },
    computed: {
      ...mapState([
        'powerMenu',
        'routeIdx'
      ])
    },
    components: { SidebarMenu },
    watch: {
      'routeIdx' (val, old) {
        this.getMenus()
      },
      '$route' (val, old) {
        setTimeout(() => {
          if (Number(sessionStorage.getItem('routingIndex')) !== this.index) {
            this.$nextTick(() => {
              this.index = Number(sessionStorage.getItem('routingIndex'))
              this.Menus = this.powerMenus.children[this.index].children
            })
          }
        })
      }
    }
  }
</script>
<style scoped>
  .user-panel .image img {
    border-radius: 50%;
  }
</style>
