<!--李晶-->
<!--工作小结统计-->
<style rel="stylesheet/scss" lang="scss" scoped></style>
<template>
  <div class="container-fluid" style="height: 99%">
    <el-row class="filter_style">
      <el-col :gutter="24">
        <div class="text-right">
          <el-date-picker
            v-model="timer"
            type="daterange"
            @change="rangeTime"
            placeholder="选择日期范围">
          </el-date-picker>
          <!--<DatePickerTemp @on-change="rangeTime" :types="daterange" :quick="quick"/>-->
          <el-button type="primary" @click="findClk">查询</el-button>
        </div>
      </el-col>
    </el-row>
    <div style="height: calc(100% - 94px)">
      <iframe id="myIframe" :src="htl" frameborder="0" allowtransparency="true" width="100%" height="100%" scrolling="yes"></iframe>
    </div>
  </div>
</template>
<script>
  import config from '@/config'
  import {getUser} from '@/config/info'
  import {dateFormat} from '@/utils/dateFormat'
  import DatePickerTemp from '@/components/Template/DatePicker/DatePickerTemp.vue'
  export default {
    name: 'ReportVisitStatistics',
    props: {},
    mounted () {
      var date = new Date()
      this.timer = [new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 1), new Date(date.getFullYear(), date.getMonth(), date.getDate(), 23, 59)]
      this.start_expected = dateFormat(Date.parse(this.timer[0]), 'YYYY-MM-DD')
      this.end_expected = dateFormat(Date.parse(this.timer[1]), 'YYYY-MM-DD')
      this.findClk()
    },
    data () {
      return {
        timer: [],
        start_expected: '',
        end_expected: '',
        daterange: 'daterange',
        quick: true,
        company_id: '',
        county_dept: '',
        htl: ''
      }
    },
    methods: {
      rangeTime (val) {
        var tmp = val.split(' - ')
        this.start_expected = tmp[0]
        this.end_expected = tmp[1]
      },
      findClk () {
        var reportId = ''
        if (this.start_expected === '' && this.end_expected === '') {
          this.$notify({
            title: '警告',
            message: '时间范围不能为空',
            type: 'warning'
          })
        } else {
          // 省公司
          if (Number(getUser().unitLevel) === 1) {
            reportId = '5204d869-c599-4ae8-8d47-dac53b288db6'
            this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&begin_date=' + this.start_expected + '&end_date=' + this.end_expected
          } else if (Number(getUser().unitLevel) === 2) {
            // 市公司
            if (getUser().countyId === null || getUser().countyId === 'null') {
              reportId = 'b5d5e822-bfa3-4f04-8926-0b4626ad1877'
              this.company_id = getUser().companyId
              this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&begin_date=' + this.start_expected + '&end_date=' + this.end_expected + '&company_id=' + this.company_id
              // 分公司
            } else if (getUser().countyId !== null) {
              reportId = '0368900b-b3c1-4d51-a311-0a1c0582efd3'
              this.county_dept = getUser().countyId
              this.htl = config.REPORT_FORM + '/report/Report-ResultAction.html?reportId=' + reportId + '&begin_date=' + this.start_expected + '&end_date=' + this.end_expected + '&county_id=' + this.county_dept
            }
          }
        }
      }
    },
    components: {
      DatePickerTemp
    },
    watch: {}
  }
</script>

