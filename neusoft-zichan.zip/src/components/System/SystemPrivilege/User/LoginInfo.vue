<!--赵继越-->
<template>
  <div class="container-fluid">
    <_BTN_FILTER :isMore="isMore" :btnGroups="btnGroups" :fileName="fileName"
                 @on-click="exportEve" :tableData="tableData"/>
    <div>
      <_TABLE :columns="columnHeader" :tableData="dataSource" :tableHeight="400"
              :sortChange="sortChange" :rowClick="rowClick" :btnMode=true :btns="btns"
              :pageSizes="pageSizes" :currentPage=currentPage :pageSize=pageSize
              :totalCount=totalCount :queryData=this.queryData
              :checkBox=true
              :select="select" :selectAll="selectAll" :hasPagination="true"
              ref="tableGrid" :tableType=tableType :headerClick="headerClick"></_TABLE>
    </div>
    <!--<_POPUP :dialogObj='updateLoginObj' @confirmBack="updateBack"/>-->
    <_POPUP :dialogObj='moreDialogobj' @confirmBack="moreBack"/>
    <_POPUP :dialogObj='sessionFailedDialogObj' @confirmBack="sessionFailedBack" />-
    <_POPUP :dialogObj='settingCodeDialogObj' @confirmBack="settingCode" />
    <_POPUP :dialogObj='insertCodeDialogObj' @confirmBack="insertCode" />
    <_POPUP :dialogObj='addLoginDialogObj' @confirmBack="addBack"/>


  </div>
</template>
<script>
  import _TABLE from '@/components/Template/TabPagin/Table.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import api from '@/api'
  import log from '@/log'
  export default {
    mounted () {
      /** 调用初始化数据 **/
      this.init()
    },
    data () {
      return {
        rowId: '',
        isSelect: true,
        isMore: true, // 查询更多条件
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['idType', 'idNo'],
        btnGroups: [
          {
            name: '返回',
            className: 'btn-warning',
            iconName: 'fa-backward',
            event: this.backClk
          },
          {
            name: '新增',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.addClk
          }
        ],
        /** table **/
        tableType: '4',
        currentPage: 1, // 默认当前第一页
        pageSize: 10,  // 默认每页20条数据
        pageSizes: [10, 20, 40, 50], // 分页数选择项
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            value: 'idType', // 列的值
            label: '登录类型', // 列的显示字段
            align: 'left' // 列的对齐方式，[left, center, right]，选填，默认是left
          }, {
            value: 'idNo',
            align: 'left',
            label: '备用账号'
          }, {
            value: 'remark',
            label: '备注',
            align: 'left'
          }
        ],
        /** 表格数据 **/
        tableData: [],
        dataSource: [], // 当前页的数据
        btns: {
          btnArr: [
            {
              label: '修改', // 按钮的名称
              value: 'modify', // 按钮的值
              type: 'warning',
              icon: 'edit',
              functionName: this.modify // 按钮的方法
            },
            {
              label: '删除',
              value: 'del',
              type: 'danger',
              icon: 'delete',
              functionName: this.del
            }
          ],
          value: 'operation',
          label: '操作',
          width: '200px'
        },
        /** 弹出层 **/
        addLoginDialogObj: {
          title: '新增账户',
          type: 'addNo',
          dialogVisible: false,
          data: {
            form: {
              idType: '',
              idNo: '',
              remark: ''
            }
          }
        },
        settingCodeDialogObj: {
          title: '修改用户',
          type: 'editLogin',
          dialogVisible: false,
          data: {
            form: {
              rowId: '',
              idType: '',
              idNo: '',
              remark: ''
            }
          }
        },
        insertCodeDialogObj: {
          title: '设置添加用户',
          type: 'addCode',
          dialogVisible: false,
          data: {
            form: {
              idType: '',
              idNo: '',
              remark: ''
            }
          }
        },
        sessionFailedDialogObj: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        moreDialogobj: {
          title: '查询',
          type: 'query',
          dialogVisible: false,
          data: {
            form: {
              idType: '',
              idNo: ''
            }
          }
        }
      }
    },
    methods: {
      /** 初始化数据方法 **/
      init () {
        let param = {}
        param.userId = this.$route.params.rowId
        api.requestJava('POST', '/system/userid/selectList.do', param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
        api.requestJava('POST', '/system/user/selectList.do', param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData.userName = request.data.data.userName
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      backClk () {
        this.$router.push('/User')
      },
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      select (selection, index) {
        if (selection[0] !== undefined) {
          this.sel_all = []
          this.sel_allRole = []
          for (var i in selection) {
            let param = {}
            param.rowId = selection[i].rowId
            this.sel_all.push(param)
          }
          console.log(this.sel_all)
        }
      }, // 选中某1条
      selectAll (data) {
        this.sel_all = []
        for (var i in data) {
          let param = {}
          param.rowId = data[i].rowId
          this.sel_all.push(param)
        }
      }, // 全选
      addClk () {
        this.clearObject()
        this.addLoginDialogObj.title = '新增用户'
        this.addLoginDialogObj.dialogVisible = true
      }, // 新增
      modify (index, row) {
        Object.assign(this.settingCodeDialogObj.data.form, row)
        this.$set(this.settingCodeDialogObj.data.form, 'oldIdNo', row.idNo)
        this.settingCodeDialogObj.data.form.status = (Number(row.status) === 1)
        this.settingCodeDialogObj.data.form.loginFlag = ((row.loginFlag) === 'Y')
        /* TODO 公司和部门替换为字典 */
        this.settingCodeDialogObj.title = '修改用户'
        this.settingCodeDialogObj.dialogVisible = true
      }, // 修改
      del (index, row) {
        console.log(row.rowId)
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let param = {}
          param.rowId = row.rowId
          api.requestJava('POST', '/system/userid/delete.do', param)
            .then((request) => {
              if (Number(request.data.code) === 200) {
                this.init()
                this.$message({type: 'success', message: '删除成功!'})
              } else if (Number(request.data.code) === 401) {
                this.sessionFailedDialogObj.dialogVisible = true
              } else {
                throw new Error(JSON.stringify(request))
              }
            })
        }).catch(() => {
          this.$message({type: 'info', message: '已取消删除!'})
        })
      },  // 删除
      isMoreClk () {
        this.moreDialogobj.dialogVisible = true
      }, // 更多条件
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = this.currentPage
        let size = this.pageSize
        this.dataSource = JSON.parse(val).filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      addBack (msg) {
        if (msg) {
          this.add(msg)
        } else {
          this.clearObject()
        }
      },
      add (msg) {
        let data = msg.data.form
        let paraminfo = data
        paraminfo.userId = this.$route.params.rowId
        api.requestJava('POST', '/system/userid/insert.do', paraminfo)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.clearObject()
              this.init()
              this.$message({type: 'success', message: '新增成功!'})
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      settingCode (msg) {
        let paraminfo = msg.data.form
        api.requestJava('POST', '/system/userid/update.do', paraminfo)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.init()
              this.$message({type: 'success', message: '设置修改成功!'})
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      insertCode (msg) {
        let data = msg.data.form
        let paraminfo = data
        api.requestJava('POST', '/system/userid/insert.do', paraminfo)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.init()
              this.$message({type: 'success', message: '设置成功!'})
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      updateBack (msg) {
        let data = msg.data.form
        let paraminfo = data
        api.requestJava('POST', '/system/userid/update.do', paraminfo)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.init()
              this.$message({type: 'success', message: '修改成功!'})
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
      },
      clearObject () {
        let temp = {
          title: '新增账号',
          type: 'addNo',
          dialogVisible: false,
          data: {
            form: {
              userId: '',
              idType: '',
              idNo: '',
              remark: ''
            }
          }
        }
        let tempMore = {
          title: '查询',
          type: 'query',
          dialogVisible: false,
          data: {
            form: {
              idType: '',
              idNo: ''
            }
          }
        }
        Object.assign(this.addLoginDialogObj, temp)
        Object.assign(this.moreDialogobj, tempMore)
      },
      sortChange (msg) {},
      rowClick (msg) {},
      moreBack (msg) {
        let param = msg.data.form
        api.requestJava('POST', '/system/user/selectListForFuzzy.do', param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              console.log(request.data.data)
              this.tableData = request.data.data
              this.queryData(this.currentPage, this.pageSize)
              this.clearObject()
            } else if (Number(request.data.code) === 401) {
              this.sessionFailedDialogObj.dialogVisible = true
            } else {
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            this.$store.commit('TOGGLE_LOADING')
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 多条件查询
      sessionFailedBack (msg) {
        let headers = msg.data.form
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.sessionFailedDialogObj.dialogVisible = false
            }
          })
          .catch((err) => { console.log(err) })
      }, // 会话失效
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      headerClick (column, event) {}
    },
    components: {
      _TABLE,
      _POPUP,
      _BTN_FILTER

    }
  }
</script>
