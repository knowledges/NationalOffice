<style scoped>
  .el-form-item__label{
    margin: 0px!important;
  }
  .filter_style .el-col-24 {
    height: 36px;
  }
  .el-form-item {
    margin-bottom: 12px;
  }
</style>
<template>
    <div class="container-fluid">
      <el-row class="filter_style">
        <el-col :gutter="24">
          <el-col :span='12'>
            <div v-if="isSelect">
              <el-form ref="searchForm" :model="searchForm" label-width="120px">
                <el-col :gutter="24">
                  <el-col :span='8'>
                    <el-form-item label="录入人" >
                      {{gatherer}}
                    </el-form-item>
                  </el-col>
                  <el-col :span='16'>
                    <div class="block">
                      <el-form-item label="采集日期">
                        <el-date-picker
                          v-model="searchForm.gatherDate"
                          type="date"
                          format="yyyy-MM-dd"
                          placeholder="选择日期">
                        </el-date-picker>
                      </el-form-item>
                    </div>
                  </el-col>
                </el-col>
              </el-form>
            </div>
          </el-col>
          <el-col :span="12">
            <_BTN_FILTER :isMore="isMore" :btnGroups="btnGroups" :fileName="fileName" :filterMethod="inputChange"
                         @on-click="exportEve" :tableData="tableData"/>
          </el-col>
        </el-col>
      </el-row>
      <tableVue
        ref="tableGrid"
        stripe
        maxHeight="500"
        :data="dataSource"
        @update:data="tabChange" :reqParams="reqParams"
        :columns="columns"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData>
      </tableVue>
      <_POPUP :dialogObj='sessionFailedDialogObj' @confirmBack="sessionFailedBack" />
    </div>
</template>
<script>
  import tableVue from '@/components/Template/table/Table.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import {getUser} from '@/config/info'
  import {dateFormat} from '@/utils/dateFormat.js'
  import BasePath from '@/config/BasePath'
  import api from '@/api'
  import log from '@/log'
  import axios from 'axios'
  import { convertVal } from '@/utils/common'
  export default {
    mounted () {
      let allParam = {} // 所有人员
      allParam.county_dept = getUser().companyId
      allParam.fields = {include: 'employeeName,rowId'}
      allParam.status = 1
      let countyIdParam = {} // 分公司
      countyIdParam.orgRoleTypId = '203'
      countyIdParam.fields = {include: 'orgRoleNm,orgUnitId'}
      console.log('countyIdParam:' + JSON.stringify(countyIdParam))
      axios.all([
        api.requestJava('POST', BasePath.EMPLOYEE_SELECT, allParam), // 所有人员
        api.requestJava('POST', BasePath.SELECT_FACTORYIDGROUP, countyIdParam) // 分公司
      ])
        .then(axios.spread((_all, _countyId) => {
          this.options_allParam = _all.data.data
          this.options_countyIdParam = _countyId.data.data
          console.log(JSON.stringify(this.options_countyIdParam))
        }))
      this.init()
    },
    data () {
      return {
        gatherer: '',
        isSelect: true,
        isMore: true, // 查询更多条件
        searchForm: {
          gatherDate: new Date()
        },
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['companyId', 'gatherer'],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '',
            className: 'btn-primary',
            iconName: 'fa-th',
            event: this.isMoreClk
          },
          {
            name: '查询',
            className: 'btn-success',
            iconName: 'fa-search',
            event: this.query
          },
          {
            name: '新建',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.addClk
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        selectSells: [],
        totalCount: 0, // 表格总记录数
        hasPagination: true, // 是否有分页
        columns: [ // 表格列
          { label: '分公司', prop: 'salesUnitId', columnsProps: {width: 220, formatter: this.colFormatter_salesUnitId} },
          { label: '采集人', prop: 'gatherer', columnsProps: {width: 200, formatter: this.colFormatter_gatherer} },
          { label: '采集日期', prop: 'gatherDate', columnsProps: {width: 200} },
          { label: '状态', prop: 'status', columnsProps: {width: 200, formatter: this.colFormatter_status} },
          { label: '操作', prop: 'operation', columnsProps: {type: 'button'}, cptProperties: [{ label: '编辑', value: 'modify', type: 'warning', icon: 'edit', eventClick: this.modify }, { label: '删除', value: 'del', type: 'danger', icon: 'delete', eventClick: this.del }] }
        ],
        tableData: [],
        tableType: '4',
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        sessionFailedDialogObj: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        options_allParam: [],
        options_countyIdParam: []
      }
    },
    methods: {
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      isMoreClk () {
        this.isSelect = !this.isSelect
      },
      del (index, row) {
        let params = {}
        params.rowId = row.rowId
        console.log('params.rowId' + JSON.stringify(params))
        if (Number(row.status) === 1) {
          this.$message({ type: 'info', message: '记录已经提交，不允许删除！' })
          return
        }
        this.$confirm('确定删除此条信息吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          api.requestJava('POST', BasePath.GATHER_PRICE_DELETE, params)
        .then(request => {
          if (Number(request.data.code) === 200) {
            this.$message({ type: 'success', message: '删除成功!' })
            this.init()
          } else {
            this.$notify.error({ title: '提示', message: Number(request.data.code) })
            throw new Error(JSON.stringify(request))
          }
        }).catch(() => {
          this.$message({ type: 'info', message: '删除操作异常!' })
        }
      )
        }).catch(() => {
          this.$message({ type: 'info', message: '已取消删除!' })
        })
      },
      init () {
        this.gatherer = getUser().userName
        let param = {}
        param.gatherer = getUser().personId
        param.companyId = getUser().companyId
        param.gatherDate = this.getTime(Date.parse(this.searchForm.gatherDate))
        this.reqParams.url = BasePath.GATHER_PRICE_SELECT
        this.reqParams.params = param
        api.requestJava('POST', BasePath.GATHER_PRICE_SELECT, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
              this.totalCount = +request.data.count
              this.tableData = request.data.data
              if (request.data.data.length === 0) {
                let _btnGroups = []
                let _querybtn = {}
                _querybtn.name = '查询'
                _querybtn.className = 'iconName'
                _querybtn.iconName = 'fa-search'
                _querybtn.event = this.query
                _btnGroups.push(_querybtn)
                let _addbtn = {}
                _addbtn.name = '新建'
                _addbtn.className = 'btn-info'
                _addbtn.iconName = 'fa-plus'
                _addbtn.event = this.addClk
                _btnGroups.push(_addbtn)
                this.btnGroups = _btnGroups
              } else {
                let _btnGroups = []
                let _querybtn = {}
                _querybtn.name = '查询'
                _querybtn.className = 'iconName'
                _querybtn.iconName = 'fa-search'
                _querybtn.event = this.query
                _btnGroups.push(_querybtn)
                this.btnGroups = _btnGroups
              }
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      query () {
        let param = {}
        param.gatherer = getUser().personId
        param.companyId = getUser().companyId
        param.gatherDate = this.getTime(Date.parse(this.searchForm.gatherDate))
        console.log('queryParam:' + JSON.stringify(param))
        api.requestJava('POST', BasePath.GATHER_PRICE_SELECT, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              if (Number(request.data.data.length) === 0) {
                let _btnGroups = []
                let _querybtn = {}
                _querybtn.name = '查询'
                _querybtn.className = 'iconName'
                _querybtn.iconName = 'fa-search'
                _querybtn.event = this.query
                _btnGroups.push(_querybtn)
                let _addbtn = {}
                _addbtn.name = '新建'
                _addbtn.className = 'btn-info'
                _addbtn.iconName = 'fa-plus'
                _addbtn.event = this.addClk
                _btnGroups.push(_addbtn)
                this.btnGroups = _btnGroups
              } else {
                var i = 0
                request.data.data.forEach((e) => {
                  var tempVal = ''
                  if (Number(request.data.data[i].status) === 0) {
                    tempVal = '已保存'
                  } else if (Number(request.data.data[i].status) === 1) {
                    tempVal = '已提交'
                  } else {
                    tempVal = '未保存'
                  }
                  this.tableData[i].status = tempVal
                  i++
                })
                let _btnGroups = []
                let _querybtn = {}
                _querybtn.name = '查询'
                _querybtn.className = 'iconName'
                _querybtn.event = this.query
                _btnGroups.push(_querybtn)
                this.btnGroups = _btnGroups
              }
              this.currentPage = 1
              this.queryData(this.currentPage, this.pageSize)
            }
          })
          .catch(err => {
            console.error(err)
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      queryData (page, size) {
        // 前段分页
        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      headerClick () {},
      sortChange (msg) {},
      rowClick (msg) {},
      addClk () {
        this.$message('新增')
        let temp = {}
        temp.rowId = 0
        temp.gatherDate = this.getTime(Date.parse(this.searchForm.gatherDate))
        let str = JSON.stringify(temp)
        let enCode = encodeURI(str)
        this.$router.push({name: 'RecordDetail', params: {rowId: enCode}})
      }, // 新增
      modify (index, row) {
        this.$message('修改')
        let temp = {}
        temp.rowId = row.rowId
        temp.gatherDate = this.getTime(Date.parse(this.searchForm.gatherDate))
        temp.gatherer = row.gatherer
        let str = JSON.stringify(temp)
        let enCode = encodeURI(str)
        this.$router.push({name: 'RecordDetail', params: {rowId: enCode}})
      }, // 修改
      sessionFailedBack (msg) {
        let headers = msg.data.form
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.sessionFailedDialogObj.dialogVisible = false
            }
          })
          .catch((err) => { console.log(err) })
      }, // 会话失效
      exportEve () {
        this.$refs.tableGrid.exportExcel()
      }, // 导出Elxc
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      colFormatter_status (row, column) {
        let retStr = ''
        switch (row.status) {
          case '0':
            retStr = '已保存'
            break
          case '1':
            retStr = '已提交'
            break
        }
        return retStr
      },
      colFormatter_salesUnitId (row, column) {
        return convertVal(this.options_countyIdParam, row.salesUnitId, 'orgUnitId', 'orgRoleNm')
      },
      colFormatter_gatherer (row, column) {
        return convertVal(this.options_allParam, row.gatherer, 'rowId', 'employeeName')
      }
    },
    components: {
      tableVue,
      _BTN_FILTER,
      _POPUP
    }
  }
</script>
