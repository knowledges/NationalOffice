<!-- 徐晓菁 -->
<!-- 第一个style 是因为scoped 的局限性所有不能加scoped-->
<style>
  .fa-car {
    font-size: 16px;
    color: #1e347b;
  }
  .fa-ban {
    font-size: 16px;
    color: #f1f2f3;
  }
  .fa-phone {
    font-size: 16px;
    color: green;
  }
</style>
<style scoped>
  .form-group {
    margin: 0!important;
    cursor: pointer;
  }
  .el-form-item__label_new {
    margin: 0!important;
    text-align: center;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #48576a;
    line-height: 1;
    padding: 11px 12px 11px 0;
    box-sizing: border-box;
  }
  .label {
    display: inline-block;
    max-width: 100%;
    margin-bottom: 5px;
    font-weight: 700;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-8 {
    height: 46px;
  }
  .el-col-2 {
    height: 61px;
  }
  .el-col-7 {
    height: 16px;
  }
  .el-col-15 {
    margin-top: 12px;
  }
  .build-seach, div.build-table {
    display: inline-block;
    width: 100%;
    padding: 0 25px;
  }
  .well {
    margin: 0 0;
      padding: 15px 25px!important;
    form {
      div {
        margin-bottom: 0;
      }
    }
  }
  .divider {
    background-color: white;
  }
  .dropdown-menu>li>a:hover{
    background: none!important;
  }
  .el-dialog__body {
    padding: 0 0!important;
    margin: 0 0!important;
  }
</style>
<template>
  <div class="container-fluid">
    <el-collapse-transition>
      <div v-if="isSelect" class="filter_more">
        <!--<div class="build-seach">-->
          <!--<div class="well well-lg">-->
         <el-form ref="searchForm" :model="searchForm" label-width="120px">
          <el-col :gutter="24">
            <!--<el-col :span='8'>-->
              <!--<el-form-item label="拜访情况" >-->
                <!--<el-select v-model="searchForm.visitStatus"  :clearable="true"  placeholder="请选择拜访情况">-->
                  <!--<template v-for="item in visitStatusGroup">-->
                    <!--<el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>-->
                  <!--</template>-->
                <!--</el-select>-->
              <!--</el-form-item>-->
            <!--</el-col>-->
            <el-col :span='8'>
              <el-form-item prop="batchNo" label="订货批次">
                <el-select v-model="searchForm.batchNo" multiple :clearable="true" placeholder="请选择">
                  <el-option
                    v-for="item in options_batchNo"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span='8'>
              <el-form-item label="规模">
                <el-select v-model="searchForm.operationScale" multiple :clearable="true"  placeholder="请选择规模">
                  <template v-for="item in operationScaleGroup">
                    <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                  </template>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span='8'>
              <el-form-item label="市场类型">
                <el-select v-model="searchForm.geoType" multiple :clearable="true"  placeholder="请选择市场类型">
                  <template v-for="item in geoTypeGroup">
                    <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                  </template>
                </el-select>
              </el-form-item>
            </el-col>
          </el-col>
          <el-col :gutter="24">
            <el-col :span='8'>
              <el-form-item label="客户集">
                <el-select v-model="searchForm.rtlcatId" multiple :clearable="true"   placeholder="请选择客户集">
                  <template v-for="item in rtlcatIdGroup">
                    <el-option  :key="item.rowId"  :label="item.name" :value="item.rowId"></el-option>
                  </template>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span='8'>
              <el-form-item label="业态">
                <el-select v-model="searchForm.businessType" multiple :clearable="true"   placeholder="请选择业态">
                  <template v-for="item in businessTypeGroup">
                    <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                  </template>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span='8'>
              <el-form-item label="客户档级">
                <el-select v-model="searchForm.customerGrade" multiple :clearable="true"  placeholder="请选择客户档级">
                  <template v-for="item in customerGradeGroup">
                    <el-option  :key="item.value"  :label="item.label" :value="item.value"></el-option>
                  </template>
                </el-select>
              </el-form-item>
            </el-col>
          </el-col>
           <el-col :gutter="24">
             <el-col :span='8'>
               <el-form-item label="拜访批次">
                 <el-select v-model="searchForm.visitBatch" :clearable="true" placeholder="请选择">
                   <el-option
                     v-for="item in options_visitBatch"
                     :key="item.value"
                     :label="item.label"
                     :value="item.value">
                   </el-option>
                 </el-select>
               </el-form-item>
             </el-col>
             <el-col :span='6'>
               <el-form-item  prop="starGrade" label="客户星级" >
                 <el-select v-model="searchForm.starGrade" :clearable="true" placeholder="请选择">
                   <el-option
                     v-for="item in options_starGrade"
                     :key="item.value"
                     :label="item.label"
                     :value="item.value">
                   </el-option>
                 </el-select>
               </el-form-item>
             </el-col>
           </el-col>
        </el-form>
          <!--</div>-->
        <!--</div>-->
      </div>
    </el-collapse-transition>
    <el-row class="filter_style">
      <el-col :gutter="24">
        <el-col :span="12">
          <el-col :span='4'>
            <div class="form-group">
              <div class="input-group"><label class="el-form-item__label_new" style="width: 120px;">制定计划周期</label>
              </div>
            </div>
          </el-col>
          <el-col :span='14'>
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-addon" @click="changeData(-1)"><i class="el-icon-caret-left"></i></div>
                <input type="text" class="form-control" readonly v-model="planTime" style="border: 1px solid #bfcbd9;">
                <div class="input-group-addon" @click="changeData(1)"><i class="el-icon-caret-right"></i></div>
              </div>
            </div>
          </el-col>
          <el-col :span='5'>
            <div class="form-group">
              <div class="input-group">
                <div class="btn-group">
                  <button type="button" class="btn btn-primary dropdown-toggle " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    数据分析 <span class="caret"></span>
                  </button>
                  <ul class="dropdown-menu"  style="background-color: #009a55;">
                    <li><a href="#" @click="activityClick()"><i class="fa fa-users" style="color: white;"></i><span style="color: white;">近期营销活动</span></a></li>
                    <li role="separator" class="divider" ></li>
                    <li ><a href="#" @click="feedbackClick()"><i class="fa fa-expand" style="color: white;"></i><span style="color: white;">近期反馈</span></a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="#" @click="warningClick()"><i class="fa fa-warning" style="color: white;"></i><span style="color: white;">近期预警</span></a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="#" @click="getDialogMarkerClk()"><i class="fa fa-expand" style="color: white;"></i><span style="color: white;">客户分布</span></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </el-col>
        </el-col>
        <el-col :span="12">
          <_BTN_FILTER :filterMethod="inputChange" :btnGroups="btnGroups" :fileName="fileName" @on-click="exportEve" :tableData="tableData" :isMore="isMore"/></_BTN_FILTER>
        </el-col>
      </el-col>
    </el-row>
    <div>
      <_TABLE
        ref="table"
        @update:data="tabChange"
        :reqParams="reqParams"
        stripe
        border
        maxHeight="500"
        :data="dataSource"
        :columns="columnHeader"
        :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
        :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
        @header-click="headerClick" :summary-method="summaryMethod"
        :show-summary="showSummary" ></_TABLE>
    </div>
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
    <ACTIVITY :dialogObj='activity' @confirmBack="activityEve" />
    <FEEDBACK :dialogObj='feedback' @confirmBack="feedbackEve" />
    <WARNING :dialogObj='warning' @confirmBack="warningEve" />
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve"/>
    <CUSBASE :dialogObj='cusbase'/>
    <DIALOG_PLAN_MAP ref="marker" :open="open" :coors="dataSource"/>
  </div>
</template>
<script>
  import CUSBASE from '@/components/System/Other/Map/Monitor/DetailPopup.vue'
  import _TABLE from '@/components/Template/table/Table.vue'
  import ACTIVITY from './activityPopup.vue'
  import FEEDBACK from './feedbackPopup.vue'
  import WARNING from './warningPopup.vue'
  import MY_POPUP_CONFIG from './fwxPopup.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import _BTN_FILTER from '@/components/Template/Screen/btn&filterTemp.vue'
  import DIALOG_PLAN_MAP from './DialogPlanMap.vue'
  import api from '@/api'
  import log from '@/log'
  import axios from 'axios'
  import {changeListValueByCode1, changeListValueByCode, dateFormat, weekStart, weekEnd, lastDate, nextDate, getMonthBegin, getMonthEnd, changJson} from '@/utils/common'
  import BasePath from '@/config/BasePath'
  import {getCodeList, getUser} from '@/config/info'
  export default {
    mounted () {
      this.initDate(this.getNowTime())
      let params1 = {}
      params1.defPersonId = getUser().personId
      params1.fields = {'include': 'rowId,name'}
      let starGradeParam = {} // 客户星级
      starGradeParam.companyId = getUser().companyId
      starGradeParam.typeCode = 'STAR_GRADE'
      /* starGradeParam.fields = {'include': 'value,label'} */
      let companyparams = {}
      companyparams.companyId = getUser().companyId
      axios.all([
        api.requestJava('POST', BasePath.SELECT_RTLCATIDGROUP, params1),
        api.requestJava('POST', BasePath.CUSTOMER_STARGRADE, starGradeParam), // 客户星级
        api.requestJava('POST', BasePath.CUSTOMER_BANTCHNO, companyparams) // 公司批次
      ])
      .then(axios.spread((first, _starGrade, _batchNo) => {
        this.rtlcatIdGroup = first.data.data
        this.options_starGrade = _starGrade.data.data
        this.options_batchNo = _batchNo.data.data
      }))
      getCodeList('CUSTOMER_VISIT_BATCH', (data) => {
        this.options_visitBatch = data
      }) // 拜访批次
      getCodeList('YC_BUSINESS_TYPE', (data) => {
        this.businessTypeGroup = data
      }) // 零售业态
      getCodeList('YC_GEO_TYPE', (data) => {
        this.geoTypeGroup = data
      }) // 市场类型
      getCodeList('YC_OPERATION_SCALE', (data) => {
        this.operationScaleGroup = data
      }) // 经营规模
      getCodeList('VISITING_STATUS', (data) => {
        this.visitStatusGroup = data
      }) // 拜访情况
      getCodeList('CUSTOMER_GRADE', (data) => {
        this.customerGradeGroup = data
        this.changeValueDate1.customerGrade.group = changJson(data, 'value', 'label')
      }) // 客户档级
      getCodeList('VISIT_MODE', (data) => {
        this.changeValueDate1.latestVisitMode.group = changJson(data, 'value', 'label')
      }) // 拜访方式
      this.$nextTick(() => {
        /* 修改 flex 的高 */
        this.setFiexHeigth()
      })
    },
    data () {
      return {
        edit: {
          title: '服务项目查看',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              data0: '',
              steps0: [],
              data1: '',
              steps1: [],
              data2: '',
              steps2: [],
              data3: '',
              steps3: [],
              data4: '',
              steps4: [],
              data5: '',
              steps5: [],
              data6: '',
              steps6: [],
              date7: '',
              date1: '',
              date2: '',
              date3: '',
              date4: '',
              date5: '',
              date6: ''
            }
          }
        },
        activity: {
          title: '近期营销活动查询',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {}
          }
        },
        feedback: {
          title: '近期反馈查询',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {}
          }
        },
        warning: {
          title: '近期预警查询',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {}
          }
        },
        cusbase: {
          title: '客户详情',
          type: 'addConfigure',
          dialogVisible: false,
          size: 'large',
          customerId: '',
          data: {
            form: {
              customerId: ''
            }
          }
        },
        isSelect: false,
        isMore: false, // 查询更多条件
        showSummary: true,
        iconArr: ['fa fa-ban', 'fa fa-car', 'fa fa-phone'],
        rtlcatIdGroup: [], // 客户集id
        visitStatusGroup: [], // 拜访情况
        customerGradeGroup: [], // 客户档级
        routeIdGroup: [], // 送货线路id
        visitTypeGroup: [], // 拜访方式..
        operationScaleGroup: [], // 经营规模..
        geoTypeGroup: [], // 市场类型id..
        businessTypeGroup: [], // 经营业态id..
        options_visitBatch: [], // 拜访批次
        options_starGrade: [], // 客户星级
        options_batchNo: [],
        /** 过滤的字段 **/
        filemode: 0,  // 过滤方式；0:代表本地过滤，1：服务器过滤,
        fileType: 1, // 过滤类型；0：单列数据过滤，1：整条数据过滤
        fileName: ['customerDesc', 'addr', 'customerCode', 'customerGrade'],
        hasPagination: true,
        moreS: [
          {
            colunm: 'batchNo',
            type: 'int'
          },
          {
            colunm: 'visitStatus',
            type: 'string'
          },
          {
            colunm: 'customerGrade',
            type: 'string'
          },
          {
            colunm: 'geoType',
            type: 'string'
          },
          {
            colunm: 'businessType',
            type: 'string'
          },
          {
            colunm: 'routeId',
            type: 'string'
          },
          {
            colunm: 'rtlcatId',
            type: 'string'
          },
          {
            colunm: 'operationScale',
            type: 'string'
          },
          {
            colunm: 'visitBatch',
            type: 'string'
          }
        ],
        moreA: [],
        /** 定义按钮 **/
        btnGroups: [
          {
            name: '筛选',
            className: 'btn-primary',
            iconName: 'fa-th',
            event: this.isMoreClk
          },
          {
            name: '保存',
            className: 'btn-info',
            iconName: 'fa-plus',
            event: this.save
          },
          {
            name: '查询',
            className: 'btn-primary',
            iconName: 'fa-search',
            event: this.query
          }
        ],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 500,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'customerDesc', // 列的值
            label: '客户名称', // 列的显示字段
            columnsProps: {width: 230, align: 'left', fixed: 'left'}
          }, {
            prop: 'customerGrade',
            label: '客户档次',
            columnsProps: {width: 120, align: 'center', fixed: 'left', formatter: this.getTranisform, sortable: true} // , formatter: this.changeValue1
          }, {
            prop: 'addr',
            label: '经营地址',
            columnsProps: {width: 340, align: 'left', sortable: true}
          }, {
            prop: 'planNums',
            label: '计划',
            columnsProps: {width: 90, align: 'center', sortable: true}
          }, {
            prop: 'visitNums',
            label: '已拜访',
            columnsProps: {width: 130, align: 'center', sortable: true}
          }, {
            prop: 'date7',
            label: '日',
            columnsProps: {width: 70, type: 'icon', align: 'center'},
            options: ['fa fa-ban', 'fa fa-car', 'fa fa-phone'],
            eventClick: this.changeIcon
          }, {
            prop: 'date1',
            label: '一',
            columnsProps: {width: 70, type: 'icon', align: 'center'},
            options: ['fa fa-ban', 'fa fa-car', 'fa fa-phone'],
            eventClick: this.changeIcon
          }, {
            prop: 'date2',
            label: '二',
            columnsProps: {width: 55, type: 'icon', align: 'center'},
            options: ['fa fa-ban', 'fa fa-car', 'fa fa-phone'],
            eventClick: this.changeIcon
          }, {
            prop: 'date3',
            label: '三',
            columnsProps: {width: 55, type: 'icon', align: 'center'},
            options: ['fa fa-ban', 'fa fa-car', 'fa fa-phone'],
            eventClick: this.changeIcon
          }, {
            prop: 'date4',
            label: '四',
            columnsProps: {width: 55, type: 'icon', align: 'center'},
            options: ['fa fa-ban', 'fa fa-car', 'fa fa-phone'],
            eventClick: this.changeIcon
          }, {
            prop: 'date5',
            label: '五',
            columnsProps: {width: 55, type: 'icon', align: 'center'},
            options: ['fa fa-ban', 'fa fa-car', 'fa fa-phone'],
            eventClick: this.changeIcon
          }, {
            prop: 'date6',
            label: '六',
            columnsProps: {width: 55, type: 'icon', align: 'center'},
            options: ['fa fa-ban', 'fa fa-car', 'fa fa-phone'],
            eventClick: this.changeIcon
          }, {
            prop: 'customerCode',
            label: '客户代码',
            columnsProps: {width: 150, align: 'center'}
          }, {
            prop: 'reserveTag2',
            label: '是否采集点',
            columnsProps: {width: 120, align: 'center', formatter: this.changeValue1}
          }, {
            prop: 'latestVisitTime',
            label: '最近拜访时间',
            columnsProps: {width: 140, align: 'center', formatter: this.changeValue}
          }, {
            prop: 'latestVisitMode',
            label: '方式',
            columnsProps: {width: 100, align: 'center', formatter: this.changeValue1}
          }, {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 240, type: 'button'},
            cptProperties: [
              {
                label: '客户详情',
                value: 'query',
                icon: 'search',
                size: 'small',
                type: 'primary',
                eventClick: this.detailRow
              },
              {
                label: '服务项目',
                value: 'query',
                icon: 'search',
                size: 'small',
                type: 'primary',
                eventClick: this.modifyfwx
              }
            ]
          }
        ],
        changeValueDate: {
          latestVisitTime: {
            type: 'date1'
          }
        },
        changeValueDate1: {
          customerGrade: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          latestVisitMode: {
            type: 'text',
            group: [],
            key: 'value',
            value: 'label'
          },
          reserveTag2: {
            type: 'text',
            group: {1: '是'},
            key: 'value',
            value: 'label'
          }
        },
        tableData: [],
        timeDate: {
          rowId: '201711',
          periodName: '',
          startDate: '2017-11-05',
          endDate: '2017-11-11',
          startMonthDate: '2017-11-01',
          endMonthDate: '2017-30',
          upDate: '2017-11-04',
          nextDate: '2017-11-12'
        },
        weekTime: {
          date7: 0,
          date1: 1,
          date2: 2,
          date3: 3,
          date4: 4,
          date5: 5,
          date6: 6
        },
        btns: {},
        tableType: '1',
        planTime: '',
        totalNum1: '',
        totalNum2: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        /** searchForm **/
        searchForm: {
          custmgrId: '',
          planBegin: '',
          planEnd: '',
          planMonthBegin: '',
          planMonthEnd: '',
          visitStatus: '',
          customerGrade: '',
          geoType: '',
          visitBatch: '',
          businessType: '',
          routeId: '',
          rtlcatId: '',
          operationScale: '',
          status: '1',
          batchNo: '',
          starGrade: ''
        },
        totalForm: {
          custmgrId: '',
          visitCusts: '',
          visitCoverage: '',
          allCusts: ''
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        },
        /** 实际操作 **/
        sel_id: '', // 当前选中的值id
        sel_all: [],
        sel_all_row: [],
        sums: [],
        weekTimeH: {
          date7: 0,
          date1: 0,
          date2: 0,
          date3: 0,
          date4: 0,
          date5: 0,
          date6: 0
        },
        open: false
      }
    },
    methods: {
      getTranisform (row, column) {
        return this.$set(row, 'customerGrade', Number(row.customerGrade))
//        console.log('转换 transformation =>', row, column)
      },
      changeValue1 (row, column) {
        return changeListValueByCode1(this.changeValueDate1, row, column)
      },  // 转换list中的code
      editEve (msg) {
        this.edit.dialogVisible = false
        let tmp = {
          title: '服务项目查看',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              data0: '',
              steps0: [],
              data1: '',
              steps1: [],
              data2: '',
              steps2: [],
              data3: '',
              steps3: [],
              data4: '',
              steps4: [],
              data5: '',
              steps5: [],
              data6: '',
              steps6: [],
              date7: '',
              date1: '',
              date2: '',
              date3: '',
              date4: '',
              date5: '',
              date6: ''
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      modifyfwx (index, row) {
        this.edit.title = row.customerDesc + '(' + this.timeDate.startDate + '至' + this.timeDate.startDate + ')' + '拜访计划服务项'
        this.edit.data.form.data0 = this.timeDate.startDate
        this.edit.data.form.data1 = nextDate(this.edit.data.form.data0, 'YYYY-MM-DD')
        this.edit.data.form.data2 = nextDate(this.edit.data.form.data1, 'YYYY-MM-DD')
        this.edit.data.form.data3 = nextDate(this.edit.data.form.data2, 'YYYY-MM-DD')
        this.edit.data.form.data4 = nextDate(this.edit.data.form.data3, 'YYYY-MM-DD')
        this.edit.data.form.data5 = nextDate(this.edit.data.form.data4, 'YYYY-MM-DD')
        this.edit.data.form.data6 = nextDate(this.edit.data.form.data5, 'YYYY-MM-DD')
        this.edit.data.form.date7 = row.date7
        this.edit.data.form.date1 = row.date1
        this.edit.data.form.date2 = row.date2
        this.edit.data.form.date3 = row.date3
        this.edit.data.form.date4 = row.date4
        this.edit.data.form.date5 = row.date5
        this.edit.data.form.date6 = row.date6
        this.modifyfwxUpper(this.edit.data.form.data0, 'steps0', 0, row.rowId)
        this.modifyfwxUpper(this.edit.data.form.data1, 'steps1', 1, row.rowId)
        this.modifyfwxUpper(this.edit.data.form.data2, 'steps2', 2, row.rowId)
        this.modifyfwxUpper(this.edit.data.form.data3, 'steps3', 3, row.rowId)
        this.modifyfwxUpper(this.edit.data.form.data4, 'steps4', 4, row.rowId)
        this.modifyfwxUpper(this.edit.data.form.data5, 'steps5', 5, row.rowId)
        this.modifyfwxUpper(this.edit.data.form.data6, 'steps6', 6, row.rowId)
      }, // 修改
      modifyfwxUpper (time, step, i, rowid) {
        let param = {}
        param.userId = getUser().personId
        param.userPlaceId = getUser().place
        param.userPlaceCode = getUser().place
        param.customerId = rowid
        param.currentDate = time
        param.unitId = getUser().companyId
        param.deptId = getUser().deptId
        param.countyDept = getUser().countyId
//        console.log('param', JSON.stringify(param))
        api.requestJava('POST', BasePath.VISITPLAN_PASS_STEPSSELECT, param)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              let kh = []
              let pp = []
              let xf = []
              for (let i = 0; i < request.data.data.length; i++) {
                let rowS = {}
                if (request.data.data[i].cat === 'kh') {
                  rowS.id = request.data.data[i].formId
                  rowS.label = request.data.data[i].title
                  kh.push(rowS)
                } else if (request.data.data[i].cat === 'pp') {
                  rowS.id = request.data.data[i].formId
                  rowS.label = request.data.data[i].title
                  pp.push(rowS)
                } else {
                  rowS.id = request.data.data[i].formId
                  rowS.label = request.data.data[i].title
                  xf.push(rowS)
                }
              }
              let treeData = []
              let step1 = {}
              step1.id = 'xh'
              step1.label = '客户'
              step1.children = kh
              let step2 = {}
              step2.id = 'pp'
              step2.label = '品牌'
              step2.children = pp
              let step3 = {}
              step3.id = 'xf'
              step3.label = '消费'
              step3.children = xf
              treeData.push(step1)
              treeData.push(step2)
              treeData.push(step3)
//              console.log('step', step)
//              console.log('treeData', treeData)
              this.edit.data.form[step] = treeData
              if (i === 6) {
                this.edit.dialogVisible = true
              }
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      detailRow (index, row) {
        let param = {}
        param.rowId = row.rowId
        param.haveAttach = '1'
        api.requestJava('POST', BasePath.CUSTOMER_SELECTONE, param)
          .then(request => {
            if (Number(request.data.code) === 200) {
//              this.cusbase.data.form = request.data.data
              this.cusbase.customerId = JSON.stringify(request.data.data)
              this.cusbase.dialogVisible = true
            } else {
              this.$notify.error({ title: '提示', message: request.message })
              throw new Error(JSON.stringify(request))
            }
          })
          .catch(err => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      },
      activityEve (msg) {
        this.activity.dialogVisible = false
      },
      feedbackEve (msg) {
        this.feedback.dialogVisible = false
      },
      warningEve (msg) {
        this.warning.dialogVisible = false
      },
      activityClick () {
        this.activity.dialogVisible = true
      },
      feedbackClick () {
        this.feedback.dialogVisible = true
      },
      warningClick () {
        this.warning.dialogVisible = true
      },
      getDialogMarkerClk () {
        this.open = true
        this.$refs.marker.findAll()
      },
      changeValue (row, column) {
        return changeListValueByCode(this.changeValueDate, row, column)
      },  // 转换list中的code
      isMoreClk () {
        this.isSelect = !this.isSelect
      },
      headerClick (column, event) { // 周期列--点击事件
        let columnValue = column.property
        if (['date1', 'date2', 'date3', 'date4', 'date5', 'date6', 'date7'].indexOf(columnValue) !== -1) {
          if (this.getNowTime() >= this.timeDate.startDate) {
            if (this.timeDate.endDate < this.getNowTime()) {
              return
            }
            if (this.weekTime[columnValue] < new Date().getDay()) {
              return
            }
          }
          let num = this.weekTimeH[columnValue]
          let length = this.iconArr.length
          let idx = Number(num) + 1
          if (idx === length) {
            idx = 0
          }
          /* weekTimeH 记录三总状态【0：default，1.现场拜访，2.电话拜访】 */
          this.weekTimeH[columnValue] = idx
          for (let i = 0; i < this.dataSource.length; i++) {
            let row = this.dataSource[i]
            // 改变周期列所有的图标的样式
            this.changeIconAll(row, this.iconArr, columnValue, idx)
          }
        }
      },
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      toMoreChange (values, type) {
        let result = ''
        for (let i = 0; i < values.length; i++) {
          if (type === 'int') {
            result = result + values[i] + ','
          } else if (type === 'string') {
            result = result + "'" + values[i] + "'" + ','
          }
        }
        if (result.length > 0) {
          result = result.substr(0, result.length - 1)
        }
        // alert(result)
        return result
      },
      summaryMethod (param) {
        const { columns, data } = param
        columns.forEach((column, index) => {
          if (index === 0) {
            this.sums[index] = this.totalNum1
            return
          }
          if (index === 2) {
            this.sums[index] = this.totalNum2
            return
          }
          if (index === 4) {
            this.sums[index] = '周计划数(户):'
            return
          }
          const values = data.map(item => Number(item[column.property]))
          if (['date1', 'date2', 'date3', 'date4', 'date5', 'date6', 'date7'].indexOf(column.property) !== -1) {
            this.sums[index] = values.reduce((prev, curr) => {
              const value = Number(curr)
              if (value === 1 || value === 2) {
                return prev + 1
              } else {
                return prev
              }
            }, 0)
            this.columnHeader[index].num = this.sums[index]
          } else {
            this.sums[index] = ''
          }
        })
        return this.sums
      },
      /**
       * 改变周期列所有的图标的样式
       * @param item 当前table行的数据
       * @param iconArr 修改图标名[电话、家、汽车]
       * @param columnValue 周期列的名称 【data1、data2、data3、data4、data5、data6、data7】
       * @param idx
       */
      changeIconAll (item, iconArr, columnValue, idx) { // 改变周期列所有的图标的样式
        if (this.weekTime[columnValue] === new Date().getDay()) {
          var lastTime = 'latestVisitTime'
          if (this.getNowTime() === item[lastTime]) {
            if (item[columnValue] !== '0') {
              return
            }
          }
        }
        item[columnValue] = idx
      },
      changeIcon (row, col) { // 周期列-单行点击事件
        if (this.getNowTime() >= this.timeDate.startDate) {
          if (this.timeDate.endDate < this.getNowTime()) {
            return
          }
          if (this.weekTime[col] < new Date().getDay()) {
            return
          } else if (this.weekTime[col] === new Date().getDay()) {
            var lastTime = 'latestVisitTime'
            if (this.getNowTime() === row[lastTime]) {
              if (row[col] !== '0') {
                return
              }
            }
          }
        }
        // 改变 data1~7 里的状态【0：default，1：现场拜访，2：电话拜访】
        let length = this.iconArr.length
        let idx = 0
        if (row[col] !== '') {
          idx = Number(row[col]) + 1
        }
        if (idx === length) {
          row[col] = 0
        } else {
          row[col] = idx
        }
      },
      query () {
        let params = {}
        for (let i = 0; i < this.moreS.length; i++) {
          params[this.moreS[i].colunm] = this.toMoreChange(this.searchForm[this.moreS[i].colunm], this.moreS[i].type)
        }
        params.starGrade = this.searchForm.starGrade
        params.custmgrId = this.searchForm.custmgrId
        params.planBegin = this.searchForm.planBegin
        params.planEnd = this.searchForm.planEnd
        params.planMonthBegin = this.searchForm.planMonthBegin
        params.planMonthEnd = this.searchForm.planMonthEnd
        params.pageNum = this.currentPage
        params.pageSize = this.pageSize
        if (this.searchForm.visitStatus !== '') {
          params.visitStatus = Number(this.searchForm.visitStatus)
        }
        if (params.rtlcatId.length > 0) {
          params.sorter = 'ORDERS'
        }
        console.log(JSON.stringify(params))
        this.queryUpper(params)
      },
      queryUpper (params) {
        /* 将已有的参数赋值给分页参数 */
        this.$set(this.reqParams, 'url', BasePath.VISITPLAN_SELECT)
        this.$set(this.reqParams, 'params', params)
        api.requestJava('POST', BasePath.VISITPLAN_SELECT, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.tableData = request.data.data
              this.tableData.forEach((item, key) => {
                this.$set(item, 'init1', item.date1)
                this.$set(item, 'init2', item.date2)
                this.$set(item, 'init3', item.date3)
                this.$set(item, 'init4', item.date4)
                this.$set(item, 'init5', item.date5)
                this.$set(item, 'init6', item.date6)
                this.$set(item, 'init7', item.date7)
              })
              this.currentPage = 1
              this.totalCount = request.data.data.length
              this.queryData(this.currentPage, this.pageSize)
              console.log(this.tableData[2])
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      queryTotalUpper () {
        let params = {}
        params.custmgrId = getUser().personId
        params.planMonthBegin = this.searchForm.planMonthBegin
        params.planMonthEnd = this.searchForm.planMonthEnd
        api.requestJava('POST', BasePath.VISITPLAN_TOTAL, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
//              this.totalCount = Number(request.data.data.allCusts)
              var all = Number(request.data.data.allCusts)
              var visit = Number(request.data.data.visitCusts)
              if (all === 0) {
                this.totalNum1 = '有效客户数: ' + all
                this.totalNum2 = '当前月度拜访户数:' + visit + ' 拜访覆盖率: 0.00%'
              } else {
                this.totalNum1 = '有效客户数: ' + all
                this.totalNum2 = '当前月度拜访户数:' + visit + ' 拜访覆盖率:' + (Number(request.data.data.visitCusts) * 100 / Number(request.data.data.allCusts)).toFixed(2) + '%'
              }
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            log.work(err, culprit)
          })
      }, // 查询接口
      changeData (num) {
        if (Number(num) === 1) {
          this.initDate(this.timeDate.nextDate)
        } else {
          this.initDate(this.timeDate.upDate)
        }
      },
      initDate (time) {
        // weekStart, weekEnd, lastDate, nextDate, getMonthBegin, getMonthEnd
        this.timeDate.startDate = weekStart(time, 'YYYY-MM-DD')
        this.timeDate.endDate = weekEnd(time, 'YYYY-MM-DD')
        this.timeDate.startMonthDate = getMonthBegin(time, 'YYYY-MM-DD')
        this.timeDate.endMonthDate = getMonthEnd(time, 'YYYY-MM-DD')
        this.timeDate.upDate = lastDate(this.timeDate.startDate, 'YYYY-MM-DD')
        this.timeDate.nextDate = nextDate(this.timeDate.endDate, 'YYYY-MM-DD')
        this.planTime = this.timeDate.startDate + '/' + this.timeDate.endDate
        this.searchForm.custmgrId = getUser().personId
        this.searchForm.planBegin = this.timeDate.startDate
        this.searchForm.planEnd = this.timeDate.endDate
        this.searchForm.planMonthBegin = this.timeDate.startMonthDate
        this.searchForm.planMonthEnd = this.timeDate.endMonthDate
        this.query()
        this.queryTotalUpper()
      }, // 查询接口
      save () {
        if (this.timeDate.endDate < this.getNowTime()) {
          this.$message({type: 'info', message: '只能修改本周和本周以后的计划!'})
          return
        }
        this.$confirm('确定保存拜访计划吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.saveUpper()
        }).catch(() => {
          this.$message({type: 'info', message: '已取消保存操作!'})
        })
      },
      saveUpper () {
        this.$store.dispatch('setLoading', JSON.stringify({'status': true, 'msg': '正在保存请耐心等待...'}))
        let params = []
        this.dataSource.forEach((item, key) => {
          /* 将过滤修改过过状态的 */
          if (Number(item.status1) === 4 && item.init1 !== item.date1 ||
            Number(item.status2) === 4 && item.init2 !== item.date2 ||
            Number(item.status3) === 4 && item.init3 !== item.date3 ||
            Number(item.status4) === 4 && item.init4 !== item.date4 ||
            Number(item.status5) === 4 && item.init5 !== item.date5 ||
            Number(item.status6) === 4 && item.init6 !== item.date6 ||
            Number(item.status7) === 4 && item.init7 !== item.date7) {
            let rowS = {}
            rowS.customerId = item.rowId
            rowS.companyId = getUser().companyId
            rowS.visitor = getUser().personId
            rowS.visitorName = getUser().userName
            rowS.customerName = item.customerDesc
            rowS.partyName = item.legalPerson
            rowS.customerCode = item.customerCode
            rowS.planBegin = this.timeDate.startDate
            rowS.planEnd = this.timeDate.endDate
            //  状态: 0 未拜访、1 拜访中、2拜访完成、3异常 4未审核 5巡店 9 作废
            debugger
            if (item.init1 !== item.date1) {
              rowS.date1 = item.date1
              rowS.status1 = item.status1
            }
            if (item.init2 !== item.date2) {
              rowS.date2 = item.date2
              rowS.status2 = item.status2
            }
            if (item.init3 !== item.date3) {
              rowS.date3 = item.date3
              rowS.status3 = item.status3
            }
            if (item.init4 !== item.date4) {
              rowS.date4 = item.date4
              rowS.status4 = item.status4
            }
            if (item.init5 !== item.date5) {
              rowS.date5 = item.date5
              rowS.status5 = item.status5
            }
            if (item.init6 !== item.date6) {
              rowS.date6 = item.date6
              rowS.status6 = item.status6
            }
            if (item.init7 !== item.date7) {
              rowS.date7 = item.date7
              rowS.status7 = item.status7
            }
            rowS.onSchedule = 'Y'
//          rowS.status = '4'
            params.push(rowS)
          }
        })
        if (params.length > 0) {
          api.requestJava('POST', BasePath.VISITPLAN_SAVE, params)
            .then((request) => {
              this.$store.dispatch('setLoading', JSON.stringify({'status': false, 'msg': '保存成功...'}))
              if (Number(request.data.code) === 200) {
                this.$notify({title: '成功', message: '保存成功', type: 'success'})
                this.query()
              } else if (Number(request.data.code) === 401) {
                this.$message('登录失效')
                this.logInvalid.dialogVisible = true
              } else {
                this.$notify.error({ title: '提示', message: request.data.message })
                throw new Error(JSON.stringify(request))
              }
            })
            .catch((err) => {
              let culprit = this.$route.name
              log.work(err, culprit)
            })
        } else {
          this.$store.dispatch('setLoading', JSON.stringify({'status': false, 'msg': '保存成功...'}))
          this.$notify({title: '成功', message: '保存成功', type: 'success'})
        }
      }, // 保存
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      dateFormatter (row, column) {
        var unixDate = row[column.property]
        return dateFormat(unixDate, 'YYYY-MM-DD')
      },  // 时间格式化
      getNowTime () {
        return dateFormat(new Date().getTime(), 'YYYY-MM-DD')
      },  // 时间格式化
      exportEve () {
        this.$refs.table.exportExcel()
      }, // 导出Elxc
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
        this.setFiexHeigth()
      }, // 分页请求
      setFiexHeigth () {
        let form1 = document.getElementsByClassName('el-table')
        let fixed = document.getElementsByClassName('el-table__fixed')
        if (Number(fixed.length) === 1) {
          setTimeout(() => {
            fixed[0].style.height = (parseInt(form1[0].style.height) - parseInt('1px')) + 'px'
          })
        } else {
          console.log('存在多个固定列，注意检查')
        }
      } // 给flex 列 修改 高度
    },
    components: {
      _TABLE,
      _POPUP,
      _BTN_FILTER,
      ACTIVITY,
      FEEDBACK,
      WARNING,
      CUSBASE,
      MY_POPUP_CONFIG,
      DIALOG_PLAN_MAP
    }
  }
</script>


