<!-- 徐晓菁 -->
<template>
  <el-dialog :title="dialogObj.title" :visible.sync="dialogObj.dialogVisible" :close-on-click-modal="false">
    <el-form :model="dialogObj.data.form" label-width="80px" :rules="addrules" ref="update">
      <el-row>
        <el-col :gutter="24">
          <el-col :span='12'>
            <el-form-item label="卷烟代码">
              <el-input  v-model="dialogObj.data.form.goodsCode" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='12' >
            <el-form-item label="卷烟名称">
              <el-input  v-model="dialogObj.data.form.goodsDesc" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
      <el-row>
        <el-col :gutter="24">
          <el-col :span='12' >
            <el-form-item label="市场定位">
              <el-input  v-model="dialogObj.data.form.marketPosition"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='12' >
            <el-form-item label="消费对象">
              <el-input  v-model="dialogObj.data.form.targetobject"></el-input>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
      <el-row>
        <el-col :gutter="24">
          <el-col :span='12'>
            <el-form-item prop="nmprice" label="市场价格">
              <el-input v-model="dialogObj.data.form.nmprice"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span='12' >
            <el-form-item label="生命周期">
              <el-select v-model="dialogObj.data.form.cigLifecycle" :clearable="true" placeholder="请选择" >
                <el-option
                  v-for="item in lifeCycle"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
      <el-row>
        <el-col :gutter="24">
          <el-col :span='24'>
            <el-form-item label="简介">
              <el-input  v-model="dialogObj.data.form.synopsis"></el-input>
            </el-form-item>
          </el-col>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer" style="text-align: right">
      <el-button @click="cancleClk('addForm')">取 消</el-button>
      <el-button type="success" @click="updateClk('update')">更 新</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {getCodeList} from '@/config/info'
  export default {
    props: ['dialogObj'],
    mounted () {
      getCodeList('LIFECYCLE', (data) => {
        this.lifeCycle = data
        console.log(JSON.stringify(this.lifeCycle))
      }) // 生命周期
    },
    data () {
      var checkNumber = (rule, value, callback) => {
        let reg = /^([1-9]\d*|0)(\.\d{1,2})?$/
        if (!value) {
          callback(new Error('价格不能为空'))
        } else if (!reg.test(value)) {
          callback(new Error('请输入数字值|或保留两位小数'))
        } else {
          callback()
        }
      }
      return {
        lifeCycle: [],
        value: '',
        form: {},
        addrules: {
          nmprice: [
            {required: true, validator: checkNumber, trigger: 'blur'}
          ]
        }
      }
    },
    methods: {
      cancleClk () {
        this.$emit('confirmBack', 'cancle')
      },
      updateClk (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dialogObj.dialogVisible = false
            this.$emit('confirmBack', this.dialogObj)
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      clearClk (formName) {
        let selectTmp = {
          title: '查询条件选择',
          type: 'selectCommodityManagement',
          dialogVisible: false,
          size: 'small',
          data: {
            form: {
              goodsCode: '',
              goodsDesc: '',
              marketPosition: '',
              targetobject: '',
              nmprice: 0,
              cigLifecycle: '',
              synopsis: '',
              lifeCycle: []
            }
          }
        }
        Object.assign(this.dialogObj, selectTmp)
        this.dialogObj.dialogVisible = true
      }
    }
  }
</script>

