<!-- 徐晓菁 -->
<template>
  <div class="container-fluid">
     <div>
       <_TABLE
         ref="table"
         @update:data="tabChange"
         :reqParams="reqParams"
         stripe
         maxHeight="500"
         :data="dataSource"
         :columns="columnHeader"
         :pageSizes="pageSizes" :currentPage="currentPage" :pageSize="pageSize"
         :totalCount="totalCount" :hasPagination="hasPagination" :setPage=this.queryData
         @selection-change="selectionChange"></_TABLE>
    </div>
    <MY_POPUP_CONFIG :dialogObj='edit' @confirmBack="editEve" />
    <_POPUP :dialogObj='logInvalid' @confirmBack="logEve" />
  </div>
</template>
<script>
  import _TABLE from '@/components/Template/table/Table.vue'
  import _POPUP from '@/components/Template/Popup/Popup.vue'
  import MY_POPUP_CONFIG from './Popup.vue'
  import log from '@/log'
  import api from '@/api'
  import BasePath from '@/config/BasePath'
  import {getUser} from '@/config/info'
  export default {
    mounted () {
//      this.queryData(this.currentPage, this.pageSize)
      this.query()
    },
    data () {
      return {
        isSelect: true,
        isMore: true, // 查询更多条件
        /** 过滤的字段 **/
        fileName: ['matterName', 'makerNm', 'title'],
        /** 定义按钮 **/
        btnGroups: [],
        /** table **/
        currentPage: 1, // 默认当前第一页
        pageSize: 100,  // 默认每页20条数据
        pageSizes: [100, 200, 500], // 分页数选择项
        reqParams: {
          url: '',
          params: {}
        },
        totalCount: 0, // 表格总记录数
        columnHeader: [
          {
            prop: 'name', // 列的值
            label: '预警项', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'descText', // 列的值
            label: '描述', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            prop: 'count', // 列的值
            label: '预警数', // 列的显示字段
            columnsProps: {align: 'left'}
          },
          {
            label: '操作',
            prop: 'operation',
            columnsProps: {width: 120, type: 'button'},
            cptProperties: [
              {
                label: '查看',
                value: 'query',
                icon: 'search',
                size: 'small',
                type: 'primary',
                eventClick: this.modify
              }
            ]
          }
        ],
        hasPagination: true,
        tableData: [
          {
            rowId: '1',
            name: '重复IP订货客户'
          },
          {
            rowId: '2',
            name: '连续3个月未订货'
          }
        ],
        planTime: '',
        dataSource: [], // 当前页的数据
        /** filter **/
        templTableData: [], // 临时记录tableDate的值
        /** searchForm **/
        edit: {
          title: '预警明细查看',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              rowId: '',
              cat: '',
              name: '',
              descText: '',
              priority: '',
              checkFlag: '',
              receiverType: '',
              exeMode: '',
              interface: '',
              templateId: '',
              status: ''
            }
          }
        },
        logInvalid: {
          title: '会话失效',
          type: 'sessionFailured',
          dialogVisible: false,
          size: 'tiny',
          data: {
            form: {
              userCode: '',
              password: ''
            }
          }
        }
      }
    },
    methods: {
      query () {
        this.queryUpper({})
      }, // 查询方法
      queryUpper (params) {
        params.companyId = getUser().companyId
        params.empId = getUser().personId
        params.status = 1
//        params.fields = {'include': 'rowId,name,cat,descText,priority,checkFlag,count'}
        /* 将已有的参数赋值给分页参数 */
        this.$set(this.reqParams, 'url', BasePath.WARNINGINFO_RULE)
        this.$set(this.reqParams, 'params', params)
        api.requestJava('POST', BasePath.WARNINGINFO_RULE, params)
          .then((request) => {
            if (Number(request.data.code) === 200) {
              this.dataSource = request.data.data
              this.tableData = request.data.data
              this.totalCount = Number(request.data.count)
            } else if (Number(request.data.code) === 401) {
              this.$message('登录失效')
              this.logInvalid.dialogVisible = true
            } else {
              this.$notify.error({title: '提示', message: request.data.message})
              throw new Error(JSON.stringify(request))
            }
          })
          .catch((err) => {
            let culprit = this.$route.name
            // this.toggleLoading()
            log.work(err, culprit)
          })
      }, // 查询接口
      modify (index, row) {
        this.edit.title = row.name + '预警明细'
        Object.assign(this.edit.data.form, row)
        this.edit.dialogVisible = true
      }, // 修改// 修改
      editEve (msg) {
        this.edit.dialogVisible = false
        let tmp = {
          title: '预警明细查看',
          type: '3',
          dialogVisible: false,
          size: 'large',
          data: {
            form: {
              rowId: '',
              cat: '',
              name: '',
              descText: '',
              priority: '',
              checkFlag: '',
              receiverType: '',
              exeMode: '',
              interface: '',
              templateId: '',
              status: ''
            }
          }
        }
        Object.assign(this.edit, tmp)
      }, // 修改事件
      inputChange (val) {
        /** 搜索功能回调 **/
        let page = 1
        let size = this.pageSize
        this.dataSource = val.filter((u, index) => index < size * page && index >= size * (page - 1))
      },
      exportEve () {
        this.$refs.table.exportExcel()
      }, // 导出Elxc
      tabChange (msg) {
        let tmp = JSON.parse(msg)
        this.currentPage = tmp.currentPage
        this.dataSource = this.tableData = tmp.arr
      }, // 表格数据便跟后
      queryData (page, size) {
        // 前段分页
//        this.totalCount = this.tableData.length
        this.dataSource = this.tableData.filter((u, index) => index < size * page && index >= size * (page - 1))
      }, // 分页请求
      onendChange (val) {}, // 过滤器修改事件
      logEve (msg) {
        let headers = {}
        headers.userCode = msg.data.form.userCode
        headers.password = msg.data.form.password
        let array = [headers, this]
        this.$store.dispatch('login', array)
          .then((msg) => {
            if (msg === 'success') {
              this.logInvalid.dialogVisible = false
              this.$router.go(0)  //  刷新父页面
            }
          })
          .catch((err) => { console.log(err) })
      }, //  session 失效
      dateFormatter (row, column) {
        var unixDate = row[column.property]
        return dateFormat(unixDate, 'YYYY-MM-DD')
      },  // 时间格式化
      getTime (data) {
        return dateFormat(data, 'YYYY-MM-DD')
      },  // 时间格式化
      select (selection, index) {}, // 选中某1条
      selectAll (data) {}, // 全选
      headerClick (column, event) {},
      addClk () {
        var myDate = new Date()
        this.edit.data.form.beginDate = this.getTime(myDate.getTime())
        this.edit.data.form.endDate = this.getTime(myDate.getTime())
        this.edit.data.form.matterIdGroup = this.matterIdGroup
        this.edit.dialogVisible = true
      },
      sortChange (msg) {},
      rowClick (msg) {},
      selectionChange (rows) {}
    },
    components: {
      _TABLE,
      _POPUP,
      MY_POPUP_CONFIG
    }
  }
</script>

<style scoped>
  .form-group{
    margin-top: 7px;
    cursor: pointer;
  }
  .el-form-item__label_new {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 16px;
    color: #48576a;
    line-height: 1;
    padding: 11px 40px 11px 0;
    box-sizing: border-box;
  }
  .el-collapse-item__header {
    height: 30px;
    line-height: 30px;
    padding-left: 15px;
    background-color: rgba(255, 255, 255, 0);
    color: #48576a;
    cursor: pointer;
    border-bottom: 1px solid #dfe6ec;
    font-size: 13px;
  }
  .el-collapse-item__wrap {
    will-change: height;
    background-color: rgba(251, 253, 255, 0);
    overflow: hidden;
    box-sizing: border-box;
    border-bottom: 1px solid #dfe6ec;
  }
  .el-col-24 {
    height: 36px;
  }

</style>
